//#region ../../node_modules/gsap/gsap-core.js
function _assertThisInitialized(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _inheritsLoose(subClass, superClass) {
	subClass.prototype = Object.create(superClass.prototype);
	subClass.prototype.constructor = subClass;
	subClass.__proto__ = superClass;
}
/*!
* GSAP 3.15.0
* https://gsap.com
*
* @license Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var _config = {
	autoSleep: 120,
	force3D: "auto",
	nullTargetWarn: 1,
	units: { lineHeight: "" }
};
var _defaults = {
	duration: .5,
	overwrite: false,
	delay: 0
};
var _suppressOverwrites;
var _reverting$1;
var _context;
var _bigNum$1 = 1e8;
var _tinyNum = 1 / _bigNum$1;
var _2PI = Math.PI * 2;
var _HALF_PI = _2PI / 4;
var _gsID = 0;
var _sqrt = Math.sqrt;
var _cos = Math.cos;
var _sin = Math.sin;
var _isString = function _isString(value) {
	return typeof value === "string";
};
var _isFunction = function _isFunction(value) {
	return typeof value === "function";
};
var _isNumber = function _isNumber(value) {
	return typeof value === "number";
};
var _isUndefined = function _isUndefined(value) {
	return typeof value === "undefined";
};
var _isObject = function _isObject(value) {
	return typeof value === "object";
};
var _isNotFalse = function _isNotFalse(value) {
	return value !== false;
};
var _windowExists$1 = function _windowExists() {
	return typeof window !== "undefined";
};
var _isFuncOrString = function _isFuncOrString(value) {
	return _isFunction(value) || _isString(value);
};
var _isTypedArray = typeof ArrayBuffer === "function" && ArrayBuffer.isView || function() {};
var _isArray = Array.isArray;
var _randomExp = /random\([^)]+\)/g;
var _commaDelimExp = /,\s*/g;
var _strictNumExp = /(?:-?\.?\d|\.)+/gi;
var _numExp = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g;
var _numWithUnitExp = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g;
var _complexStringNumExp = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi;
var _relExp = /[+-]=-?[.\d]+/;
var _delimitedValueExp = /[^,'"\[\]\s]+/gi;
var _unitExp = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i;
var _globalTimeline;
var _win$1;
var _coreInitted;
var _doc$1;
var _globals = {};
var _installScope = {};
var _coreReady;
var _install = function _install(scope) {
	return (_installScope = _merge(scope, _globals)) && gsap;
};
var _missingPlugin = function _missingPlugin(property, value) {
	return console.warn("Invalid property", property, "set to", value, "Missing plugin? gsap.registerPlugin()");
};
var _warn = function _warn(message, suppress) {
	return !suppress && console.warn(message);
};
var _addGlobal = function _addGlobal(name, obj) {
	return name && (_globals[name] = obj) && _installScope && (_installScope[name] = obj) || _globals;
};
var _emptyFunc = function _emptyFunc() {
	return 0;
};
var _startAtRevertConfig = {
	suppressEvents: true,
	isStart: true,
	kill: false
};
var _revertConfigNoKill = {
	suppressEvents: true,
	kill: false
};
var _revertConfig = { suppressEvents: true };
var _reservedProps = {};
var _lazyTweens = [];
var _lazyLookup = {};
var _lastRenderedFrame;
var _plugins = {};
var _effects = {};
var _nextGCFrame = 30;
var _harnessPlugins = [];
var _callbackNames = "";
var _harness = function _harness(targets) {
	var target = targets[0], harnessPlugin, i;
	_isObject(target) || _isFunction(target) || (targets = [targets]);
	if (!(harnessPlugin = (target._gsap || {}).harness)) {
		i = _harnessPlugins.length;
		while (i-- && !_harnessPlugins[i].targetTest(target));
		harnessPlugin = _harnessPlugins[i];
	}
	i = targets.length;
	while (i--) targets[i] && (targets[i]._gsap || (targets[i]._gsap = new GSCache(targets[i], harnessPlugin))) || targets.splice(i, 1);
	return targets;
};
var _getCache = function _getCache(target) {
	return target._gsap || _harness(toArray(target))[0]._gsap;
};
var _getProperty = function _getProperty(target, property, v) {
	return (v = target[property]) && _isFunction(v) ? target[property]() : _isUndefined(v) && target.getAttribute && target.getAttribute(property) || v;
};
var _forEachName = function _forEachName(names, func) {
	return (names = names.split(",")).forEach(func) || names;
};
var _round = function _round(value) {
	return Math.round(value * 1e5) / 1e5 || 0;
};
var _roundPrecise = function _roundPrecise(value) {
	return Math.round(value * 1e7) / 1e7 || 0;
};
var _parseRelative = function _parseRelative(start, value) {
	var operator = value.charAt(0), end = parseFloat(value.substr(2));
	start = parseFloat(start);
	return operator === "+" ? start + end : operator === "-" ? start - end : operator === "*" ? start * end : start / end;
};
var _arrayContainsAny = function _arrayContainsAny(toSearch, toFind) {
	var l = toFind.length, i = 0;
	for (; toSearch.indexOf(toFind[i]) < 0 && ++i < l;);
	return i < l;
};
var _lazyRender = function _lazyRender() {
	var l = _lazyTweens.length, a = _lazyTweens.slice(0), i, tween;
	_lazyLookup = {};
	_lazyTweens.length = 0;
	for (i = 0; i < l; i++) {
		tween = a[i];
		tween && tween._lazy && (tween.render(tween._lazy[0], tween._lazy[1], true)._lazy = 0);
	}
};
var _isRevertWorthy = function _isRevertWorthy(animation) {
	return !!(animation._initted || animation._startAt || animation.add);
};
var _lazySafeRender = function _lazySafeRender(animation, time, suppressEvents, force) {
	_lazyTweens.length && !_reverting$1 && _lazyRender();
	animation.render(time, suppressEvents, force || !!(_reverting$1 && time < 0 && _isRevertWorthy(animation)));
	_lazyTweens.length && !_reverting$1 && _lazyRender();
};
var _numericIfPossible = function _numericIfPossible(value) {
	var n = parseFloat(value);
	return (n || n === 0) && (value + "").match(_delimitedValueExp).length < 2 ? n : _isString(value) ? value.trim() : value;
};
var _passThrough = function _passThrough(p) {
	return p;
};
var _setDefaults = function _setDefaults(obj, defaults) {
	for (var p in defaults) p in obj || (obj[p] = defaults[p]);
	return obj;
};
var _setKeyframeDefaults = function _setKeyframeDefaults(excludeDuration) {
	return function(obj, defaults) {
		for (var p in defaults) p in obj || p === "duration" && excludeDuration || p === "ease" || (obj[p] = defaults[p]);
	};
};
var _merge = function _merge(base, toMerge) {
	for (var p in toMerge) base[p] = toMerge[p];
	return base;
};
var _mergeDeep = function _mergeDeep(base, toMerge) {
	for (var p in toMerge) p !== "__proto__" && p !== "constructor" && p !== "prototype" && (base[p] = _isObject(toMerge[p]) ? _mergeDeep(base[p] || (base[p] = {}), toMerge[p]) : toMerge[p]);
	return base;
};
var _copyExcluding = function _copyExcluding(obj, excluding) {
	var copy = {}, p;
	for (p in obj) p in excluding || (copy[p] = obj[p]);
	return copy;
};
var _inheritDefaults = function _inheritDefaults(vars) {
	var parent = vars.parent || _globalTimeline, func = vars.keyframes ? _setKeyframeDefaults(_isArray(vars.keyframes)) : _setDefaults;
	if (_isNotFalse(vars.inherit)) while (parent) {
		func(vars, parent.vars.defaults);
		parent = parent.parent || parent._dp;
	}
	return vars;
};
var _arraysMatch = function _arraysMatch(a1, a2) {
	var i = a1.length, match = i === a2.length;
	while (match && i-- && a1[i] === a2[i]);
	return i < 0;
};
var _addLinkedListItem = function _addLinkedListItem(parent, child, firstProp, lastProp, sortBy) {
	if (firstProp === void 0) firstProp = "_first";
	if (lastProp === void 0) lastProp = "_last";
	var prev = parent[lastProp], t;
	if (sortBy) {
		t = child[sortBy];
		while (prev && prev[sortBy] > t) prev = prev._prev;
	}
	if (prev) {
		child._next = prev._next;
		prev._next = child;
	} else {
		child._next = parent[firstProp];
		parent[firstProp] = child;
	}
	if (child._next) child._next._prev = child;
	else parent[lastProp] = child;
	child._prev = prev;
	child.parent = child._dp = parent;
	return child;
};
var _removeLinkedListItem = function _removeLinkedListItem(parent, child, firstProp, lastProp) {
	if (firstProp === void 0) firstProp = "_first";
	if (lastProp === void 0) lastProp = "_last";
	var prev = child._prev, next = child._next;
	if (prev) prev._next = next;
	else if (parent[firstProp] === child) parent[firstProp] = next;
	if (next) next._prev = prev;
	else if (parent[lastProp] === child) parent[lastProp] = prev;
	child._next = child._prev = child.parent = null;
};
var _removeFromParent = function _removeFromParent(child, onlyIfParentHasAutoRemove) {
	child.parent && (!onlyIfParentHasAutoRemove || child.parent.autoRemoveChildren) && child.parent.remove && child.parent.remove(child);
	child._act = 0;
};
var _uncache = function _uncache(animation, child) {
	if (animation && (!child || child._end > animation._dur || child._start < 0)) {
		var a = animation;
		while (a) {
			a._dirty = 1;
			a = a.parent;
		}
	}
	return animation;
};
var _recacheAncestors = function _recacheAncestors(animation) {
	var parent = animation.parent;
	while (parent && parent.parent) {
		parent._dirty = 1;
		parent.totalDuration();
		parent = parent.parent;
	}
	return animation;
};
var _rewindStartAt = function _rewindStartAt(tween, totalTime, suppressEvents, force) {
	return tween._startAt && (_reverting$1 ? tween._startAt.revert(_revertConfigNoKill) : tween.vars.immediateRender && !tween.vars.autoRevert || tween._startAt.render(totalTime, true, force));
};
var _hasNoPausedAncestors = function _hasNoPausedAncestors(animation) {
	return !animation || animation._ts && _hasNoPausedAncestors(animation.parent);
};
var _elapsedCycleDuration = function _elapsedCycleDuration(animation) {
	return animation._repeat ? _animationCycle(animation._tTime, animation = animation.duration() + animation._rDelay) * animation : 0;
};
var _animationCycle = function _animationCycle(tTime, cycleDuration) {
	var whole = Math.floor(tTime = _roundPrecise(tTime / cycleDuration));
	return tTime && whole === tTime ? whole - 1 : whole;
};
var _parentToChildTotalTime = function _parentToChildTotalTime(parentTime, child) {
	return (parentTime - child._start) * child._ts + (child._ts >= 0 ? 0 : child._dirty ? child.totalDuration() : child._tDur);
};
var _setEnd = function _setEnd(animation) {
	return animation._end = _roundPrecise(animation._start + (animation._tDur / Math.abs(animation._ts || animation._rts || _tinyNum) || 0));
};
var _alignPlayhead = function _alignPlayhead(animation, totalTime) {
	var parent = animation._dp;
	if (parent && parent.smoothChildTiming && animation._ts) {
		animation._start = _roundPrecise(parent._time - (animation._ts > 0 ? totalTime / animation._ts : ((animation._dirty ? animation.totalDuration() : animation._tDur) - totalTime) / -animation._ts));
		_setEnd(animation);
		parent._dirty || _uncache(parent, animation);
	}
	return animation;
};
var _postAddChecks = function _postAddChecks(timeline, child) {
	var t;
	if (child._time || !child._dur && child._initted || child._start < timeline._time && (child._dur || !child.add)) {
		t = _parentToChildTotalTime(timeline.rawTime(), child);
		if (!child._dur || _clamp(0, child.totalDuration(), t) - child._tTime > _tinyNum) child.render(t, true);
	}
	if (_uncache(timeline, child)._dp && timeline._initted && timeline._time >= timeline._dur && timeline._ts) {
		if (timeline._dur < timeline.duration()) {
			t = timeline;
			while (t._dp) {
				t.rawTime() >= 0 && t.totalTime(t._tTime);
				t = t._dp;
			}
		}
		timeline._zTime = -_tinyNum;
	}
};
var _addToTimeline = function _addToTimeline(timeline, child, position, skipChecks) {
	child.parent && _removeFromParent(child);
	child._start = _roundPrecise((_isNumber(position) ? position : position || timeline !== _globalTimeline ? _parsePosition(timeline, position, child) : timeline._time) + child._delay);
	child._end = _roundPrecise(child._start + (child.totalDuration() / Math.abs(child.timeScale()) || 0));
	_addLinkedListItem(timeline, child, "_first", "_last", timeline._sort ? "_start" : 0);
	_isFromOrFromStart(child) || (timeline._recent = child);
	skipChecks || _postAddChecks(timeline, child);
	timeline._ts < 0 && _alignPlayhead(timeline, timeline._tTime);
	return timeline;
};
var _scrollTrigger = function _scrollTrigger(animation, trigger) {
	return (_globals.ScrollTrigger || _missingPlugin("scrollTrigger", trigger)) && _globals.ScrollTrigger.create(trigger, animation);
};
var _attemptInitTween = function _attemptInitTween(tween, time, force, suppressEvents, tTime) {
	_initTween(tween, time, tTime);
	if (!tween._initted) return 1;
	if (!force && tween._pt && !_reverting$1 && (tween._dur && tween.vars.lazy !== false || !tween._dur && tween.vars.lazy) && _lastRenderedFrame !== _ticker.frame) {
		_lazyTweens.push(tween);
		tween._lazy = [tTime, suppressEvents];
		return 1;
	}
};
var _parentPlayheadIsBeforeStart = function _parentPlayheadIsBeforeStart(_ref) {
	var parent = _ref.parent;
	return parent && parent._ts && parent._initted && !parent._lock && (parent.rawTime() < 0 || _parentPlayheadIsBeforeStart(parent));
};
var _isFromOrFromStart = function _isFromOrFromStart(_ref2) {
	var data = _ref2.data;
	return data === "isFromStart" || data === "isStart";
};
var _renderZeroDurationTween = function _renderZeroDurationTween(tween, totalTime, suppressEvents, force) {
	var prevRatio = tween.ratio, ratio = totalTime < 0 || !totalTime && (!tween._start && _parentPlayheadIsBeforeStart(tween) && !(!tween._initted && _isFromOrFromStart(tween)) || (tween._ts < 0 || tween._dp._ts < 0) && !_isFromOrFromStart(tween)) ? 0 : 1, repeatDelay = tween._rDelay, tTime = 0, pt, iteration, prevIteration;
	if (repeatDelay && tween._repeat) {
		tTime = _clamp(0, tween._tDur, totalTime);
		iteration = _animationCycle(tTime, repeatDelay);
		tween._yoyo && iteration & 1 && (ratio = 1 - ratio);
		if (iteration !== _animationCycle(tween._tTime, repeatDelay)) {
			prevRatio = 1 - ratio;
			tween.vars.repeatRefresh && tween._initted && tween.invalidate();
		}
	}
	if (ratio !== prevRatio || _reverting$1 || force || tween._zTime === _tinyNum || !totalTime && tween._zTime) {
		if (!tween._initted && _attemptInitTween(tween, totalTime, force, suppressEvents, tTime)) return;
		prevIteration = tween._zTime;
		tween._zTime = totalTime || (suppressEvents ? _tinyNum : 0);
		suppressEvents || (suppressEvents = totalTime && !prevIteration);
		tween.ratio = ratio;
		tween._from && (ratio = 1 - ratio);
		tween._time = 0;
		tween._tTime = tTime;
		pt = tween._pt;
		while (pt) {
			pt.r(ratio, pt.d);
			pt = pt._next;
		}
		totalTime < 0 && _rewindStartAt(tween, totalTime, suppressEvents, true);
		tween._onUpdate && !suppressEvents && _callback(tween, "onUpdate");
		tTime && tween._repeat && !suppressEvents && tween.parent && _callback(tween, "onRepeat");
		if ((totalTime >= tween._tDur || totalTime < 0) && tween.ratio === ratio) {
			ratio && _removeFromParent(tween, 1);
			if (!suppressEvents && !_reverting$1) {
				_callback(tween, ratio ? "onComplete" : "onReverseComplete", true);
				tween._prom && tween._prom();
			}
		}
	} else if (!tween._zTime) tween._zTime = totalTime;
};
var _findNextPauseTween = function _findNextPauseTween(animation, prevTime, time) {
	var child;
	if (time > prevTime) {
		child = animation._first;
		while (child && child._start <= time) {
			if (child.data === "isPause" && child._start > prevTime) return child;
			child = child._next;
		}
	} else {
		child = animation._last;
		while (child && child._start >= time) {
			if (child.data === "isPause" && child._start < prevTime) return child;
			child = child._prev;
		}
	}
};
var _setDuration = function _setDuration(animation, duration, skipUncache, leavePlayhead) {
	var repeat = animation._repeat, dur = _roundPrecise(duration) || 0, totalProgress = animation._tTime / animation._tDur;
	totalProgress && !leavePlayhead && (animation._time *= dur / animation._dur);
	animation._dur = dur;
	animation._tDur = !repeat ? dur : repeat < 0 ? 1e10 : _roundPrecise(dur * (repeat + 1) + animation._rDelay * repeat);
	totalProgress > 0 && !leavePlayhead && _alignPlayhead(animation, animation._tTime = animation._tDur * totalProgress);
	animation.parent && _setEnd(animation);
	skipUncache || _uncache(animation.parent, animation);
	return animation;
};
var _onUpdateTotalDuration = function _onUpdateTotalDuration(animation) {
	return animation instanceof Timeline ? _uncache(animation) : _setDuration(animation, animation._dur);
};
var _zeroPosition = {
	_start: 0,
	endTime: _emptyFunc,
	totalDuration: _emptyFunc
};
var _parsePosition = function _parsePosition(animation, position, percentAnimation) {
	var labels = animation.labels, recent = animation._recent || _zeroPosition, clippedDuration = animation.duration() >= _bigNum$1 ? recent.endTime(false) : animation._dur, i, offset, isPercent;
	if (_isString(position) && (isNaN(position) || position in labels)) {
		offset = position.charAt(0);
		isPercent = position.substr(-1) === "%";
		i = position.indexOf("=");
		if (offset === "<" || offset === ">") {
			i >= 0 && (position = position.replace(/=/, ""));
			return (offset === "<" ? recent._start : recent.endTime(recent._repeat >= 0)) + (parseFloat(position.substr(1)) || 0) * (isPercent ? (i < 0 ? recent : percentAnimation).totalDuration() / 100 : 1);
		}
		if (i < 0) {
			position in labels || (labels[position] = clippedDuration);
			return labels[position];
		}
		offset = parseFloat(position.charAt(i - 1) + position.substr(i + 1));
		if (isPercent && percentAnimation) offset = offset / 100 * (_isArray(percentAnimation) ? percentAnimation[0] : percentAnimation).totalDuration();
		return i > 1 ? _parsePosition(animation, position.substr(0, i - 1), percentAnimation) + offset : clippedDuration + offset;
	}
	return position == null ? clippedDuration : +position;
};
var _createTweenType = function _createTweenType(type, params, timeline) {
	var isLegacy = _isNumber(params[1]), varsIndex = (isLegacy ? 2 : 1) + (type < 2 ? 0 : 1), vars = params[varsIndex], irVars, parent;
	isLegacy && (vars.duration = params[1]);
	vars.parent = timeline;
	if (type) {
		irVars = vars;
		parent = timeline;
		while (parent && !("immediateRender" in irVars)) {
			irVars = parent.vars.defaults || {};
			parent = _isNotFalse(parent.vars.inherit) && parent.parent;
		}
		vars.immediateRender = _isNotFalse(irVars.immediateRender);
		type < 2 ? vars.runBackwards = 1 : vars.startAt = params[varsIndex - 1];
	}
	return new Tween(params[0], vars, params[varsIndex + 1]);
};
var _conditionalReturn = function _conditionalReturn(value, func) {
	return value || value === 0 ? func(value) : func;
};
var _clamp = function _clamp(min, max, value) {
	return value < min ? min : value > max ? max : value;
};
var getUnit = function getUnit(value, v) {
	return !_isString(value) || !(v = _unitExp.exec(value)) ? "" : v[1];
};
var clamp = function clamp(min, max, value) {
	return _conditionalReturn(value, function(v) {
		return _clamp(min, max, v);
	});
};
var _slice = [].slice;
var _isArrayLike = function _isArrayLike(value, nonEmpty) {
	return value && _isObject(value) && "length" in value && (!nonEmpty && !value.length || value.length - 1 in value && _isObject(value[0])) && !value.nodeType && value !== _win$1;
};
var _flatten = function _flatten(ar, leaveStrings, accumulator) {
	if (accumulator === void 0) accumulator = [];
	return ar.forEach(function(value) {
		var _accumulator;
		return _isString(value) && !leaveStrings || _isArrayLike(value, 1) ? (_accumulator = accumulator).push.apply(_accumulator, toArray(value)) : accumulator.push(value);
	}) || accumulator;
};
var toArray = function toArray(value, scope, leaveStrings) {
	return _context && !scope && _context.selector ? _context.selector(value) : _isString(value) && !leaveStrings && (_coreInitted || !_wake()) ? _slice.call((scope || _doc$1).querySelectorAll(value), 0) : _isArray(value) ? _flatten(value, leaveStrings) : _isArrayLike(value) ? _slice.call(value, 0) : value ? [value] : [];
};
var selector = function selector(value) {
	value = toArray(value)[0] || _warn("Invalid scope") || {};
	return function(v) {
		var el = value.current || value.nativeElement || value;
		return toArray(v, el.querySelectorAll ? el : el === value ? _warn("Invalid scope") || _doc$1.createElement("div") : value);
	};
};
var shuffle = function shuffle(a) {
	return a.sort(function() {
		return .5 - Math.random();
	});
};
var distribute = function distribute(v) {
	if (_isFunction(v)) return v;
	var vars = _isObject(v) ? v : { each: v }, ease = _parseEase(vars.ease), from = vars.from || 0, base = parseFloat(vars.base) || 0, cache = {}, isDecimal = from > 0 && from < 1, ratios = isNaN(from) || isDecimal, axis = vars.axis, ratioX = from, ratioY = from;
	if (_isString(from)) ratioX = ratioY = {
		center: .5,
		edges: .5,
		end: 1
	}[from] || 0;
	else if (!isDecimal && ratios) {
		ratioX = from[0];
		ratioY = from[1];
	}
	return function(i, target, a) {
		var l = (a || vars).length, distances = cache[l], originX, originY, x, y, d, j, max, min, wrapAt;
		if (!distances) {
			wrapAt = vars.grid === "auto" ? 0 : (vars.grid || [1, _bigNum$1])[1];
			if (!wrapAt) {
				max = -_bigNum$1;
				while (max < (max = a[wrapAt++].getBoundingClientRect().left) && wrapAt < l);
				wrapAt < l && wrapAt--;
			}
			distances = cache[l] = [];
			originX = ratios ? Math.min(wrapAt, l) * ratioX - .5 : from % wrapAt;
			originY = wrapAt === _bigNum$1 ? 0 : ratios ? l * ratioY / wrapAt - .5 : from / wrapAt | 0;
			max = 0;
			min = _bigNum$1;
			for (j = 0; j < l; j++) {
				x = j % wrapAt - originX;
				y = originY - (j / wrapAt | 0);
				distances[j] = d = !axis ? _sqrt(x * x + y * y) : Math.abs(axis === "y" ? y : x);
				d > max && (max = d);
				d < min && (min = d);
			}
			from === "random" && shuffle(distances);
			distances.max = max - min;
			distances.min = min;
			distances.v = l = (parseFloat(vars.amount) || parseFloat(vars.each) * (wrapAt > l ? l - 1 : !axis ? Math.max(wrapAt, l / wrapAt) : axis === "y" ? l / wrapAt : wrapAt) || 0) * (from === "edges" ? -1 : 1);
			distances.b = l < 0 ? base - l : base;
			distances.u = getUnit(vars.amount || vars.each) || 0;
			ease = ease && l < 0 ? _invertEase(ease) : ease;
		}
		l = (distances[i] - distances.min) / distances.max || 0;
		return _roundPrecise(distances.b + (ease ? ease(l) : l) * distances.v) + distances.u;
	};
};
var _roundModifier = function _roundModifier(v) {
	var p = Math.pow(10, ((v + "").split(".")[1] || "").length);
	return function(raw) {
		var n = _roundPrecise(Math.round(parseFloat(raw) / v) * v * p);
		return (n - n % 1) / p + (_isNumber(raw) ? 0 : getUnit(raw));
	};
};
var snap = function snap(snapTo, value) {
	var isArray = _isArray(snapTo), radius, is2D;
	if (!isArray && _isObject(snapTo)) {
		radius = isArray = snapTo.radius || _bigNum$1;
		if (snapTo.values) {
			snapTo = toArray(snapTo.values);
			if (is2D = !_isNumber(snapTo[0])) radius *= radius;
		} else snapTo = _roundModifier(snapTo.increment);
	}
	return _conditionalReturn(value, !isArray ? _roundModifier(snapTo) : _isFunction(snapTo) ? function(raw) {
		is2D = snapTo(raw);
		return Math.abs(is2D - raw) <= radius ? is2D : raw;
	} : function(raw) {
		var x = parseFloat(is2D ? raw.x : raw), y = parseFloat(is2D ? raw.y : 0), min = _bigNum$1, closest = 0, i = snapTo.length, dx, dy;
		while (i--) {
			if (is2D) {
				dx = snapTo[i].x - x;
				dy = snapTo[i].y - y;
				dx = dx * dx + dy * dy;
			} else dx = Math.abs(snapTo[i] - x);
			if (dx < min) {
				min = dx;
				closest = i;
			}
		}
		closest = !radius || min <= radius ? snapTo[closest] : raw;
		return is2D || closest === raw || _isNumber(raw) ? closest : closest + getUnit(raw);
	});
};
var random = function random(min, max, roundingIncrement, returnFunction) {
	return _conditionalReturn(_isArray(min) ? !max : roundingIncrement === true ? !!(roundingIncrement = 0) : !returnFunction, function() {
		return _isArray(min) ? min[~~(Math.random() * min.length)] : (roundingIncrement = roundingIncrement || 1e-5) && (returnFunction = roundingIncrement < 1 ? Math.pow(10, (roundingIncrement + "").length - 2) : 1) && Math.floor(Math.round((min - roundingIncrement / 2 + Math.random() * (max - min + roundingIncrement * .99)) / roundingIncrement) * roundingIncrement * returnFunction) / returnFunction;
	});
};
var pipe = function pipe() {
	for (var _len = arguments.length, functions = new Array(_len), _key = 0; _key < _len; _key++) functions[_key] = arguments[_key];
	return function(value) {
		return functions.reduce(function(v, f) {
			return f(v);
		}, value);
	};
};
var unitize = function unitize(func, unit) {
	return function(value) {
		return func(parseFloat(value)) + (unit || getUnit(value));
	};
};
var normalize = function normalize(min, max, value) {
	return mapRange(min, max, 0, 1, value);
};
var _wrapArray = function _wrapArray(a, wrapper, value) {
	return _conditionalReturn(value, function(index) {
		return a[~~wrapper(index)];
	});
};
var wrap = function wrap(min, max, value) {
	var range = max - min;
	return _isArray(min) ? _wrapArray(min, wrap(0, min.length), max) : _conditionalReturn(value, function(value) {
		return (range + (value - min) % range) % range + min;
	});
};
var wrapYoyo = function wrapYoyo(min, max, value) {
	var range = max - min, total = range * 2;
	return _isArray(min) ? _wrapArray(min, wrapYoyo(0, min.length - 1), max) : _conditionalReturn(value, function(value) {
		value = (total + (value - min) % total) % total || 0;
		return min + (value > range ? total - value : value);
	});
};
var _replaceRandom = function _replaceRandom(s) {
	return s.replace(_randomExp, function(match) {
		var arIndex = match.indexOf("[") + 1, values = match.substring(arIndex || 7, arIndex ? match.indexOf("]") : match.length - 1).split(_commaDelimExp);
		return random(arIndex ? values : +values[0], arIndex ? 0 : +values[1], +values[2] || 1e-5);
	});
};
var mapRange = function mapRange(inMin, inMax, outMin, outMax, value) {
	var inRange = inMax - inMin, outRange = outMax - outMin;
	return _conditionalReturn(value, function(value) {
		return outMin + ((value - inMin) / inRange * outRange || 0);
	});
};
var interpolate = function interpolate(start, end, progress, mutate) {
	var func = isNaN(start + end) ? 0 : function(p) {
		return (1 - p) * start + p * end;
	};
	if (!func) {
		var isString = _isString(start), master = {}, p, i, interpolators, l, il;
		progress === true && (mutate = 1) && (progress = null);
		if (isString) {
			start = { p: start };
			end = { p: end };
		} else if (_isArray(start) && !_isArray(end)) {
			interpolators = [];
			l = start.length;
			il = l - 2;
			for (i = 1; i < l; i++) interpolators.push(interpolate(start[i - 1], start[i]));
			l--;
			func = function func(p) {
				p *= l;
				var i = Math.min(il, ~~p);
				return interpolators[i](p - i);
			};
			progress = end;
		} else if (!mutate) start = _merge(_isArray(start) ? [] : {}, start);
		if (!interpolators) {
			for (p in end) _addPropTween.call(master, start, p, "get", end[p]);
			func = function func(p) {
				return _renderPropTweens(p, master) || (isString ? start.p : start);
			};
		}
	}
	return _conditionalReturn(progress, func);
};
var _getLabelInDirection = function _getLabelInDirection(timeline, fromTime, backward) {
	var labels = timeline.labels, min = _bigNum$1, p, distance, label;
	for (p in labels) {
		distance = labels[p] - fromTime;
		if (distance < 0 === !!backward && distance && min > (distance = Math.abs(distance))) {
			label = p;
			min = distance;
		}
	}
	return label;
};
var _callback = function _callback(animation, type, executeLazyFirst) {
	var v = animation.vars, callback = v[type], prevContext = _context, context = animation._ctx, params, scope, result;
	if (!callback) return;
	params = v[type + "Params"];
	scope = v.callbackScope || animation;
	executeLazyFirst && _lazyTweens.length && _lazyRender();
	context && (_context = context);
	result = params ? callback.apply(scope, params) : callback.call(scope);
	_context = prevContext;
	return result;
};
var _interrupt = function _interrupt(animation) {
	_removeFromParent(animation);
	animation.scrollTrigger && animation.scrollTrigger.kill(!!_reverting$1);
	animation.progress() < 1 && _callback(animation, "onInterrupt");
	return animation;
};
var _quickTween;
var _registerPluginQueue = [];
var _createPlugin = function _createPlugin(config) {
	if (!config) return;
	config = !config.name && config["default"] || config;
	if (_windowExists$1() || config.headless) {
		var name = config.name, isFunc = _isFunction(config), Plugin = name && !isFunc && config.init ? function() {
			this._props = [];
		} : config, instanceDefaults = {
			init: _emptyFunc,
			render: _renderPropTweens,
			add: _addPropTween,
			kill: _killPropTweensOf,
			modifier: _addPluginModifier,
			rawVars: 0
		}, statics = {
			targetTest: 0,
			get: 0,
			getSetter: _getSetter,
			aliases: {},
			register: 0
		};
		_wake();
		if (config !== Plugin) {
			if (_plugins[name]) return;
			_setDefaults(Plugin, _setDefaults(_copyExcluding(config, instanceDefaults), statics));
			_merge(Plugin.prototype, _merge(instanceDefaults, _copyExcluding(config, statics)));
			_plugins[Plugin.prop = name] = Plugin;
			if (config.targetTest) {
				_harnessPlugins.push(Plugin);
				_reservedProps[name] = 1;
			}
			name = (name === "css" ? "CSS" : name.charAt(0).toUpperCase() + name.substr(1)) + "Plugin";
		}
		_addGlobal(name, Plugin);
		config.register && config.register(gsap, Plugin, PropTween);
	} else _registerPluginQueue.push(config);
};
var _255 = 255;
var _colorLookup = {
	aqua: [
		0,
		_255,
		_255
	],
	lime: [
		0,
		_255,
		0
	],
	silver: [
		192,
		192,
		192
	],
	black: [
		0,
		0,
		0
	],
	maroon: [
		128,
		0,
		0
	],
	teal: [
		0,
		128,
		128
	],
	blue: [
		0,
		0,
		_255
	],
	navy: [
		0,
		0,
		128
	],
	white: [
		_255,
		_255,
		_255
	],
	olive: [
		128,
		128,
		0
	],
	yellow: [
		_255,
		_255,
		0
	],
	orange: [
		_255,
		165,
		0
	],
	gray: [
		128,
		128,
		128
	],
	purple: [
		128,
		0,
		128
	],
	green: [
		0,
		128,
		0
	],
	red: [
		_255,
		0,
		0
	],
	pink: [
		_255,
		192,
		203
	],
	cyan: [
		0,
		_255,
		_255
	],
	transparent: [
		_255,
		_255,
		_255,
		0
	]
};
var _hue = function _hue(h, m1, m2) {
	h += h < 0 ? 1 : h > 1 ? -1 : 0;
	return (h * 6 < 1 ? m1 + (m2 - m1) * h * 6 : h < .5 ? m2 : h * 3 < 2 ? m1 + (m2 - m1) * (2 / 3 - h) * 6 : m1) * _255 + .5 | 0;
};
var splitColor = function splitColor(v, toHSL, forceAlpha) {
	var a = !v ? _colorLookup.black : _isNumber(v) ? [
		v >> 16,
		v >> 8 & _255,
		v & _255
	] : 0, r, g, b, h, s, l, max, min, d, wasHSL;
	if (!a) {
		if (v.substr(-1) === ",") v = v.substr(0, v.length - 1);
		if (_colorLookup[v]) a = _colorLookup[v];
		else if (v.charAt(0) === "#") {
			if (v.length < 6) {
				r = v.charAt(1);
				g = v.charAt(2);
				b = v.charAt(3);
				v = "#" + r + r + g + g + b + b + (v.length === 5 ? v.charAt(4) + v.charAt(4) : "");
			}
			if (v.length === 9) {
				a = parseInt(v.substr(1, 6), 16);
				return [
					a >> 16,
					a >> 8 & _255,
					a & _255,
					parseInt(v.substr(7), 16) / 255
				];
			}
			v = parseInt(v.substr(1), 16);
			a = [
				v >> 16,
				v >> 8 & _255,
				v & _255
			];
		} else if (v.substr(0, 3) === "hsl") {
			a = wasHSL = v.match(_strictNumExp);
			if (!toHSL) {
				h = +a[0] % 360 / 360;
				s = +a[1] / 100;
				l = +a[2] / 100;
				g = l <= .5 ? l * (s + 1) : l + s - l * s;
				r = l * 2 - g;
				a.length > 3 && (a[3] *= 1);
				a[0] = _hue(h + 1 / 3, r, g);
				a[1] = _hue(h, r, g);
				a[2] = _hue(h - 1 / 3, r, g);
			} else if (~v.indexOf("=")) {
				a = v.match(_numExp);
				forceAlpha && a.length < 4 && (a[3] = 1);
				return a;
			}
		} else a = v.match(_strictNumExp) || _colorLookup.transparent;
		a = a.map(Number);
	}
	if (toHSL && !wasHSL) {
		r = a[0] / _255;
		g = a[1] / _255;
		b = a[2] / _255;
		max = Math.max(r, g, b);
		min = Math.min(r, g, b);
		l = (max + min) / 2;
		if (max === min) h = s = 0;
		else {
			d = max - min;
			s = l > .5 ? d / (2 - max - min) : d / (max + min);
			h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
			h *= 60;
		}
		a[0] = ~~(h + .5);
		a[1] = ~~(s * 100 + .5);
		a[2] = ~~(l * 100 + .5);
	}
	forceAlpha && a.length < 4 && (a[3] = 1);
	return a;
};
var _colorOrderData = function _colorOrderData(v) {
	var values = [], c = [], i = -1;
	v.split(_colorExp).forEach(function(v) {
		var a = v.match(_numWithUnitExp) || [];
		values.push.apply(values, a);
		c.push(i += a.length + 1);
	});
	values.c = c;
	return values;
};
var _formatColors = function _formatColors(s, toHSL, orderMatchData) {
	var result = "", colors = (s + result).match(_colorExp), type = toHSL ? "hsla(" : "rgba(", i = 0, c, shell, d, l;
	if (!colors) return s;
	colors = colors.map(function(color) {
		return (color = splitColor(color, toHSL, 1)) && type + (toHSL ? color[0] + "," + color[1] + "%," + color[2] + "%," + color[3] : color.join(",")) + ")";
	});
	if (orderMatchData) {
		d = _colorOrderData(s);
		c = orderMatchData.c;
		if (c.join(result) !== d.c.join(result)) {
			shell = s.replace(_colorExp, "1").split(_numWithUnitExp);
			l = shell.length - 1;
			for (; i < l; i++) result += shell[i] + (~c.indexOf(i) ? colors.shift() || type + "0,0,0,0)" : (d.length ? d : colors.length ? colors : orderMatchData).shift());
		}
	}
	if (!shell) {
		shell = s.split(_colorExp);
		l = shell.length - 1;
		for (; i < l; i++) result += shell[i] + colors[i];
	}
	return result + shell[l];
};
var _colorExp = function() {
	var s = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b", p;
	for (p in _colorLookup) s += "|" + p + "\\b";
	return new RegExp(s + ")", "gi");
}();
var _hslExp = /hsl[a]?\(/;
var _colorStringFilter = function _colorStringFilter(a) {
	var combined = a.join(" "), toHSL;
	_colorExp.lastIndex = 0;
	if (_colorExp.test(combined)) {
		toHSL = _hslExp.test(combined);
		a[1] = _formatColors(a[1], toHSL);
		a[0] = _formatColors(a[0], toHSL, _colorOrderData(a[1]));
		return true;
	}
};
var _tickerActive;
var _ticker = function() {
	var _getTime = Date.now, _lagThreshold = 500, _adjustedLag = 33, _startTime = _getTime(), _lastUpdate = _startTime, _gap = 1e3 / 240, _nextTime = _gap, _listeners = [], _id, _req, _raf, _self, _delta, _i, _tick = function _tick(v) {
		var elapsed = _getTime() - _lastUpdate, manual = v === true, overlap, dispatch, time, frame;
		(elapsed > _lagThreshold || elapsed < 0) && (_startTime += elapsed - _adjustedLag);
		_lastUpdate += elapsed;
		time = _lastUpdate - _startTime;
		overlap = time - _nextTime;
		if (overlap > 0 || manual) {
			frame = ++_self.frame;
			_delta = time - _self.time * 1e3;
			_self.time = time = time / 1e3;
			_nextTime += overlap + (overlap >= _gap ? 4 : _gap - overlap);
			dispatch = 1;
		}
		manual || (_id = _req(_tick));
		if (dispatch) for (_i = 0; _i < _listeners.length; _i++) _listeners[_i](time, _delta, frame, v);
	};
	_self = {
		time: 0,
		frame: 0,
		tick: function tick() {
			_tick(true);
		},
		deltaRatio: function deltaRatio(fps) {
			return _delta / (1e3 / (fps || 60));
		},
		wake: function wake() {
			if (_coreReady) {
				if (!_coreInitted && _windowExists$1()) {
					_win$1 = _coreInitted = window;
					_doc$1 = _win$1.document || {};
					_globals.gsap = gsap;
					(_win$1.gsapVersions || (_win$1.gsapVersions = [])).push(gsap.version);
					_install(_installScope || _win$1.GreenSockGlobals || !_win$1.gsap && _win$1 || {});
					_registerPluginQueue.forEach(_createPlugin);
				}
				_raf = typeof requestAnimationFrame !== "undefined" && requestAnimationFrame;
				_id && _self.sleep();
				_req = _raf || function(f) {
					return setTimeout(f, _nextTime - _self.time * 1e3 + 1 | 0);
				};
				_tickerActive = 1;
				_tick(2);
			}
		},
		sleep: function sleep() {
			(_raf ? cancelAnimationFrame : clearTimeout)(_id);
			_tickerActive = 0;
			_req = _emptyFunc;
		},
		lagSmoothing: function lagSmoothing(threshold, adjustedLag) {
			_lagThreshold = threshold || Infinity;
			_adjustedLag = Math.min(adjustedLag || 33, _lagThreshold);
		},
		fps: function fps(_fps) {
			_gap = 1e3 / (_fps || 240);
			_nextTime = _self.time * 1e3 + _gap;
		},
		add: function add(callback, once, prioritize) {
			var func = once ? function(t, d, f, v) {
				callback(t, d, f, v);
				_self.remove(func);
			} : callback;
			_self.remove(callback);
			_listeners[prioritize ? "unshift" : "push"](func);
			_wake();
			return func;
		},
		remove: function remove(callback, i) {
			~(i = _listeners.indexOf(callback)) && _listeners.splice(i, 1) && _i >= i && _i--;
		},
		_listeners
	};
	return _self;
}();
var _wake = function _wake() {
	return !_tickerActive && _ticker.wake();
};
var _easeMap = {};
var _customEaseExp = /^[\d.\-M][\d.\-,\s]/;
var _quotesExp = /["']/g;
var _parseObjectInString = function _parseObjectInString(value) {
	var obj = {}, split = value.substr(1, value.length - 3).split(":"), key = split[0], i = 1, l = split.length, index, val, parsedVal;
	for (; i < l; i++) {
		val = split[i];
		index = i !== l - 1 ? val.lastIndexOf(",") : val.length;
		parsedVal = val.substr(0, index);
		obj[key] = isNaN(parsedVal) ? parsedVal.replace(_quotesExp, "").trim() : +parsedVal;
		key = val.substr(index + 1).trim();
	}
	return obj;
};
var _valueInParentheses = function _valueInParentheses(value) {
	var open = value.indexOf("(") + 1, close = value.indexOf(")"), nested = value.indexOf("(", open);
	return value.substring(open, ~nested && nested < close ? value.indexOf(")", close + 1) : close);
};
var _configEaseFromString = function _configEaseFromString(name) {
	var split = (name + "").split("("), ease = _easeMap[split[0]];
	return ease && split.length > 1 && ease.config ? ease.config.apply(null, ~name.indexOf("{") ? [_parseObjectInString(split[1])] : _valueInParentheses(name).split(",").map(_numericIfPossible)) : _easeMap._CE && _customEaseExp.test(name) ? _easeMap._CE("", name) : ease;
};
var _invertEase = function _invertEase(ease) {
	return function(p) {
		return 1 - ease(1 - p);
	};
};
var _parseEase = function _parseEase(ease, defaultEase) {
	return !ease ? defaultEase : (_isFunction(ease) ? ease : _easeMap[ease] || _configEaseFromString(ease)) || defaultEase;
};
var _insertEase = function _insertEase(names, easeIn, easeOut, easeInOut) {
	if (easeOut === void 0) easeOut = function easeOut(p) {
		return 1 - easeIn(1 - p);
	};
	if (easeInOut === void 0) easeInOut = function easeInOut(p) {
		return p < .5 ? easeIn(p * 2) / 2 : 1 - easeIn((1 - p) * 2) / 2;
	};
	var ease = {
		easeIn,
		easeOut,
		easeInOut
	}, lowercaseName;
	_forEachName(names, function(name) {
		_easeMap[name] = _globals[name] = ease;
		_easeMap[lowercaseName = name.toLowerCase()] = easeOut;
		for (var p in ease) _easeMap[lowercaseName + (p === "easeIn" ? ".in" : p === "easeOut" ? ".out" : ".inOut")] = _easeMap[name + "." + p] = ease[p];
	});
	return ease;
};
var _easeInOutFromOut = function _easeInOutFromOut(easeOut) {
	return function(p) {
		return p < .5 ? (1 - easeOut(1 - p * 2)) / 2 : .5 + easeOut((p - .5) * 2) / 2;
	};
};
var _configElastic = function _configElastic(type, amplitude, period) {
	var p1 = amplitude >= 1 ? amplitude : 1, p2 = (period || (type ? .3 : .45)) / (amplitude < 1 ? amplitude : 1), p3 = p2 / _2PI * (Math.asin(1 / p1) || 0), easeOut = function easeOut(p) {
		return p === 1 ? 1 : p1 * Math.pow(2, -10 * p) * _sin((p - p3) * p2) + 1;
	}, ease = type === "out" ? easeOut : type === "in" ? function(p) {
		return 1 - easeOut(1 - p);
	} : _easeInOutFromOut(easeOut);
	p2 = _2PI / p2;
	ease.config = function(amplitude, period) {
		return _configElastic(type, amplitude, period);
	};
	return ease;
};
var _configBack = function _configBack(type, overshoot) {
	if (overshoot === void 0) overshoot = 1.70158;
	var easeOut = function easeOut(p) {
		return p ? --p * p * ((overshoot + 1) * p + overshoot) + 1 : 0;
	}, ease = type === "out" ? easeOut : type === "in" ? function(p) {
		return 1 - easeOut(1 - p);
	} : _easeInOutFromOut(easeOut);
	ease.config = function(overshoot) {
		return _configBack(type, overshoot);
	};
	return ease;
};
_forEachName("Linear,Quad,Cubic,Quart,Quint,Strong", function(name, i) {
	var power = i < 5 ? i + 1 : i;
	_insertEase(name + ",Power" + (power - 1), i ? function(p) {
		return Math.pow(p, power);
	} : function(p) {
		return p;
	}, function(p) {
		return 1 - Math.pow(1 - p, power);
	}, function(p) {
		return p < .5 ? Math.pow(p * 2, power) / 2 : 1 - Math.pow((1 - p) * 2, power) / 2;
	});
});
_easeMap.Linear.easeNone = _easeMap.none = _easeMap.Linear.easeIn;
_insertEase("Elastic", _configElastic("in"), _configElastic("out"), _configElastic());
(function(n, c) {
	var n1 = 1 / c, n2 = 2 * n1, n3 = 2.5 * n1, easeOut = function easeOut(p) {
		return p < n1 ? n * p * p : p < n2 ? n * Math.pow(p - 1.5 / c, 2) + .75 : p < n3 ? n * (p -= 2.25 / c) * p + .9375 : n * Math.pow(p - 2.625 / c, 2) + .984375;
	};
	_insertEase("Bounce", function(p) {
		return 1 - easeOut(1 - p);
	}, easeOut);
})(7.5625, 2.75);
_insertEase("Expo", function(p) {
	return Math.pow(2, 10 * (p - 1)) * p + p * p * p * p * p * p * (1 - p);
});
_insertEase("Circ", function(p) {
	return -(_sqrt(1 - p * p) - 1);
});
_insertEase("Sine", function(p) {
	return p === 1 ? 1 : -_cos(p * _HALF_PI) + 1;
});
_insertEase("Back", _configBack("in"), _configBack("out"), _configBack());
_easeMap.SteppedEase = _easeMap.steps = _globals.SteppedEase = { config: function config(steps, immediateStart) {
	if (steps === void 0) steps = 1;
	var p1 = 1 / steps, p2 = steps + (immediateStart ? 0 : 1), p3 = immediateStart ? 1 : 0, max = 1 - _tinyNum;
	return function(p) {
		return ((p2 * _clamp(0, max, p) | 0) + p3) * p1;
	};
} };
_defaults.ease = _easeMap["quad.out"];
_forEachName("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(name) {
	return _callbackNames += name + "," + name + "Params,";
});
var GSCache = function GSCache(target, harness) {
	this.id = _gsID++;
	target._gsap = this;
	this.target = target;
	this.harness = harness;
	this.get = harness ? harness.get : _getProperty;
	this.set = harness ? harness.getSetter : _getSetter;
};
var Animation = /*#__PURE__*/ function() {
	function Animation(vars) {
		this.vars = vars;
		this._delay = +vars.delay || 0;
		if (this._repeat = vars.repeat === Infinity ? -2 : vars.repeat || 0) {
			this._rDelay = vars.repeatDelay || 0;
			this._yoyo = !!vars.yoyo || !!vars.yoyoEase;
		}
		this._ts = 1;
		_setDuration(this, +vars.duration, 1, 1);
		this.data = vars.data;
		if (_context) {
			this._ctx = _context;
			_context.data.push(this);
		}
		_tickerActive || _ticker.wake();
	}
	var _proto = Animation.prototype;
	_proto.delay = function delay(value) {
		if (value || value === 0) {
			this.parent && this.parent.smoothChildTiming && this.startTime(this._start + value - this._delay);
			this._delay = value;
			return this;
		}
		return this._delay;
	};
	_proto.duration = function duration(value) {
		return arguments.length ? this.totalDuration(this._repeat > 0 ? value + (value + this._rDelay) * this._repeat : value) : this.totalDuration() && this._dur;
	};
	_proto.totalDuration = function totalDuration(value) {
		if (!arguments.length) return this._tDur;
		this._dirty = 0;
		return _setDuration(this, this._repeat < 0 ? value : (value - this._repeat * this._rDelay) / (this._repeat + 1));
	};
	_proto.totalTime = function totalTime(_totalTime, suppressEvents) {
		_wake();
		if (!arguments.length) return this._tTime;
		var parent = this._dp;
		if (parent && parent.smoothChildTiming && this._ts) {
			_alignPlayhead(this, _totalTime);
			!parent._dp || parent.parent || _postAddChecks(parent, this);
			while (parent && parent.parent) {
				if (parent.parent._time !== parent._start + (parent._ts >= 0 ? parent._tTime / parent._ts : (parent.totalDuration() - parent._tTime) / -parent._ts)) parent.totalTime(parent._tTime, true);
				parent = parent.parent;
			}
			if (!this.parent && this._dp.autoRemoveChildren && (this._ts > 0 && _totalTime < this._tDur || this._ts < 0 && _totalTime > 0 || !this._tDur && !_totalTime)) _addToTimeline(this._dp, this, this._start - this._delay);
		}
		if (this._tTime !== _totalTime || !this._dur && !suppressEvents || this._initted && Math.abs(this._zTime) === _tinyNum || !this._initted && this._dur && _totalTime || !_totalTime && !this._initted && (this.add || this._ptLookup)) {
			this._ts || (this._pTime = _totalTime);
			_lazySafeRender(this, _totalTime, suppressEvents);
		}
		return this;
	};
	_proto.time = function time(value, suppressEvents) {
		return arguments.length ? this.totalTime(Math.min(this.totalDuration(), value + _elapsedCycleDuration(this)) % (this._dur + this._rDelay) || (value ? this._dur : 0), suppressEvents) : this._time;
	};
	_proto.totalProgress = function totalProgress(value, suppressEvents) {
		return arguments.length ? this.totalTime(this.totalDuration() * value, suppressEvents) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.rawTime() >= 0 && this._initted ? 1 : 0;
	};
	_proto.progress = function progress(value, suppressEvents) {
		return arguments.length ? this.totalTime(this.duration() * (this._yoyo && !(this.iteration() & 1) ? 1 - value : value) + _elapsedCycleDuration(this), suppressEvents) : this.duration() ? Math.min(1, this._time / this._dur) : this.rawTime() > 0 ? 1 : 0;
	};
	_proto.iteration = function iteration(value, suppressEvents) {
		var cycleDuration = this.duration() + this._rDelay;
		return arguments.length ? this.totalTime(this._time + (value - 1) * cycleDuration, suppressEvents) : this._repeat ? _animationCycle(this._tTime, cycleDuration) + 1 : 1;
	};
	_proto.timeScale = function timeScale(value, suppressEvents) {
		if (!arguments.length) return this._rts === -_tinyNum ? 0 : this._rts;
		if (this._rts === value) return this;
		var tTime = this.parent && this._ts ? _parentToChildTotalTime(this.parent._time, this) : this._tTime;
		this._rts = +value || 0;
		this._ts = this._ps || value === -_tinyNum ? 0 : this._rts;
		this.totalTime(_clamp(-Math.abs(this._delay), this.totalDuration(), tTime), suppressEvents !== false);
		_setEnd(this);
		return _recacheAncestors(this);
	};
	_proto.paused = function paused(value) {
		if (!arguments.length) return this._ps;
		if (this._ps !== value) {
			this._ps = value;
			if (value) {
				this._pTime = this._tTime || Math.max(-this._delay, this.rawTime());
				this._ts = this._act = 0;
			} else {
				_wake();
				this._ts = this._rts;
				this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, this.progress() === 1 && Math.abs(this._zTime) !== _tinyNum && (this._tTime -= _tinyNum));
			}
		}
		return this;
	};
	_proto.startTime = function startTime(value) {
		if (arguments.length) {
			this._start = _roundPrecise(value);
			var parent = this.parent || this._dp;
			parent && (parent._sort || !this.parent) && _addToTimeline(parent, this, this._start - this._delay);
			return this;
		}
		return this._start;
	};
	_proto.endTime = function endTime(includeRepeats) {
		return this._start + (_isNotFalse(includeRepeats) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1);
	};
	_proto.rawTime = function rawTime(wrapRepeats) {
		var parent = this.parent || this._dp;
		return !parent ? this._tTime : wrapRepeats && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : !this._ts ? this._tTime : _parentToChildTotalTime(parent.rawTime(wrapRepeats), this);
	};
	_proto.revert = function revert(config) {
		if (config === void 0) config = _revertConfig;
		var prevIsReverting = _reverting$1;
		_reverting$1 = config;
		if (_isRevertWorthy(this)) {
			this.timeline && this.timeline.revert(config);
			this.totalTime(-.01, config.suppressEvents);
		}
		this.data !== "nested" && config.kill !== false && this.kill();
		_reverting$1 = prevIsReverting;
		return this;
	};
	_proto.globalTime = function globalTime(rawTime) {
		var animation = this, time = arguments.length ? rawTime : animation.rawTime();
		while (animation) {
			time = animation._start + time / (Math.abs(animation._ts) || 1);
			animation = animation._dp;
		}
		return !this.parent && this._sat ? this._sat.globalTime(rawTime) : time;
	};
	_proto.repeat = function repeat(value) {
		if (arguments.length) {
			this._repeat = value === Infinity ? -2 : value;
			return _onUpdateTotalDuration(this);
		}
		return this._repeat === -2 ? Infinity : this._repeat;
	};
	_proto.repeatDelay = function repeatDelay(value) {
		if (arguments.length) {
			var time = this._time;
			this._rDelay = value;
			_onUpdateTotalDuration(this);
			return time ? this.time(time) : this;
		}
		return this._rDelay;
	};
	_proto.yoyo = function yoyo(value) {
		if (arguments.length) {
			this._yoyo = value;
			return this;
		}
		return this._yoyo;
	};
	_proto.seek = function seek(position, suppressEvents) {
		return this.totalTime(_parsePosition(this, position), _isNotFalse(suppressEvents));
	};
	_proto.restart = function restart(includeDelay, suppressEvents) {
		this.play().totalTime(includeDelay ? -this._delay : 0, _isNotFalse(suppressEvents));
		this._dur || (this._zTime = -_tinyNum);
		return this;
	};
	_proto.play = function play(from, suppressEvents) {
		from != null && this.seek(from, suppressEvents);
		return this.reversed(false).paused(false);
	};
	_proto.reverse = function reverse(from, suppressEvents) {
		from != null && this.seek(from || this.totalDuration(), suppressEvents);
		return this.reversed(true).paused(false);
	};
	_proto.pause = function pause(atTime, suppressEvents) {
		atTime != null && this.seek(atTime, suppressEvents);
		return this.paused(true);
	};
	_proto.resume = function resume() {
		return this.paused(false);
	};
	_proto.reversed = function reversed(value) {
		if (arguments.length) {
			!!value !== this.reversed() && this.timeScale(-this._rts || (value ? -_tinyNum : 0));
			return this;
		}
		return this._rts < 0;
	};
	_proto.invalidate = function invalidate() {
		this._initted = this._act = 0;
		this._zTime = -_tinyNum;
		return this;
	};
	_proto.isActive = function isActive() {
		var parent = this.parent || this._dp, start = this._start, rawTime;
		return !!(!parent || this._ts && this._initted && parent.isActive() && (rawTime = parent.rawTime(true)) >= start && rawTime < this.endTime(true) - _tinyNum);
	};
	_proto.eventCallback = function eventCallback(type, callback, params) {
		var vars = this.vars;
		if (arguments.length > 1) {
			if (!callback) delete vars[type];
			else {
				vars[type] = callback;
				params && (vars[type + "Params"] = params);
				type === "onUpdate" && (this._onUpdate = callback);
			}
			return this;
		}
		return vars[type];
	};
	_proto.then = function then(onFulfilled) {
		var self = this, prevProm = self._prom;
		return new Promise(function(resolve) {
			var f = _isFunction(onFulfilled) ? onFulfilled : _passThrough, _resolve = function _resolve() {
				var _then = self.then;
				self.then = null;
				prevProm && prevProm();
				_isFunction(f) && (f = f(self)) && (f.then || f === self) && (self.then = _then);
				resolve(f);
				self.then = _then;
			};
			if (self._initted && self.totalProgress() === 1 && self._ts >= 0 || !self._tTime && self._ts < 0) _resolve();
			else self._prom = _resolve;
		});
	};
	_proto.kill = function kill() {
		_interrupt(this);
	};
	return Animation;
}();
_setDefaults(Animation.prototype, {
	_time: 0,
	_start: 0,
	_end: 0,
	_tTime: 0,
	_tDur: 0,
	_dirty: 0,
	_repeat: 0,
	_yoyo: false,
	parent: null,
	_initted: false,
	_rDelay: 0,
	_ts: 1,
	_dp: 0,
	ratio: 0,
	_zTime: -_tinyNum,
	_prom: 0,
	_ps: false,
	_rts: 1
});
var Timeline = /*#__PURE__*/ function(_Animation) {
	_inheritsLoose(Timeline, _Animation);
	function Timeline(vars, position) {
		var _this;
		if (vars === void 0) vars = {};
		_this = _Animation.call(this, vars) || this;
		_this.labels = {};
		_this.smoothChildTiming = !!vars.smoothChildTiming;
		_this.autoRemoveChildren = !!vars.autoRemoveChildren;
		_this._sort = _isNotFalse(vars.sortChildren);
		_globalTimeline && _addToTimeline(vars.parent || _globalTimeline, _assertThisInitialized(_this), position);
		vars.reversed && _this.reverse();
		vars.paused && _this.paused(true);
		vars.scrollTrigger && _scrollTrigger(_assertThisInitialized(_this), vars.scrollTrigger);
		return _this;
	}
	var _proto2 = Timeline.prototype;
	_proto2.to = function to(targets, vars, position) {
		_createTweenType(0, arguments, this);
		return this;
	};
	_proto2.from = function from(targets, vars, position) {
		_createTweenType(1, arguments, this);
		return this;
	};
	_proto2.fromTo = function fromTo(targets, fromVars, toVars, position) {
		_createTweenType(2, arguments, this);
		return this;
	};
	_proto2.set = function set(targets, vars, position) {
		vars.duration = 0;
		vars.parent = this;
		_inheritDefaults(vars).repeatDelay || (vars.repeat = 0);
		vars.immediateRender = !!vars.immediateRender;
		new Tween(targets, vars, _parsePosition(this, position), 1);
		return this;
	};
	_proto2.call = function call(callback, params, position) {
		return _addToTimeline(this, Tween.delayedCall(0, callback, params), position);
	};
	_proto2.staggerTo = function staggerTo(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams) {
		vars.duration = duration;
		vars.stagger = vars.stagger || stagger;
		vars.onComplete = onCompleteAll;
		vars.onCompleteParams = onCompleteAllParams;
		vars.parent = this;
		new Tween(targets, vars, _parsePosition(this, position));
		return this;
	};
	_proto2.staggerFrom = function staggerFrom(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams) {
		vars.runBackwards = 1;
		_inheritDefaults(vars).immediateRender = _isNotFalse(vars.immediateRender);
		return this.staggerTo(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams);
	};
	_proto2.staggerFromTo = function staggerFromTo(targets, duration, fromVars, toVars, stagger, position, onCompleteAll, onCompleteAllParams) {
		toVars.startAt = fromVars;
		_inheritDefaults(toVars).immediateRender = _isNotFalse(toVars.immediateRender);
		return this.staggerTo(targets, duration, toVars, stagger, position, onCompleteAll, onCompleteAllParams);
	};
	_proto2.render = function render(totalTime, suppressEvents, force) {
		var prevTime = this._time, tDur = this._dirty ? this.totalDuration() : this._tDur, dur = this._dur, tTime = totalTime <= 0 ? 0 : _roundPrecise(totalTime), crossingStart = this._zTime < 0 !== totalTime < 0 && (this._initted || !dur), time, child, next, iteration, cycleDuration, prevPaused, pauseTween, timeScale, prevStart, prevIteration, yoyo, isYoyo;
		this !== _globalTimeline && tTime > tDur && totalTime >= 0 && (tTime = tDur);
		if (tTime !== this._tTime || force || crossingStart) {
			if (prevTime !== this._time && dur) {
				tTime += this._time - prevTime;
				totalTime += this._time - prevTime;
			}
			time = tTime;
			prevStart = this._start;
			timeScale = this._ts;
			prevPaused = !timeScale;
			if (crossingStart) {
				dur || (prevTime = this._zTime);
				(totalTime || !suppressEvents) && (this._zTime = totalTime);
			}
			if (this._repeat) {
				yoyo = this._yoyo;
				cycleDuration = dur + this._rDelay;
				if (this._repeat < -1 && totalTime < 0) return this.totalTime(cycleDuration * 100 + totalTime, suppressEvents, force);
				time = _roundPrecise(tTime % cycleDuration);
				if (tTime === tDur) {
					iteration = this._repeat;
					time = dur;
				} else {
					prevIteration = _roundPrecise(tTime / cycleDuration);
					iteration = ~~prevIteration;
					if (iteration && iteration === prevIteration) {
						time = dur;
						iteration--;
					}
					time > dur && (time = dur);
				}
				prevIteration = _animationCycle(this._tTime, cycleDuration);
				!prevTime && this._tTime && prevIteration !== iteration && this._tTime - prevIteration * cycleDuration - this._dur <= 0 && (prevIteration = iteration);
				if (yoyo && iteration & 1) {
					time = dur - time;
					isYoyo = 1;
				}
				if (iteration !== prevIteration && !this._lock) {
					var rewinding = yoyo && prevIteration & 1, doesWrap = rewinding === (yoyo && iteration & 1);
					iteration < prevIteration && (rewinding = !rewinding);
					prevTime = rewinding ? 0 : tTime % dur ? dur : tTime;
					this._lock = 1;
					this.render(prevTime || (isYoyo ? 0 : _roundPrecise(iteration * cycleDuration)), suppressEvents, !dur)._lock = 0;
					this._tTime = tTime;
					!suppressEvents && this.parent && _callback(this, "onRepeat");
					if (this.vars.repeatRefresh && !isYoyo) {
						this.invalidate()._lock = 1;
						prevIteration = iteration;
					}
					if (prevTime && prevTime !== this._time || prevPaused !== !this._ts || this.vars.onRepeat && !this.parent && !this._act) return this;
					dur = this._dur;
					tDur = this._tDur;
					if (doesWrap) {
						this._lock = 2;
						prevTime = rewinding ? dur : -1e-4;
						this.render(prevTime, true);
						this.vars.repeatRefresh && !isYoyo && this.invalidate();
					}
					this._lock = 0;
					if (!this._ts && !prevPaused) return this;
				}
			}
			if (this._hasPause && !this._forcing && this._lock < 2) {
				pauseTween = _findNextPauseTween(this, _roundPrecise(prevTime), _roundPrecise(time));
				if (pauseTween) tTime -= time - (time = pauseTween._start);
			}
			this._tTime = tTime;
			this._time = time;
			this._act = !!timeScale;
			if (!this._initted) {
				this._onUpdate = this.vars.onUpdate;
				this._initted = 1;
				this._zTime = totalTime;
				prevTime = 0;
			}
			if (!prevTime && tTime && dur && !suppressEvents && !prevIteration) {
				_callback(this, "onStart");
				if (this._tTime !== tTime) return this;
			}
			if (time >= prevTime && totalTime >= 0) {
				child = this._first;
				while (child) {
					next = child._next;
					if ((child._act || time >= child._start) && child._ts && pauseTween !== child) {
						if (child.parent !== this) return this.render(totalTime, suppressEvents, force);
						child.render(child._ts > 0 ? (time - child._start) * child._ts : (child._dirty ? child.totalDuration() : child._tDur) + (time - child._start) * child._ts, suppressEvents, force);
						if (time !== this._time || !this._ts && !prevPaused) {
							pauseTween = 0;
							next && (tTime += this._zTime = -_tinyNum);
							break;
						}
					}
					child = next;
				}
			} else {
				child = this._last;
				var adjustedTime = totalTime < 0 ? totalTime : time;
				while (child) {
					next = child._prev;
					if ((child._act || adjustedTime <= child._end) && child._ts && pauseTween !== child) {
						if (child.parent !== this) return this.render(totalTime, suppressEvents, force);
						child.render(child._ts > 0 ? (adjustedTime - child._start) * child._ts : (child._dirty ? child.totalDuration() : child._tDur) + (adjustedTime - child._start) * child._ts, suppressEvents, force || _reverting$1 && _isRevertWorthy(child));
						if (time !== this._time || !this._ts && !prevPaused) {
							pauseTween = 0;
							next && (tTime += this._zTime = adjustedTime ? -_tinyNum : _tinyNum);
							break;
						}
					}
					child = next;
				}
			}
			if (pauseTween && !suppressEvents) {
				this.pause();
				pauseTween.render(time >= prevTime ? 0 : -_tinyNum)._zTime = time >= prevTime ? 1 : -1;
				if (this._ts) {
					this._start = prevStart;
					_setEnd(this);
					return this.render(totalTime, suppressEvents, force);
				}
			}
			this._onUpdate && !suppressEvents && _callback(this, "onUpdate", true);
			if (tTime === tDur && this._tTime >= this.totalDuration() || !tTime && prevTime) {
				if (prevStart === this._start || Math.abs(timeScale) !== Math.abs(this._ts)) {
					if (!this._lock) {
						(totalTime || !dur) && (tTime === tDur && this._ts > 0 || !tTime && this._ts < 0) && _removeFromParent(this, 1);
						if (!suppressEvents && !(totalTime < 0 && !prevTime) && (tTime || prevTime || !tDur)) {
							_callback(this, tTime === tDur && totalTime >= 0 ? "onComplete" : "onReverseComplete", true);
							this._prom && !(tTime < tDur && this.timeScale() > 0) && this._prom();
						}
					}
				}
			}
		}
		return this;
	};
	_proto2.add = function add(child, position) {
		var _this2 = this;
		_isNumber(position) || (position = _parsePosition(this, position, child));
		if (!(child instanceof Animation)) {
			if (_isArray(child)) {
				child.forEach(function(obj) {
					return _this2.add(obj, position);
				});
				return this;
			}
			if (_isString(child)) return this.addLabel(child, position);
			if (_isFunction(child)) child = Tween.delayedCall(0, child);
			else return this;
		}
		return this !== child ? _addToTimeline(this, child, position) : this;
	};
	_proto2.getChildren = function getChildren(nested, tweens, timelines, ignoreBeforeTime) {
		if (nested === void 0) nested = true;
		if (tweens === void 0) tweens = true;
		if (timelines === void 0) timelines = true;
		if (ignoreBeforeTime === void 0) ignoreBeforeTime = -_bigNum$1;
		var a = [], child = this._first;
		while (child) {
			if (child._start >= ignoreBeforeTime) {
				if (child instanceof Tween) tweens && a.push(child);
				else {
					timelines && a.push(child);
					nested && a.push.apply(a, child.getChildren(true, tweens, timelines));
				}
			}
			child = child._next;
		}
		return a;
	};
	_proto2.getById = function getById(id) {
		var animations = this.getChildren(1, 1, 1), i = animations.length;
		while (i--) if (animations[i].vars.id === id) return animations[i];
	};
	_proto2.remove = function remove(child) {
		if (_isString(child)) return this.removeLabel(child);
		if (_isFunction(child)) return this.killTweensOf(child);
		child.parent === this && _removeLinkedListItem(this, child);
		if (child === this._recent) this._recent = this._last;
		return _uncache(this);
	};
	_proto2.totalTime = function totalTime(_totalTime2, suppressEvents) {
		if (!arguments.length) return this._tTime;
		this._forcing = 1;
		if (!this._dp && this._ts) this._start = _roundPrecise(_ticker.time - (this._ts > 0 ? _totalTime2 / this._ts : (this.totalDuration() - _totalTime2) / -this._ts));
		_Animation.prototype.totalTime.call(this, _totalTime2, suppressEvents);
		this._forcing = 0;
		return this;
	};
	_proto2.addLabel = function addLabel(label, position) {
		this.labels[label] = _parsePosition(this, position);
		return this;
	};
	_proto2.removeLabel = function removeLabel(label) {
		delete this.labels[label];
		return this;
	};
	_proto2.addPause = function addPause(position, callback, params) {
		var t = Tween.delayedCall(0, callback || _emptyFunc, params);
		t.data = "isPause";
		this._hasPause = 1;
		return _addToTimeline(this, t, _parsePosition(this, position));
	};
	_proto2.removePause = function removePause(position) {
		var child = this._first;
		position = _parsePosition(this, position);
		while (child) {
			if (child._start === position && child.data === "isPause") _removeFromParent(child);
			child = child._next;
		}
	};
	_proto2.killTweensOf = function killTweensOf(targets, props, onlyActive) {
		var tweens = this.getTweensOf(targets, onlyActive), i = tweens.length;
		while (i--) _overwritingTween !== tweens[i] && tweens[i].kill(targets, props);
		return this;
	};
	_proto2.getTweensOf = function getTweensOf(targets, onlyActive) {
		var a = [], parsedTargets = toArray(targets), child = this._first, isGlobalTime = _isNumber(onlyActive), children;
		while (child) {
			if (child instanceof Tween) {
				if (_arrayContainsAny(child._targets, parsedTargets) && (isGlobalTime ? (!_overwritingTween || child._initted && child._ts) && child.globalTime(0) <= onlyActive && child.globalTime(child.totalDuration()) > onlyActive : !onlyActive || child.isActive())) a.push(child);
			} else if ((children = child.getTweensOf(parsedTargets, onlyActive)).length) a.push.apply(a, children);
			child = child._next;
		}
		return a;
	};
	_proto2.tweenTo = function tweenTo(position, vars) {
		vars = vars || {};
		var tl = this, endTime = _parsePosition(tl, position), _vars = vars, startAt = _vars.startAt, _onStart = _vars.onStart, onStartParams = _vars.onStartParams, immediateRender = _vars.immediateRender, initted, tween = Tween.to(tl, _setDefaults({
			ease: vars.ease || "none",
			lazy: false,
			immediateRender: false,
			time: endTime,
			overwrite: "auto",
			duration: vars.duration || Math.abs((endTime - (startAt && "time" in startAt ? startAt.time : tl._time)) / tl.timeScale()) || _tinyNum,
			onStart: function onStart() {
				tl.pause();
				if (!initted) {
					var duration = vars.duration || Math.abs((endTime - (startAt && "time" in startAt ? startAt.time : tl._time)) / tl.timeScale());
					tween._dur !== duration && _setDuration(tween, duration, 0, 1).render(tween._time, true, true);
					initted = 1;
				}
				_onStart && _onStart.apply(tween, onStartParams || []);
			}
		}, vars));
		return immediateRender ? tween.render(0) : tween;
	};
	_proto2.tweenFromTo = function tweenFromTo(fromPosition, toPosition, vars) {
		return this.tweenTo(toPosition, _setDefaults({ startAt: { time: _parsePosition(this, fromPosition) } }, vars));
	};
	_proto2.recent = function recent() {
		return this._recent;
	};
	_proto2.nextLabel = function nextLabel(afterTime) {
		if (afterTime === void 0) afterTime = this._time;
		return _getLabelInDirection(this, _parsePosition(this, afterTime));
	};
	_proto2.previousLabel = function previousLabel(beforeTime) {
		if (beforeTime === void 0) beforeTime = this._time;
		return _getLabelInDirection(this, _parsePosition(this, beforeTime), 1);
	};
	_proto2.currentLabel = function currentLabel(value) {
		return arguments.length ? this.seek(value, true) : this.previousLabel(this._time + _tinyNum);
	};
	_proto2.shiftChildren = function shiftChildren(amount, adjustLabels, ignoreBeforeTime) {
		if (ignoreBeforeTime === void 0) ignoreBeforeTime = 0;
		var child = this._first, labels = this.labels, p;
		amount = _roundPrecise(amount);
		while (child) {
			if (child._start >= ignoreBeforeTime) {
				child._start += amount;
				child._end += amount;
			}
			child = child._next;
		}
		if (adjustLabels) {
			for (p in labels) if (labels[p] >= ignoreBeforeTime) labels[p] += amount;
		}
		return _uncache(this);
	};
	_proto2.invalidate = function invalidate(soft) {
		var child = this._first;
		this._lock = 0;
		while (child) {
			child.invalidate(soft);
			child = child._next;
		}
		return _Animation.prototype.invalidate.call(this, soft);
	};
	_proto2.clear = function clear(includeLabels) {
		if (includeLabels === void 0) includeLabels = true;
		var child = this._first, next;
		while (child) {
			next = child._next;
			this.remove(child);
			child = next;
		}
		this._dp && (this._time = this._tTime = this._pTime = 0);
		includeLabels && (this.labels = {});
		return _uncache(this);
	};
	_proto2.totalDuration = function totalDuration(value) {
		var max = 0, self = this, child = self._last, prevStart = _bigNum$1, prev, start, parent;
		if (arguments.length) return self.timeScale((self._repeat < 0 ? self.duration() : self.totalDuration()) / (self.reversed() ? -value : value));
		if (self._dirty) {
			parent = self.parent;
			while (child) {
				prev = child._prev;
				child._dirty && child.totalDuration();
				start = child._start;
				if (start > prevStart && self._sort && child._ts && !self._lock) {
					self._lock = 1;
					_addToTimeline(self, child, start - child._delay, 1)._lock = 0;
				} else prevStart = start;
				if (start < 0 && child._ts) {
					max -= start;
					if (!parent && !self._dp || parent && parent.smoothChildTiming) {
						self._start += _roundPrecise(start / self._ts);
						self._time -= start;
						self._tTime -= start;
					}
					self.shiftChildren(-start, false, -Infinity);
					prevStart = 0;
				}
				child._end > max && child._ts && (max = child._end);
				child = prev;
			}
			_setDuration(self, self === _globalTimeline && self._time > max ? self._time : max, 1, 1);
			self._dirty = 0;
		}
		return self._tDur;
	};
	Timeline.updateRoot = function updateRoot(time) {
		if (_globalTimeline._ts) {
			_lazySafeRender(_globalTimeline, _parentToChildTotalTime(time, _globalTimeline));
			_lastRenderedFrame = _ticker.frame;
		}
		if (_ticker.frame >= _nextGCFrame) {
			_nextGCFrame += _config.autoSleep || 120;
			var child = _globalTimeline._first;
			if (!child || !child._ts) {
				if (_config.autoSleep && _ticker._listeners.length < 2) {
					while (child && !child._ts) child = child._next;
					child || _ticker.sleep();
				}
			}
		}
	};
	return Timeline;
}(Animation);
_setDefaults(Timeline.prototype, {
	_lock: 0,
	_hasPause: 0,
	_forcing: 0
});
var _addComplexStringPropTween = function _addComplexStringPropTween(target, prop, start, end, setter, stringFilter, funcParam) {
	var pt = new PropTween(this._pt, target, prop, 0, 1, _renderComplexString, null, setter), index = 0, matchIndex = 0, result, startNums, color, endNum, chunk, startNum, hasRandom, a;
	pt.b = start;
	pt.e = end;
	start += "";
	end += "";
	if (hasRandom = ~end.indexOf("random(")) end = _replaceRandom(end);
	if (stringFilter) {
		a = [start, end];
		stringFilter(a, target, prop);
		start = a[0];
		end = a[1];
	}
	startNums = start.match(_complexStringNumExp) || [];
	while (result = _complexStringNumExp.exec(end)) {
		endNum = result[0];
		chunk = end.substring(index, result.index);
		if (color) color = (color + 1) % 5;
		else if (chunk.substr(-5) === "rgba(") color = 1;
		if (endNum !== startNums[matchIndex++]) {
			startNum = parseFloat(startNums[matchIndex - 1]) || 0;
			pt._pt = {
				_next: pt._pt,
				p: chunk || matchIndex === 1 ? chunk : ",",
				s: startNum,
				c: endNum.charAt(1) === "=" ? _parseRelative(startNum, endNum) - startNum : parseFloat(endNum) - startNum,
				m: color && color < 4 ? Math.round : 0
			};
			index = _complexStringNumExp.lastIndex;
		}
	}
	pt.c = index < end.length ? end.substring(index, end.length) : "";
	pt.fp = funcParam;
	if (_relExp.test(end) || hasRandom) pt.e = 0;
	this._pt = pt;
	return pt;
};
var _addPropTween = function _addPropTween(target, prop, start, end, index, targets, modifier, stringFilter, funcParam, optional) {
	_isFunction(end) && (end = end(index || 0, target, targets));
	var currentValue = target[prop], parsedStart = start !== "get" ? start : !_isFunction(currentValue) ? currentValue : funcParam ? target[prop.indexOf("set") || !_isFunction(target["get" + prop.substr(3)]) ? prop : "get" + prop.substr(3)](funcParam) : target[prop](), setter = !_isFunction(currentValue) ? _setterPlain : funcParam ? _setterFuncWithParam : _setterFunc, pt;
	if (_isString(end)) {
		if (~end.indexOf("random(")) end = _replaceRandom(end);
		if (end.charAt(1) === "=") {
			pt = _parseRelative(parsedStart, end) + (getUnit(parsedStart) || 0);
			if (pt || pt === 0) end = pt;
		}
	}
	if (!optional || parsedStart !== end || _forceAllPropTweens) {
		if (!isNaN(parsedStart * end) && end !== "") {
			pt = new PropTween(this._pt, target, prop, +parsedStart || 0, end - (parsedStart || 0), typeof currentValue === "boolean" ? _renderBoolean : _renderPlain, 0, setter);
			funcParam && (pt.fp = funcParam);
			modifier && pt.modifier(modifier, this, target);
			return this._pt = pt;
		}
		!currentValue && !(prop in target) && _missingPlugin(prop, end);
		return _addComplexStringPropTween.call(this, target, prop, parsedStart, end, setter, stringFilter || _config.stringFilter, funcParam);
	}
};
var _processVars = function _processVars(vars, index, target, targets, tween) {
	_isFunction(vars) && (vars = _parseFuncOrString(vars, tween, index, target, targets));
	if (!_isObject(vars) || vars.style && vars.nodeType || _isArray(vars) || _isTypedArray(vars)) return _isString(vars) ? _parseFuncOrString(vars, tween, index, target, targets) : vars;
	var copy = {}, p;
	for (p in vars) copy[p] = _parseFuncOrString(vars[p], tween, index, target, targets);
	return copy;
};
var _checkPlugin = function _checkPlugin(property, vars, tween, index, target, targets) {
	var plugin, pt, ptLookup, i;
	if (_plugins[property] && (plugin = new _plugins[property]()).init(target, plugin.rawVars ? vars[property] : _processVars(vars[property], index, target, targets, tween), tween, index, targets) !== false) {
		tween._pt = pt = new PropTween(tween._pt, target, property, 0, 1, plugin.render, plugin, 0, plugin.priority);
		if (tween !== _quickTween) {
			ptLookup = tween._ptLookup[tween._targets.indexOf(target)];
			i = plugin._props.length;
			while (i--) ptLookup[plugin._props[i]] = pt;
		}
	}
	return plugin;
};
var _overwritingTween;
var _forceAllPropTweens;
var _initTween = function _initTween(tween, time, tTime) {
	var vars = tween.vars, ease = vars.ease, startAt = vars.startAt, immediateRender = vars.immediateRender, lazy = vars.lazy, onUpdate = vars.onUpdate, runBackwards = vars.runBackwards, yoyoEase = vars.yoyoEase, keyframes = vars.keyframes, autoRevert = vars.autoRevert, dur = tween._dur, prevStartAt = tween._startAt, targets = tween._targets, parent = tween.parent, fullTargets = parent && parent.data === "nested" ? parent.vars.targets : targets, autoOverwrite = tween._overwrite === "auto" && !_suppressOverwrites, tl = tween.timeline, reverseEase = vars.easeReverse || yoyoEase, cleanVars, i, p, pt, target, hasPriority, gsData, harness, plugin, ptLookup, index, harnessVars, overwritten;
	tl && (!keyframes || !ease) && (ease = "none");
	tween._ease = _parseEase(ease, _defaults.ease);
	tween._rEase = reverseEase && (_parseEase(reverseEase) || tween._ease);
	tween._from = !tl && !!vars.runBackwards;
	if (tween._from) tween.ratio = 1;
	if (!tl || keyframes && !vars.stagger) {
		harness = targets[0] ? _getCache(targets[0]).harness : 0;
		harnessVars = harness && vars[harness.prop];
		cleanVars = _copyExcluding(vars, _reservedProps);
		if (prevStartAt) {
			prevStartAt._zTime < 0 && prevStartAt.progress(1);
			time < 0 && runBackwards && immediateRender && !autoRevert ? prevStartAt.render(-1, true) : prevStartAt.revert(runBackwards && dur ? _revertConfigNoKill : _startAtRevertConfig);
			prevStartAt._lazy = 0;
		}
		if (startAt) {
			_removeFromParent(tween._startAt = Tween.set(targets, _setDefaults({
				data: "isStart",
				overwrite: false,
				parent,
				immediateRender: true,
				lazy: !prevStartAt && _isNotFalse(lazy),
				startAt: null,
				delay: 0,
				onUpdate: onUpdate && function() {
					return _callback(tween, "onUpdate");
				},
				stagger: 0
			}, startAt)));
			tween._startAt._dp = 0;
			tween._startAt._sat = tween;
			time < 0 && (_reverting$1 || !immediateRender && !autoRevert) && tween._startAt.revert(_revertConfigNoKill);
			if (immediateRender) {
				if (dur && time <= 0 && tTime <= 0) {
					time && (tween._zTime = time);
					return;
				}
			}
		} else if (runBackwards && dur) {
			if (!prevStartAt) {
				time && (immediateRender = false);
				p = _setDefaults({
					overwrite: false,
					data: "isFromStart",
					lazy: immediateRender && !prevStartAt && _isNotFalse(lazy),
					immediateRender,
					stagger: 0,
					parent
				}, cleanVars);
				harnessVars && (p[harness.prop] = harnessVars);
				_removeFromParent(tween._startAt = Tween.set(targets, p));
				tween._startAt._dp = 0;
				tween._startAt._sat = tween;
				time < 0 && (_reverting$1 ? tween._startAt.revert(_revertConfigNoKill) : tween._startAt.render(-1, true));
				tween._zTime = time;
				if (!immediateRender) _initTween(tween._startAt, _tinyNum, _tinyNum);
				else if (!time) return;
			}
		}
		tween._pt = tween._ptCache = 0;
		lazy = dur && _isNotFalse(lazy) || lazy && !dur;
		for (i = 0; i < targets.length; i++) {
			target = targets[i];
			gsData = target._gsap || _harness(targets)[i]._gsap;
			tween._ptLookup[i] = ptLookup = {};
			_lazyLookup[gsData.id] && _lazyTweens.length && _lazyRender();
			index = fullTargets === targets ? i : fullTargets.indexOf(target);
			if (harness && (plugin = new harness()).init(target, harnessVars || cleanVars, tween, index, fullTargets) !== false) {
				tween._pt = pt = new PropTween(tween._pt, target, plugin.name, 0, 1, plugin.render, plugin, 0, plugin.priority);
				plugin._props.forEach(function(name) {
					ptLookup[name] = pt;
				});
				plugin.priority && (hasPriority = 1);
			}
			if (!harness || harnessVars) for (p in cleanVars) if (_plugins[p] && (plugin = _checkPlugin(p, cleanVars, tween, index, target, fullTargets))) plugin.priority && (hasPriority = 1);
			else ptLookup[p] = pt = _addPropTween.call(tween, target, p, "get", cleanVars[p], index, fullTargets, 0, vars.stringFilter);
			tween._op && tween._op[i] && tween.kill(target, tween._op[i]);
			if (autoOverwrite && tween._pt) {
				_overwritingTween = tween;
				_globalTimeline.killTweensOf(target, ptLookup, tween.globalTime(time));
				overwritten = !tween.parent;
				_overwritingTween = 0;
			}
			tween._pt && lazy && (_lazyLookup[gsData.id] = 1);
		}
		hasPriority && _sortPropTweensByPriority(tween);
		tween._onInit && tween._onInit(tween);
	}
	tween._onUpdate = onUpdate;
	tween._initted = (!tween._op || tween._pt) && !overwritten;
	keyframes && time <= 0 && tl.render(_bigNum$1, true, true);
};
var _updatePropTweens = function _updatePropTweens(tween, property, value, start, startIsRelative, ratio, time, skipRecursion) {
	var ptCache = (tween._pt && tween._ptCache || (tween._ptCache = {}))[property], pt, rootPT, lookup, i;
	if (!ptCache) {
		ptCache = tween._ptCache[property] = [];
		lookup = tween._ptLookup;
		i = tween._targets.length;
		while (i--) {
			pt = lookup[i][property];
			if (pt && pt.d && pt.d._pt) {
				pt = pt.d._pt;
				while (pt && pt.p !== property && pt.fp !== property) pt = pt._next;
			}
			if (!pt) {
				_forceAllPropTweens = 1;
				tween.vars[property] = "+=0";
				_initTween(tween, time);
				_forceAllPropTweens = 0;
				return skipRecursion ? _warn(property + " not eligible for reset. Try splitting into individual properties") : 1;
			}
			ptCache.push(pt);
		}
	}
	i = ptCache.length;
	while (i--) {
		rootPT = ptCache[i];
		pt = rootPT._pt || rootPT;
		pt.s = (start || start === 0) && !startIsRelative ? start : pt.s + (start || 0) + ratio * pt.c;
		pt.c = value - pt.s;
		rootPT.e && (rootPT.e = _round(value) + getUnit(rootPT.e));
		rootPT.b && (rootPT.b = pt.s + getUnit(rootPT.b));
	}
};
var _addAliasesToVars = function _addAliasesToVars(targets, vars) {
	var harness = targets[0] ? _getCache(targets[0]).harness : 0, propertyAliases = harness && harness.aliases, copy, p, i, aliases;
	if (!propertyAliases) return vars;
	copy = _merge({}, vars);
	for (p in propertyAliases) if (p in copy) {
		aliases = propertyAliases[p].split(",");
		i = aliases.length;
		while (i--) copy[aliases[i]] = copy[p];
	}
	return copy;
};
var _parseKeyframe = function _parseKeyframe(prop, obj, allProps, easeEach) {
	var ease = obj.ease || easeEach || "power1.inOut", p, a;
	if (_isArray(obj)) {
		a = allProps[prop] || (allProps[prop] = []);
		obj.forEach(function(value, i) {
			return a.push({
				t: i / (obj.length - 1) * 100,
				v: value,
				e: ease
			});
		});
	} else for (p in obj) {
		a = allProps[p] || (allProps[p] = []);
		p === "ease" || a.push({
			t: parseFloat(prop),
			v: obj[p],
			e: ease
		});
	}
};
var _parseFuncOrString = function _parseFuncOrString(value, tween, i, target, targets) {
	return _isFunction(value) ? value.call(tween, i, target, targets) : _isString(value) && ~value.indexOf("random(") ? _replaceRandom(value) : value;
};
var _staggerTweenProps = _callbackNames + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,easeReverse,autoRevert";
var _staggerPropsToSkip = {};
_forEachName(_staggerTweenProps + ",id,stagger,delay,duration,paused,scrollTrigger", function(name) {
	return _staggerPropsToSkip[name] = 1;
});
var Tween = /*#__PURE__*/ function(_Animation2) {
	_inheritsLoose(Tween, _Animation2);
	function Tween(targets, vars, position, skipInherit) {
		var _this3;
		if (typeof vars === "number") {
			position.duration = vars;
			vars = position;
			position = null;
		}
		_this3 = _Animation2.call(this, skipInherit ? vars : _inheritDefaults(vars)) || this;
		var _this3$vars = _this3.vars, duration = _this3$vars.duration, delay = _this3$vars.delay, immediateRender = _this3$vars.immediateRender, stagger = _this3$vars.stagger, overwrite = _this3$vars.overwrite, keyframes = _this3$vars.keyframes, defaults = _this3$vars.defaults, scrollTrigger = _this3$vars.scrollTrigger, parent = vars.parent || _globalTimeline, parsedTargets = (_isArray(targets) || _isTypedArray(targets) ? _isNumber(targets[0]) : "length" in vars) ? [targets] : toArray(targets), tl, i, copy, l, p, curTarget, staggerFunc, staggerVarsToMerge;
		_this3._targets = parsedTargets.length ? _harness(parsedTargets) : _warn("GSAP target " + targets + " not found. https://gsap.com", !_config.nullTargetWarn) || [];
		_this3._ptLookup = [];
		_this3._overwrite = overwrite;
		if (keyframes || stagger || _isFuncOrString(duration) || _isFuncOrString(delay)) {
			vars = _this3.vars;
			var easeReverse = vars.easeReverse || vars.yoyoEase;
			tl = _this3.timeline = new Timeline({
				data: "nested",
				defaults: defaults || {},
				targets: parent && parent.data === "nested" ? parent.vars.targets : parsedTargets
			});
			tl.kill();
			tl.parent = tl._dp = _assertThisInitialized(_this3);
			tl._start = 0;
			if (stagger || _isFuncOrString(duration) || _isFuncOrString(delay)) {
				l = parsedTargets.length;
				staggerFunc = stagger && distribute(stagger);
				if (_isObject(stagger)) {
					for (p in stagger) if (~_staggerTweenProps.indexOf(p)) {
						staggerVarsToMerge || (staggerVarsToMerge = {});
						staggerVarsToMerge[p] = stagger[p];
					}
				}
				for (i = 0; i < l; i++) {
					copy = _copyExcluding(vars, _staggerPropsToSkip);
					copy.stagger = 0;
					easeReverse && (copy.easeReverse = easeReverse);
					staggerVarsToMerge && _merge(copy, staggerVarsToMerge);
					curTarget = parsedTargets[i];
					copy.duration = +_parseFuncOrString(duration, _assertThisInitialized(_this3), i, curTarget, parsedTargets);
					copy.delay = (+_parseFuncOrString(delay, _assertThisInitialized(_this3), i, curTarget, parsedTargets) || 0) - _this3._delay;
					if (!stagger && l === 1 && copy.delay) {
						_this3._delay = delay = copy.delay;
						_this3._start += delay;
						copy.delay = 0;
					}
					tl.to(curTarget, copy, staggerFunc ? staggerFunc(i, curTarget, parsedTargets) : 0);
					tl._ease = _easeMap.none;
				}
				tl.duration() ? duration = delay = 0 : _this3.timeline = 0;
			} else if (keyframes) {
				_inheritDefaults(_setDefaults(tl.vars.defaults, { ease: "none" }));
				tl._ease = _parseEase(keyframes.ease || vars.ease || "none");
				var time = 0, a, kf, v;
				if (_isArray(keyframes)) {
					keyframes.forEach(function(frame) {
						return tl.to(parsedTargets, frame, ">");
					});
					tl.duration();
				} else {
					copy = {};
					for (p in keyframes) p === "ease" || p === "easeEach" || _parseKeyframe(p, keyframes[p], copy, keyframes.easeEach);
					for (p in copy) {
						a = copy[p].sort(function(a, b) {
							return a.t - b.t;
						});
						time = 0;
						for (i = 0; i < a.length; i++) {
							kf = a[i];
							v = {
								ease: kf.e,
								duration: (kf.t - (i ? a[i - 1].t : 0)) / 100 * duration
							};
							v[p] = kf.v;
							tl.to(parsedTargets, v, time);
							time += v.duration;
						}
					}
					tl.duration() < duration && tl.to({}, { duration: duration - tl.duration() });
				}
			}
			duration || _this3.duration(duration = tl.duration());
		} else _this3.timeline = 0;
		if (overwrite === true && !_suppressOverwrites) {
			_overwritingTween = _assertThisInitialized(_this3);
			_globalTimeline.killTweensOf(parsedTargets);
			_overwritingTween = 0;
		}
		_addToTimeline(parent, _assertThisInitialized(_this3), position);
		vars.reversed && _this3.reverse();
		vars.paused && _this3.paused(true);
		if (immediateRender || !duration && !keyframes && _this3._start === _roundPrecise(parent._time) && _isNotFalse(immediateRender) && _hasNoPausedAncestors(_assertThisInitialized(_this3)) && parent.data !== "nested") {
			_this3._tTime = -_tinyNum;
			_this3.render(Math.max(0, -delay) || 0);
		}
		scrollTrigger && _scrollTrigger(_assertThisInitialized(_this3), scrollTrigger);
		return _this3;
	}
	var _proto3 = Tween.prototype;
	_proto3.render = function render(totalTime, suppressEvents, force) {
		var prevTime = this._time, tDur = this._tDur, dur = this._dur, isNegative = totalTime < 0, tTime = totalTime > tDur - _tinyNum && !isNegative ? tDur : totalTime < _tinyNum ? 0 : totalTime, time, pt, iteration, cycleDuration, prevIteration, isYoyo, ratio, timeline;
		if (!dur) _renderZeroDurationTween(this, totalTime, suppressEvents, force);
		else if (tTime !== this._tTime || !totalTime || force || !this._initted && this._tTime || this._startAt && this._zTime < 0 !== isNegative || this._lazy) {
			time = tTime;
			timeline = this.timeline;
			if (this._repeat) {
				cycleDuration = dur + this._rDelay;
				if (this._repeat < -1 && isNegative) return this.totalTime(cycleDuration * 100 + totalTime, suppressEvents, force);
				time = _roundPrecise(tTime % cycleDuration);
				if (tTime === tDur) {
					iteration = this._repeat;
					time = dur;
				} else {
					prevIteration = _roundPrecise(tTime / cycleDuration);
					iteration = ~~prevIteration;
					if (iteration && iteration === prevIteration) {
						time = dur;
						iteration--;
					} else if (time > dur) time = dur;
				}
				isYoyo = this._yoyo && iteration & 1;
				if (isYoyo) time = dur - time;
				prevIteration = _animationCycle(this._tTime, cycleDuration);
				if (time === prevTime && !force && this._initted && iteration === prevIteration) {
					this._tTime = tTime;
					return this;
				}
				if (iteration !== prevIteration) {
					if (this.vars.repeatRefresh && !isYoyo && !this._lock && time !== cycleDuration && this._initted) {
						this._lock = force = 1;
						this.render(_roundPrecise(cycleDuration * iteration), true).invalidate()._lock = 0;
					}
				}
			}
			if (!this._initted) {
				if (_attemptInitTween(this, isNegative ? totalTime : time, force, suppressEvents, tTime)) {
					this._tTime = 0;
					return this;
				}
				if (prevTime !== this._time && !(force && this.vars.repeatRefresh && iteration !== prevIteration)) return this;
				if (dur !== this._dur) return this.render(totalTime, suppressEvents, force);
			}
			if (this._rEase) {
				var inv = time < prevTime;
				if (inv !== this._inv) {
					var segDur = inv ? prevTime : dur - prevTime;
					this._inv = inv;
					if (this._from) this.ratio = 1 - this.ratio;
					this._invRatio = this.ratio;
					this._invTime = prevTime;
					this._invRecip = segDur ? (inv ? -1 : 1) / segDur : 0;
					this._invScale = inv ? -this.ratio : 1 - this.ratio;
					this._invEase = inv ? this._rEase : this._ease;
				}
				this.ratio = ratio = this._invRatio + this._invScale * this._invEase((time - this._invTime) * this._invRecip);
			} else this.ratio = ratio = this._ease(time / dur);
			if (this._from) this.ratio = ratio = 1 - ratio;
			this._tTime = tTime;
			this._time = time;
			if (!this._act && this._ts) {
				this._act = 1;
				this._lazy = 0;
			}
			if (!prevTime && tTime && !suppressEvents && !prevIteration) {
				_callback(this, "onStart");
				if (this._tTime !== tTime) return this;
			}
			pt = this._pt;
			while (pt) {
				pt.r(ratio, pt.d);
				pt = pt._next;
			}
			timeline && timeline.render(totalTime < 0 ? totalTime : timeline._dur * timeline._ease(time / this._dur), suppressEvents, force) || this._startAt && (this._zTime = totalTime);
			if (this._onUpdate && !suppressEvents) {
				isNegative && _rewindStartAt(this, totalTime, suppressEvents, force);
				_callback(this, "onUpdate");
			}
			this._repeat && iteration !== prevIteration && this.vars.onRepeat && !suppressEvents && this.parent && _callback(this, "onRepeat");
			if ((tTime === this._tDur || !tTime) && this._tTime === tTime) {
				isNegative && !this._onUpdate && _rewindStartAt(this, totalTime, true, true);
				(totalTime || !dur) && (tTime === this._tDur && this._ts > 0 || !tTime && this._ts < 0) && _removeFromParent(this, 1);
				if (!suppressEvents && !(isNegative && !prevTime) && (tTime || prevTime || isYoyo)) {
					_callback(this, tTime === tDur ? "onComplete" : "onReverseComplete", true);
					this._prom && !(tTime < tDur && this.timeScale() > 0) && this._prom();
				}
			}
		}
		return this;
	};
	_proto3.targets = function targets() {
		return this._targets;
	};
	_proto3.invalidate = function invalidate(soft) {
		(!soft || !this.vars.runBackwards) && (this._startAt = 0);
		this._pt = this._op = this._onUpdate = this._lazy = this.ratio = 0;
		this._ptLookup = [];
		this.timeline && this.timeline.invalidate(soft);
		return _Animation2.prototype.invalidate.call(this, soft);
	};
	_proto3.resetTo = function resetTo(property, value, start, startIsRelative, skipRecursion) {
		_tickerActive || _ticker.wake();
		this._ts || this.play();
		var time = Math.min(this._dur, (this._dp._time - this._start) * this._ts), ratio;
		this._initted || _initTween(this, time);
		ratio = this._ease(time / this._dur);
		if (_updatePropTweens(this, property, value, start, startIsRelative, ratio, time, skipRecursion)) return this.resetTo(property, value, start, startIsRelative, 1);
		_alignPlayhead(this, 0);
		this.parent || _addLinkedListItem(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0);
		return this.render(0);
	};
	_proto3.kill = function kill(targets, vars) {
		if (vars === void 0) vars = "all";
		if (!targets && (!vars || vars === "all")) {
			this._lazy = this._pt = 0;
			this.parent ? _interrupt(this) : this.scrollTrigger && this.scrollTrigger.kill(!!_reverting$1);
			return this;
		}
		if (this.timeline) {
			var tDur = this.timeline.totalDuration();
			this.timeline.killTweensOf(targets, vars, _overwritingTween && _overwritingTween.vars.overwrite !== true)._first || _interrupt(this);
			this.parent && tDur !== this.timeline.totalDuration() && _setDuration(this, this._dur * this.timeline._tDur / tDur, 0, 1);
			return this;
		}
		var parsedTargets = this._targets, killingTargets = targets ? toArray(targets) : parsedTargets, propTweenLookup = this._ptLookup, firstPT = this._pt, overwrittenProps, curLookup, curOverwriteProps, props, p, pt, i;
		if ((!vars || vars === "all") && _arraysMatch(parsedTargets, killingTargets)) {
			vars === "all" && (this._pt = 0);
			return _interrupt(this);
		}
		overwrittenProps = this._op = this._op || [];
		if (vars !== "all") {
			if (_isString(vars)) {
				p = {};
				_forEachName(vars, function(name) {
					return p[name] = 1;
				});
				vars = p;
			}
			vars = _addAliasesToVars(parsedTargets, vars);
		}
		i = parsedTargets.length;
		while (i--) if (~killingTargets.indexOf(parsedTargets[i])) {
			curLookup = propTweenLookup[i];
			if (vars === "all") {
				overwrittenProps[i] = vars;
				props = curLookup;
				curOverwriteProps = {};
			} else {
				curOverwriteProps = overwrittenProps[i] = overwrittenProps[i] || {};
				props = vars;
			}
			for (p in props) {
				pt = curLookup && curLookup[p];
				if (pt) {
					if (!("kill" in pt.d) || pt.d.kill(p) === true) _removeLinkedListItem(this, pt, "_pt");
					delete curLookup[p];
				}
				if (curOverwriteProps !== "all") curOverwriteProps[p] = 1;
			}
		}
		this._initted && !this._pt && firstPT && _interrupt(this);
		return this;
	};
	Tween.to = function to(targets, vars) {
		return new Tween(targets, vars, arguments[2]);
	};
	Tween.from = function from(targets, vars) {
		return _createTweenType(1, arguments);
	};
	Tween.delayedCall = function delayedCall(delay, callback, params, scope) {
		return new Tween(callback, 0, {
			immediateRender: false,
			lazy: false,
			overwrite: false,
			delay,
			onComplete: callback,
			onReverseComplete: callback,
			onCompleteParams: params,
			onReverseCompleteParams: params,
			callbackScope: scope
		});
	};
	Tween.fromTo = function fromTo(targets, fromVars, toVars) {
		return _createTweenType(2, arguments);
	};
	Tween.set = function set(targets, vars) {
		vars.duration = 0;
		vars.repeatDelay || (vars.repeat = 0);
		return new Tween(targets, vars);
	};
	Tween.killTweensOf = function killTweensOf(targets, props, onlyActive) {
		return _globalTimeline.killTweensOf(targets, props, onlyActive);
	};
	return Tween;
}(Animation);
_setDefaults(Tween.prototype, {
	_targets: [],
	_lazy: 0,
	_startAt: 0,
	_op: 0,
	_onInit: 0
});
_forEachName("staggerTo,staggerFrom,staggerFromTo", function(name) {
	Tween[name] = function() {
		var tl = new Timeline(), params = _slice.call(arguments, 0);
		params.splice(name === "staggerFromTo" ? 5 : 4, 0, 0);
		return tl[name].apply(tl, params);
	};
});
var _setterPlain = function _setterPlain(target, property, value) {
	return target[property] = value;
};
var _setterFunc = function _setterFunc(target, property, value) {
	return target[property](value);
};
var _setterFuncWithParam = function _setterFuncWithParam(target, property, value, data) {
	return target[property](data.fp, value);
};
var _setterAttribute = function _setterAttribute(target, property, value) {
	return target.setAttribute(property, value);
};
var _getSetter = function _getSetter(target, property) {
	return _isFunction(target[property]) ? _setterFunc : _isUndefined(target[property]) && target.setAttribute ? _setterAttribute : _setterPlain;
};
var _renderPlain = function _renderPlain(ratio, data) {
	return data.set(data.t, data.p, Math.round((data.s + data.c * ratio) * 1e6) / 1e6, data);
};
var _renderBoolean = function _renderBoolean(ratio, data) {
	return data.set(data.t, data.p, !!(data.s + data.c * ratio), data);
};
var _renderComplexString = function _renderComplexString(ratio, data) {
	var pt = data._pt, s = "";
	if (!ratio && data.b) s = data.b;
	else if (ratio === 1 && data.e) s = data.e;
	else {
		while (pt) {
			s = pt.p + (pt.m ? pt.m(pt.s + pt.c * ratio) : Math.round((pt.s + pt.c * ratio) * 1e4) / 1e4) + s;
			pt = pt._next;
		}
		s += data.c;
	}
	data.set(data.t, data.p, s, data);
};
var _renderPropTweens = function _renderPropTweens(ratio, data) {
	var pt = data._pt;
	while (pt) {
		pt.r(ratio, pt.d);
		pt = pt._next;
	}
};
var _addPluginModifier = function _addPluginModifier(modifier, tween, target, property) {
	var pt = this._pt, next;
	while (pt) {
		next = pt._next;
		pt.p === property && pt.modifier(modifier, tween, target);
		pt = next;
	}
};
var _killPropTweensOf = function _killPropTweensOf(property) {
	var pt = this._pt, hasNonDependentRemaining, next;
	while (pt) {
		next = pt._next;
		if (pt.p === property && !pt.op || pt.op === property) _removeLinkedListItem(this, pt, "_pt");
		else if (!pt.dep) hasNonDependentRemaining = 1;
		pt = next;
	}
	return !hasNonDependentRemaining;
};
var _setterWithModifier = function _setterWithModifier(target, property, value, data) {
	data.mSet(target, property, data.m.call(data.tween, value, data.mt), data);
};
var _sortPropTweensByPriority = function _sortPropTweensByPriority(parent) {
	var pt = parent._pt, next, pt2, first, last;
	while (pt) {
		next = pt._next;
		pt2 = first;
		while (pt2 && pt2.pr > pt.pr) pt2 = pt2._next;
		if (pt._prev = pt2 ? pt2._prev : last) pt._prev._next = pt;
		else first = pt;
		if (pt._next = pt2) pt2._prev = pt;
		else last = pt;
		pt = next;
	}
	parent._pt = first;
};
var PropTween = /*#__PURE__*/ function() {
	function PropTween(next, target, prop, start, change, renderer, data, setter, priority) {
		this.t = target;
		this.s = start;
		this.c = change;
		this.p = prop;
		this.r = renderer || _renderPlain;
		this.d = data || this;
		this.set = setter || _setterPlain;
		this.pr = priority || 0;
		this._next = next;
		if (next) next._prev = this;
	}
	var _proto4 = PropTween.prototype;
	_proto4.modifier = function modifier(func, tween, target) {
		this.mSet = this.mSet || this.set;
		this.set = _setterWithModifier;
		this.m = func;
		this.mt = target;
		this.tween = tween;
	};
	return PropTween;
}();
_forEachName(_callbackNames + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger,easeReverse", function(name) {
	return _reservedProps[name] = 1;
});
_globals.TweenMax = _globals.TweenLite = Tween;
_globals.TimelineLite = _globals.TimelineMax = Timeline;
_globalTimeline = new Timeline({
	sortChildren: false,
	defaults: _defaults,
	autoRemoveChildren: true,
	id: "root",
	smoothChildTiming: true
});
_config.stringFilter = _colorStringFilter;
var _media = [];
var _listeners = {};
var _emptyArray = [];
var _lastMediaTime = 0;
var _contextID = 0;
var _dispatch = function _dispatch(type) {
	return (_listeners[type] || _emptyArray).map(function(f) {
		return f();
	});
};
var _onMediaChange = function _onMediaChange() {
	var time = Date.now(), matches = [];
	if (time - _lastMediaTime > 2) {
		_dispatch("matchMediaInit");
		_media.forEach(function(c) {
			var queries = c.queries, conditions = c.conditions, match, p, anyMatch, toggled;
			for (p in queries) {
				match = _win$1.matchMedia(queries[p]).matches;
				match && (anyMatch = 1);
				if (match !== conditions[p]) {
					conditions[p] = match;
					toggled = 1;
				}
			}
			if (toggled) {
				c.revert();
				anyMatch && matches.push(c);
			}
		});
		_dispatch("matchMediaRevert");
		matches.forEach(function(c) {
			return c.onMatch(c, function(func) {
				return c.add(null, func);
			});
		});
		_lastMediaTime = time;
		_dispatch("matchMedia");
	}
};
var Context = /*#__PURE__*/ function() {
	function Context(func, scope) {
		this.selector = scope && selector(scope);
		this.data = [];
		this._r = [];
		this.isReverted = false;
		this.id = _contextID++;
		func && this.add(func);
	}
	var _proto5 = Context.prototype;
	_proto5.add = function add(name, func, scope) {
		if (_isFunction(name)) {
			scope = func;
			func = name;
			name = _isFunction;
		}
		var self = this, f = function f() {
			var prev = _context, prevSelector = self.selector, result;
			prev && prev !== self && prev.data.push(self);
			scope && (self.selector = selector(scope));
			_context = self;
			result = func.apply(self, arguments);
			_isFunction(result) && self._r.push(result);
			_context = prev;
			self.selector = prevSelector;
			self.isReverted = false;
			return result;
		};
		self.last = f;
		return name === _isFunction ? f(self, function(func) {
			return self.add(null, func);
		}) : name ? self[name] = f : f;
	};
	_proto5.ignore = function ignore(func) {
		var prev = _context;
		_context = null;
		func(this);
		_context = prev;
	};
	_proto5.getTweens = function getTweens() {
		var a = [];
		this.data.forEach(function(e) {
			return e instanceof Context ? a.push.apply(a, e.getTweens()) : e instanceof Tween && !(e.parent && e.parent.data === "nested") && a.push(e);
		});
		return a;
	};
	_proto5.clear = function clear() {
		this._r.length = this.data.length = 0;
	};
	_proto5.kill = function kill(revert, matchMedia) {
		var _this4 = this;
		if (revert) (function() {
			var tweens = _this4.getTweens(), i = _this4.data.length, t;
			while (i--) {
				t = _this4.data[i];
				if (t.data === "isFlip") {
					t.revert();
					t.getChildren(true, true, false).forEach(function(tween) {
						return tweens.splice(tweens.indexOf(tween), 1);
					});
				}
			}
			tweens.map(function(t) {
				return {
					g: t._dur || t._delay || t._sat && !t._sat.vars.immediateRender ? t.globalTime(0) : -Infinity,
					t
				};
			}).sort(function(a, b) {
				return b.g - a.g || -Infinity;
			}).forEach(function(o) {
				return o.t.revert(revert);
			});
			i = _this4.data.length;
			while (i--) {
				t = _this4.data[i];
				if (t instanceof Timeline) {
					if (t.data !== "nested") {
						t.scrollTrigger && t.scrollTrigger.revert();
						t.kill();
					}
				} else !(t instanceof Tween) && t.revert && t.revert(revert);
			}
			_this4._r.forEach(function(f) {
				return f(revert, _this4);
			});
			_this4.isReverted = true;
		})();
		else this.data.forEach(function(e) {
			return e.kill && e.kill();
		});
		this.clear();
		if (matchMedia) {
			var i = _media.length;
			while (i--) _media[i].id === this.id && _media.splice(i, 1);
		}
	};
	_proto5.revert = function revert(config) {
		this.kill(config || {});
	};
	return Context;
}();
var MatchMedia = /*#__PURE__*/ function() {
	function MatchMedia(scope) {
		this.contexts = [];
		this.scope = scope;
		_context && _context.data.push(this);
	}
	var _proto6 = MatchMedia.prototype;
	_proto6.add = function add(conditions, func, scope) {
		_isObject(conditions) || (conditions = { matches: conditions });
		var context = new Context(0, scope || this.scope), cond = context.conditions = {}, mq, p, active;
		_context && !context.selector && (context.selector = _context.selector);
		this.contexts.push(context);
		func = context.add("onMatch", func);
		context.queries = conditions;
		for (p in conditions) if (p === "all") active = 1;
		else {
			mq = _win$1.matchMedia(conditions[p]);
			if (mq) {
				_media.indexOf(context) < 0 && _media.push(context);
				(cond[p] = mq.matches) && (active = 1);
				mq.addListener ? mq.addListener(_onMediaChange) : mq.addEventListener("change", _onMediaChange);
			}
		}
		active && func(context, function(f) {
			return context.add(null, f);
		});
		return this;
	};
	_proto6.revert = function revert(config) {
		this.kill(config || {});
	};
	_proto6.kill = function kill(revert) {
		this.contexts.forEach(function(c) {
			return c.kill(revert, true);
		});
	};
	return MatchMedia;
}();
var _gsap = {
	registerPlugin: function registerPlugin() {
		for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) args[_key2] = arguments[_key2];
		args.forEach(function(config) {
			return _createPlugin(config);
		});
	},
	timeline: function timeline(vars) {
		return new Timeline(vars);
	},
	getTweensOf: function getTweensOf(targets, onlyActive) {
		return _globalTimeline.getTweensOf(targets, onlyActive);
	},
	getProperty: function getProperty(target, property, unit, uncache) {
		_isString(target) && (target = toArray(target)[0]);
		var getter = _getCache(target || {}).get, format = unit ? _passThrough : _numericIfPossible;
		unit === "native" && (unit = "");
		return !target ? target : !property ? function(property, unit, uncache) {
			return format((_plugins[property] && _plugins[property].get || getter)(target, property, unit, uncache));
		} : format((_plugins[property] && _plugins[property].get || getter)(target, property, unit, uncache));
	},
	quickSetter: function quickSetter(target, property, unit) {
		target = toArray(target);
		if (target.length > 1) {
			var setters = target.map(function(t) {
				return gsap.quickSetter(t, property, unit);
			}), l = setters.length;
			return function(value) {
				var i = l;
				while (i--) setters[i](value);
			};
		}
		target = target[0] || {};
		var Plugin = _plugins[property], cache = _getCache(target), p = cache.harness && (cache.harness.aliases || {})[property] || property, setter = Plugin ? function(value) {
			var p = new Plugin();
			_quickTween._pt = 0;
			p.init(target, unit ? value + unit : value, _quickTween, 0, [target]);
			p.render(1, p);
			_quickTween._pt && _renderPropTweens(1, _quickTween);
		} : cache.set(target, p);
		return Plugin ? setter : function(value) {
			return setter(target, p, unit ? value + unit : value, cache, 1);
		};
	},
	quickTo: function quickTo(target, property, vars) {
		var _setDefaults2;
		var tween = gsap.to(target, _setDefaults((_setDefaults2 = {}, _setDefaults2[property] = "+=0.1", _setDefaults2.paused = true, _setDefaults2.stagger = 0, _setDefaults2), vars || {})), func = function func(value, start, startIsRelative) {
			return tween.resetTo(property, value, start, startIsRelative);
		};
		func.tween = tween;
		return func;
	},
	isTweening: function isTweening(targets) {
		return _globalTimeline.getTweensOf(targets, true).length > 0;
	},
	defaults: function defaults(value) {
		value && value.ease && (value.ease = _parseEase(value.ease, _defaults.ease));
		return _mergeDeep(_defaults, value || {});
	},
	config: function config(value) {
		return _mergeDeep(_config, value || {});
	},
	registerEffect: function registerEffect(_ref3) {
		var name = _ref3.name, effect = _ref3.effect, plugins = _ref3.plugins, defaults = _ref3.defaults, extendTimeline = _ref3.extendTimeline;
		(plugins || "").split(",").forEach(function(pluginName) {
			return pluginName && !_plugins[pluginName] && !_globals[pluginName] && _warn(name + " effect requires " + pluginName + " plugin.");
		});
		_effects[name] = function(targets, vars, tl) {
			return effect(toArray(targets), _setDefaults(vars || {}, defaults), tl);
		};
		if (extendTimeline) Timeline.prototype[name] = function(targets, vars, position) {
			return this.add(_effects[name](targets, _isObject(vars) ? vars : (position = vars) && {}, this), position);
		};
	},
	registerEase: function registerEase(name, ease) {
		_easeMap[name] = _parseEase(ease);
	},
	parseEase: function parseEase(ease, defaultEase) {
		return arguments.length ? _parseEase(ease, defaultEase) : _easeMap;
	},
	getById: function getById(id) {
		return _globalTimeline.getById(id);
	},
	exportRoot: function exportRoot(vars, includeDelayedCalls) {
		if (vars === void 0) vars = {};
		var tl = new Timeline(vars), child, next;
		tl.smoothChildTiming = _isNotFalse(vars.smoothChildTiming);
		_globalTimeline.remove(tl);
		tl._dp = 0;
		tl._time = tl._tTime = _globalTimeline._time;
		child = _globalTimeline._first;
		while (child) {
			next = child._next;
			if (includeDelayedCalls || !(!child._dur && child instanceof Tween && child.vars.onComplete === child._targets[0])) _addToTimeline(tl, child, child._start - child._delay);
			child = next;
		}
		_addToTimeline(_globalTimeline, tl, 0);
		return tl;
	},
	context: function context(func, scope) {
		return func ? new Context(func, scope) : _context;
	},
	matchMedia: function matchMedia(scope) {
		return new MatchMedia(scope);
	},
	matchMediaRefresh: function matchMediaRefresh() {
		return _media.forEach(function(c) {
			var cond = c.conditions, found, p;
			for (p in cond) if (cond[p]) {
				cond[p] = false;
				found = 1;
			}
			found && c.revert();
		}) || _onMediaChange();
	},
	addEventListener: function addEventListener(type, callback) {
		var a = _listeners[type] || (_listeners[type] = []);
		~a.indexOf(callback) || a.push(callback);
	},
	removeEventListener: function removeEventListener(type, callback) {
		var a = _listeners[type], i = a && a.indexOf(callback);
		i >= 0 && a.splice(i, 1);
	},
	utils: {
		wrap,
		wrapYoyo,
		distribute,
		random,
		snap,
		normalize,
		getUnit,
		clamp,
		splitColor,
		toArray,
		selector,
		mapRange,
		pipe,
		unitize,
		interpolate,
		shuffle
	},
	install: _install,
	effects: _effects,
	ticker: _ticker,
	updateRoot: Timeline.updateRoot,
	plugins: _plugins,
	globalTimeline: _globalTimeline,
	core: {
		PropTween,
		globals: _addGlobal,
		Tween,
		Timeline,
		Animation,
		getCache: _getCache,
		_removeLinkedListItem,
		reverting: function reverting() {
			return _reverting$1;
		},
		context: function context(toAdd) {
			if (toAdd && _context) {
				_context.data.push(toAdd);
				toAdd._ctx = _context;
			}
			return _context;
		},
		suppressOverwrites: function suppressOverwrites(value) {
			return _suppressOverwrites = value;
		}
	}
};
_forEachName("to,from,fromTo,delayedCall,set,killTweensOf", function(name) {
	return _gsap[name] = Tween[name];
});
_ticker.add(Timeline.updateRoot);
_quickTween = _gsap.to({}, { duration: 0 });
var _getPluginPropTween = function _getPluginPropTween(plugin, prop) {
	var pt = plugin._pt;
	while (pt && pt.p !== prop && pt.op !== prop && pt.fp !== prop) pt = pt._next;
	return pt;
};
var _addModifiers = function _addModifiers(tween, modifiers) {
	var targets = tween._targets, p, i, pt;
	for (p in modifiers) {
		i = targets.length;
		while (i--) {
			pt = tween._ptLookup[i][p];
			if (pt && (pt = pt.d)) {
				if (pt._pt) pt = _getPluginPropTween(pt, p);
				pt && pt.modifier && pt.modifier(modifiers[p], tween, targets[i], p);
			}
		}
	}
};
var _buildModifierPlugin = function _buildModifierPlugin(name, modifier) {
	return {
		name,
		headless: 1,
		rawVars: 1,
		init: function init(target, vars, tween) {
			tween._onInit = function(tween) {
				var temp, p;
				if (_isString(vars)) {
					temp = {};
					_forEachName(vars, function(name) {
						return temp[name] = 1;
					});
					vars = temp;
				}
				if (modifier) {
					temp = {};
					for (p in vars) temp[p] = modifier(vars[p]);
					vars = temp;
				}
				_addModifiers(tween, vars);
			};
		}
	};
};
var gsap = _gsap.registerPlugin({
	name: "attr",
	init: function init(target, vars, tween, index, targets) {
		var p, pt, v;
		this.tween = tween;
		for (p in vars) {
			v = target.getAttribute(p) || "";
			pt = this.add(target, "setAttribute", (v || 0) + "", vars[p], index, targets, 0, 0, p);
			pt.op = p;
			pt.b = v;
			this._props.push(p);
		}
	},
	render: function render(ratio, data) {
		var pt = data._pt;
		while (pt) {
			_reverting$1 ? pt.set(pt.t, pt.p, pt.b, pt) : pt.r(ratio, pt.d);
			pt = pt._next;
		}
	}
}, {
	name: "endArray",
	headless: 1,
	init: function init(target, value) {
		var i = value.length;
		while (i--) this.add(target, i, target[i] || 0, value[i], 0, 0, 0, 0, 0, 1);
	}
}, _buildModifierPlugin("roundProps", _roundModifier), _buildModifierPlugin("modifiers"), _buildModifierPlugin("snap", snap)) || _gsap;
Tween.version = Timeline.version = gsap.version = "3.15.0";
_coreReady = 1;
_windowExists$1() && _wake();
_easeMap.Power0;
_easeMap.Power1;
_easeMap.Power2;
_easeMap.Power3;
_easeMap.Power4;
_easeMap.Linear;
_easeMap.Quad;
_easeMap.Cubic;
_easeMap.Quart;
_easeMap.Quint;
_easeMap.Strong;
_easeMap.Elastic;
_easeMap.Back;
_easeMap.SteppedEase;
_easeMap.Bounce;
_easeMap.Sine;
_easeMap.Expo;
_easeMap.Circ;
//#endregion
//#region ../../node_modules/gsap/CSSPlugin.js
/*!
* CSSPlugin 3.15.0
* https://gsap.com
*
* Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var _win;
var _doc;
var _docElement;
var _pluginInitted;
var _tempDiv;
var _recentSetterPlugin;
var _reverting;
var _windowExists = function _windowExists() {
	return typeof window !== "undefined";
};
var _transformProps = {};
var _RAD2DEG = 180 / Math.PI;
var _DEG2RAD = Math.PI / 180;
var _atan2 = Math.atan2;
var _bigNum = 1e8;
var _capsExp = /([A-Z])/g;
var _horizontalExp = /(left|right|width|margin|padding|x)/i;
var _complexExp = /[\s,\(]\S/;
var _propertyAliases = {
	autoAlpha: "opacity,visibility",
	scale: "scaleX,scaleY",
	alpha: "opacity"
};
var _renderCSSProp = function _renderCSSProp(ratio, data) {
	return data.set(data.t, data.p, Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u, data);
};
var _renderPropWithEnd = function _renderPropWithEnd(ratio, data) {
	return data.set(data.t, data.p, ratio === 1 ? data.e : Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u, data);
};
var _renderCSSPropWithBeginning = function _renderCSSPropWithBeginning(ratio, data) {
	return data.set(data.t, data.p, ratio ? Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u : data.b, data);
};
var _renderCSSPropWithBeginningAndEnd = function _renderCSSPropWithBeginningAndEnd(ratio, data) {
	return data.set(data.t, data.p, ratio === 1 ? data.e : ratio ? Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u : data.b, data);
};
var _renderRoundedCSSProp = function _renderRoundedCSSProp(ratio, data) {
	var value = data.s + data.c * ratio;
	data.set(data.t, data.p, ~~(value + (value < 0 ? -.5 : .5)) + data.u, data);
};
var _renderNonTweeningValue = function _renderNonTweeningValue(ratio, data) {
	return data.set(data.t, data.p, ratio ? data.e : data.b, data);
};
var _renderNonTweeningValueOnlyAtEnd = function _renderNonTweeningValueOnlyAtEnd(ratio, data) {
	return data.set(data.t, data.p, ratio !== 1 ? data.b : data.e, data);
};
var _setterCSSStyle = function _setterCSSStyle(target, property, value) {
	return target.style[property] = value;
};
var _setterCSSProp = function _setterCSSProp(target, property, value) {
	return target.style.setProperty(property, value);
};
var _setterTransform = function _setterTransform(target, property, value) {
	return target._gsap[property] = value;
};
var _setterScale = function _setterScale(target, property, value) {
	return target._gsap.scaleX = target._gsap.scaleY = value;
};
var _setterScaleWithRender = function _setterScaleWithRender(target, property, value, data, ratio) {
	var cache = target._gsap;
	cache.scaleX = cache.scaleY = value;
	cache.renderTransform(ratio, cache);
};
var _setterTransformWithRender = function _setterTransformWithRender(target, property, value, data, ratio) {
	var cache = target._gsap;
	cache[property] = value;
	cache.renderTransform(ratio, cache);
};
var _transformProp = "transform";
var _transformOriginProp = _transformProp + "Origin";
var _saveStyle = function _saveStyle(property, isNotCSS) {
	var _this = this;
	var target = this.target, style = target.style, cache = target._gsap;
	if (property in _transformProps && style) {
		this.tfm = this.tfm || {};
		if (property !== "transform") {
			property = _propertyAliases[property] || property;
			~property.indexOf(",") ? property.split(",").forEach(function(a) {
				return _this.tfm[a] = _get(target, a);
			}) : this.tfm[property] = cache.x ? cache[property] : _get(target, property);
			property === _transformOriginProp && (this.tfm.zOrigin = cache.zOrigin);
		} else return _propertyAliases.transform.split(",").forEach(function(p) {
			return _saveStyle.call(_this, p, isNotCSS);
		});
		if (this.props.indexOf(_transformProp) >= 0) return;
		if (cache.svg) {
			this.svgo = target.getAttribute("data-svg-origin");
			this.props.push(_transformOriginProp, isNotCSS, "");
		}
		property = _transformProp;
	}
	(style || isNotCSS) && this.props.push(property, isNotCSS, style[property]);
};
var _removeIndependentTransforms = function _removeIndependentTransforms(style) {
	if (style.translate) {
		style.removeProperty("translate");
		style.removeProperty("scale");
		style.removeProperty("rotate");
	}
};
var _revertStyle = function _revertStyle() {
	var props = this.props, target = this.target, style = target.style, cache = target._gsap, i, p;
	for (i = 0; i < props.length; i += 3) if (!props[i + 1]) props[i + 2] ? style[props[i]] = props[i + 2] : style.removeProperty(props[i].substr(0, 2) === "--" ? props[i] : props[i].replace(_capsExp, "-$1").toLowerCase());
	else if (props[i + 1] === 2) target[props[i]](props[i + 2]);
	else target[props[i]] = props[i + 2];
	if (this.tfm) {
		for (p in this.tfm) cache[p] = this.tfm[p];
		if (cache.svg) {
			cache.renderTransform();
			target.setAttribute("data-svg-origin", this.svgo || "");
		}
		i = _reverting();
		if ((!i || !i.isStart) && !style[_transformProp]) {
			_removeIndependentTransforms(style);
			if (cache.zOrigin && style[_transformOriginProp]) {
				style[_transformOriginProp] += " " + cache.zOrigin + "px";
				cache.zOrigin = 0;
				cache.renderTransform();
			}
			cache.uncache = 1;
		}
	}
};
var _getStyleSaver = function _getStyleSaver(target, properties) {
	var saver = {
		target,
		props: [],
		revert: _revertStyle,
		save: _saveStyle
	};
	target._gsap || gsap.core.getCache(target);
	properties && target.style && target.nodeType && properties.split(",").forEach(function(p) {
		return saver.save(p);
	});
	return saver;
};
var _supports3D;
var _createElement = function _createElement(type, ns) {
	var e = _doc.createElementNS ? _doc.createElementNS((ns || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), type) : _doc.createElement(type);
	return e && e.style ? e : _doc.createElement(type);
};
var _getComputedProperty = function _getComputedProperty(target, property, skipPrefixFallback) {
	var cs = getComputedStyle(target);
	return cs[property] || cs.getPropertyValue(property.replace(_capsExp, "-$1").toLowerCase()) || cs.getPropertyValue(property) || !skipPrefixFallback && _getComputedProperty(target, _checkPropPrefix(property) || property, 1) || "";
};
var _prefixes = "O,Moz,ms,Ms,Webkit".split(",");
var _checkPropPrefix = function _checkPropPrefix(property, element, preferPrefix) {
	var s = (element || _tempDiv).style, i = 5;
	if (property in s && !preferPrefix) return property;
	property = property.charAt(0).toUpperCase() + property.substr(1);
	while (i-- && !(_prefixes[i] + property in s));
	return i < 0 ? null : (i === 3 ? "ms" : i >= 0 ? _prefixes[i] : "") + property;
};
var _initCore = function _initCore() {
	if (_windowExists() && window.document) {
		_win = window;
		_doc = _win.document;
		_docElement = _doc.documentElement;
		_tempDiv = _createElement("div") || { style: {} };
		_createElement("div");
		_transformProp = _checkPropPrefix(_transformProp);
		_transformOriginProp = _transformProp + "Origin";
		_tempDiv.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0";
		_supports3D = !!_checkPropPrefix("perspective");
		_reverting = gsap.core.reverting;
		_pluginInitted = 1;
	}
};
var _getReparentedCloneBBox = function _getReparentedCloneBBox(target) {
	var owner = target.ownerSVGElement, svg = _createElement("svg", owner && owner.getAttribute("xmlns") || "http://www.w3.org/2000/svg"), clone = target.cloneNode(true), bbox;
	clone.style.display = "block";
	svg.appendChild(clone);
	_docElement.appendChild(svg);
	try {
		bbox = clone.getBBox();
	} catch (e) {}
	svg.removeChild(clone);
	_docElement.removeChild(svg);
	return bbox;
};
var _getAttributeFallbacks = function _getAttributeFallbacks(target, attributesArray) {
	var i = attributesArray.length;
	while (i--) if (target.hasAttribute(attributesArray[i])) return target.getAttribute(attributesArray[i]);
};
var _getBBox = function _getBBox(target) {
	var bounds, cloned;
	try {
		bounds = target.getBBox();
	} catch (error) {
		bounds = _getReparentedCloneBBox(target);
		cloned = 1;
	}
	bounds && (bounds.width || bounds.height) || cloned || (bounds = _getReparentedCloneBBox(target));
	return bounds && !bounds.width && !bounds.x && !bounds.y ? {
		x: +_getAttributeFallbacks(target, [
			"x",
			"cx",
			"x1"
		]) || 0,
		y: +_getAttributeFallbacks(target, [
			"y",
			"cy",
			"y1"
		]) || 0,
		width: 0,
		height: 0
	} : bounds;
};
var _isSVG = function _isSVG(e) {
	return !!(e.getCTM && (!e.parentNode || e.ownerSVGElement) && _getBBox(e));
};
var _removeProperty = function _removeProperty(target, property) {
	if (property) {
		var style = target.style, first2Chars;
		if (property in _transformProps && property !== _transformOriginProp) property = _transformProp;
		if (style.removeProperty) {
			first2Chars = property.substr(0, 2);
			if (first2Chars === "ms" || property.substr(0, 6) === "webkit") property = "-" + property;
			style.removeProperty(first2Chars === "--" ? property : property.replace(_capsExp, "-$1").toLowerCase());
		} else style.removeAttribute(property);
	}
};
var _addNonTweeningPT = function _addNonTweeningPT(plugin, target, property, beginning, end, onlySetAtEnd) {
	var pt = new PropTween(plugin._pt, target, property, 0, 1, onlySetAtEnd ? _renderNonTweeningValueOnlyAtEnd : _renderNonTweeningValue);
	plugin._pt = pt;
	pt.b = beginning;
	pt.e = end;
	plugin._props.push(property);
	return pt;
};
var _nonConvertibleUnits = {
	deg: 1,
	rad: 1,
	turn: 1
};
var _nonStandardLayouts = {
	grid: 1,
	flex: 1
};
var _convertToUnit = function _convertToUnit(target, property, value, unit) {
	var curValue = parseFloat(value) || 0, curUnit = (value + "").trim().substr((curValue + "").length) || "px", style = _tempDiv.style, horizontal = _horizontalExp.test(property), isRootSVG = target.tagName.toLowerCase() === "svg", measureProperty = (isRootSVG ? "client" : "offset") + (horizontal ? "Width" : "Height"), amount = 100, toPixels = unit === "px", toPercent = unit === "%", px, parent, cache, isSVG;
	if (unit === curUnit || !curValue || _nonConvertibleUnits[unit] || _nonConvertibleUnits[curUnit]) return curValue;
	curUnit !== "px" && !toPixels && (curValue = _convertToUnit(target, property, value, "px"));
	isSVG = target.getCTM && _isSVG(target);
	if ((toPercent || curUnit === "%") && (_transformProps[property] || ~property.indexOf("adius"))) {
		px = isSVG ? target.getBBox()[horizontal ? "width" : "height"] : target[measureProperty];
		return _round(toPercent ? curValue / px * amount : curValue / 100 * px);
	}
	style[horizontal ? "width" : "height"] = amount + (toPixels ? curUnit : unit);
	parent = unit !== "rem" && ~property.indexOf("adius") || unit === "em" && target.appendChild && !isRootSVG ? target : target.parentNode;
	if (isSVG) parent = (target.ownerSVGElement || {}).parentNode;
	if (!parent || parent === _doc || !parent.appendChild) parent = _doc.body;
	cache = parent._gsap;
	if (cache && toPercent && cache.width && horizontal && cache.time === _ticker.time && !cache.uncache) return _round(curValue / cache.width * amount);
	else {
		if (toPercent && (property === "height" || property === "width")) {
			var v = target.style[property];
			target.style[property] = amount + unit;
			px = target[measureProperty];
			v ? target.style[property] = v : _removeProperty(target, property);
		} else {
			(toPercent || curUnit === "%") && !_nonStandardLayouts[_getComputedProperty(parent, "display")] && (style.position = _getComputedProperty(target, "position"));
			parent === target && (style.position = "static");
			parent.appendChild(_tempDiv);
			px = _tempDiv[measureProperty];
			parent.removeChild(_tempDiv);
			style.position = "absolute";
		}
		if (horizontal && toPercent) {
			cache = _getCache(parent);
			cache.time = _ticker.time;
			cache.width = parent[measureProperty];
		}
	}
	return _round(toPixels ? px * curValue / amount : px && curValue ? amount / px * curValue : 0);
};
var _get = function _get(target, property, unit, uncache) {
	var value;
	_pluginInitted || _initCore();
	if (property in _propertyAliases && property !== "transform") {
		property = _propertyAliases[property];
		if (~property.indexOf(",")) property = property.split(",")[0];
	}
	if (_transformProps[property] && property !== "transform") {
		value = _parseTransform(target, uncache);
		value = property !== "transformOrigin" ? value[property] : value.svg ? value.origin : _firstTwoOnly(_getComputedProperty(target, _transformOriginProp)) + " " + value.zOrigin + "px";
	} else {
		value = target.style[property];
		if (!value || value === "auto" || uncache || ~(value + "").indexOf("calc(")) value = _specialProps[property] && _specialProps[property](target, property, unit) || _getComputedProperty(target, property) || _getProperty(target, property) || (property === "opacity" ? 1 : 0);
	}
	return unit && !~(value + "").trim().indexOf(" ") ? _convertToUnit(target, property, value, unit) + unit : value;
};
var _tweenComplexCSSString = function _tweenComplexCSSString(target, prop, start, end) {
	if (!start || start === "none") {
		var p = _checkPropPrefix(prop, target, 1), s = p && _getComputedProperty(target, p, 1);
		if (s && s !== start) {
			prop = p;
			start = s;
		} else if (prop === "borderColor") start = _getComputedProperty(target, "borderTopColor");
	}
	var pt = new PropTween(this._pt, target.style, prop, 0, 1, _renderComplexString), index = 0, matchIndex = 0, a, result, startValues, startNum, color, startValue, endValue, endNum, chunk, endUnit, startUnit, endValues;
	pt.b = start;
	pt.e = end;
	start += "";
	end += "";
	if (end.substring(0, 6) === "var(--") end = _getComputedProperty(target, end.substring(4, end.indexOf(")")));
	if (end === "auto") {
		startValue = target.style[prop];
		target.style[prop] = end;
		end = _getComputedProperty(target, prop) || end;
		startValue ? target.style[prop] = startValue : _removeProperty(target, prop);
	}
	a = [start, end];
	_colorStringFilter(a);
	start = a[0];
	end = a[1];
	startValues = start.match(_numWithUnitExp) || [];
	endValues = end.match(_numWithUnitExp) || [];
	if (endValues.length) {
		while (result = _numWithUnitExp.exec(end)) {
			endValue = result[0];
			chunk = end.substring(index, result.index);
			if (color) color = (color + 1) % 5;
			else if (chunk.substr(-5) === "rgba(" || chunk.substr(-5) === "hsla(") color = 1;
			if (endValue !== (startValue = startValues[matchIndex++] || "")) {
				startNum = parseFloat(startValue) || 0;
				startUnit = startValue.substr((startNum + "").length);
				endValue.charAt(1) === "=" && (endValue = _parseRelative(startNum, endValue) + startUnit);
				endNum = parseFloat(endValue);
				endUnit = endValue.substr((endNum + "").length);
				index = _numWithUnitExp.lastIndex - endUnit.length;
				if (!endUnit) {
					endUnit = endUnit || _config.units[prop] || startUnit;
					if (index === end.length) {
						end += endUnit;
						pt.e += endUnit;
					}
				}
				if (startUnit !== endUnit) startNum = _convertToUnit(target, prop, startValue, endUnit) || 0;
				pt._pt = {
					_next: pt._pt,
					p: chunk || matchIndex === 1 ? chunk : ",",
					s: startNum,
					c: endNum - startNum,
					m: color && color < 4 || prop === "zIndex" ? Math.round : 0
				};
			}
		}
		pt.c = index < end.length ? end.substring(index, end.length) : "";
	} else pt.r = prop === "display" && end === "none" ? _renderNonTweeningValueOnlyAtEnd : _renderNonTweeningValue;
	_relExp.test(end) && (pt.e = 0);
	this._pt = pt;
	return pt;
};
var _keywordToPercent = {
	top: "0%",
	bottom: "100%",
	left: "0%",
	right: "100%",
	center: "50%"
};
var _convertKeywordsToPercentages = function _convertKeywordsToPercentages(value) {
	var split = value.split(" "), x = split[0], y = split[1] || "50%";
	if (x === "top" || x === "bottom" || y === "left" || y === "right") {
		value = x;
		x = y;
		y = value;
	}
	split[0] = _keywordToPercent[x] || x;
	split[1] = _keywordToPercent[y] || y;
	return split.join(" ");
};
var _renderClearProps = function _renderClearProps(ratio, data) {
	if (data.tween && data.tween._time === data.tween._dur) {
		var target = data.t, style = target.style, props = data.u, cache = target._gsap, prop, clearTransforms, i;
		if (props === "all" || props === true) {
			style.cssText = "";
			clearTransforms = 1;
		} else {
			props = props.split(",");
			i = props.length;
			while (--i > -1) {
				prop = props[i];
				if (_transformProps[prop]) {
					clearTransforms = 1;
					prop = prop === "transformOrigin" ? _transformOriginProp : _transformProp;
				}
				_removeProperty(target, prop);
			}
		}
		if (clearTransforms) {
			_removeProperty(target, _transformProp);
			if (cache) {
				cache.svg && target.removeAttribute("transform");
				style.scale = style.rotate = style.translate = "none";
				_parseTransform(target, 1);
				cache.uncache = 1;
				_removeIndependentTransforms(style);
			}
		}
	}
};
var _specialProps = { clearProps: function clearProps(plugin, target, property, endValue, tween) {
	if (tween.data !== "isFromStart") {
		var pt = plugin._pt = new PropTween(plugin._pt, target, property, 0, 0, _renderClearProps);
		pt.u = endValue;
		pt.pr = -10;
		pt.tween = tween;
		plugin._props.push(property);
		return 1;
	}
} };
var _identity2DMatrix = [
	1,
	0,
	0,
	1,
	0,
	0
];
var _rotationalProperties = {};
var _isNullTransform = function _isNullTransform(value) {
	return value === "matrix(1, 0, 0, 1, 0, 0)" || value === "none" || !value;
};
var _getComputedTransformMatrixAsArray = function _getComputedTransformMatrixAsArray(target) {
	var matrixString = _getComputedProperty(target, _transformProp);
	return _isNullTransform(matrixString) ? _identity2DMatrix : matrixString.substr(7).match(_numExp).map(_round);
};
var _getMatrix = function _getMatrix(target, force2D) {
	var cache = target._gsap || _getCache(target), style = target.style, matrix = _getComputedTransformMatrixAsArray(target), parent, nextSibling, temp, addedToDOM;
	if (cache.svg && target.getAttribute("transform")) {
		temp = target.transform.baseVal.consolidate().matrix;
		matrix = [
			temp.a,
			temp.b,
			temp.c,
			temp.d,
			temp.e,
			temp.f
		];
		return matrix.join(",") === "1,0,0,1,0,0" ? _identity2DMatrix : matrix;
	} else if (matrix === _identity2DMatrix && !target.offsetParent && target !== _docElement && !cache.svg) {
		temp = style.display;
		style.display = "block";
		parent = target.parentNode;
		if (!parent || !target.offsetParent && !target.getBoundingClientRect().width) {
			addedToDOM = 1;
			nextSibling = target.nextElementSibling;
			_docElement.appendChild(target);
		}
		matrix = _getComputedTransformMatrixAsArray(target);
		temp ? style.display = temp : _removeProperty(target, "display");
		if (addedToDOM) nextSibling ? parent.insertBefore(target, nextSibling) : parent ? parent.appendChild(target) : _docElement.removeChild(target);
	}
	return force2D && matrix.length > 6 ? [
		matrix[0],
		matrix[1],
		matrix[4],
		matrix[5],
		matrix[12],
		matrix[13]
	] : matrix;
};
var _applySVGOrigin = function _applySVGOrigin(target, origin, originIsAbsolute, smooth, matrixArray, pluginToAddPropTweensTo) {
	var cache = target._gsap, matrix = matrixArray || _getMatrix(target, true), xOriginOld = cache.xOrigin || 0, yOriginOld = cache.yOrigin || 0, xOffsetOld = cache.xOffset || 0, yOffsetOld = cache.yOffset || 0, a = matrix[0], b = matrix[1], c = matrix[2], d = matrix[3], tx = matrix[4], ty = matrix[5], originSplit = origin.split(" "), xOrigin = parseFloat(originSplit[0]) || 0, yOrigin = parseFloat(originSplit[1]) || 0, bounds, determinant, x, y;
	if (!originIsAbsolute) {
		bounds = _getBBox(target);
		xOrigin = bounds.x + (~originSplit[0].indexOf("%") ? xOrigin / 100 * bounds.width : xOrigin);
		yOrigin = bounds.y + (~(originSplit[1] || originSplit[0]).indexOf("%") ? yOrigin / 100 * bounds.height : yOrigin);
	} else if (matrix !== _identity2DMatrix && (determinant = a * d - b * c)) {
		x = xOrigin * (d / determinant) + yOrigin * (-c / determinant) + (c * ty - d * tx) / determinant;
		y = xOrigin * (-b / determinant) + yOrigin * (a / determinant) - (a * ty - b * tx) / determinant;
		xOrigin = x;
		yOrigin = y;
	}
	if (smooth || smooth !== false && cache.smooth) {
		tx = xOrigin - xOriginOld;
		ty = yOrigin - yOriginOld;
		cache.xOffset = xOffsetOld + (tx * a + ty * c) - tx;
		cache.yOffset = yOffsetOld + (tx * b + ty * d) - ty;
	} else cache.xOffset = cache.yOffset = 0;
	cache.xOrigin = xOrigin;
	cache.yOrigin = yOrigin;
	cache.smooth = !!smooth;
	cache.origin = origin;
	cache.originIsAbsolute = !!originIsAbsolute;
	target.style[_transformOriginProp] = "0px 0px";
	if (pluginToAddPropTweensTo) {
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "xOrigin", xOriginOld, xOrigin);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "yOrigin", yOriginOld, yOrigin);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "xOffset", xOffsetOld, cache.xOffset);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "yOffset", yOffsetOld, cache.yOffset);
	}
	target.setAttribute("data-svg-origin", xOrigin + " " + yOrigin);
};
var _parseTransform = function _parseTransform(target, uncache) {
	var cache = target._gsap || new GSCache(target);
	if ("x" in cache && !uncache && !cache.uncache) return cache;
	var style = target.style, invertedScaleX = cache.scaleX < 0, px = "px", deg = "deg", cs = getComputedStyle(target), origin = _getComputedProperty(target, _transformOriginProp) || "0", x = y = z = rotation = rotationX = rotationY = skewX = skewY = perspective = 0, y, z, scaleX = scaleY = 1, scaleY, rotation, rotationX, rotationY, skewX, skewY, perspective, xOrigin, yOrigin, matrix, angle, cos, sin, a, b, c, d, a12, a22, t1, t2, t3, a13, a23, a33, a42, a43, a32;
	cache.svg = !!(target.getCTM && _isSVG(target));
	if (cs.translate) {
		if (cs.translate !== "none" || cs.scale !== "none" || cs.rotate !== "none") style[_transformProp] = (cs.translate !== "none" ? "translate3d(" + (cs.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + (cs.rotate !== "none" ? "rotate(" + cs.rotate + ") " : "") + (cs.scale !== "none" ? "scale(" + cs.scale.split(" ").join(",") + ") " : "") + (cs[_transformProp] !== "none" ? cs[_transformProp] : "");
		style.scale = style.rotate = style.translate = "none";
	}
	matrix = _getMatrix(target, cache.svg);
	if (cache.svg) {
		if (cache.uncache) {
			t2 = target.getBBox();
			origin = cache.xOrigin - t2.x + "px " + (cache.yOrigin - t2.y) + "px";
			t1 = "";
		} else t1 = !uncache && target.getAttribute("data-svg-origin");
		_applySVGOrigin(target, t1 || origin, !!t1 || cache.originIsAbsolute, cache.smooth !== false, matrix);
	}
	xOrigin = cache.xOrigin || 0;
	yOrigin = cache.yOrigin || 0;
	if (matrix !== _identity2DMatrix) {
		a = matrix[0];
		b = matrix[1];
		c = matrix[2];
		d = matrix[3];
		x = a12 = matrix[4];
		y = a22 = matrix[5];
		if (matrix.length === 6) {
			scaleX = Math.sqrt(a * a + b * b);
			scaleY = Math.sqrt(d * d + c * c);
			rotation = a || b ? _atan2(b, a) * _RAD2DEG : 0;
			skewX = c || d ? _atan2(c, d) * _RAD2DEG + rotation : 0;
			skewX && (scaleY *= Math.abs(Math.cos(skewX * _DEG2RAD)));
			if (cache.svg) {
				x -= xOrigin - (xOrigin * a + yOrigin * c);
				y -= yOrigin - (xOrigin * b + yOrigin * d);
			}
		} else {
			a32 = matrix[6];
			a42 = matrix[7];
			a13 = matrix[8];
			a23 = matrix[9];
			a33 = matrix[10];
			a43 = matrix[11];
			x = matrix[12];
			y = matrix[13];
			z = matrix[14];
			angle = _atan2(a32, a33);
			rotationX = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(-angle);
				sin = Math.sin(-angle);
				t1 = a12 * cos + a13 * sin;
				t2 = a22 * cos + a23 * sin;
				t3 = a32 * cos + a33 * sin;
				a13 = a12 * -sin + a13 * cos;
				a23 = a22 * -sin + a23 * cos;
				a33 = a32 * -sin + a33 * cos;
				a43 = a42 * -sin + a43 * cos;
				a12 = t1;
				a22 = t2;
				a32 = t3;
			}
			angle = _atan2(-c, a33);
			rotationY = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(-angle);
				sin = Math.sin(-angle);
				t1 = a * cos - a13 * sin;
				t2 = b * cos - a23 * sin;
				t3 = c * cos - a33 * sin;
				a43 = d * sin + a43 * cos;
				a = t1;
				b = t2;
				c = t3;
			}
			angle = _atan2(b, a);
			rotation = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(angle);
				sin = Math.sin(angle);
				t1 = a * cos + b * sin;
				t2 = a12 * cos + a22 * sin;
				b = b * cos - a * sin;
				a22 = a22 * cos - a12 * sin;
				a = t1;
				a12 = t2;
			}
			if (rotationX && Math.abs(rotationX) + Math.abs(rotation) > 359.9) {
				rotationX = rotation = 0;
				rotationY = 180 - rotationY;
			}
			scaleX = _round(Math.sqrt(a * a + b * b + c * c));
			scaleY = _round(Math.sqrt(a22 * a22 + a32 * a32));
			angle = _atan2(a12, a22);
			skewX = Math.abs(angle) > 2e-4 ? angle * _RAD2DEG : 0;
			perspective = a43 ? 1 / (a43 < 0 ? -a43 : a43) : 0;
		}
		if (cache.svg) {
			t1 = target.getAttribute("transform");
			cache.forceCSS = target.setAttribute("transform", "") || !_isNullTransform(_getComputedProperty(target, _transformProp));
			t1 && target.setAttribute("transform", t1);
		}
	}
	if (Math.abs(skewX) > 90 && Math.abs(skewX) < 270) {
		if (invertedScaleX) {
			scaleX *= -1;
			skewX += rotation <= 0 ? 180 : -180;
			rotation += rotation <= 0 ? 180 : -180;
		} else {
			scaleY *= -1;
			skewX += skewX <= 0 ? 180 : -180;
		}
	}
	uncache = uncache || cache.uncache;
	cache.x = x - ((cache.xPercent = x && (!uncache && cache.xPercent || (Math.round(target.offsetWidth / 2) === Math.round(-x) ? -50 : 0))) ? target.offsetWidth * cache.xPercent / 100 : 0) + px;
	cache.y = y - ((cache.yPercent = y && (!uncache && cache.yPercent || (Math.round(target.offsetHeight / 2) === Math.round(-y) ? -50 : 0))) ? target.offsetHeight * cache.yPercent / 100 : 0) + px;
	cache.z = z + px;
	cache.scaleX = _round(scaleX);
	cache.scaleY = _round(scaleY);
	cache.rotation = _round(rotation) + deg;
	cache.rotationX = _round(rotationX) + deg;
	cache.rotationY = _round(rotationY) + deg;
	cache.skewX = skewX + deg;
	cache.skewY = skewY + deg;
	cache.transformPerspective = perspective + px;
	if (cache.zOrigin = parseFloat(origin.split(" ")[2]) || !uncache && cache.zOrigin || 0) style[_transformOriginProp] = _firstTwoOnly(origin);
	cache.xOffset = cache.yOffset = 0;
	cache.force3D = _config.force3D;
	cache.renderTransform = cache.svg ? _renderSVGTransforms : _supports3D ? _renderCSSTransforms : _renderNon3DTransforms;
	cache.uncache = 0;
	return cache;
};
var _firstTwoOnly = function _firstTwoOnly(value) {
	return (value = value.split(" "))[0] + " " + value[1];
};
var _addPxTranslate = function _addPxTranslate(target, start, value) {
	var unit = getUnit(start);
	return _round(parseFloat(start) + parseFloat(_convertToUnit(target, "x", value + "px", unit))) + unit;
};
var _renderNon3DTransforms = function _renderNon3DTransforms(ratio, cache) {
	cache.z = "0px";
	cache.rotationY = cache.rotationX = "0deg";
	cache.force3D = 0;
	_renderCSSTransforms(ratio, cache);
};
var _zeroDeg = "0deg";
var _zeroPx = "0px";
var _endParenthesis = ") ";
var _renderCSSTransforms = function _renderCSSTransforms(ratio, cache) {
	var _ref = cache || this, xPercent = _ref.xPercent, yPercent = _ref.yPercent, x = _ref.x, y = _ref.y, z = _ref.z, rotation = _ref.rotation, rotationY = _ref.rotationY, rotationX = _ref.rotationX, skewX = _ref.skewX, skewY = _ref.skewY, scaleX = _ref.scaleX, scaleY = _ref.scaleY, transformPerspective = _ref.transformPerspective, force3D = _ref.force3D, target = _ref.target, zOrigin = _ref.zOrigin, transforms = "", use3D = force3D === "auto" && ratio && ratio !== 1 || force3D === true;
	if (zOrigin && (rotationX !== _zeroDeg || rotationY !== _zeroDeg)) {
		var angle = parseFloat(rotationY) * _DEG2RAD, a13 = Math.sin(angle), a33 = Math.cos(angle), cos;
		angle = parseFloat(rotationX) * _DEG2RAD;
		cos = Math.cos(angle);
		x = _addPxTranslate(target, x, a13 * cos * -zOrigin);
		y = _addPxTranslate(target, y, -Math.sin(angle) * -zOrigin);
		z = _addPxTranslate(target, z, a33 * cos * -zOrigin + zOrigin);
	}
	if (transformPerspective !== _zeroPx) transforms += "perspective(" + transformPerspective + _endParenthesis;
	if (xPercent || yPercent) transforms += "translate(" + xPercent + "%, " + yPercent + "%) ";
	if (use3D || x !== _zeroPx || y !== _zeroPx || z !== _zeroPx) transforms += z !== _zeroPx || use3D ? "translate3d(" + x + ", " + y + ", " + z + ") " : "translate(" + x + ", " + y + _endParenthesis;
	if (rotation !== _zeroDeg) transforms += "rotate(" + rotation + _endParenthesis;
	if (rotationY !== _zeroDeg) transforms += "rotateY(" + rotationY + _endParenthesis;
	if (rotationX !== _zeroDeg) transforms += "rotateX(" + rotationX + _endParenthesis;
	if (skewX !== _zeroDeg || skewY !== _zeroDeg) transforms += "skew(" + skewX + ", " + skewY + _endParenthesis;
	if (scaleX !== 1 || scaleY !== 1) transforms += "scale(" + scaleX + ", " + scaleY + _endParenthesis;
	target.style[_transformProp] = transforms || "translate(0, 0)";
};
var _renderSVGTransforms = function _renderSVGTransforms(ratio, cache) {
	var _ref2 = cache || this, xPercent = _ref2.xPercent, yPercent = _ref2.yPercent, x = _ref2.x, y = _ref2.y, rotation = _ref2.rotation, skewX = _ref2.skewX, skewY = _ref2.skewY, scaleX = _ref2.scaleX, scaleY = _ref2.scaleY, target = _ref2.target, xOrigin = _ref2.xOrigin, yOrigin = _ref2.yOrigin, xOffset = _ref2.xOffset, yOffset = _ref2.yOffset, forceCSS = _ref2.forceCSS, tx = parseFloat(x), ty = parseFloat(y), a11, a21, a12, a22, temp;
	rotation = parseFloat(rotation);
	skewX = parseFloat(skewX);
	skewY = parseFloat(skewY);
	if (skewY) {
		skewY = parseFloat(skewY);
		skewX += skewY;
		rotation += skewY;
	}
	if (rotation || skewX) {
		rotation *= _DEG2RAD;
		skewX *= _DEG2RAD;
		a11 = Math.cos(rotation) * scaleX;
		a21 = Math.sin(rotation) * scaleX;
		a12 = Math.sin(rotation - skewX) * -scaleY;
		a22 = Math.cos(rotation - skewX) * scaleY;
		if (skewX) {
			skewY *= _DEG2RAD;
			temp = Math.tan(skewX - skewY);
			temp = Math.sqrt(1 + temp * temp);
			a12 *= temp;
			a22 *= temp;
			if (skewY) {
				temp = Math.tan(skewY);
				temp = Math.sqrt(1 + temp * temp);
				a11 *= temp;
				a21 *= temp;
			}
		}
		a11 = _round(a11);
		a21 = _round(a21);
		a12 = _round(a12);
		a22 = _round(a22);
	} else {
		a11 = scaleX;
		a22 = scaleY;
		a21 = a12 = 0;
	}
	if (tx && !~(x + "").indexOf("px") || ty && !~(y + "").indexOf("px")) {
		tx = _convertToUnit(target, "x", x, "px");
		ty = _convertToUnit(target, "y", y, "px");
	}
	if (xOrigin || yOrigin || xOffset || yOffset) {
		tx = _round(tx + xOrigin - (xOrigin * a11 + yOrigin * a12) + xOffset);
		ty = _round(ty + yOrigin - (xOrigin * a21 + yOrigin * a22) + yOffset);
	}
	if (xPercent || yPercent) {
		temp = target.getBBox();
		tx = _round(tx + xPercent / 100 * temp.width);
		ty = _round(ty + yPercent / 100 * temp.height);
	}
	temp = "matrix(" + a11 + "," + a21 + "," + a12 + "," + a22 + "," + tx + "," + ty + ")";
	target.setAttribute("transform", temp);
	forceCSS && (target.style[_transformProp] = temp);
};
var _addRotationalPropTween = function _addRotationalPropTween(plugin, target, property, startNum, endValue) {
	var cap = 360, isString = _isString(endValue), change = parseFloat(endValue) * (isString && ~endValue.indexOf("rad") ? _RAD2DEG : 1) - startNum, finalValue = startNum + change + "deg", direction, pt;
	if (isString) {
		direction = endValue.split("_")[1];
		if (direction === "short") {
			change %= cap;
			if (change !== change % (cap / 2)) change += change < 0 ? cap : -cap;
		}
		if (direction === "cw" && change < 0) change = (change + cap * _bigNum) % cap - ~~(change / cap) * cap;
		else if (direction === "ccw" && change > 0) change = (change - cap * _bigNum) % cap - ~~(change / cap) * cap;
	}
	plugin._pt = pt = new PropTween(plugin._pt, target, property, startNum, change, _renderPropWithEnd);
	pt.e = finalValue;
	pt.u = "deg";
	plugin._props.push(property);
	return pt;
};
var _assign = function _assign(target, source) {
	for (var p in source) target[p] = source[p];
	return target;
};
var _addRawTransformPTs = function _addRawTransformPTs(plugin, transforms, target) {
	var startCache = _assign({}, target._gsap), exclude = "perspective,force3D,transformOrigin,svgOrigin", style = target.style, endCache, p, startValue, endValue, startNum, endNum, startUnit, endUnit;
	if (startCache.svg) {
		startValue = target.getAttribute("transform");
		target.setAttribute("transform", "");
		style[_transformProp] = transforms;
		endCache = _parseTransform(target, 1);
		_removeProperty(target, _transformProp);
		target.setAttribute("transform", startValue);
	} else {
		startValue = getComputedStyle(target)[_transformProp];
		style[_transformProp] = transforms;
		endCache = _parseTransform(target, 1);
		style[_transformProp] = startValue;
	}
	for (p in _transformProps) {
		startValue = startCache[p];
		endValue = endCache[p];
		if (startValue !== endValue && exclude.indexOf(p) < 0) {
			startUnit = getUnit(startValue);
			endUnit = getUnit(endValue);
			startNum = startUnit !== endUnit ? _convertToUnit(target, p, startValue, endUnit) : parseFloat(startValue);
			endNum = parseFloat(endValue);
			plugin._pt = new PropTween(plugin._pt, endCache, p, startNum, endNum - startNum, _renderCSSProp);
			plugin._pt.u = endUnit || 0;
			plugin._props.push(p);
		}
	}
	_assign(endCache, startCache);
};
_forEachName("padding,margin,Width,Radius", function(name, index) {
	var t = "Top", r = "Right", b = "Bottom", l = "Left", props = (index < 3 ? [
		t,
		r,
		b,
		l
	] : [
		t + l,
		t + r,
		b + r,
		b + l
	]).map(function(side) {
		return index < 2 ? name + side : "border" + side + name;
	});
	_specialProps[index > 1 ? "border" + name : name] = function(plugin, target, property, endValue, tween) {
		var a, vars;
		if (arguments.length < 4) {
			a = props.map(function(prop) {
				return _get(plugin, prop, property);
			});
			vars = a.join(" ");
			return vars.split(a[0]).length === 5 ? a[0] : vars;
		}
		a = (endValue + "").split(" ");
		vars = {};
		props.forEach(function(prop, i) {
			return vars[prop] = a[i] = a[i] || a[(i - 1) / 2 | 0];
		});
		plugin.init(target, vars, tween);
	};
});
var CSSPlugin = {
	name: "css",
	register: _initCore,
	targetTest: function targetTest(target) {
		return target.style && target.nodeType;
	},
	init: function init(target, vars, tween, index, targets) {
		var props = this._props, style = target.style, startAt = tween.vars.startAt, startValue, endValue, endNum, startNum, type, specialProp, p, startUnit, endUnit, relative, isTransformRelated, transformPropTween, cache, smooth, hasPriority, inlineProps, finalTransformValue;
		_pluginInitted || _initCore();
		this.styles = this.styles || _getStyleSaver(target);
		inlineProps = this.styles.props;
		this.tween = tween;
		for (p in vars) {
			if (p === "autoRound") continue;
			endValue = vars[p];
			if (_plugins[p] && _checkPlugin(p, vars, tween, index, target, targets)) continue;
			type = typeof endValue;
			specialProp = _specialProps[p];
			if (type === "function") {
				endValue = endValue.call(tween, index, target, targets);
				type = typeof endValue;
			}
			if (type === "string" && ~endValue.indexOf("random(")) endValue = _replaceRandom(endValue);
			if (specialProp) specialProp(this, target, p, endValue, tween) && (hasPriority = 1);
			else if (p.substr(0, 2) === "--") {
				startValue = (getComputedStyle(target).getPropertyValue(p) + "").trim();
				endValue += "";
				_colorExp.lastIndex = 0;
				if (!_colorExp.test(startValue)) {
					startUnit = getUnit(startValue);
					endUnit = getUnit(endValue);
					endUnit ? startUnit !== endUnit && (startValue = _convertToUnit(target, p, startValue, endUnit) + endUnit) : startUnit && (endValue += startUnit);
				}
				this.add(style, "setProperty", startValue, endValue, index, targets, 0, 0, p);
				props.push(p);
				inlineProps.push(p, 0, style[p]);
			} else if (type !== "undefined") {
				if (startAt && p in startAt) {
					startValue = typeof startAt[p] === "function" ? startAt[p].call(tween, index, target, targets) : startAt[p];
					_isString(startValue) && ~startValue.indexOf("random(") && (startValue = _replaceRandom(startValue));
					getUnit(startValue + "") || startValue === "auto" || (startValue += _config.units[p] || getUnit(_get(target, p)) || "");
					(startValue + "").charAt(1) === "=" && (startValue = _get(target, p));
				} else startValue = _get(target, p);
				startNum = parseFloat(startValue);
				relative = type === "string" && endValue.charAt(1) === "=" && endValue.substr(0, 2);
				relative && (endValue = endValue.substr(2));
				endNum = parseFloat(endValue);
				if (p in _propertyAliases) {
					if (p === "autoAlpha") {
						if (startNum === 1 && _get(target, "visibility") === "hidden" && endNum) startNum = 0;
						inlineProps.push("visibility", 0, style.visibility);
						_addNonTweeningPT(this, style, "visibility", startNum ? "inherit" : "hidden", endNum ? "inherit" : "hidden", !endNum);
					}
					if (p !== "scale" && p !== "transform") {
						p = _propertyAliases[p];
						~p.indexOf(",") && (p = p.split(",")[0]);
					}
				}
				isTransformRelated = p in _transformProps;
				if (isTransformRelated) {
					this.styles.save(p);
					finalTransformValue = endValue;
					if (type === "string" && endValue.substring(0, 6) === "var(--") {
						endValue = _getComputedProperty(target, endValue.substring(4, endValue.indexOf(")")));
						if (endValue.substring(0, 5) === "calc(") {
							var origPerspective = target.style.perspective;
							target.style.perspective = endValue;
							endValue = _getComputedProperty(target, "perspective");
							origPerspective ? target.style.perspective = origPerspective : _removeProperty(target, "perspective");
						}
						endNum = parseFloat(endValue);
					}
					if (!transformPropTween) {
						cache = target._gsap;
						cache.renderTransform && !vars.parseTransform || _parseTransform(target, vars.parseTransform);
						smooth = vars.smoothOrigin !== false && cache.smooth;
						transformPropTween = this._pt = new PropTween(this._pt, style, _transformProp, 0, 1, cache.renderTransform, cache, 0, -1);
						transformPropTween.dep = 1;
					}
					if (p === "scale") {
						this._pt = new PropTween(this._pt, cache, "scaleY", cache.scaleY, (relative ? _parseRelative(cache.scaleY, relative + endNum) : endNum) - cache.scaleY || 0, _renderCSSProp);
						this._pt.u = 0;
						props.push("scaleY", p);
						p += "X";
					} else if (p === "transformOrigin") {
						inlineProps.push(_transformOriginProp, 0, style[_transformOriginProp]);
						endValue = _convertKeywordsToPercentages(endValue);
						if (cache.svg) _applySVGOrigin(target, endValue, 0, smooth, 0, this);
						else {
							endUnit = parseFloat(endValue.split(" ")[2]) || 0;
							endUnit !== cache.zOrigin && _addNonTweeningPT(this, cache, "zOrigin", cache.zOrigin, endUnit);
							_addNonTweeningPT(this, style, p, _firstTwoOnly(startValue), _firstTwoOnly(endValue));
						}
						continue;
					} else if (p === "svgOrigin") {
						_applySVGOrigin(target, endValue, 1, smooth, 0, this);
						continue;
					} else if (p in _rotationalProperties) {
						_addRotationalPropTween(this, cache, p, startNum, relative ? _parseRelative(startNum, relative + endValue) : endValue);
						continue;
					} else if (p === "smoothOrigin") {
						_addNonTweeningPT(this, cache, "smooth", cache.smooth, endValue);
						continue;
					} else if (p === "force3D") {
						cache[p] = endValue;
						continue;
					} else if (p === "transform") {
						_addRawTransformPTs(this, endValue, target);
						continue;
					}
				} else if (!(p in style)) p = _checkPropPrefix(p) || p;
				if (isTransformRelated || (endNum || endNum === 0) && (startNum || startNum === 0) && !_complexExp.test(endValue) && p in style) {
					startUnit = (startValue + "").substr((startNum + "").length);
					endNum || (endNum = 0);
					endUnit = getUnit(endValue) || (p in _config.units ? _config.units[p] : startUnit);
					startUnit !== endUnit && (startNum = _convertToUnit(target, p, startValue, endUnit));
					this._pt = new PropTween(this._pt, isTransformRelated ? cache : style, p, startNum, (relative ? _parseRelative(startNum, relative + endNum) : endNum) - startNum, !isTransformRelated && (endUnit === "px" || p === "zIndex") && vars.autoRound !== false ? _renderRoundedCSSProp : _renderCSSProp);
					this._pt.u = endUnit || 0;
					if (isTransformRelated && finalTransformValue !== endValue) {
						this._pt.b = startValue;
						this._pt.e = finalTransformValue;
						this._pt.r = _renderCSSPropWithBeginningAndEnd;
					} else if (startUnit !== endUnit && endUnit !== "%") {
						this._pt.b = startValue;
						this._pt.r = _renderCSSPropWithBeginning;
					}
				} else if (!(p in style)) {
					if (p in target) this.add(target, p, startValue || target[p], relative ? relative + endValue : endValue, index, targets);
					else if (p !== "parseTransform") {
						_missingPlugin(p, endValue);
						continue;
					}
				} else _tweenComplexCSSString.call(this, target, p, startValue, relative ? relative + endValue : endValue);
				isTransformRelated || (p in style ? inlineProps.push(p, 0, style[p]) : typeof target[p] === "function" ? inlineProps.push(p, 2, target[p]()) : inlineProps.push(p, 1, startValue || target[p]));
				props.push(p);
			}
		}
		hasPriority && _sortPropTweensByPriority(this);
	},
	render: function render(ratio, data) {
		if (data.tween._time || !_reverting()) {
			var pt = data._pt;
			while (pt) {
				pt.r(ratio, pt.d);
				pt = pt._next;
			}
		} else data.styles.revert();
	},
	get: _get,
	aliases: _propertyAliases,
	getSetter: function getSetter(target, property, plugin) {
		var p = _propertyAliases[property];
		p && p.indexOf(",") < 0 && (property = p);
		return property in _transformProps && property !== _transformOriginProp && (target._gsap.x || _get(target, "x")) ? plugin && _recentSetterPlugin === plugin ? property === "scale" ? _setterScale : _setterTransform : (_recentSetterPlugin = plugin || {}) && (property === "scale" ? _setterScaleWithRender : _setterTransformWithRender) : target.style && !_isUndefined(target.style[property]) ? _setterCSSStyle : ~property.indexOf("-") ? _setterCSSProp : _getSetter(target, property);
	},
	core: {
		_removeProperty,
		_getMatrix
	}
};
gsap.utils.checkPrefix = _checkPropPrefix;
gsap.core.getStyleSaver = _getStyleSaver;
(function(positionAndScale, rotation, others, aliases) {
	var all = _forEachName(positionAndScale + "," + rotation + "," + others, function(name) {
		_transformProps[name] = 1;
	});
	_forEachName(rotation, function(name) {
		_config.units[name] = "deg";
		_rotationalProperties[name] = 1;
	});
	_propertyAliases[all[13]] = positionAndScale + "," + rotation;
	_forEachName(aliases, function(name) {
		var split = name.split(":");
		_propertyAliases[split[1]] = all[split[0]];
	});
})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");
_forEachName("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(name) {
	_config.units[name] = "px";
});
gsap.registerPlugin(CSSPlugin);
//#endregion
//#region ../../node_modules/gsap/index.js
var gsapWithCSS = gsap.registerPlugin(CSSPlugin) || gsap;
gsapWithCSS.core.Tween;
//#endregion
//#region ../scene-model/src/paint.ts
function stopColor(stop) {
	const opacity = Math.max(0, Math.min(1, stop.opacity));
	const match = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(stop.color);
	if (match) return `rgba(${Number.parseInt(match[1], 16)}, ${Number.parseInt(match[2], 16)}, ${Number.parseInt(match[3], 16)}, ${opacity})`;
	return opacity >= 1 ? stop.color : `color-mix(in srgb, ${stop.color} ${opacity * 100}%, transparent)`;
}
function paintToCss(paint) {
	if (typeof paint === "string") return paint;
	const stops = [...paint.stops].sort((a, b) => a.offset - b.offset).map((stop) => `${stopColor(stop)} ${Math.max(0, Math.min(1, stop.offset)) * 100}%`).join(", ");
	if (paint.type === "radial") return `radial-gradient(circle, ${stops})`;
	if (paint.type === "conic") return `conic-gradient(from ${paint.angle}deg, ${stops})`;
	return `linear-gradient(${paint.angle}deg, ${stops})`;
}
//#endregion
//#region ../scene-model/src/layerEffects.ts
function colorWithOpacity(color, opacity) {
	const match = /^#([0-9a-f]{6})$/i.exec(color);
	if (!match) return color;
	const value = Number.parseInt(match[1], 16);
	return `rgba(${value >> 16 & 255}, ${value >> 8 & 255}, ${value & 255}, ${opacity})`;
}
function layerEffectsToCssFilter(effects) {
	const filters = [];
	if (effects.blur > 0) filters.push(`blur(${effects.blur}px)`);
	if (effects.dropShadowEnabled) filters.push(`drop-shadow(${effects.dropShadowOffsetX}px ${effects.dropShadowOffsetY}px ${effects.dropShadowBlur}px ${colorWithOpacity(effects.dropShadowColor, effects.dropShadowOpacity)})`);
	return filters.length > 0 ? filters.join(" ") : "none";
}
//#endregion
//#region ../scene-model/src/layerAnimation.ts
var TRANSFORM_ANIMATION_PROPERTIES = [
	"x",
	"y",
	"width",
	"height",
	"rotation",
	"opacity",
	"transformOriginX",
	"transformOriginY"
];
var EFFECT_ANIMATION_PROPERTIES = [
	"blur",
	"dropShadowOpacity",
	"dropShadowOffsetX",
	"dropShadowOffsetY",
	"dropShadowBlur"
];
[...TRANSFORM_ANIMATION_PROPERTIES, ...EFFECT_ANIMATION_PROPERTIES];
var GRADIENT_STOP_OFFSET_PROPERTY = /^fill\.stops\[(0|[1-9]\d*)\]\.offset$/;
function gradientStopOffsetProperty(index) {
	if (!Number.isInteger(index) || index < 0) throw new Error("Gradient stop index must be non-negative.");
	return `fill.stops[${index}].offset`;
}
function gradientStopIndexForProperty(property) {
	const match = GRADIENT_STOP_OFFSET_PROPERTY.exec(property);
	return match ? Number(match[1]) : null;
}
function isGradientStopOffsetProperty(property) {
	return gradientStopIndexForProperty(property) !== null;
}
function bounceOut(progress) {
	const n1 = 7.5625;
	const d1 = 2.75;
	if (progress < 1 / d1) return n1 * progress * progress;
	if (progress < 2 / d1) {
		const shifted = progress - 1.5 / d1;
		return n1 * shifted * shifted + .75;
	}
	if (progress < 2.5 / d1) {
		const shifted = progress - 2.25 / d1;
		return n1 * shifted * shifted + .9375;
	}
	const shifted = progress - 2.625 / d1;
	return n1 * shifted * shifted + .984375;
}
/** Shared deterministic easing sampler used by editor evaluation and the GSAP runtime. */
function easedProgress(progress, easing) {
	const inverse = 1 - progress;
	switch (easing) {
		case "linear": return progress;
		case "ease-in":
		case "quad-in": return progress * progress;
		case "ease-out":
		case "quad-out": return 1 - (1 - progress) * (1 - progress);
		case "ease-in-out":
		case "quad-in-out": return progress < .5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
		case "cubic-in": return progress ** 3;
		case "cubic-out": return 1 - inverse ** 3;
		case "cubic-in-out": return progress < .5 ? 4 * progress ** 3 : 1 - (-2 * progress + 2) ** 3 / 2;
		case "quart-in": return progress ** 4;
		case "quart-out": return 1 - inverse ** 4;
		case "quart-in-out": return progress < .5 ? 8 * progress ** 4 : 1 - (-2 * progress + 2) ** 4 / 2;
		case "quint-in": return progress ** 5;
		case "quint-out": return 1 - inverse ** 5;
		case "quint-in-out": return progress < .5 ? 16 * progress ** 5 : 1 - (-2 * progress + 2) ** 5 / 2;
		case "sine-in": return 1 - Math.cos(progress * Math.PI / 2);
		case "sine-out": return Math.sin(progress * Math.PI / 2);
		case "sine-in-out": return -(Math.cos(Math.PI * progress) - 1) / 2;
		case "expo-in": return progress === 0 ? 0 : 2 ** (10 * progress - 10);
		case "expo-out": return progress === 1 ? 1 : 1 - 2 ** (-10 * progress);
		case "expo-in-out":
			if (progress === 0 || progress === 1) return progress;
			return progress < .5 ? 2 ** (20 * progress - 10) / 2 : (2 - 2 ** (-20 * progress + 10)) / 2;
		case "circ-in": return 1 - Math.sqrt(1 - progress ** 2);
		case "circ-out": return Math.sqrt(1 - (progress - 1) ** 2);
		case "circ-in-out": return progress < .5 ? (1 - Math.sqrt(1 - (2 * progress) ** 2)) / 2 : (Math.sqrt(1 - (-2 * progress + 2) ** 2) + 1) / 2;
		case "back-in": return 2.70158 * progress ** 3 - 1.70158 * progress ** 2;
		case "back-out": return 1 + 2.70158 * (progress - 1) ** 3 + 1.70158 * (progress - 1) ** 2;
		case "back-in-out": {
			const c2 = 2.5949095;
			return progress < .5 ? (2 * progress) ** 2 * (7.189819 * progress - c2) / 2 : ((2 * progress - 2) ** 2 * (3.5949095 * (progress * 2 - 2) + c2) + 2) / 2;
		}
		case "bounce-in": return 1 - bounceOut(1 - progress);
		case "bounce-out": return bounceOut(progress);
		case "bounce-in-out": return progress < .5 ? (1 - bounceOut(1 - 2 * progress)) / 2 : (1 + bounceOut(2 * progress - 1)) / 2;
		case "elastic-in": {
			if (progress === 0 || progress === 1) return progress;
			const c4 = 2 * Math.PI / 3;
			return -(2 ** (10 * progress - 10)) * Math.sin((progress * 10 - 10.75) * c4);
		}
		case "elastic-out": {
			if (progress === 0 || progress === 1) return progress;
			const c4 = 2 * Math.PI / 3;
			return 2 ** (-10 * progress) * Math.sin((progress * 10 - .75) * c4) + 1;
		}
		case "elastic-in-out": {
			if (progress === 0 || progress === 1) return progress;
			const c5 = 2 * Math.PI / 4.5;
			return progress < .5 ? -(2 ** (20 * progress - 10) * Math.sin((20 * progress - 11.125) * c5)) / 2 : 2 ** (-20 * progress + 10) * Math.sin((20 * progress - 11.125) * c5) / 2 + 1;
		}
	}
}
/** CSS cubic-bezier sampler: solve x(t)=progress, then return y(t). */
function cubicBezierProgress(progress, curve) {
	const sample = (t, a, b) => {
		const inverse = 1 - t;
		return 3 * inverse * inverse * t * a + 3 * inverse * t * t * b + t * t * t;
	};
	let low = 0;
	let high = 1;
	let t = progress;
	for (let index = 0; index < 14; index++) {
		const x = sample(t, curve.x1, curve.x2);
		if (Math.abs(x - progress) < 1e-5) break;
		if (x < progress) low = t;
		else high = t;
		t = (low + high) / 2;
	}
	return sample(t, curve.y1, curve.y2);
}
function sortLayerPropertyKeyframes(keyframes) {
	return [...keyframes].sort((a, b) => a.frame - b.frame || a.id.localeCompare(b.id));
}
function getTrackValueAtFrame(keyframes, frame, fallback) {
	const sorted = sortLayerPropertyKeyframes(keyframes);
	const first = sorted[0];
	if (!first) return fallback;
	if (frame <= first.frame) return first.value;
	const last = sorted.at(-1);
	if (frame >= last.frame) return last.value;
	const nextIndex = sorted.findIndex((keyframe) => keyframe.frame >= frame);
	const next = sorted[nextIndex];
	if (next.frame === frame) return next.value;
	const previous = sorted[nextIndex - 1];
	const rawProgress = (frame - previous.frame) / (next.frame - previous.frame);
	const progress = next.curve ? cubicBezierProgress(rawProgress, next.curve) : easedProgress(rawProgress, next.easing);
	return previous.value + (next.value - previous.value) * progress;
}
/** Applies canonical stop-offset tracks without mutating the authored or data-bound paint. */
function getPaintAtFrame(paint, tracks, frame) {
	if (typeof paint === "string") return paint;
	return {
		...paint,
		stops: paint.stops.map((stop, index) => {
			const offset = getTrackValueAtFrame(tracks[gradientStopOffsetProperty(index)] ?? [], frame, stop.offset);
			return {
				...stop,
				offset: Math.max(0, Math.min(1, offset))
			};
		})
	};
}
//#endregion
//#region ../scene-model/src/loopAnimation.ts
/** Local clip position derived from absolute elapsed frames; never advances by mutable ticks. */
function getLoopFrameAtElapsed(loop, elapsedFrames) {
	const duration = Math.max(1, Math.round(loop.durationFrames));
	const shifted = Math.max(0, elapsedFrames + Math.round(loop.phaseOffsetFrames));
	if (loop.repeatCount !== null && shifted >= duration * Math.max(1, loop.repeatCount)) return duration;
	return (shifted % duration + duration) % duration;
}
//#endregion
//#region ../scene-model/src/clipping.ts
var EPSILON = 1e-6;
var rounded = (value) => Math.round(value * 1e3) / 1e3;
var pointText = (point) => `${rounded(point.x)} ${rounded(point.y)}`;
function localToWorld(point, transform) {
	const originX = transform.transformOriginX * transform.width;
	const originY = transform.transformOriginY * transform.height;
	const radians = transform.rotation * Math.PI / 180;
	const cosine = Math.cos(radians);
	const sine = Math.sin(radians);
	const x = point.x - originX;
	const y = point.y - originY;
	return {
		x: transform.x + originX + x * cosine - y * sine,
		y: transform.y + originY + x * sine + y * cosine
	};
}
function worldToLocal(point, transform) {
	const originX = transform.transformOriginX * transform.width;
	const originY = transform.transformOriginY * transform.height;
	const radians = -transform.rotation * Math.PI / 180;
	const cosine = Math.cos(radians);
	const sine = Math.sin(radians);
	const x = point.x - transform.x - originX;
	const y = point.y - transform.y - originY;
	return {
		x: originX + x * cosine - y * sine,
		y: originY + x * sine + y * cosine
	};
}
function parentPointInChild(point, child, parent) {
	return worldToLocal(localToWorld(point, parent), child);
}
/** SVG path in the child's local coordinate system for a transformed rounded parent rectangle. */
function clipPathSvgForParentBounds(child, parent, borderRadius = 0) {
	const radius = Math.max(0, Math.min(borderRadius, parent.width / 2, parent.height / 2));
	const convert = (x, y) => parentPointInChild({
		x,
		y
	}, child, parent);
	const topLeftStart = convert(radius, 0);
	const topRightStart = convert(parent.width - radius, 0);
	const topRightControl = convert(parent.width, 0);
	const topRightEnd = convert(parent.width, radius);
	const bottomRightStart = convert(parent.width, parent.height - radius);
	const bottomRightControl = convert(parent.width, parent.height);
	const bottomRightEnd = convert(parent.width - radius, parent.height);
	const bottomLeftStart = convert(radius, parent.height);
	const bottomLeftControl = convert(0, parent.height);
	const bottomLeftEnd = convert(0, parent.height - radius);
	const topLeftEdge = convert(0, radius);
	const topLeftControl = convert(0, 0);
	if (radius <= EPSILON) return `M ${[
		convert(0, 0),
		convert(parent.width, 0),
		convert(parent.width, parent.height),
		convert(0, parent.height)
	].map(pointText).join(" L ")} Z`;
	return [
		`M ${pointText(topLeftStart)}`,
		`L ${pointText(topRightStart)}`,
		`Q ${pointText(topRightControl)} ${pointText(topRightEnd)}`,
		`L ${pointText(bottomRightStart)}`,
		`Q ${pointText(bottomRightControl)} ${pointText(bottomRightEnd)}`,
		`L ${pointText(bottomLeftStart)}`,
		`Q ${pointText(bottomLeftControl)} ${pointText(bottomLeftEnd)}`,
		`L ${pointText(topLeftEdge)}`,
		`Q ${pointText(topLeftControl)} ${pointText(topLeftStart)}`,
		"Z"
	].join(" ");
}
/** CSS clipping path for a parent rectangle expressed in the transformed child's local box. */
function clipPathForParentBounds(child, parent, borderRadius = 0) {
	return `path("${clipPathSvgForParentBounds(child, parent, borderRadius)}")`;
}
//#endregion
//#region src/easing.ts
/** GSAP accepts an easing function; sharing the scene-model sampler prevents preview/runtime drift. */
function easingForGsap(easing, curve) {
	return curve ? (progress) => cubicBezierProgress(progress, curve) : (progress) => easedProgress(progress, easing);
}
//#endregion
//#region src/renderElement.ts
var textFitObservers = /* @__PURE__ */ new WeakMap();
/** Smallest legible fraction of the authored text size used by shrink-to-fit. */
var SHRINK_TO_FIT_MIN_RATIO = .5;
/** Disconnects shrink-to-fit observation before a renderer discards a content host. */
function disposeElementContent(container) {
	textFitObservers.get(container)?.disconnect();
	textFitObservers.delete(container);
	container.replaceChildren();
	delete container.dataset.ografBasePaint;
}
function rememberPaint(container, paint) {
	container.dataset.ografBasePaint = JSON.stringify(paint);
}
/** Re-evaluates gradient-stop tracks against the currently rendered authored/data-bound paint. */
function applyAnimatedPaint(container, tracks, frame) {
	const serialized = container.dataset?.ografBasePaint;
	const content = container.firstElementChild;
	if (!serialized || !content) return;
	const paint = JSON.parse(serialized);
	content.style.background = paintToCss(getPaintAtFrame(paint, tracks, frame));
}
function applyContentBaseStyle(el) {
	el.style.width = "100%";
	el.style.height = "100%";
	el.style.boxSizing = "border-box";
	el.style.pointerEvents = "none";
	el.style.userSelect = "none";
}
/**
* Vanilla-DOM equivalent of the editor's LayerNode content rendering — no framework at runtime.
* `frameIndex` only matters for `image-sequence` (which frame of the flipbook to show); every
* other element type ignores it.
*/
function renderElementContent(container, element, frameIndex = 0) {
	disposeElementContent(container);
	switch (element.type) {
		case "rectangle": {
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.background = paintToCss(element.fill);
			rememberPaint(container, element.fill);
			content.style.borderRadius = `${element.borderRadius}px`;
			if (element.strokeWidth > 0) content.style.border = `${element.strokeWidth}px solid ${element.strokeColor}`;
			container.appendChild(content);
			break;
		}
		case "ellipse": {
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.background = paintToCss(element.fill);
			rememberPaint(container, element.fill);
			content.style.borderRadius = "50%";
			if (element.strokeWidth > 0) content.style.border = `${element.strokeWidth}px solid ${element.strokeColor}`;
			container.appendChild(content);
			break;
		}
		case "text": {
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.color = element.color;
			content.style.fontFamily = element.fontFamily;
			content.style.fontSize = `${element.fontSize}px`;
			content.style.fontWeight = String(element.fontWeight);
			content.style.textAlign = element.textAlign;
			content.style.whiteSpace = element.autoFit === "auto-size" ? "pre" : "pre-wrap";
			content.style.lineHeight = element.autoFit === "shrink-to-fit" ? `${element.fontSize * 1.2}px` : "1.2";
			content.style.overflow = element.autoFit === "shrink-to-fit" ? "hidden" : "visible";
			content.textContent = element.content;
			container.appendChild(content);
			if (element.autoFit === "shrink-to-fit") {
				const fit = () => {
					if (container.clientWidth <= 0 || container.clientHeight <= 0) return;
					const floor = Math.max(1, element.fontSize * SHRINK_TO_FIT_MIN_RATIO);
					let lower = floor;
					let upper = Math.max(floor, element.fontSize);
					content.style.fontSize = `${floor}px`;
					if (!(content.scrollWidth <= container.clientWidth + .5 && content.scrollHeight <= container.clientHeight + .5)) {
						content.style.fontSize = `${Math.floor(floor * 10) / 10}px`;
						content.dataset.ografShrinkRatio = String(SHRINK_TO_FIT_MIN_RATIO);
						content.dataset.ografShrinkDegenerate = "true";
						return;
					}
					for (let iteration = 0; iteration < 12; iteration++) {
						const candidate = (lower + upper) / 2;
						content.style.fontSize = `${candidate}px`;
						if (content.scrollWidth <= container.clientWidth + .5 && content.scrollHeight <= container.clientHeight + .5) lower = candidate;
						else upper = candidate;
					}
					const applied = Math.floor(lower * 10) / 10;
					content.style.fontSize = `${applied}px`;
					content.dataset.ografShrinkRatio = String(applied / element.fontSize);
					content.dataset.ografShrinkDegenerate = "false";
				};
				fit();
				if (typeof ResizeObserver !== "undefined") {
					const observer = new ResizeObserver(fit);
					observer.observe(container);
					textFitObservers.set(container, observer);
				}
			}
			break;
		}
		case "image":
			if (element.src) {
				const img = document.createElement("img");
				applyContentBaseStyle(img);
				img.style.objectFit = "contain";
				img.src = element.src;
				img.alt = "";
				img.draggable = false;
				container.appendChild(img);
			}
			break;
		case "path": {
			const SVG_NS = "http://www.w3.org/2000/svg";
			const svg = document.createElementNS(SVG_NS, "svg");
			applyContentBaseStyle(svg);
			svg.setAttribute("viewBox", `0 0 ${element.viewBoxWidth} ${element.viewBoxHeight}`);
			svg.setAttribute("preserveAspectRatio", "none");
			const path = document.createElementNS(SVG_NS, "path");
			path.setAttribute("d", element.d);
			path.setAttribute("fill", element.fill);
			path.setAttribute("stroke", element.strokeWidth > 0 ? element.strokeColor : "none");
			path.setAttribute("stroke-width", String(element.strokeWidth));
			svg.appendChild(path);
			container.appendChild(svg);
			break;
		}
		case "image-sequence": {
			const src = element.frames.length > 0 ? element.frames[frameIndex % element.frames.length] : void 0;
			if (src) {
				const img = document.createElement("img");
				applyContentBaseStyle(img);
				img.style.objectFit = "contain";
				img.src = src;
				img.alt = "";
				img.draggable = false;
				container.appendChild(img);
			}
			break;
		}
	}
}
/**
* The element a compiled layer should render with, given runtime data — mirrors the editor's
* design-time `resolveEffectiveElement` (apps/editor/src/state/dataBinding.ts), adapted to the
* compiled descriptor's shape (data keyed by field `key`, not `fieldId`). All current bindable
* properties are string-typed, so the override always stringifies.
*/
function resolveBoundElement(layer, data) {
	if (!layer.binding) return layer.element;
	const value = data[layer.binding.dataKey];
	if (value === void 0) return layer.element;
	const resolvedValue = layer.binding.targetProperty === "fill" && value && typeof value === "object" ? value : String(value);
	return {
		...layer.element,
		[layer.binding.targetProperty]: resolvedValue
	};
}
//#endregion
//#region src/buildRuntimeTimeline.ts
var DIRECT_GSAP_PROPERTIES = {
	x: "x",
	y: "y",
	width: "width",
	height: "height",
	rotation: "rotation",
	opacity: "opacity"
};
function compiledPoseAtFrame(layer, frame) {
	const first = [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform;
	if (!first) throw new Error(`Compiled layer "${layer.id}" has no transform key.`);
	return Object.fromEntries(TRANSFORM_ANIMATION_PROPERTIES.map((property) => [property, getTrackValueAtFrame(layer.animationTracks[property] ?? [], frame, first[property])]));
}
/**
* Builds one paused GSAP timeline spanning every keyframe in sequence, from an already-compiled
* descriptor (frame positions precomputed — this never re-derives them, unlike the editor's own
* apps/editor/src/canvas/masterTimeline.ts, which builds the analogous authoring-time timeline
* directly from Composition data). Layers are first snapped to Keyframe 0's pose via `gsap.set`
* so the first tween in the chain has a correct "from" value.
*/
function buildRuntimeTimeline(descriptor, layerEls) {
	const tl = gsapWithCSS.timeline({ paused: true });
	const frameRate = descriptor.frameRate;
	const applyInitialStates = [];
	for (const keyframe of descriptor.keyframes) tl.addLabel(keyframe.id, keyframe.frame / frameRate);
	for (const layer of descriptor.layers) {
		const el = layerEls.get(layer.id);
		if (!el) continue;
		const tracks = layer.animationTracks;
		const firstTransform = Object.fromEntries(TRANSFORM_ANIMATION_PROPERTIES.map((property) => [property, [...tracks[property] ?? []].sort((a, b) => a.frame - b.frame)[0]?.value ?? [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform[property] ?? 0]));
		const originState = {
			transformOriginX: firstTransform.transformOriginX,
			transformOriginY: firstTransform.transformOriginY
		};
		const effectState = { ...layer.effects };
		for (const property of EFFECT_ANIMATION_PROPERTIES) {
			const first = [...tracks[property] ?? []].sort((a, b) => a.frame - b.frame)[0];
			if (first) effectState[property] = first.value;
		}
		const firstEffects = { ...effectState };
		const updateOrigin = () => {
			el.style.transformOrigin = `${originState.transformOriginX * 100}% ${originState.transformOriginY * 100}%`;
		};
		const updateEffects = () => {
			el.style.filter = layerEffectsToCssFilter(effectState);
		};
		const applyInitialState = () => {
			originState.transformOriginX = firstTransform.transformOriginX;
			originState.transformOriginY = firstTransform.transformOriginY;
			Object.assign(effectState, firstEffects);
			gsapWithCSS.set(el, {
				x: firstTransform.x,
				y: firstTransform.y,
				width: firstTransform.width,
				height: firstTransform.height,
				rotation: firstTransform.rotation,
				opacity: firstTransform.opacity,
				transformOrigin: `${firstTransform.transformOriginX * 100}% ${firstTransform.transformOriginY * 100}%`
			});
			updateEffects();
		};
		applyInitialStates.push(applyInitialState);
		applyInitialState();
		for (const property of Object.keys(tracks)) {
			if (isGradientStopOffsetProperty(property)) continue;
			const keyframes = [...tracks[property] ?? []].sort((a, b) => a.frame - b.frame);
			for (let index = 1; index < keyframes.length; index++) {
				const from = keyframes[index - 1];
				const to = keyframes[index];
				const common = {
					duration: (to.frame - from.frame) / frameRate,
					ease: easingForGsap(to.easing, to.curve)
				};
				const directProperty = DIRECT_GSAP_PROPERTIES[property];
				if (directProperty) tl.to(el, {
					[directProperty]: to.value,
					...common
				}, from.frame / frameRate);
				else if (property === "transformOriginX" || property === "transformOriginY") tl.to(originState, {
					[property]: to.value,
					...common,
					onUpdate: updateOrigin
				}, from.frame / frameRate);
				else tl.to(effectState, {
					[property]: to.value,
					...common,
					onUpdate: updateEffects
				}, from.frame / frameRate);
			}
		}
	}
	const endFrame = descriptor.keyframes.at(-1)?.frame ?? 0;
	const updateDynamicRendering = () => {
		const frame = tl.time() * frameRate;
		for (const layer of descriptor.layers) {
			const child = layerEls.get(layer.id);
			if (child) applyAnimatedPaint(child, layer.animationTracks, frame);
			if (!layer.clipParentId) continue;
			const parent = layerEls.get(layer.clipParentId);
			if (!child || !parent) {
				if (child) child.style.clipPath = "inset(50%)";
				continue;
			}
			const parentLayer = descriptor.layers.find((candidate) => candidate.id === layer.clipParentId);
			const radius = parentLayer?.element.type === "rectangle" ? parentLayer.element.borderRadius : 0;
			if (parentLayer) child.style.clipPath = clipPathForParentBounds(compiledPoseAtFrame(layer, frame), compiledPoseAtFrame(parentLayer, frame), radius);
		}
	};
	if (descriptor.layers.some((layer) => layer.clipParentId || Object.keys(layer.animationTracks).some(isGradientStopOffsetProperty))) {
		tl.to({ progress: 0 }, {
			progress: 1,
			duration: endFrame / frameRate,
			ease: "none",
			onUpdate: updateDynamicRendering
		}, 0);
		updateDynamicRendering();
	}
	tl.to({}, { duration: 0 }, endFrame / frameRate);
	const nativeSeek = tl.seek.bind(tl);
	tl.seek = ((position, suppressEvents) => {
		const result = nativeSeek(position, suppressEvents);
		if (tl.time() === 0) for (const applyInitialState of applyInitialStates) applyInitialState();
		updateDynamicRendering();
		return result;
	});
	return tl;
}
//#endregion
//#region src/lifecycle.ts
/** Pure OGraf step resolution shared by realtime actions and non-realtime schedule replay. */
function resolvePlayTarget(stepKeyframeIds, startKeyframeId, endKeyframeId, currentStep, params) {
	const targetStep = params.goto ?? (currentStep ?? -1) + (params.delta ?? 1);
	if (targetStep < 0) return {
		keyframeId: startKeyframeId,
		currentStep: void 0
	};
	if (targetStep >= stepKeyframeIds.length) return {
		keyframeId: endKeyframeId,
		currentStep: void 0
	};
	return {
		keyframeId: stepKeyframeIds[targetStep],
		currentStep: targetStep
	};
}
//#endregion
//#region src/loopRendering.ts
function firstTransform(layer) {
	const first = [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform;
	if (!first) throw new Error(`Compiled layer "${layer.id}" has no transform key.`);
	return first;
}
/** Pure property sampling shared by realtime loops, non-realtime seeking, and editor preview. */
function sampleCompiledLayerVisualState(layer, baseFrame, loopElapsedFrames) {
	const initial = firstTransform(layer);
	const transform = Object.fromEntries(TRANSFORM_ANIMATION_PROPERTIES.map((property) => [property, getTrackValueAtFrame(layer.animationTracks[property] ?? [], baseFrame, initial[property])]));
	const effects = { ...layer.effects };
	for (const property of EFFECT_ANIMATION_PROPERTIES) effects[property] = getTrackValueAtFrame(layer.animationTracks[property] ?? [], baseFrame, effects[property]);
	const loop = layer.loop;
	const localFrame = loop && loopElapsedFrames !== void 0 ? getLoopFrameAtElapsed(loop, loopElapsedFrames) : void 0;
	if (loop && localFrame !== void 0) for (const property of Object.keys(loop.tracks)) {
		const keys = loop.tracks[property] ?? [];
		if (keys.length === 0 || isGradientStopOffsetProperty(property)) continue;
		if (TRANSFORM_ANIMATION_PROPERTIES.includes(property)) {
			const transformProperty = property;
			transform[transformProperty] = getTrackValueAtFrame(keys, localFrame, transform[transformProperty]);
		} else if (EFFECT_ANIMATION_PROPERTIES.some((candidate) => candidate === property)) {
			const effectProperty = property;
			effects[effectProperty] = getTrackValueAtFrame(keys, localFrame, effects[effectProperty]);
		}
	}
	const paintTracks = {};
	const paintProperties = /* @__PURE__ */ new Set([...Object.keys(layer.animationTracks), ...Object.keys(loop?.tracks ?? {})]);
	for (const property of paintProperties) {
		if (!isGradientStopOffsetProperty(property)) continue;
		const baseValue = getTrackValueAtFrame(layer.animationTracks[property] ?? [], baseFrame, 0);
		const loopKeys = loop?.tracks[property] ?? [];
		const value = localFrame !== void 0 && loopKeys.length > 0 ? getTrackValueAtFrame(loopKeys, localFrame, baseValue) : baseValue;
		paintTracks[property] = [{
			id: `${layer.id}:${property}:sample`,
			frame: 0,
			value,
			easing: "linear"
		}];
	}
	return {
		transform,
		effects,
		paintTracks,
		paintFrame: 0
	};
}
function applyCompiledLayerVisualState(element, state) {
	const { transform } = state;
	gsapWithCSS.set(element, {
		x: transform.x,
		y: transform.y,
		width: transform.width,
		height: transform.height,
		rotation: transform.rotation,
		opacity: transform.opacity,
		transformOrigin: `${transform.transformOriginX * 100}% ${transform.transformOriginY * 100}%`
	});
	element.style.filter = layerEffectsToCssFilter(state.effects);
	applyAnimatedPaint(element, state.paintTracks, state.paintFrame);
}
/** Applies clipping after every participating layer pose has been resolved. */
function applyCompiledClipPaths(descriptor, elements, states) {
	for (const layer of descriptor.layers) {
		if (!layer.clipParentId) continue;
		const child = elements.get(layer.id);
		const childState = states.get(layer.id);
		const parentState = states.get(layer.clipParentId);
		const parentLayer = descriptor.layers.find((candidate) => candidate.id === layer.clipParentId);
		if (!child || !childState || !parentState || !parentLayer) {
			if (child) child.style.clipPath = "inset(50%)";
			continue;
		}
		const radius = parentLayer.element.type === "rectangle" ? parentLayer.element.borderRadius : 0;
		child.style.clipPath = clipPathForParentBounds(childState.transform, parentState.transform, radius);
	}
}
//#endregion
//#region src/GraphicElement.ts
function errorPayload(err) {
	return {
		statusCode: 550,
		statusMessage: err instanceof Error ? err.message : String(err)
	};
}
/**
* The generic, descriptor-driven `Graphic` implementation — interprets a CompiledGraphicDescriptor
* rather than being generated per-project. The SAME class (via this same npm-published/bundled
* source) drives both the editor's in-app preview harness and every exported package's `main.js`,
* which is what guarantees the two can never diverge (see docs/PLAN.md, "Runtime is interpreted,
* not templated per-project").
*
* Custom Elements can't take constructor arguments (the browser calls `new SubClass()` with no
* args when upgrading/creating one), so the descriptor is read via a `static descriptor` on the
* concrete subclass instead: `class Foo extends GraphicElement { static descriptor = {...} }`.
* The in-app preview harness dynamically declares one such subclass per compile and registers it
* under a fresh tag name; an exported package's main.js does the same thing once, statically.
*/
var GraphicElement = class extends HTMLElement {
	static descriptor;
	#layerEls = /* @__PURE__ */ new Map();
	#timeline = null;
	#activeTween = null;
	/** Index into `descriptor.stepKeyframeIds` — the OGraf "current step", not a keyframe index. */
	#currentStep;
	#lastData = {};
	#schedule = [];
	/** Snapshot of `#lastData` taken when `setActionsSchedule` is called — the baseline `goToTime`
	* replays scheduled `updateAction` entries on top of, so scrubbing backward past a scheduled
	* update correctly reverts keys that update doesn't touch, instead of leaving them stuck. */
	#scheduleBaseData = {};
	/** Realtime sequence redraw requests. Frame choice is still derived from absolute elapsed time,
	* never callback count, so dropped browser frames do not change sequence phase. */
	#sequenceAnimationFrames = /* @__PURE__ */ new Map();
	#renderType = "realtime";
	/** Absolute clock epochs for active layer-local loops. Values use performance.now() in realtime
	* and the scheduled OGraf timestamp in non-realtime; sampling always derives phase absolutely. */
	#activeLoopEpochs = /* @__PURE__ */ new Map();
	#loopAnimationFrame = null;
	#loopExitCorrection = null;
	get descriptor() {
		return this.constructor.descriptor;
	}
	connectedCallback() {
		if (!this.shadowRoot) this.attachShadow({ mode: "open" });
		this.#buildDom();
	}
	disconnectedCallback() {
		this.#activeTween?.kill();
		this.#timeline?.kill();
		this.#clearSequenceIntervals();
		this.#stopLoopRendering();
		for (const element of this.#layerEls.values()) disposeElementContent(element);
		this.#layerEls.clear();
	}
	#clearSequenceIntervals() {
		if (typeof cancelAnimationFrame !== "undefined") for (const id of this.#sequenceAnimationFrames.values()) cancelAnimationFrame(id);
		this.#sequenceAnimationFrames.clear();
	}
	#stopLoopRendering() {
		if (this.#loopAnimationFrame !== null && typeof cancelAnimationFrame !== "undefined") cancelAnimationFrame(this.#loopAnimationFrame);
		this.#loopAnimationFrame = null;
		this.#activeLoopEpochs.clear();
	}
	#renderLoopSnapshot(clockMs, epochs = this.#activeLoopEpochs) {
		const baseFrame = (this.#timeline?.time() ?? 0) * this.descriptor.frameRate;
		const states = /* @__PURE__ */ new Map();
		for (const layer of this.descriptor.layers) {
			const epoch = epochs.get(layer.id);
			const state = sampleCompiledLayerVisualState(layer, baseFrame, epoch === void 0 ? void 0 : Math.max(0, (clockMs - epoch) / 1e3 * this.descriptor.frameRate));
			const correction = this.#loopExitCorrection?.layers.get(layer.id);
			if (correction && this.#loopExitCorrection) {
				const distance = Math.abs(this.#loopExitCorrection.targetFrame - this.#loopExitCorrection.startFrame);
				const remaining = 1 - (distance === 0 ? 1 : Math.min(1, Math.abs(baseFrame - this.#loopExitCorrection.startFrame) / distance));
				for (const [property, delta] of Object.entries(correction.transform)) state.transform[property] += delta * remaining;
				for (const [property, delta] of Object.entries(correction.effects)) state.effects[property] += delta * remaining;
				for (const [property, delta] of Object.entries(correction.paint)) {
					const sampled = state.paintTracks[property]?.[0];
					if (sampled) sampled.value += delta * remaining;
				}
			}
			states.set(layer.id, state);
			const element = this.#layerEls.get(layer.id);
			if (element) applyCompiledLayerVisualState(element, state);
		}
		applyCompiledClipPaths(this.descriptor, this.#layerEls, states);
	}
	#beginLoopExit(targetFrame, clockMs, shouldExit) {
		const baseFrame = (this.#timeline?.time() ?? 0) * this.descriptor.frameRate;
		const layers = /* @__PURE__ */ new Map();
		for (const layer of this.descriptor.layers) {
			const epoch = this.#activeLoopEpochs.get(layer.id);
			if (epoch === void 0 || !layer.loop || !shouldExit(layer)) continue;
			const looped = sampleCompiledLayerVisualState(layer, baseFrame, Math.max(0, (clockMs - epoch) / 1e3 * this.descriptor.frameRate));
			const base = sampleCompiledLayerVisualState(layer, baseFrame);
			const transform = {};
			const effects = {};
			const paint = {};
			for (const property of Object.keys(layer.loop.tracks)) if (TRANSFORM_ANIMATION_PROPERTIES.includes(property)) {
				const key = property;
				transform[key] = looped.transform[key] - base.transform[key];
			} else if (EFFECT_ANIMATION_PROPERTIES.some((candidate) => candidate === property)) {
				const key = property;
				effects[key] = looped.effects[key] - base.effects[key];
			} else if (isGradientStopOffsetProperty(property)) paint[property] = (looped.paintTracks[property]?.[0]?.value ?? 0) - (base.paintTracks[property]?.[0]?.value ?? 0);
			layers.set(layer.id, {
				transform,
				effects,
				paint
			});
		}
		this.#loopExitCorrection = layers.size > 0 ? {
			startFrame: baseFrame,
			targetFrame,
			layers
		} : null;
	}
	#ensureLoopRendering() {
		if (this.#renderType !== "realtime" || this.#activeLoopEpochs.size === 0 || this.#loopAnimationFrame !== null || typeof requestAnimationFrame === "undefined") return;
		const render = (now) => {
			this.#loopAnimationFrame = null;
			if (this.#activeLoopEpochs.size === 0 || this.#renderType !== "realtime") return;
			this.#renderLoopSnapshot(now);
			this.#loopAnimationFrame = requestAnimationFrame(render);
		};
		this.#loopAnimationFrame = requestAnimationFrame(render);
	}
	#activateLoopsAtStep(step, epochMs, firstStep) {
		const stepKeyframeId = step === void 0 ? void 0 : this.descriptor.stepKeyframeIds[step];
		for (const layer of this.descriptor.layers) {
			const activation = layer.loop?.activation;
			if (!activation) continue;
			if (activation.type === "lifecycle") {
				if (firstStep || !this.#activeLoopEpochs.has(layer.id)) this.#activeLoopEpochs.set(layer.id, epochMs);
			} else if (activation.stepKeyframeId === stepKeyframeId) this.#activeLoopEpochs.set(layer.id, epochMs);
		}
		this.#ensureLoopRendering();
	}
	#deactivateStepLoops() {
		for (const layer of this.descriptor.layers) if (layer.loop?.activation.type === "step") this.#activeLoopEpochs.delete(layer.id);
	}
	#deactivateAllLoops() {
		this.#stopLoopRendering();
	}
	#buildDom() {
		const shadow = this.shadowRoot;
		if (!shadow) return;
		const descriptor = this.descriptor;
		for (const element of this.#layerEls.values()) disposeElementContent(element);
		shadow.replaceChildren();
		this.#clearSequenceIntervals();
		const style = document.createElement("style");
		style.textContent = ":host { display: block; position: relative; overflow: hidden; }";
		shadow.appendChild(style);
		this.style.width = `${descriptor.width}px`;
		this.style.height = `${descriptor.height}px`;
		this.style.backgroundColor = descriptor.backgroundColor;
		this.#layerEls.clear();
		for (const layer of descriptor.layers) {
			const el = document.createElement("div");
			el.style.position = "absolute";
			el.style.left = "0";
			el.style.top = "0";
			el.style.boxSizing = "border-box";
			el.style.display = layer.isVisible ? "" : "none";
			el.style.filter = layerEffectsToCssFilter(layer.effects);
			const firstTransform = [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform;
			if (firstTransform) {
				el.style.width = `${firstTransform.width}px`;
				el.style.height = `${firstTransform.height}px`;
			}
			renderElementContent(el, resolveBoundElement(layer, this.#lastData));
			shadow.appendChild(el);
			this.#layerEls.set(layer.id, el);
			this.#startSequencePlayback(layer, el);
		}
		this.#timeline?.kill();
		this.#timeline = buildRuntimeTimeline(descriptor, this.#layerEls);
	}
	#startSequencePlayback(layer, el) {
		const element = layer.element;
		if (element.type !== "image-sequence" || element.frames.length === 0) return;
		const frames = element.frames;
		const loop = element.loop;
		const fps = element.fps > 0 ? element.fps : 1;
		if (typeof requestAnimationFrame === "undefined") return;
		const epoch = performance.now();
		let renderedFrame = 0;
		const render = (now) => {
			const rawFrame = Math.max(0, Math.floor((now - epoch) / 1e3 * fps));
			const frameIndex = loop ? rawFrame % frames.length : Math.min(rawFrame, frames.length - 1);
			if (frameIndex !== renderedFrame) {
				renderedFrame = frameIndex;
				renderElementContent(el, element, frameIndex);
			}
			if (!loop && rawFrame >= frames.length - 1) {
				this.#sequenceAnimationFrames.delete(layer.id);
				return;
			}
			const request = requestAnimationFrame(render);
			this.#sequenceAnimationFrames.set(layer.id, request);
		};
		this.#sequenceAnimationFrames.set(layer.id, requestAnimationFrame(render));
	}
	#startRealtimeSequences() {
		this.#clearSequenceIntervals();
		for (const layer of this.descriptor.layers) {
			const el = this.#layerEls.get(layer.id);
			if (el) this.#startSequencePlayback(layer, el);
		}
	}
	#renderSequencesAt(timestampMs) {
		for (const layer of this.descriptor.layers) {
			if (layer.element.type !== "image-sequence" || layer.element.frames.length === 0) continue;
			const el = this.#layerEls.get(layer.id);
			if (!el) continue;
			const rawFrame = Math.max(0, Math.floor(timestampMs / 1e3 * Math.max(1, layer.element.fps)));
			const frameIndex = layer.element.loop ? rawFrame % layer.element.frames.length : Math.min(rawFrame, layer.element.frames.length - 1);
			renderElementContent(el, layer.element, frameIndex);
		}
	}
	#refreshBoundLayers() {
		for (const layer of this.descriptor.layers) {
			if (!layer.binding) continue;
			const el = this.#layerEls.get(layer.id);
			if (el) {
				renderElementContent(el, resolveBoundElement(layer, this.#lastData));
				applyAnimatedPaint(el, layer.animationTracks, (this.#timeline?.time() ?? 0) * this.descriptor.frameRate);
			}
		}
	}
	#applyData(data) {
		if (!data || typeof data !== "object") return;
		this.#lastData = {
			...this.#lastData,
			...data
		};
		this.#refreshBoundLayers();
	}
	#replaceData(data) {
		this.#lastData = data && typeof data === "object" ? { ...data } : {};
		this.#refreshBoundLayers();
	}
	async #seekToKeyframeId(keyframeId, skipAnimation) {
		const keyframe = this.descriptor.keyframes.find((k) => k.id === keyframeId);
		const tl = this.#timeline;
		if (!keyframe || !tl) return;
		const targetSeconds = keyframe.frame / this.descriptor.frameRate;
		this.#activeTween?.kill();
		this.#activeTween = null;
		if (skipAnimation) {
			this.#loopExitCorrection = null;
			tl.seek(targetSeconds, true);
		} else await new Promise((resolve) => {
			const finish = () => {
				this.#activeTween = null;
				this.#loopExitCorrection = null;
				this.#renderLoopSnapshot(typeof performance !== "undefined" ? performance.now() : Date.now());
				resolve();
			};
			this.#activeTween = tl.tweenTo(targetSeconds, {
				onUpdate: () => this.#renderLoopSnapshot(typeof performance !== "undefined" ? performance.now() : Date.now()),
				onComplete: finish,
				onInterrupt: finish
			});
		});
	}
	async load(params) {
		try {
			this.#replaceData(params.data);
			this.#stopLoopRendering();
			this.#renderType = params.renderType;
			if (this.#renderType === "realtime") this.#startRealtimeSequences();
			else {
				this.#clearSequenceIntervals();
				this.#renderSequencesAt(0);
			}
			this.#schedule = [];
			this.#scheduleBaseData = { ...this.#lastData };
			this.#currentStep = void 0;
			await this.#seekToKeyframeId(this.descriptor.startKeyframeId, true);
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async dispose() {
		try {
			this.#timeline?.kill();
			this.#timeline = null;
			this.#activeTween?.kill();
			this.#activeTween = null;
			this.#clearSequenceIntervals();
			this.#stopLoopRendering();
			this.#schedule = [];
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async updateAction(params) {
		try {
			this.#applyData(params.data);
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	#resolvePlayTarget(currentStep, params) {
		return resolvePlayTarget(this.descriptor.stepKeyframeIds, this.descriptor.startKeyframeId, this.descriptor.endKeyframeId, currentStep, params);
	}
	async playAction(params) {
		try {
			const previousStep = this.#currentStep;
			const target = this.#resolvePlayTarget(this.#currentStep, params);
			const targetFrame = this.descriptor.keyframes.find((keyframe) => keyframe.id === target.keyframeId)?.frame ?? 0;
			const now = typeof performance !== "undefined" ? performance.now() : Date.now();
			this.#beginLoopExit(targetFrame, now, (layer) => target.currentStep === void 0 || layer.loop?.activation.type === "step");
			this.#deactivateStepLoops();
			if (target.currentStep === void 0) this.#deactivateAllLoops();
			await this.#seekToKeyframeId(target.keyframeId, params.skipAnimation);
			this.#currentStep = target.currentStep;
			if (this.#currentStep !== void 0) this.#activateLoopsAtStep(this.#currentStep, typeof performance !== "undefined" ? performance.now() : Date.now(), previousStep === void 0);
			return {
				statusCode: 200,
				...this.#currentStep !== void 0 ? { currentStep: this.#currentStep } : {}
			};
		} catch (err) {
			return {
				...errorPayload(err),
				...this.#currentStep !== void 0 ? { currentStep: this.#currentStep } : {}
			};
		}
	}
	async stopAction(params) {
		try {
			const targetFrame = this.descriptor.keyframes.find((keyframe) => keyframe.id === this.descriptor.endKeyframeId)?.frame ?? 0;
			this.#beginLoopExit(targetFrame, typeof performance !== "undefined" ? performance.now() : Date.now(), () => true);
			this.#deactivateAllLoops();
			await this.#seekToKeyframeId(this.descriptor.endKeyframeId, params.skipAnimation);
			this.#currentStep = void 0;
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async customAction(params) {
		try {
			if (!this.descriptor.customActions.some((a) => a.id === params.id)) return {
				statusCode: 404,
				statusMessage: `Unknown customAction id: "${params.id}"`
			};
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	/**
	* Re-derives the full logical state (keyframe position + bound data) implied by every scheduled
	* action at or before `timestamp`, from the `#scheduleBaseData`/keyframe-0 baseline forward —
	* NOT an incremental cursor. Replaying the full prefix every call (rather than only newly-passed
	* entries) is what makes scrubbing backward correct: a key set by an action that's since fallen
	* out of the qualifying prefix reverts to the baseline instead of staying stuck at its old value.
	*/
	#applySchedule(timestamp) {
		const due = this.#schedule.filter((a) => a.timestamp <= timestamp);
		let step;
		let targetKeyframeId = this.descriptor.startKeyframeId;
		let data = { ...this.#scheduleBaseData };
		const keyframeSeconds = (keyframeId) => (this.descriptor.keyframes.find((keyframe) => keyframe.id === keyframeId)?.frame ?? 0) / this.descriptor.frameRate;
		let positionSeconds = keyframeSeconds(this.descriptor.startKeyframeId);
		let animation;
		let stepArrivalTimestamp;
		let lifecycleEpoch;
		const advanceTo = (atTimestamp) => {
			if (!animation) return positionSeconds;
			const progress = Math.min(1, Math.max(0, (atTimestamp - animation.startTimestamp) / animation.durationMs));
			positionSeconds = animation.startSeconds + (animation.targetSeconds - animation.startSeconds) * progress;
			if (progress >= 1) animation = void 0;
			return positionSeconds;
		};
		for (const scheduled of due) {
			advanceTo(scheduled.timestamp);
			const { type, params } = scheduled.action;
			if (type === "updateAction") {
				const updateParams = params;
				if (updateParams.data && typeof updateParams.data === "object") data = {
					...data,
					...updateParams.data
				};
			} else if (type === "playAction") {
				const playParams = params;
				const target = this.#resolvePlayTarget(step, playParams);
				step = target.currentStep;
				targetKeyframeId = target.keyframeId;
				const targetSeconds = keyframeSeconds(targetKeyframeId);
				const durationMs = Math.abs(targetSeconds - positionSeconds) * 1e3;
				animation = playParams.skipAnimation || durationMs === 0 ? void 0 : {
					startTimestamp: scheduled.timestamp,
					startSeconds: positionSeconds,
					targetSeconds,
					durationMs
				};
				if (!animation) positionSeconds = targetSeconds;
				if (target.currentStep === void 0) {
					lifecycleEpoch = void 0;
					stepArrivalTimestamp = void 0;
				} else {
					const arrival = scheduled.timestamp + (animation?.durationMs ?? 0);
					stepArrivalTimestamp = arrival;
					lifecycleEpoch ??= arrival;
				}
			} else if (type === "stopAction") {
				const stopParams = params;
				step = void 0;
				targetKeyframeId = this.descriptor.endKeyframeId;
				const targetSeconds = keyframeSeconds(targetKeyframeId);
				const durationMs = Math.abs(targetSeconds - positionSeconds) * 1e3;
				animation = stopParams.skipAnimation || durationMs === 0 ? void 0 : {
					startTimestamp: scheduled.timestamp,
					startSeconds: positionSeconds,
					targetSeconds,
					durationMs
				};
				if (!animation) positionSeconds = targetSeconds;
				lifecycleEpoch = void 0;
				stepArrivalTimestamp = void 0;
			}
		}
		this.#lastData = data;
		this.#refreshBoundLayers();
		this.#currentStep = step;
		advanceTo(timestamp);
		this.#timeline?.seek(positionSeconds, true);
		const epochs = /* @__PURE__ */ new Map();
		const settled = animation === void 0;
		const stepKeyframeId = step === void 0 ? void 0 : this.descriptor.stepKeyframeIds[step];
		for (const layer of this.descriptor.layers) {
			const activation = layer.loop?.activation;
			if (!activation) continue;
			if (activation.type === "lifecycle" && lifecycleEpoch !== void 0 && timestamp >= lifecycleEpoch) epochs.set(layer.id, lifecycleEpoch);
			else if (activation.type === "step" && settled && stepArrivalTimestamp !== void 0 && activation.stepKeyframeId === stepKeyframeId) epochs.set(layer.id, stepArrivalTimestamp);
		}
		this.#renderLoopSnapshot(timestamp, epochs);
	}
	async goToTime(params) {
		try {
			this.#timeline?.pause();
			this.#activeTween?.kill();
			this.#activeTween = null;
			this.#timeline?.seek(params.timestamp / 1e3, true);
			if (this.#schedule.length > 0) this.#applySchedule(params.timestamp);
			else this.#renderLoopSnapshot(params.timestamp, /* @__PURE__ */ new Map());
			this.#renderSequencesAt(params.timestamp);
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async setActionsSchedule(params) {
		try {
			this.#schedule = [...params.schedule].sort((a, b) => a.timestamp - b.timestamp);
			this.#scheduleBaseData = { ...this.#lastData };
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
};
//#endregion
//#region src/index.ts
/** A concrete, instantiable GraphicElement bound to one descriptor — see GraphicElement's own doc comment. */
function createGraphicClass(descriptor) {
	return class extends GraphicElement {
		static descriptor = descriptor;
	};
}
var registrationCounter = 0;
/**
* Registers a fresh Custom Element tag for this descriptor and returns the tag name — used by the
* live preview harness, which needs a new tag every recompile (`customElements.define` can't be
* called twice for the same name, and there's no way to update an already-defined element's class).
*/
function registerGraphicElement(descriptor) {
	const tagName = `ograf-preview-graphic-${registrationCounter++}`;
	customElements.define(tagName, createGraphicClass(descriptor));
	return tagName;
}
//#endregion
export { GraphicElement, applyAnimatedPaint, applyCompiledClipPaths, applyCompiledLayerVisualState, buildRuntimeTimeline, createGraphicClass, disposeElementContent, easingForGsap, registerGraphicElement, renderElementContent, resolveBoundElement, resolvePlayTarget, sampleCompiledLayerVisualState };

const exportedDescriptor = {"width":1920,"height":1080,"backgroundColor":"transparent","frameRate":50,"layers":[{"id":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44","isVisible":true,"element":{"type":"rectangle","fill":"#060D22","strokeColor":"transparent","strokeWidth":0,"borderRadius":4},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb","frame":0,"transform":{"x":358,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-fea133de-ea77-4cdc-8997-4bcd44c65421","frame":16,"transform":{"x":358,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f","frame":30,"transform":{"x":358,"y":976,"width":1338,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-1bd3d2aa-a84f-4693-bc2d-c61db3da37a9","frame":38,"transform":{"x":358,"y":976,"width":1338,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-ddfcaf4e-7c6a-4e31-94ad-e2b7b3325445","frame":44,"transform":{"x":358,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"quad-in"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3","frame":50,"transform":{"x":358,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb:x","frame":0,"value":358,"easing":"ease-in-out"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f:x","frame":30,"value":358,"easing":"ease-out"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3:x","frame":50,"value":358,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb:y","frame":0,"value":976,"easing":"ease-in-out"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f:y","frame":30,"value":976,"easing":"ease-out"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3:y","frame":50,"value":976,"easing":"ease-in"}],"width":[{"id":"property-keyframe-0ffd20dd-85a3-4afa-8faf-59eff21592cc","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-2cfeb4ec-0393-47cf-9c55-075fe185f81c","frame":16,"value":0,"easing":"linear"},{"id":"property-keyframe-0c56c40f-a5db-4a31-94f1-5a2811ba398e","frame":30,"value":1338,"easing":"cubic-out"},{"id":"property-keyframe-96fe1025-85cb-4702-af39-0d2f829518a0","frame":38,"value":1338,"easing":"linear"},{"id":"property-keyframe-ad87f6ae-6de9-4a19-81f5-0811a6a6702b","frame":44,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb:height","frame":0,"value":48,"easing":"ease-in-out"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f:height","frame":30,"value":48,"easing":"ease-out"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3:height","frame":50,"value":48,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-487ea2a6-91b9-4ffa-ba7d-93faa1aecf81","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-8d24eab8-9812-41d0-a40d-6b39efadf68e","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-8a18d3e9-e46b-4a17-b6d7-2b54f3bf2ceb:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-87602f25-bdfa-419f-8cd1-5318a5e7fc1f:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-ff8ea018-cd27-4ce3-b3ee-9bb6f67111d3:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":null,"clipParentId":null},{"id":"layer-3d3bce13-acb7-4dd6-8843-c7bbb51de6ba","isVisible":true,"element":{"type":"text","content":"BIST 100 +1.4%   EUR/TRY 47.20   GOLD 4,180 USD/OZ   BRENT 71.40   AEGEAN COAST 33C   IZMIR RING ROAD CLEAR","color":"#E0EBFC","fontFamily":"Arial, Helvetica, sans-serif","fontSize":24,"fontWeight":600,"textAlign":"left","autoFit":"fixed"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95","frame":0,"transform":{"x":358,"y":984,"width":3000,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394","frame":30,"transform":{"x":358,"y":984,"width":3000,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762","frame":50,"transform":{"x":358,"y":984,"width":3000,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:x","frame":0,"value":358,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:x","frame":30,"value":358,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:x","frame":50,"value":358,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:y","frame":0,"value":984,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:y","frame":30,"value":984,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:y","frame":50,"value":984,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:width","frame":0,"value":3000,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:width","frame":30,"value":3000,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:width","frame":50,"value":3000,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:height","frame":0,"value":34,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:height","frame":30,"value":34,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:height","frame":50,"value":34,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-98deae1e-e93e-40ed-9db6-560e7bc1f1e6","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-5b8babfd-64de-4563-9c54-c84fb69c0102","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-2f4809f9-22d6-453b-9b55-eab6f12b5a95:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-cae23972-1375-43f7-a16b-9aab15785394:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-61fb5e83-7d64-4f71-a204-ba9dcaf90762:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-3d3bce13-acb7-4dd6-8843-c7bbb51de6ba:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-3d3bce13-acb7-4dd6-8843-c7bbb51de6ba:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-3d3bce13-acb7-4dd6-8843-c7bbb51de6ba:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-3d3bce13-acb7-4dd6-8843-c7bbb51de6ba:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-3d3bce13-acb7-4dd6-8843-c7bbb51de6ba:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":{"id":"layer-loop-e5107876-49c6-4a34-99f0-21988ec68f8c","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":750,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"x":[{"id":"property-keyframe-04e078d4-18aa-4bf8-b3f1-cd2298b29965","frame":0,"value":358,"easing":"linear"},{"id":"property-keyframe-afc4360c-111c-4e56-b699-95e000e810e3","frame":750,"value":-1142,"easing":"linear"}]}},"binding":{"dataKey":"ticker","targetProperty":"content"},"clipParentId":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44"},{"id":"layer-6423df88-22fa-4f0d-a109-03fbafdf931a","isVisible":true,"element":{"type":"text","content":"BIST 100 +1.4%   EUR/TRY 47.20   GOLD 4,180 USD/OZ   BRENT 71.40   AEGEAN COAST 33C   IZMIR RING ROAD CLEAR","color":"#E0EBFC","fontFamily":"Arial, Helvetica, sans-serif","fontSize":24,"fontWeight":600,"textAlign":"left","autoFit":"fixed"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870","frame":0,"transform":{"x":1858,"y":984,"width":3000,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8","frame":30,"transform":{"x":1858,"y":984,"width":3000,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2","frame":50,"transform":{"x":1858,"y":984,"width":3000,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:x","frame":0,"value":1858,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:x","frame":30,"value":1858,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:x","frame":50,"value":1858,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:y","frame":0,"value":984,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:y","frame":30,"value":984,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:y","frame":50,"value":984,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:width","frame":0,"value":3000,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:width","frame":30,"value":3000,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:width","frame":50,"value":3000,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:height","frame":0,"value":34,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:height","frame":30,"value":34,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:height","frame":50,"value":34,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-7a036460-7d92-4ccd-9953-ec8a03ae2e0b","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-6399dd8f-f27c-403f-a8eb-92e16c6e58c1","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-4ebb71e6-e5cf-43b6-905a-49ec9e835870:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a6fa77d1-dc23-4d7f-ae6e-9f1ea5b100f8:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-e3d24af2-0599-4b77-8a3e-3b33781350f2:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-6423df88-22fa-4f0d-a109-03fbafdf931a:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-6423df88-22fa-4f0d-a109-03fbafdf931a:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-6423df88-22fa-4f0d-a109-03fbafdf931a:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-6423df88-22fa-4f0d-a109-03fbafdf931a:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-6423df88-22fa-4f0d-a109-03fbafdf931a:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":{"id":"layer-loop-c1977594-882e-4303-9bbd-752a966a4434","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":750,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"x":[{"id":"property-keyframe-ee4c913a-ea06-4da6-9d23-18d098dac1fc","frame":0,"value":1858,"easing":"linear"},{"id":"property-keyframe-d8f10759-86a5-48f7-ad7b-ccef92f0bbb3","frame":750,"value":358,"easing":"linear"}]}},"binding":{"dataKey":"ticker","targetProperty":"content"},"clipParentId":"layer-3712383f-0ca1-4642-af4b-62d70fa72d44"},{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1","isVisible":true,"element":{"type":"rectangle","fill":{"angle":180,"stops":[{"color":"#E11D2E","offset":0,"opacity":1},{"color":"#96101C","offset":1,"opacity":1}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":4},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250","frame":0,"transform":{"x":150,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-7bbe7bbb-fe30-4ba6-a718-6922fa8ac5a2","frame":14,"transform":{"x":150,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-3abb5d54-7a2c-4250-95eb-2badf4f0bac9","frame":28,"transform":{"x":150,"y":976,"width":200,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183","frame":30,"transform":{"x":150,"y":976,"width":200,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-6a532f60-398d-4673-a2c3-538faabf0216","frame":40,"transform":{"x":150,"y":976,"width":200,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-e9bcfb9c-84d4-4ce9-8a3b-7fe63728fa53","frame":46,"transform":{"x":150,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"quad-in"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf","frame":50,"transform":{"x":150,"y":976,"width":1,"height":48,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250:x","frame":0,"value":150,"easing":"ease-in-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183:x","frame":30,"value":150,"easing":"ease-out"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf:x","frame":50,"value":150,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250:y","frame":0,"value":976,"easing":"ease-in-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183:y","frame":30,"value":976,"easing":"ease-out"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf:y","frame":50,"value":976,"easing":"ease-in"}],"width":[{"id":"property-keyframe-9013f98f-3fbf-421d-b823-d2a59736b8d1","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-8d8a049e-cabc-4e43-b964-8907fdd99b74","frame":14,"value":0,"easing":"linear"},{"id":"property-keyframe-f1fd9bee-c6d7-4fdb-8de1-a4dc64b65b2f","frame":28,"value":200,"easing":"cubic-out"},{"id":"property-keyframe-87d5a025-75dc-4a58-b5de-4c4a0f32a724","frame":40,"value":200,"easing":"linear"},{"id":"property-keyframe-43d2adc7-98bc-4abb-a9f6-ba2ddd1a2868","frame":46,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250:height","frame":0,"value":48,"easing":"ease-in-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183:height","frame":30,"value":48,"easing":"ease-out"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf:height","frame":50,"value":48,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-9eb1a263-c4f6-4936-a2ca-55509a78b8cc","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-3de00cba-089b-4e82-aabf-5530d637e453","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-1de781bc-406b-4e3f-abd5-2c3c227f2250:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-5dc22d92-8099-4b58-ab10-8be8a4656183:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-0a1ce297-48cf-4f89-a05f-340c9d16a7bf:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1:fill.stops[1].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"accent_paint","targetProperty":"fill"},"clipParentId":null},{"id":"layer-56647da1-71fb-419c-83ec-48d3bdf00371","isVisible":true,"element":{"type":"text","content":"PIYASA","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":24,"fontWeight":800,"textAlign":"center","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54","frame":0,"transform":{"x":150,"y":988,"width":200,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31","frame":30,"transform":{"x":150,"y":988,"width":200,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce","frame":50,"transform":{"x":150,"y":988,"width":200,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:x","frame":0,"value":150,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:x","frame":30,"value":150,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:x","frame":50,"value":150,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:y","frame":0,"value":988,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:y","frame":30,"value":988,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:y","frame":50,"value":988,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:width","frame":0,"value":200,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:width","frame":30,"value":200,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:width","frame":50,"value":200,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:height","frame":0,"value":34,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:height","frame":30,"value":34,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:height","frame":50,"value":34,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-92a69bcf-d4f6-4c36-a0cf-72ba9e7fcbf1","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-cf847acf-611e-45ad-951d-5d6f9c3fa9cf","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-7602a292-b112-4b05-a63e-c39e8e19cd54:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-992e5de9-443b-4228-9320-466fdfb53b31:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-431e22de-c1f6-41db-b75b-c797ef3337ce:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-56647da1-71fb-419c-83ec-48d3bdf00371:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-56647da1-71fb-419c-83ec-48d3bdf00371:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-56647da1-71fb-419c-83ec-48d3bdf00371:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-56647da1-71fb-419c-83ec-48d3bdf00371:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-56647da1-71fb-419c-83ec-48d3bdf00371:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"ticker_label","targetProperty":"content"},"clipParentId":"layer-bc0e1536-bd09-4440-a011-8a3b111a12d1"},{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276","isVisible":true,"element":{"type":"rectangle","fill":{"angle":180,"stops":[{"color":"#0C1836","offset":0,"opacity":1},{"color":"#060D22","offset":1,"opacity":1}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":0},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531","frame":0,"transform":{"x":346,"y":914,"width":1,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-589311cf-cc28-4298-8f30-7424bdc7cba7","frame":10,"transform":{"x":346,"y":914,"width":1,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-2a2bc8b1-d609-48da-877c-d17a191fa5b5","frame":26,"transform":{"x":346,"y":914,"width":1350,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a","frame":30,"transform":{"x":346,"y":914,"width":1350,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-0ba937c0-d9f5-4044-8944-606718bc4436","frame":42,"transform":{"x":346,"y":914,"width":1350,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-78859c49-3667-4646-8050-0f171f4aa82d","frame":48,"transform":{"x":346,"y":914,"width":1,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"quad-in"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27","frame":50,"transform":{"x":346,"y":914,"width":1,"height":54,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531:x","frame":0,"value":346,"easing":"ease-in-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a:x","frame":30,"value":346,"easing":"ease-out"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27:x","frame":50,"value":346,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531:y","frame":0,"value":914,"easing":"ease-in-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a:y","frame":30,"value":914,"easing":"ease-out"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27:y","frame":50,"value":914,"easing":"ease-in"}],"width":[{"id":"property-keyframe-ce3bf7c2-977b-4e53-b737-c69daadf4269","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-eba5125d-5aad-4029-b117-5270ec43559d","frame":10,"value":0,"easing":"linear"},{"id":"property-keyframe-57b44699-ef77-4ed2-85f5-ee8cf88773d5","frame":26,"value":1350,"easing":"cubic-out"},{"id":"property-keyframe-0a2217db-9c25-4d5d-a8f2-92c475fb988b","frame":42,"value":1350,"easing":"linear"},{"id":"property-keyframe-583c2c18-2cd8-444e-b8b6-846f7c331fb3","frame":48,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531:height","frame":0,"value":54,"easing":"ease-in-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a:height","frame":30,"value":54,"easing":"ease-out"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27:height","frame":50,"value":54,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-30b67fab-5330-4277-9138-3f49e838aa48","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-0185ffc9-dece-4615-8084-ed7c40e99546","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-14e13ea3-e92d-45ee-9d81-9a497800e531:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-264d5dd5-1ac1-4d3b-953c-657bee5f8c9a:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-3bef8d45-38fe-4ae8-975f-d42192f11d27:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-c631f8a8-fb12-467e-b311-7588906f5276:fill.stops[1].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":null,"binding":null,"clipParentId":null},{"id":"layer-407277d2-510d-44d2-9358-0c7878757e11","isVisible":true,"element":{"type":"text","content":"MELIS ARSLAN","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":26,"fontWeight":700,"textAlign":"left","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658","frame":0,"transform":{"x":386,"y":923,"width":640,"height":36,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29","frame":30,"transform":{"x":386,"y":923,"width":640,"height":36,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0","frame":50,"transform":{"x":386,"y":923,"width":640,"height":36,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:x","frame":0,"value":386,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:x","frame":30,"value":386,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:x","frame":50,"value":386,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:y","frame":0,"value":923,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:y","frame":30,"value":923,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:y","frame":50,"value":923,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:width","frame":0,"value":640,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:width","frame":30,"value":640,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:width","frame":50,"value":640,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:height","frame":0,"value":36,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:height","frame":30,"value":36,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:height","frame":50,"value":36,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-3920b62b-d8eb-45a2-b31e-6dc6987f2ac1","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-b457aca4-554a-4e12-b35c-05088d965797","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-e5072a11-494c-494f-8c9b-e724df861658:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-30607ef9-0bff-4e2a-8456-b2dd188cfa29:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-be4067ae-e570-4704-8359-32a001fbd3c0:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-407277d2-510d-44d2-9358-0c7878757e11:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-407277d2-510d-44d2-9358-0c7878757e11:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-407277d2-510d-44d2-9358-0c7878757e11:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-407277d2-510d-44d2-9358-0c7878757e11:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-407277d2-510d-44d2-9358-0c7878757e11:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"reporter","targetProperty":"content"},"clipParentId":"layer-c631f8a8-fb12-467e-b311-7588906f5276"},{"id":"layer-e61bbad7-2a6e-4f6c-9eda-56a1d2363059","isVisible":true,"element":{"type":"text","content":"SEFERIHISAR / IZMIR","color":"#B9D2F6","fontFamily":"Arial, Helvetica, sans-serif","fontSize":25,"fontWeight":500,"textAlign":"right","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b","frame":0,"transform":{"x":1026,"y":924,"width":630,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd","frame":30,"transform":{"x":1026,"y":924,"width":630,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a","frame":50,"transform":{"x":1026,"y":924,"width":630,"height":34,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:x","frame":0,"value":1026,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:x","frame":30,"value":1026,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:x","frame":50,"value":1026,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:y","frame":0,"value":924,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:y","frame":30,"value":924,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:y","frame":50,"value":924,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:width","frame":0,"value":630,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:width","frame":30,"value":630,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:width","frame":50,"value":630,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:height","frame":0,"value":34,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:height","frame":30,"value":34,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:height","frame":50,"value":34,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-06b3cf21-9c5d-43f8-a405-25061116e179","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-4233a1b1-69ee-4286-8a32-e6cd38b1d3cf","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-2714a8d6-721d-4fae-ba2a-47a5db3ce22b:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-9f319e33-d06c-4557-9924-615fe7cef9cd:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-ba66eb5e-ff70-47ba-abda-19edda1cd85a:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-e61bbad7-2a6e-4f6c-9eda-56a1d2363059:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-e61bbad7-2a6e-4f6c-9eda-56a1d2363059:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-e61bbad7-2a6e-4f6c-9eda-56a1d2363059:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-e61bbad7-2a6e-4f6c-9eda-56a1d2363059:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-e61bbad7-2a6e-4f6c-9eda-56a1d2363059:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"location","targetProperty":"content"},"clipParentId":"layer-c631f8a8-fb12-467e-b311-7588906f5276"},{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a","isVisible":true,"element":{"type":"rectangle","fill":{"angle":180,"stops":[{"color":"#1E3A8A","offset":0,"opacity":1},{"color":"#0C1836","offset":1,"opacity":1}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":0},"effects":{"blur":0,"dropShadowEnabled":true,"dropShadowColor":"#000000","dropShadowOpacity":0.42,"dropShadowOffsetX":0,"dropShadowOffsetY":12,"dropShadowBlur":30},"keyframes":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe","frame":0,"transform":{"x":346,"y":794,"width":1,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-fe104210-3db3-4771-9143-4be8d65ce114","frame":2,"transform":{"x":346,"y":794,"width":1,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-b7f9b3c6-060f-4cea-8946-ac5541183bd5","frame":20,"transform":{"x":346,"y":794,"width":1350,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31","frame":30,"transform":{"x":346,"y":794,"width":1350,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-720790bd-4e5b-4f71-aac0-343066b4c384","frame":44,"transform":{"x":346,"y":794,"width":1350,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993","frame":50,"transform":{"x":346,"y":794,"width":1,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe:x","frame":0,"value":346,"easing":"ease-in-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31:x","frame":30,"value":346,"easing":"ease-out"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993:x","frame":50,"value":346,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe:y","frame":0,"value":794,"easing":"ease-in-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31:y","frame":30,"value":794,"easing":"ease-out"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993:y","frame":50,"value":794,"easing":"ease-in"}],"width":[{"id":"property-keyframe-f9a5def1-f87e-4112-9dab-d05dcb68fa1a","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-62da6309-2b91-45a6-a5e4-bfc5e961ab1e","frame":2,"value":0,"easing":"linear"},{"id":"property-keyframe-f899ec1b-598e-4bf6-b796-0d604058f2f5","frame":20,"value":1350,"easing":"cubic-out"},{"id":"property-keyframe-801d9b26-8018-4610-b8d5-d3aea4a2f35c","frame":44,"value":1350,"easing":"linear"},{"id":"property-keyframe-85d9f814-7b55-4363-95aa-9416440bed32","frame":50,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe:height","frame":0,"value":120,"easing":"ease-in-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31:height","frame":30,"value":120,"easing":"ease-out"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993:height","frame":50,"value":120,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-2a4bb5f6-5582-485f-baf2-be01761bd338","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-1f2c5cb0-c2a3-4b54-a24f-2395eec67e02","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-318388e9-509f-4463-a97e-126d803158fe:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-0e5813c5-18e6-4e5b-a3b8-cdd16bb80f31:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-4d096288-35a2-4d9b-9e0c-1109341a1993:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:dropShadowOpacity:0","frame":0,"value":0.42,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:dropShadowOffsetX:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:dropShadowOffsetY:0","frame":0,"value":12,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:dropShadowBlur:0","frame":0,"value":30,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a:fill.stops[1].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"bar_paint","targetProperty":"fill"},"clipParentId":null},{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9","isVisible":true,"element":{"type":"rectangle","fill":{"angle":90,"stops":[{"color":"#FFFFFF","offset":0,"opacity":0.14},{"color":"#FFFFFF","offset":0.0833,"opacity":0},{"color":"#FFFFFF","offset":0.1667,"opacity":0.14},{"color":"#FFFFFF","offset":0.25,"opacity":0},{"color":"#FFFFFF","offset":0.3333,"opacity":0.14},{"color":"#FFFFFF","offset":0.4167,"opacity":0},{"color":"#FFFFFF","offset":0.5,"opacity":0.14},{"color":"#FFFFFF","offset":0.5833,"opacity":0},{"color":"#FFFFFF","offset":0.6667,"opacity":0.14},{"color":"#FFFFFF","offset":0.75,"opacity":0},{"color":"#FFFFFF","offset":0.8333,"opacity":0.14},{"color":"#FFFFFF","offset":0.9167,"opacity":0},{"color":"#FFFFFF","offset":1,"opacity":0.14}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":0},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2","frame":0,"transform":{"x":-329,"y":654,"width":2700,"height":400,"rotation":-18,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac","frame":30,"transform":{"x":-329,"y":654,"width":2700,"height":400,"rotation":-18,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30","frame":50,"transform":{"x":-329,"y":654,"width":2700,"height":400,"rotation":-18,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:x","frame":0,"value":-329,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:x","frame":30,"value":-329,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:x","frame":50,"value":-329,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:y","frame":0,"value":654,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:y","frame":30,"value":654,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:y","frame":50,"value":654,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:width","frame":0,"value":2700,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:width","frame":30,"value":2700,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:width","frame":50,"value":2700,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:height","frame":0,"value":400,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:height","frame":30,"value":400,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:height","frame":50,"value":400,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:rotation","frame":0,"value":-18,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:rotation","frame":30,"value":-18,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:rotation","frame":50,"value":-18,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-0bd010ae-8982-4f11-b267-b8cb9a33395c","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-7a455b37-390a-4a7a-b90a-c93494a31c6f","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-1c1d8493-f8f2-427a-af4c-91bcadaeabc2:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-0e4d8230-21a8-4fc4-af62-c7f7ead769ac:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-28943315-e5d5-44e6-8f11-c5d173e8ed30:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[1].offset:0","frame":0,"value":0.0833,"easing":"linear"}],"fill.stops[2].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[2].offset:0","frame":0,"value":0.1667,"easing":"linear"}],"fill.stops[3].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[3].offset:0","frame":0,"value":0.25,"easing":"linear"}],"fill.stops[4].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[4].offset:0","frame":0,"value":0.3333,"easing":"linear"}],"fill.stops[5].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[5].offset:0","frame":0,"value":0.4167,"easing":"linear"}],"fill.stops[6].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[6].offset:0","frame":0,"value":0.5,"easing":"linear"}],"fill.stops[7].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[7].offset:0","frame":0,"value":0.5833,"easing":"linear"}],"fill.stops[8].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[8].offset:0","frame":0,"value":0.6667,"easing":"linear"}],"fill.stops[9].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[9].offset:0","frame":0,"value":0.75,"easing":"linear"}],"fill.stops[10].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[10].offset:0","frame":0,"value":0.8333,"easing":"linear"}],"fill.stops[11].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[11].offset:0","frame":0,"value":0.9167,"easing":"linear"}],"fill.stops[12].offset":[{"id":"layer-a6b48a54-76fe-4ff5-8829-508fe6017ed9:fill.stops[12].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":{"id":"layer-loop-451534be-5890-4e76-80b7-bcf867f89b0e","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":280,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"x":[{"id":"property-keyframe-cc33c071-7fb0-4aa4-a033-36f6bc2602aa","frame":0,"value":-329,"easing":"linear"},{"id":"property-keyframe-b4a4174e-0707-46ef-a05b-bedf561c6680","frame":280,"value":-802,"easing":"linear"}]}},"binding":null,"clipParentId":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a"},{"id":"layer-ae4cff04-9df4-44c5-a3ed-1081ff0a2b4d","isVisible":true,"element":{"type":"text","content":"Aegean wildfire contained after four days","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":48,"fontWeight":700,"textAlign":"left","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4","frame":0,"transform":{"x":386,"y":820,"width":1270,"height":68,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1","frame":30,"transform":{"x":386,"y":820,"width":1270,"height":68,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330","frame":50,"transform":{"x":386,"y":820,"width":1270,"height":68,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:x","frame":0,"value":386,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:x","frame":30,"value":386,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:x","frame":50,"value":386,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:y","frame":0,"value":820,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:y","frame":30,"value":820,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:y","frame":50,"value":820,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:width","frame":0,"value":1270,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:width","frame":30,"value":1270,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:width","frame":50,"value":1270,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:height","frame":0,"value":68,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:height","frame":30,"value":68,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:height","frame":50,"value":68,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-7159214b-a12a-44b4-a68c-546879016d6c","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-81277467-c8e7-4c66-93a8-daa5b5e19c3f","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-acb189fb-42a8-4b04-8d93-7fb3bb96ffb4:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a8edf77a-afb3-4a0d-9fe9-eb3c68468bf1:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-27f85c44-7d0b-4496-b656-6727b4ab9330:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-ae4cff04-9df4-44c5-a3ed-1081ff0a2b4d:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-ae4cff04-9df4-44c5-a3ed-1081ff0a2b4d:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-ae4cff04-9df4-44c5-a3ed-1081ff0a2b4d:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-ae4cff04-9df4-44c5-a3ed-1081ff0a2b4d:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-ae4cff04-9df4-44c5-a3ed-1081ff0a2b4d:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"headline","targetProperty":"content"},"clipParentId":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a"},{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f","isVisible":true,"element":{"type":"rectangle","fill":{"angle":90,"stops":[{"color":"#FFFFFF","offset":0,"opacity":0},{"color":"#BFDBFE","offset":0.5,"opacity":0.5},{"color":"#FFFFFF","offset":1,"opacity":0}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":0},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00","frame":0,"transform":{"x":46,"y":794,"width":300,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13","frame":30,"transform":{"x":46,"y":794,"width":300,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8","frame":50,"transform":{"x":46,"y":794,"width":300,"height":120,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:x","frame":0,"value":46,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:x","frame":30,"value":46,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:x","frame":50,"value":46,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:y","frame":0,"value":794,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:y","frame":30,"value":794,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:y","frame":50,"value":794,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:width","frame":0,"value":300,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:width","frame":30,"value":300,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:width","frame":50,"value":300,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:height","frame":0,"value":120,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:height","frame":30,"value":120,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:height","frame":50,"value":120,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-00f8c754-7fe6-439d-8a1c-0a55b8acff4c","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-d1549a1d-58df-44c4-a17c-54b96fd6eadc","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-c0e39395-3c7b-4786-82f5-4c34c8bf8f00:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-e3c81233-68d8-4f64-bbcd-22a77f0f5e13:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-655c20f7-ed77-4a05-ba70-5a5244aa9ca8:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:fill.stops[1].offset:0","frame":0,"value":0.5,"easing":"linear"}],"fill.stops[2].offset":[{"id":"layer-822a0433-257b-4b2a-9397-184062f7770f:fill.stops[2].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":{"id":"layer-loop-ef9a6226-d18f-457b-b556-791b0bb9e96d","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":200,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"x":[{"id":"property-keyframe-06dd5e5f-d743-4ecd-80ee-6f94be4718b7","frame":0,"value":46,"easing":"linear"},{"id":"property-keyframe-6ac7f9d5-2d2d-42f7-bbba-830c5b43ba75","frame":200,"value":1696,"easing":"linear"}]}},"binding":null,"clipParentId":"layer-1adcb489-436a-4ea7-859e-9d77b6a3562a"},{"id":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a","isVisible":true,"element":{"type":"rectangle","fill":"#0A1230","strokeColor":"transparent","strokeWidth":0,"borderRadius":100},"effects":{"blur":0,"dropShadowEnabled":true,"dropShadowColor":"#000000","dropShadowOpacity":0.45,"dropShadowOffsetX":0,"dropShadowOffsetY":10,"dropShadowBlur":26},"keyframes":[{"id":"layer-keyframe-82ad9327-2248-4113-b74d-dee3d216debc","frame":0,"transform":{"x":250,"y":852,"width":1,"height":1,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-7f7a3b64-14d0-43d8-a5f5-a1e55e6be156","frame":4,"transform":{"x":250,"y":852,"width":1,"height":1,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-20c274f1-1fce-4ce9-afd6-f1d5f0d0b2b3","frame":22,"transform":{"x":150,"y":752,"width":200,"height":200,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-a77c43f0-07e9-4831-8255-f5b5fb2c8a60","frame":30,"transform":{"x":150,"y":752,"width":200,"height":200,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-43f980ee-8211-41cd-ba25-d6bfb348d946","frame":44,"transform":{"x":150,"y":752,"width":200,"height":200,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-70be6b83-7c82-4b91-bbb9-d770ec648691","frame":50,"transform":{"x":250,"y":852,"width":1,"height":1,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"property-keyframe-6fca5c27-1cd6-41d2-9add-5047567705e7","frame":0,"value":250,"easing":"linear"},{"id":"property-keyframe-3d3ecf1d-d0c4-442e-b3c9-b84b9f5665fe","frame":4,"value":250,"easing":"linear"},{"id":"property-keyframe-81475d4d-ec4d-4c18-83a2-8ecb9ed5414c","frame":22,"value":150,"easing":"cubic-out"},{"id":"property-keyframe-379eaaed-afbb-4337-8265-9a476e9c48bc","frame":44,"value":150,"easing":"linear"},{"id":"property-keyframe-14d4a9b9-86fa-41ce-94e2-7a822055ae64","frame":50,"value":250,"easing":"quad-in"}],"y":[{"id":"property-keyframe-7ac599cc-9d65-4e67-89f3-5b295d4c457b","frame":0,"value":852,"easing":"linear"},{"id":"property-keyframe-375c9e65-58a1-4f01-86dc-b45487d1317e","frame":4,"value":852,"easing":"linear"},{"id":"property-keyframe-749116a8-e3ac-4739-8cef-0cdb2540ceaf","frame":22,"value":752,"easing":"cubic-out"},{"id":"property-keyframe-5562d681-a380-4681-839b-1f50db2b0bc4","frame":44,"value":752,"easing":"linear"},{"id":"property-keyframe-3f2bce01-efe8-409f-a7bf-16467ae9fc6a","frame":50,"value":852,"easing":"quad-in"}],"width":[{"id":"property-keyframe-de488a2f-6142-4469-af7a-a4cf63fe8ac6","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-a49ef8c7-901e-4e3f-a3e7-55801a050d3d","frame":4,"value":0,"easing":"linear"},{"id":"property-keyframe-9fe6f88f-0c0a-4c6d-88a0-eba87033c8df","frame":22,"value":200,"easing":"cubic-out"},{"id":"property-keyframe-64f8acbe-37fd-4ca8-b170-0708e1d3d39d","frame":44,"value":200,"easing":"linear"},{"id":"property-keyframe-91fbd64f-c03e-46d7-9522-6c4dc5c11e27","frame":50,"value":0,"easing":"quad-in"}],"height":[{"id":"property-keyframe-a891b392-98cd-45d1-bb13-885152079b22","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-93ded266-47c2-4fa9-bfef-0006dc7e48b1","frame":4,"value":0,"easing":"linear"},{"id":"property-keyframe-adcbf250-5f05-4905-9c8a-f9ba999f41da","frame":22,"value":200,"easing":"cubic-out"},{"id":"property-keyframe-c46c2422-1a50-4b29-b382-680e7450e740","frame":44,"value":200,"easing":"linear"},{"id":"property-keyframe-e144e781-fcb8-447e-9d23-871c448a0398","frame":50,"value":0,"easing":"quad-in"}],"rotation":[{"id":"layer-keyframe-82ad9327-2248-4113-b74d-dee3d216debc:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-a77c43f0-07e9-4831-8255-f5b5fb2c8a60:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-70be6b83-7c82-4b91-bbb9-d770ec648691:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-8818973c-4dc0-403d-be99-58a417db2e0c","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-8aa545bc-6748-4819-9354-538c055e0f3c","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-82ad9327-2248-4113-b74d-dee3d216debc:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a77c43f0-07e9-4831-8255-f5b5fb2c8a60:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-70be6b83-7c82-4b91-bbb9-d770ec648691:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-82ad9327-2248-4113-b74d-dee3d216debc:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a77c43f0-07e9-4831-8255-f5b5fb2c8a60:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-70be6b83-7c82-4b91-bbb9-d770ec648691:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a:dropShadowOpacity:0","frame":0,"value":0.45,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a:dropShadowOffsetX:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a:dropShadowOffsetY:0","frame":0,"value":10,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a:dropShadowBlur:0","frame":0,"value":26,"easing":"linear"}]},"loop":null,"binding":null,"clipParentId":null},{"id":"layer-5a09ca77-ccd8-44ed-b8a6-1b82485e7b87","isVisible":true,"element":{"type":"image","src":"assets/asset-e88c61ce-3a23-40e3-ac88-046ca99c8e70.svg"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded","frame":0,"transform":{"x":116,"y":726,"width":268,"height":268,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841","frame":30,"transform":{"x":116,"y":726,"width":268,"height":268,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f","frame":50,"transform":{"x":116,"y":726,"width":268,"height":268,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:x","frame":0,"value":116,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:x","frame":30,"value":116,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:x","frame":50,"value":116,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:y","frame":0,"value":726,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:y","frame":30,"value":726,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:y","frame":50,"value":726,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:width","frame":0,"value":268,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:width","frame":30,"value":268,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:width","frame":50,"value":268,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:height","frame":0,"value":268,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:height","frame":30,"value":268,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:height","frame":50,"value":268,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-2f37d6f1-bcd6-41bf-a951-4511f819988b","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-a1c6d75c-8ee9-4401-b511-fac555112dc3","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-3fbd9b8b-1323-4a24-98d9-d276b7daeded:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-a20664ff-05bf-4100-bc55-1e12b35cf841:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-30e1fc64-d46a-4699-9a48-bf0508a0323f:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-5a09ca77-ccd8-44ed-b8a6-1b82485e7b87:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-5a09ca77-ccd8-44ed-b8a6-1b82485e7b87:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-5a09ca77-ccd8-44ed-b8a6-1b82485e7b87:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-5a09ca77-ccd8-44ed-b8a6-1b82485e7b87:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-5a09ca77-ccd8-44ed-b8a6-1b82485e7b87:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"portrait","targetProperty":"src"},"clipParentId":"layer-d8e48794-c19d-42a2-966f-b4bdcc58af6a"},{"id":"layer-2f18a959-1f0e-4fab-be2d-375167684071","isVisible":true,"element":{"type":"path","d":"M50,6 A44,44 0 0,1 94,50 M50,94 A44,44 0 0,1 6,50","fill":"transparent","strokeColor":"#38BDF8","strokeWidth":5,"viewBoxWidth":100,"viewBoxHeight":100},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4","frame":0,"transform":{"x":138,"y":740,"width":224,"height":224,"rotation":0,"opacity":0,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-8df10627-f37f-4d71-a1e5-ebd717970e4e","frame":6,"transform":{"x":138,"y":740,"width":224,"height":224,"rotation":0,"opacity":0,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-ef20b0ab-3a1d-4a2f-8009-2570a063afc0","frame":20,"transform":{"x":138,"y":740,"width":224,"height":224,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470","frame":30,"transform":{"x":138,"y":740,"width":224,"height":224,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-7bc545d3-0875-4fdf-b3a5-96228e9443b4","frame":44,"transform":{"x":138,"y":740,"width":224,"height":224,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049","frame":50,"transform":{"x":138,"y":740,"width":224,"height":224,"rotation":0,"opacity":0,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:x","frame":0,"value":138,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:x","frame":30,"value":138,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:x","frame":50,"value":138,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:y","frame":0,"value":740,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:y","frame":30,"value":740,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:y","frame":50,"value":740,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:width","frame":0,"value":224,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:width","frame":30,"value":224,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:width","frame":50,"value":224,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:height","frame":0,"value":224,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:height","frame":30,"value":224,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:height","frame":50,"value":224,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-2e5e8ece-68a7-444d-a520-718d8c8d6e5d","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-6647214c-8396-4771-9205-5d471076fb63","frame":6,"value":0,"easing":"linear"},{"id":"property-keyframe-9430f4dd-d991-42ed-a3a2-14640d96ee0b","frame":20,"value":1,"easing":"cubic-out"},{"id":"property-keyframe-74be7834-b95c-4ebb-b169-a4d5585fe46e","frame":44,"value":1,"easing":"linear"},{"id":"property-keyframe-2f9eda6f-355b-43c0-a07a-6e5db5529ede","frame":50,"value":0,"easing":"quad-in"}],"transformOriginX":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-c960f916-4d5c-4193-bac0-2e76ef278ed4:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-1b28301b-8167-4788-9ed8-6bc8c14a7470:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-9ad844a1-6620-41d8-b74c-9babd085a049:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-2f18a959-1f0e-4fab-be2d-375167684071:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-2f18a959-1f0e-4fab-be2d-375167684071:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-2f18a959-1f0e-4fab-be2d-375167684071:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-2f18a959-1f0e-4fab-be2d-375167684071:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-2f18a959-1f0e-4fab-be2d-375167684071:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":{"id":"layer-loop-01a7e45b-354b-4cf1-aba1-b95f7781a9f9","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":200,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"rotation":[{"id":"property-keyframe-904bbb22-ddba-46d7-960f-6680efeb2632","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-3630958e-8db5-456e-85bb-b74a1a6ad81f","frame":200,"value":360,"easing":"linear"}]}},"binding":null,"clipParentId":null},{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132","isVisible":true,"element":{"type":"rectangle","fill":{"angle":180,"stops":[{"color":"#E11D2E","offset":0,"opacity":1},{"color":"#96101C","offset":1,"opacity":1}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":0},"effects":{"blur":0,"dropShadowEnabled":true,"dropShadowColor":"#000000","dropShadowOpacity":0.4,"dropShadowOffsetX":0,"dropShadowOffsetY":6,"dropShadowBlur":18},"keyframes":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547","frame":0,"transform":{"x":372,"y":726,"width":1,"height":64,"rotation":-4,"opacity":1,"transformOriginX":0,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-6ddeab68-c3f6-4ee4-9edf-ae98139f8577","frame":16,"transform":{"x":372,"y":726,"width":380,"height":64,"rotation":-4,"opacity":1,"transformOriginX":0,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e","frame":30,"transform":{"x":372,"y":726,"width":380,"height":64,"rotation":-4,"opacity":1,"transformOriginX":0,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-a93fe07c-672c-42db-b8da-3422141be853","frame":44,"transform":{"x":372,"y":726,"width":380,"height":64,"rotation":-4,"opacity":1,"transformOriginX":0,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974","frame":50,"transform":{"x":372,"y":726,"width":1,"height":64,"rotation":-4,"opacity":1,"transformOriginX":0,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547:x","frame":0,"value":372,"easing":"ease-in-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e:x","frame":30,"value":372,"easing":"ease-out"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974:x","frame":50,"value":372,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547:y","frame":0,"value":726,"easing":"ease-in-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e:y","frame":30,"value":726,"easing":"ease-out"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974:y","frame":50,"value":726,"easing":"ease-in"}],"width":[{"id":"property-keyframe-761c5022-a3e3-4dd7-bfb5-2bb8b4adf3ad","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-52b09e74-50b0-4466-8ff0-26dadde99b09","frame":16,"value":380,"easing":"cubic-out"},{"id":"property-keyframe-a5a8d6dd-3f49-4685-9eed-8e855a1304e7","frame":44,"value":380,"easing":"linear"},{"id":"property-keyframe-a3eadff3-b397-4fa2-adbc-516c0b106d3e","frame":50,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547:height","frame":0,"value":64,"easing":"ease-in-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e:height","frame":30,"value":64,"easing":"ease-out"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974:height","frame":50,"value":64,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547:rotation","frame":0,"value":-4,"easing":"ease-in-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e:rotation","frame":30,"value":-4,"easing":"ease-out"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974:rotation","frame":50,"value":-4,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-de24be21-1414-4855-a271-049616d3f48b","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-75022064-fcc9-402b-ad83-36d96fcb299a","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547:transformOriginX","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e:transformOriginX","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974:transformOriginX","frame":50,"value":0,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-1998973f-8651-475a-88c9-4dec19671547:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-5cc4f03b-3753-4c3a-91bc-17098188ef3e:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-dee9ac5e-d2ad-40d2-83e3-20712154f974:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:dropShadowOpacity:0","frame":0,"value":0.4,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:dropShadowOffsetX:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:dropShadowOffsetY:0","frame":0,"value":6,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:dropShadowBlur:0","frame":0,"value":18,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132:fill.stops[1].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"accent_paint","targetProperty":"fill"},"clipParentId":null},{"id":"layer-3c2d4ec4-2e9e-4ca3-8cf6-cf106bccd866","isVisible":true,"element":{"type":"text","content":"SON DAKIKA","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":27,"fontWeight":800,"textAlign":"center","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf","frame":0,"transform":{"x":396,"y":740,"width":332,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e","frame":30,"transform":{"x":396,"y":740,"width":332,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c","frame":50,"transform":{"x":396,"y":740,"width":332,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:x","frame":0,"value":396,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:x","frame":30,"value":396,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:x","frame":50,"value":396,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:y","frame":0,"value":740,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:y","frame":30,"value":740,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:y","frame":50,"value":740,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:width","frame":0,"value":332,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:width","frame":30,"value":332,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:width","frame":50,"value":332,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:height","frame":0,"value":38,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:height","frame":30,"value":38,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:height","frame":50,"value":38,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-b08699e5-1f64-49d6-87d0-9c784edc6fa4","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-1c920766-3364-41a0-b4f8-ca1430157446","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-f28d3e2d-051a-4d3a-96a3-d3c1a406b6bf:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-dbd4c63a-ef65-4364-b481-24732e07135e:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-0a88c28a-2197-41d8-8e51-c2e96650e69c:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-3c2d4ec4-2e9e-4ca3-8cf6-cf106bccd866:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-3c2d4ec4-2e9e-4ca3-8cf6-cf106bccd866:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-3c2d4ec4-2e9e-4ca3-8cf6-cf106bccd866:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-3c2d4ec4-2e9e-4ca3-8cf6-cf106bccd866:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-3c2d4ec4-2e9e-4ca3-8cf6-cf106bccd866:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"kicker","targetProperty":"content"},"clipParentId":"layer-2459da83-1c6a-411a-bca0-6c8b4d75a132"},{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0","isVisible":true,"element":{"type":"rectangle","fill":{"angle":90,"stops":[{"color":"#E11D2E","offset":0,"opacity":1},{"color":"#FF6B7A","offset":0.5,"opacity":1},{"color":"#96101C","offset":1,"opacity":1}],"type":"linear"},"strokeColor":"transparent","strokeWidth":0,"borderRadius":8},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53","frame":0,"transform":{"x":1330,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-9dd3f750-394b-43f9-afc5-7d3545248de4","frame":8,"transform":{"x":1330,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-d5a94cac-8ec7-4c6d-b72e-e46c5e81dd14","frame":22,"transform":{"x":1330,"y":726,"width":150,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432","frame":30,"transform":{"x":1330,"y":726,"width":150,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-18d8e898-1dc4-4125-9c1a-c232c03790ea","frame":42,"transform":{"x":1330,"y":726,"width":150,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-c60068de-1485-44e3-ba90-ba308ebd8525","frame":48,"transform":{"x":1330,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"quad-in"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31","frame":50,"transform":{"x":1330,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53:x","frame":0,"value":1330,"easing":"ease-in-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432:x","frame":30,"value":1330,"easing":"ease-out"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31:x","frame":50,"value":1330,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53:y","frame":0,"value":726,"easing":"ease-in-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432:y","frame":30,"value":726,"easing":"ease-out"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31:y","frame":50,"value":726,"easing":"ease-in"}],"width":[{"id":"property-keyframe-4455d69d-4046-432c-8f35-0f5048e847f3","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-2fe74d07-c565-4106-af4e-90a8e1a9884c","frame":8,"value":0,"easing":"linear"},{"id":"property-keyframe-5b00722b-4375-4538-af6e-7be652076077","frame":22,"value":150,"easing":"cubic-out"},{"id":"property-keyframe-e7faf0a5-cd77-4934-8dd0-09b2ca9e2f29","frame":42,"value":150,"easing":"linear"},{"id":"property-keyframe-fa7a804e-de93-4ec0-b0e3-690a61e1fd0d","frame":48,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53:height","frame":0,"value":64,"easing":"ease-in-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432:height","frame":30,"value":64,"easing":"ease-out"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31:height","frame":50,"value":64,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-efe4f859-b25c-4da0-80d8-23e32f295d97","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-df901a5b-6cc3-4a24-98ad-ca59a3e3509f","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-8597f7ae-1472-4bd9-8670-edfb96de8b53:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-44414e11-b1ae-4b23-aa1b-20aa6c608432:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-ec43d577-bcf7-4995-9a90-4284a710ad31:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}],"fill.stops[0].offset":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:fill.stops[0].offset:0","frame":0,"value":0,"easing":"linear"}],"fill.stops[1].offset":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:fill.stops[1].offset:0","frame":0,"value":0.5,"easing":"linear"}],"fill.stops[2].offset":[{"id":"layer-0f7d4585-bfda-4138-974b-c009df798fd0:fill.stops[2].offset:0","frame":0,"value":1,"easing":"linear"}]},"loop":{"id":"layer-loop-73241347-25cc-43b9-9d31-0db57d917c0c","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":120,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"fill.stops[1].offset":[{"id":"property-keyframe-8bd5edad-a58f-47fc-9d73-95f61278542c","frame":0,"value":0.15,"easing":"sine-in-out"},{"id":"property-keyframe-5352d3a1-cd14-4e9a-af3b-e77061adf4e1","frame":60,"value":0.85,"easing":"sine-in-out"},{"id":"property-keyframe-14cb5409-332c-4614-96de-8ca913be5853","frame":120,"value":0.15,"easing":"sine-in-out"}]}},"binding":{"dataKey":"badge_paint","targetProperty":"fill"},"clipParentId":null},{"id":"layer-a46f7138-17b4-4855-9395-3d9a3090b201","isVisible":true,"element":{"type":"ellipse","fill":"#FFFFFF","strokeColor":"transparent","strokeWidth":0},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c","frame":0,"transform":{"x":1352,"y":748,"width":20,"height":20,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2","frame":30,"transform":{"x":1352,"y":748,"width":20,"height":20,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec","frame":50,"transform":{"x":1352,"y":748,"width":20,"height":20,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:x","frame":0,"value":1352,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:x","frame":30,"value":1352,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:x","frame":50,"value":1352,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:y","frame":0,"value":748,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:y","frame":30,"value":748,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:y","frame":50,"value":748,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:width","frame":0,"value":20,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:width","frame":30,"value":20,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:width","frame":50,"value":20,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:height","frame":0,"value":20,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:height","frame":30,"value":20,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:height","frame":50,"value":20,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-43d1eeec-5887-4da6-9b53-8da761bfd67a","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-a425b45a-d3fe-43e5-8a90-9c9f7ba62712","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-dd0eefc6-718d-4f23-9bae-b0f23135459c:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-e4c39bbe-6f90-4c1b-b592-1a86c4664ef2:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-baa9c3b6-86e7-412e-ada8-c25175c2dcec:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-a46f7138-17b4-4855-9395-3d9a3090b201:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-a46f7138-17b4-4855-9395-3d9a3090b201:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-a46f7138-17b4-4855-9395-3d9a3090b201:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-a46f7138-17b4-4855-9395-3d9a3090b201:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-a46f7138-17b4-4855-9395-3d9a3090b201:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":{"id":"layer-loop-a6c41b11-2ed7-471b-bb95-de8f39a1c7fc","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":60,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"opacity":[{"id":"property-keyframe-7952e048-201a-4787-be20-cfbffe1a1d52","frame":0,"value":1,"easing":"sine-in-out"},{"id":"property-keyframe-3fb6ca3b-61d6-42b8-bd00-2ddad8315855","frame":30,"value":0.15,"easing":"sine-in-out"},{"id":"property-keyframe-9b1dfb54-cda1-43ff-917f-303018f844ff","frame":60,"value":1,"easing":"sine-in-out"}]}},"binding":null,"clipParentId":"layer-0f7d4585-bfda-4138-974b-c009df798fd0"},{"id":"layer-5e19cd7e-e9df-4bbc-9d92-08b3e51f54b8","isVisible":true,"element":{"type":"text","content":"CANLI","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":26,"fontWeight":800,"textAlign":"left","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd","frame":0,"transform":{"x":1380,"y":740,"width":84,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608","frame":30,"transform":{"x":1380,"y":740,"width":84,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628","frame":50,"transform":{"x":1380,"y":740,"width":84,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:x","frame":0,"value":1380,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:x","frame":30,"value":1380,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:x","frame":50,"value":1380,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:y","frame":0,"value":740,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:y","frame":30,"value":740,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:y","frame":50,"value":740,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:width","frame":0,"value":84,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:width","frame":30,"value":84,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:width","frame":50,"value":84,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:height","frame":0,"value":38,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:height","frame":30,"value":38,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:height","frame":50,"value":38,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-bb952824-b179-455c-8175-4047f8ce238f","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-a59dfd67-447f-4a39-a976-8ec3be7cc655","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-8336fda6-f781-4c1d-a1ab-c8e15ce638fd:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-24920baa-2bbc-4644-bd52-06950288f608:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-76ba9f63-febe-4801-bdf0-9486162fa628:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-5e19cd7e-e9df-4bbc-9d92-08b3e51f54b8:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-5e19cd7e-e9df-4bbc-9d92-08b3e51f54b8:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-5e19cd7e-e9df-4bbc-9d92-08b3e51f54b8:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-5e19cd7e-e9df-4bbc-9d92-08b3e51f54b8:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-5e19cd7e-e9df-4bbc-9d92-08b3e51f54b8:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"live_label","targetProperty":"content"},"clipParentId":"layer-0f7d4585-bfda-4138-974b-c009df798fd0"},{"id":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a","isVisible":true,"element":{"type":"rectangle","fill":"#0C1836","strokeColor":"transparent","strokeWidth":0,"borderRadius":8},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7","frame":0,"transform":{"x":1496,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-34b872bf-292b-48bc-a379-ba9b23ff6fcf","frame":12,"transform":{"x":1496,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-0f0a09cb-2fc4-4226-82cd-3143520b667d","frame":26,"transform":{"x":1496,"y":726,"width":200,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec","frame":30,"transform":{"x":1496,"y":726,"width":200,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-d5a6a22d-5a4b-4fca-a91e-e259adf34611","frame":40,"transform":{"x":1496,"y":726,"width":200,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"linear"},{"id":"layer-keyframe-3e646de5-8100-4db3-88a3-aa43737337c9","frame":46,"transform":{"x":1496,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"quad-in"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21","frame":50,"transform":{"x":1496,"y":726,"width":1,"height":64,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7:x","frame":0,"value":1496,"easing":"ease-in-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec:x","frame":30,"value":1496,"easing":"ease-out"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21:x","frame":50,"value":1496,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7:y","frame":0,"value":726,"easing":"ease-in-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec:y","frame":30,"value":726,"easing":"ease-out"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21:y","frame":50,"value":726,"easing":"ease-in"}],"width":[{"id":"property-keyframe-c680e580-8cd4-4227-b3b3-dd03076df7ac","frame":0,"value":0,"easing":"linear"},{"id":"property-keyframe-309fb8ea-b730-4cf7-a112-6efc0a01e417","frame":12,"value":0,"easing":"linear"},{"id":"property-keyframe-e9ac003f-6b93-44fb-931d-d1bc38d51817","frame":26,"value":200,"easing":"cubic-out"},{"id":"property-keyframe-dfb5f61f-163c-460b-a9f3-d84b7702a3ec","frame":40,"value":200,"easing":"linear"},{"id":"property-keyframe-0c250310-cdaa-4a41-9020-33d30fc34791","frame":46,"value":0,"easing":"quad-in"}],"height":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7:height","frame":0,"value":64,"easing":"ease-in-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec:height","frame":30,"value":64,"easing":"ease-out"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21:height","frame":50,"value":64,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-571e88b7-8aa3-4126-9e6b-33d1e3ca9c95","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-86687499-1d01-4eb2-8c3e-37edaf64e981","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-fe74c275-4279-4020-a7b2-6b0e2d5d5bb7:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-0506913d-1fd7-41d7-b210-323aac13eaec:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-a3f00ac9-e735-4e36-8a04-50298e8bca21:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":null,"clipParentId":null},{"id":"layer-2d60abe2-3b47-44c2-9675-7291e4d4434a","isVisible":true,"element":{"type":"text","content":"18","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":28,"fontWeight":700,"textAlign":"right","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf","frame":0,"transform":{"x":1526,"y":740,"width":60,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684","frame":30,"transform":{"x":1526,"y":740,"width":60,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c","frame":50,"transform":{"x":1526,"y":740,"width":60,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:x","frame":0,"value":1526,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:x","frame":30,"value":1526,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:x","frame":50,"value":1526,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:y","frame":0,"value":740,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:y","frame":30,"value":740,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:y","frame":50,"value":740,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:width","frame":0,"value":60,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:width","frame":30,"value":60,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:width","frame":50,"value":60,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:height","frame":0,"value":38,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:height","frame":30,"value":38,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:height","frame":50,"value":38,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-b620a507-18f7-4bcf-8468-669acee1d555","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-ef13777a-e019-4a89-8468-c9859712b85f","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-5ad55d92-33f2-45b2-a293-86c480ffbccf:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-5cab77db-c9fa-45dc-a1c9-66b5be947684:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-aa5e4f0b-10e7-4a27-906e-e34ed2147c7c:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-2d60abe2-3b47-44c2-9675-7291e4d4434a:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-2d60abe2-3b47-44c2-9675-7291e4d4434a:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-2d60abe2-3b47-44c2-9675-7291e4d4434a:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-2d60abe2-3b47-44c2-9675-7291e4d4434a:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-2d60abe2-3b47-44c2-9675-7291e4d4434a:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"clock_h","targetProperty":"content"},"clipParentId":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a"},{"id":"layer-851e0c93-7d7c-4f4d-b03b-5b5d5888942d","isVisible":true,"element":{"type":"text","content":":","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":28,"fontWeight":700,"textAlign":"center","autoFit":"fixed"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b","frame":0,"transform":{"x":1586,"y":740,"width":20,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc","frame":30,"transform":{"x":1586,"y":740,"width":20,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578","frame":50,"transform":{"x":1586,"y":740,"width":20,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:x","frame":0,"value":1586,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:x","frame":30,"value":1586,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:x","frame":50,"value":1586,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:y","frame":0,"value":740,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:y","frame":30,"value":740,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:y","frame":50,"value":740,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:width","frame":0,"value":20,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:width","frame":30,"value":20,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:width","frame":50,"value":20,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:height","frame":0,"value":38,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:height","frame":30,"value":38,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:height","frame":50,"value":38,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-903451b3-158f-4e54-abfd-13dcf6e9bb6b","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-4ac4c2cd-710e-4a50-a4d8-35dd8c1f475f","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-7301a2f5-d419-42cb-928f-5a33a5ee483b:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-690ab6da-2051-4ed3-a3d3-30a8338838fc:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-02bdf23b-2435-473f-8310-c96e356f4578:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-851e0c93-7d7c-4f4d-b03b-5b5d5888942d:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-851e0c93-7d7c-4f4d-b03b-5b5d5888942d:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-851e0c93-7d7c-4f4d-b03b-5b5d5888942d:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-851e0c93-7d7c-4f4d-b03b-5b5d5888942d:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-851e0c93-7d7c-4f4d-b03b-5b5d5888942d:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":{"id":"layer-loop-0876d0e5-d6d5-41e8-b1b2-53841cd7dea5","name":"Loop","activation":{"type":"lifecycle"},"durationFrames":50,"phaseOffsetFrames":0,"repeatCount":null,"tracks":{"opacity":[{"id":"property-keyframe-52251ffd-e89d-4c8a-815b-ac83d046eb54","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-f30cc3e2-9c0d-426f-8ac6-19dcd36b0bc9","frame":24,"value":1,"easing":"linear"},{"id":"property-keyframe-f2fb568f-a6f2-44d7-b04a-16d7883ae48a","frame":25,"value":0,"easing":"linear"},{"id":"property-keyframe-4a4f7f75-d755-416a-917b-0d258c0caf99","frame":49,"value":0,"easing":"linear"},{"id":"property-keyframe-7d0a5303-a7f6-4627-b41a-59e065f5039a","frame":50,"value":1,"easing":"linear"}]}},"binding":null,"clipParentId":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a"},{"id":"layer-569d279a-6ec0-40cd-8b3e-b6c0a51088b2","isVisible":true,"element":{"type":"text","content":"42","color":"#FFFFFF","fontFamily":"Arial, Helvetica, sans-serif","fontSize":28,"fontWeight":700,"textAlign":"left","autoFit":"shrink-to-fit"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b","frame":0,"transform":{"x":1606,"y":740,"width":60,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8","frame":30,"transform":{"x":1606,"y":740,"width":60,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa","frame":50,"transform":{"x":1606,"y":740,"width":60,"height":38,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in"}],"animationTracks":{"x":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:x","frame":0,"value":1606,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:x","frame":30,"value":1606,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:x","frame":50,"value":1606,"easing":"ease-in"}],"y":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:y","frame":0,"value":740,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:y","frame":30,"value":740,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:y","frame":50,"value":740,"easing":"ease-in"}],"width":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:width","frame":0,"value":60,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:width","frame":30,"value":60,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:width","frame":50,"value":60,"easing":"ease-in"}],"height":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:height","frame":0,"value":38,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:height","frame":30,"value":38,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:height","frame":50,"value":38,"easing":"ease-in"}],"rotation":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:rotation","frame":30,"value":0,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:rotation","frame":50,"value":0,"easing":"ease-in"}],"opacity":[{"id":"property-keyframe-8147dfa4-ee66-40d0-87bb-55cceb89739b","frame":0,"value":1,"easing":"linear"},{"id":"property-keyframe-ffa3f387-888b-481b-a91f-38ae20b0d77e","frame":50,"value":1,"easing":"linear"}],"transformOriginX":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:transformOriginX","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:transformOriginX","frame":50,"value":0.5,"easing":"ease-in"}],"transformOriginY":[{"id":"layer-keyframe-096e162a-cf61-4ee5-8dd0-51ca4594069b:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-02ca57b6-8cf7-4a5f-8615-1dc371d03ba8:transformOriginY","frame":30,"value":0.5,"easing":"ease-out"},{"id":"layer-keyframe-bf0e7d12-c990-4efe-844f-8ba6b01fa7fa:transformOriginY","frame":50,"value":0.5,"easing":"ease-in"}],"blur":[{"id":"layer-569d279a-6ec0-40cd-8b3e-b6c0a51088b2:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-569d279a-6ec0-40cd-8b3e-b6c0a51088b2:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-569d279a-6ec0-40cd-8b3e-b6c0a51088b2:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-569d279a-6ec0-40cd-8b3e-b6c0a51088b2:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-569d279a-6ec0-40cd-8b3e-b6c0a51088b2:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"binding":{"dataKey":"clock_m","targetProperty":"content"},"clipParentId":"layer-f4f84e97-33ce-44bd-8816-3df3ddcb526a"}],"keyframes":[{"id":"keyframe-4d56f406-9be1-43d6-b3d1-489ec07fa2e0","frame":0,"role":"start"},{"id":"keyframe-ba151e57-99cf-444d-b879-45b3bdadd822","frame":30,"role":"step"},{"id":"keyframe-d37930eb-3f31-479b-9737-8015813fba6f","frame":50,"role":"end"}],"transitions":[{"fromKeyframeId":"keyframe-4d56f406-9be1-43d6-b3d1-489ec07fa2e0","toKeyframeId":"keyframe-ba151e57-99cf-444d-b879-45b3bdadd822","durationFrames":30,"easing":"ease-out"},{"fromKeyframeId":"keyframe-ba151e57-99cf-444d-b879-45b3bdadd822","toKeyframeId":"keyframe-d37930eb-3f31-479b-9737-8015813fba6f","durationFrames":20,"easing":"ease-in"}],"stepKeyframeIds":["keyframe-ba151e57-99cf-444d-b879-45b3bdadd822"],"stepCount":1,"startKeyframeId":"keyframe-4d56f406-9be1-43d6-b3d1-489ec07fa2e0","endKeyframeId":"keyframe-d37930eb-3f31-479b-9737-8015813fba6f","customActions":[]};
const exportedModuleBaseUrl = import.meta.url.startsWith('blob:') ? document.baseURI : import.meta.url;
for (const layer of exportedDescriptor.layers) {
  if (layer.element.type === 'image' && layer.element.src?.startsWith('assets/')) {
    layer.element.src = new URL(layer.element.src, exportedModuleBaseUrl).href;
  } else if (layer.element.type === 'image-sequence') {
    layer.element.frames = layer.element.frames.map((frame) =>
      frame.startsWith('assets/') ? new URL(frame, exportedModuleBaseUrl).href : frame
    );
  }
}
class ExportedGraphic extends GraphicElement {
  static descriptor = exportedDescriptor;
}
export default ExportedGraphic;
