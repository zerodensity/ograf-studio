//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region ../../node_modules/gsap/gsap-core.js
function _assertThisInitialized(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _inheritsLoose(subClass, superClass) {
	subClass.prototype = Object.create(superClass.prototype);
	subClass.prototype.constructor = subClass;
	subClass.__proto__ = superClass;
}
/*!
* GSAP 3.15.0
* https://gsap.com
*
* @license Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var _config = {
	autoSleep: 120,
	force3D: "auto",
	nullTargetWarn: 1,
	units: { lineHeight: "" }
};
var _defaults = {
	duration: .5,
	overwrite: false,
	delay: 0
};
var _suppressOverwrites;
var _reverting$1;
var _context;
var _bigNum$1 = 1e8;
var _tinyNum = 1 / _bigNum$1;
var _2PI = Math.PI * 2;
var _HALF_PI = _2PI / 4;
var _gsID = 0;
var _sqrt = Math.sqrt;
var _cos = Math.cos;
var _sin = Math.sin;
var _isString = function _isString(value) {
	return typeof value === "string";
};
var _isFunction = function _isFunction(value) {
	return typeof value === "function";
};
var _isNumber = function _isNumber(value) {
	return typeof value === "number";
};
var _isUndefined = function _isUndefined(value) {
	return typeof value === "undefined";
};
var _isObject = function _isObject(value) {
	return typeof value === "object";
};
var _isNotFalse = function _isNotFalse(value) {
	return value !== false;
};
var _windowExists$1 = function _windowExists() {
	return typeof window !== "undefined";
};
var _isFuncOrString = function _isFuncOrString(value) {
	return _isFunction(value) || _isString(value);
};
var _isTypedArray = typeof ArrayBuffer === "function" && ArrayBuffer.isView || function() {};
var _isArray = Array.isArray;
var _randomExp = /random\([^)]+\)/g;
var _commaDelimExp = /,\s*/g;
var _strictNumExp = /(?:-?\.?\d|\.)+/gi;
var _numExp = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g;
var _numWithUnitExp = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g;
var _complexStringNumExp = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi;
var _relExp = /[+-]=-?[.\d]+/;
var _delimitedValueExp = /[^,'"\[\]\s]+/gi;
var _unitExp = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i;
var _globalTimeline;
var _win$1;
var _coreInitted;
var _doc$1;
var _globals = {};
var _installScope = {};
var _coreReady;
var _install = function _install(scope) {
	return (_installScope = _merge(scope, _globals)) && gsap;
};
var _missingPlugin = function _missingPlugin(property, value) {
	return console.warn("Invalid property", property, "set to", value, "Missing plugin? gsap.registerPlugin()");
};
var _warn = function _warn(message, suppress) {
	return !suppress && console.warn(message);
};
var _addGlobal = function _addGlobal(name, obj) {
	return name && (_globals[name] = obj) && _installScope && (_installScope[name] = obj) || _globals;
};
var _emptyFunc = function _emptyFunc() {
	return 0;
};
var _startAtRevertConfig = {
	suppressEvents: true,
	isStart: true,
	kill: false
};
var _revertConfigNoKill = {
	suppressEvents: true,
	kill: false
};
var _revertConfig = { suppressEvents: true };
var _reservedProps = {};
var _lazyTweens = [];
var _lazyLookup = {};
var _lastRenderedFrame;
var _plugins = {};
var _effects = {};
var _nextGCFrame = 30;
var _harnessPlugins = [];
var _callbackNames = "";
var _harness = function _harness(targets) {
	var target = targets[0], harnessPlugin, i;
	_isObject(target) || _isFunction(target) || (targets = [targets]);
	if (!(harnessPlugin = (target._gsap || {}).harness)) {
		i = _harnessPlugins.length;
		while (i-- && !_harnessPlugins[i].targetTest(target));
		harnessPlugin = _harnessPlugins[i];
	}
	i = targets.length;
	while (i--) targets[i] && (targets[i]._gsap || (targets[i]._gsap = new GSCache(targets[i], harnessPlugin))) || targets.splice(i, 1);
	return targets;
};
var _getCache = function _getCache(target) {
	return target._gsap || _harness(toArray(target))[0]._gsap;
};
var _getProperty = function _getProperty(target, property, v) {
	return (v = target[property]) && _isFunction(v) ? target[property]() : _isUndefined(v) && target.getAttribute && target.getAttribute(property) || v;
};
var _forEachName = function _forEachName(names, func) {
	return (names = names.split(",")).forEach(func) || names;
};
var _round = function _round(value) {
	return Math.round(value * 1e5) / 1e5 || 0;
};
var _roundPrecise = function _roundPrecise(value) {
	return Math.round(value * 1e7) / 1e7 || 0;
};
var _parseRelative = function _parseRelative(start, value) {
	var operator = value.charAt(0), end = parseFloat(value.substr(2));
	start = parseFloat(start);
	return operator === "+" ? start + end : operator === "-" ? start - end : operator === "*" ? start * end : start / end;
};
var _arrayContainsAny = function _arrayContainsAny(toSearch, toFind) {
	var l = toFind.length, i = 0;
	for (; toSearch.indexOf(toFind[i]) < 0 && ++i < l;);
	return i < l;
};
var _lazyRender = function _lazyRender() {
	var l = _lazyTweens.length, a = _lazyTweens.slice(0), i, tween;
	_lazyLookup = {};
	_lazyTweens.length = 0;
	for (i = 0; i < l; i++) {
		tween = a[i];
		tween && tween._lazy && (tween.render(tween._lazy[0], tween._lazy[1], true)._lazy = 0);
	}
};
var _isRevertWorthy = function _isRevertWorthy(animation) {
	return !!(animation._initted || animation._startAt || animation.add);
};
var _lazySafeRender = function _lazySafeRender(animation, time, suppressEvents, force) {
	_lazyTweens.length && !_reverting$1 && _lazyRender();
	animation.render(time, suppressEvents, force || !!(_reverting$1 && time < 0 && _isRevertWorthy(animation)));
	_lazyTweens.length && !_reverting$1 && _lazyRender();
};
var _numericIfPossible = function _numericIfPossible(value) {
	var n = parseFloat(value);
	return (n || n === 0) && (value + "").match(_delimitedValueExp).length < 2 ? n : _isString(value) ? value.trim() : value;
};
var _passThrough = function _passThrough(p) {
	return p;
};
var _setDefaults = function _setDefaults(obj, defaults) {
	for (var p in defaults) p in obj || (obj[p] = defaults[p]);
	return obj;
};
var _setKeyframeDefaults = function _setKeyframeDefaults(excludeDuration) {
	return function(obj, defaults) {
		for (var p in defaults) p in obj || p === "duration" && excludeDuration || p === "ease" || (obj[p] = defaults[p]);
	};
};
var _merge = function _merge(base, toMerge) {
	for (var p in toMerge) base[p] = toMerge[p];
	return base;
};
var _mergeDeep = function _mergeDeep(base, toMerge) {
	for (var p in toMerge) p !== "__proto__" && p !== "constructor" && p !== "prototype" && (base[p] = _isObject(toMerge[p]) ? _mergeDeep(base[p] || (base[p] = {}), toMerge[p]) : toMerge[p]);
	return base;
};
var _copyExcluding = function _copyExcluding(obj, excluding) {
	var copy = {}, p;
	for (p in obj) p in excluding || (copy[p] = obj[p]);
	return copy;
};
var _inheritDefaults = function _inheritDefaults(vars) {
	var parent = vars.parent || _globalTimeline, func = vars.keyframes ? _setKeyframeDefaults(_isArray(vars.keyframes)) : _setDefaults;
	if (_isNotFalse(vars.inherit)) while (parent) {
		func(vars, parent.vars.defaults);
		parent = parent.parent || parent._dp;
	}
	return vars;
};
var _arraysMatch = function _arraysMatch(a1, a2) {
	var i = a1.length, match = i === a2.length;
	while (match && i-- && a1[i] === a2[i]);
	return i < 0;
};
var _addLinkedListItem = function _addLinkedListItem(parent, child, firstProp, lastProp, sortBy) {
	if (firstProp === void 0) firstProp = "_first";
	if (lastProp === void 0) lastProp = "_last";
	var prev = parent[lastProp], t;
	if (sortBy) {
		t = child[sortBy];
		while (prev && prev[sortBy] > t) prev = prev._prev;
	}
	if (prev) {
		child._next = prev._next;
		prev._next = child;
	} else {
		child._next = parent[firstProp];
		parent[firstProp] = child;
	}
	if (child._next) child._next._prev = child;
	else parent[lastProp] = child;
	child._prev = prev;
	child.parent = child._dp = parent;
	return child;
};
var _removeLinkedListItem = function _removeLinkedListItem(parent, child, firstProp, lastProp) {
	if (firstProp === void 0) firstProp = "_first";
	if (lastProp === void 0) lastProp = "_last";
	var prev = child._prev, next = child._next;
	if (prev) prev._next = next;
	else if (parent[firstProp] === child) parent[firstProp] = next;
	if (next) next._prev = prev;
	else if (parent[lastProp] === child) parent[lastProp] = prev;
	child._next = child._prev = child.parent = null;
};
var _removeFromParent = function _removeFromParent(child, onlyIfParentHasAutoRemove) {
	child.parent && (!onlyIfParentHasAutoRemove || child.parent.autoRemoveChildren) && child.parent.remove && child.parent.remove(child);
	child._act = 0;
};
var _uncache = function _uncache(animation, child) {
	if (animation && (!child || child._end > animation._dur || child._start < 0)) {
		var a = animation;
		while (a) {
			a._dirty = 1;
			a = a.parent;
		}
	}
	return animation;
};
var _recacheAncestors = function _recacheAncestors(animation) {
	var parent = animation.parent;
	while (parent && parent.parent) {
		parent._dirty = 1;
		parent.totalDuration();
		parent = parent.parent;
	}
	return animation;
};
var _rewindStartAt = function _rewindStartAt(tween, totalTime, suppressEvents, force) {
	return tween._startAt && (_reverting$1 ? tween._startAt.revert(_revertConfigNoKill) : tween.vars.immediateRender && !tween.vars.autoRevert || tween._startAt.render(totalTime, true, force));
};
var _hasNoPausedAncestors = function _hasNoPausedAncestors(animation) {
	return !animation || animation._ts && _hasNoPausedAncestors(animation.parent);
};
var _elapsedCycleDuration = function _elapsedCycleDuration(animation) {
	return animation._repeat ? _animationCycle(animation._tTime, animation = animation.duration() + animation._rDelay) * animation : 0;
};
var _animationCycle = function _animationCycle(tTime, cycleDuration) {
	var whole = Math.floor(tTime = _roundPrecise(tTime / cycleDuration));
	return tTime && whole === tTime ? whole - 1 : whole;
};
var _parentToChildTotalTime = function _parentToChildTotalTime(parentTime, child) {
	return (parentTime - child._start) * child._ts + (child._ts >= 0 ? 0 : child._dirty ? child.totalDuration() : child._tDur);
};
var _setEnd = function _setEnd(animation) {
	return animation._end = _roundPrecise(animation._start + (animation._tDur / Math.abs(animation._ts || animation._rts || _tinyNum) || 0));
};
var _alignPlayhead = function _alignPlayhead(animation, totalTime) {
	var parent = animation._dp;
	if (parent && parent.smoothChildTiming && animation._ts) {
		animation._start = _roundPrecise(parent._time - (animation._ts > 0 ? totalTime / animation._ts : ((animation._dirty ? animation.totalDuration() : animation._tDur) - totalTime) / -animation._ts));
		_setEnd(animation);
		parent._dirty || _uncache(parent, animation);
	}
	return animation;
};
var _postAddChecks = function _postAddChecks(timeline, child) {
	var t;
	if (child._time || !child._dur && child._initted || child._start < timeline._time && (child._dur || !child.add)) {
		t = _parentToChildTotalTime(timeline.rawTime(), child);
		if (!child._dur || _clamp(0, child.totalDuration(), t) - child._tTime > _tinyNum) child.render(t, true);
	}
	if (_uncache(timeline, child)._dp && timeline._initted && timeline._time >= timeline._dur && timeline._ts) {
		if (timeline._dur < timeline.duration()) {
			t = timeline;
			while (t._dp) {
				t.rawTime() >= 0 && t.totalTime(t._tTime);
				t = t._dp;
			}
		}
		timeline._zTime = -_tinyNum;
	}
};
var _addToTimeline = function _addToTimeline(timeline, child, position, skipChecks) {
	child.parent && _removeFromParent(child);
	child._start = _roundPrecise((_isNumber(position) ? position : position || timeline !== _globalTimeline ? _parsePosition(timeline, position, child) : timeline._time) + child._delay);
	child._end = _roundPrecise(child._start + (child.totalDuration() / Math.abs(child.timeScale()) || 0));
	_addLinkedListItem(timeline, child, "_first", "_last", timeline._sort ? "_start" : 0);
	_isFromOrFromStart(child) || (timeline._recent = child);
	skipChecks || _postAddChecks(timeline, child);
	timeline._ts < 0 && _alignPlayhead(timeline, timeline._tTime);
	return timeline;
};
var _scrollTrigger = function _scrollTrigger(animation, trigger) {
	return (_globals.ScrollTrigger || _missingPlugin("scrollTrigger", trigger)) && _globals.ScrollTrigger.create(trigger, animation);
};
var _attemptInitTween = function _attemptInitTween(tween, time, force, suppressEvents, tTime) {
	_initTween(tween, time, tTime);
	if (!tween._initted) return 1;
	if (!force && tween._pt && !_reverting$1 && (tween._dur && tween.vars.lazy !== false || !tween._dur && tween.vars.lazy) && _lastRenderedFrame !== _ticker.frame) {
		_lazyTweens.push(tween);
		tween._lazy = [tTime, suppressEvents];
		return 1;
	}
};
var _parentPlayheadIsBeforeStart = function _parentPlayheadIsBeforeStart(_ref) {
	var parent = _ref.parent;
	return parent && parent._ts && parent._initted && !parent._lock && (parent.rawTime() < 0 || _parentPlayheadIsBeforeStart(parent));
};
var _isFromOrFromStart = function _isFromOrFromStart(_ref2) {
	var data = _ref2.data;
	return data === "isFromStart" || data === "isStart";
};
var _renderZeroDurationTween = function _renderZeroDurationTween(tween, totalTime, suppressEvents, force) {
	var prevRatio = tween.ratio, ratio = totalTime < 0 || !totalTime && (!tween._start && _parentPlayheadIsBeforeStart(tween) && !(!tween._initted && _isFromOrFromStart(tween)) || (tween._ts < 0 || tween._dp._ts < 0) && !_isFromOrFromStart(tween)) ? 0 : 1, repeatDelay = tween._rDelay, tTime = 0, pt, iteration, prevIteration;
	if (repeatDelay && tween._repeat) {
		tTime = _clamp(0, tween._tDur, totalTime);
		iteration = _animationCycle(tTime, repeatDelay);
		tween._yoyo && iteration & 1 && (ratio = 1 - ratio);
		if (iteration !== _animationCycle(tween._tTime, repeatDelay)) {
			prevRatio = 1 - ratio;
			tween.vars.repeatRefresh && tween._initted && tween.invalidate();
		}
	}
	if (ratio !== prevRatio || _reverting$1 || force || tween._zTime === _tinyNum || !totalTime && tween._zTime) {
		if (!tween._initted && _attemptInitTween(tween, totalTime, force, suppressEvents, tTime)) return;
		prevIteration = tween._zTime;
		tween._zTime = totalTime || (suppressEvents ? _tinyNum : 0);
		suppressEvents || (suppressEvents = totalTime && !prevIteration);
		tween.ratio = ratio;
		tween._from && (ratio = 1 - ratio);
		tween._time = 0;
		tween._tTime = tTime;
		pt = tween._pt;
		while (pt) {
			pt.r(ratio, pt.d);
			pt = pt._next;
		}
		totalTime < 0 && _rewindStartAt(tween, totalTime, suppressEvents, true);
		tween._onUpdate && !suppressEvents && _callback(tween, "onUpdate");
		tTime && tween._repeat && !suppressEvents && tween.parent && _callback(tween, "onRepeat");
		if ((totalTime >= tween._tDur || totalTime < 0) && tween.ratio === ratio) {
			ratio && _removeFromParent(tween, 1);
			if (!suppressEvents && !_reverting$1) {
				_callback(tween, ratio ? "onComplete" : "onReverseComplete", true);
				tween._prom && tween._prom();
			}
		}
	} else if (!tween._zTime) tween._zTime = totalTime;
};
var _findNextPauseTween = function _findNextPauseTween(animation, prevTime, time) {
	var child;
	if (time > prevTime) {
		child = animation._first;
		while (child && child._start <= time) {
			if (child.data === "isPause" && child._start > prevTime) return child;
			child = child._next;
		}
	} else {
		child = animation._last;
		while (child && child._start >= time) {
			if (child.data === "isPause" && child._start < prevTime) return child;
			child = child._prev;
		}
	}
};
var _setDuration = function _setDuration(animation, duration, skipUncache, leavePlayhead) {
	var repeat = animation._repeat, dur = _roundPrecise(duration) || 0, totalProgress = animation._tTime / animation._tDur;
	totalProgress && !leavePlayhead && (animation._time *= dur / animation._dur);
	animation._dur = dur;
	animation._tDur = !repeat ? dur : repeat < 0 ? 1e10 : _roundPrecise(dur * (repeat + 1) + animation._rDelay * repeat);
	totalProgress > 0 && !leavePlayhead && _alignPlayhead(animation, animation._tTime = animation._tDur * totalProgress);
	animation.parent && _setEnd(animation);
	skipUncache || _uncache(animation.parent, animation);
	return animation;
};
var _onUpdateTotalDuration = function _onUpdateTotalDuration(animation) {
	return animation instanceof Timeline ? _uncache(animation) : _setDuration(animation, animation._dur);
};
var _zeroPosition = {
	_start: 0,
	endTime: _emptyFunc,
	totalDuration: _emptyFunc
};
var _parsePosition = function _parsePosition(animation, position, percentAnimation) {
	var labels = animation.labels, recent = animation._recent || _zeroPosition, clippedDuration = animation.duration() >= _bigNum$1 ? recent.endTime(false) : animation._dur, i, offset, isPercent;
	if (_isString(position) && (isNaN(position) || position in labels)) {
		offset = position.charAt(0);
		isPercent = position.substr(-1) === "%";
		i = position.indexOf("=");
		if (offset === "<" || offset === ">") {
			i >= 0 && (position = position.replace(/=/, ""));
			return (offset === "<" ? recent._start : recent.endTime(recent._repeat >= 0)) + (parseFloat(position.substr(1)) || 0) * (isPercent ? (i < 0 ? recent : percentAnimation).totalDuration() / 100 : 1);
		}
		if (i < 0) {
			position in labels || (labels[position] = clippedDuration);
			return labels[position];
		}
		offset = parseFloat(position.charAt(i - 1) + position.substr(i + 1));
		if (isPercent && percentAnimation) offset = offset / 100 * (_isArray(percentAnimation) ? percentAnimation[0] : percentAnimation).totalDuration();
		return i > 1 ? _parsePosition(animation, position.substr(0, i - 1), percentAnimation) + offset : clippedDuration + offset;
	}
	return position == null ? clippedDuration : +position;
};
var _createTweenType = function _createTweenType(type, params, timeline) {
	var isLegacy = _isNumber(params[1]), varsIndex = (isLegacy ? 2 : 1) + (type < 2 ? 0 : 1), vars = params[varsIndex], irVars, parent;
	isLegacy && (vars.duration = params[1]);
	vars.parent = timeline;
	if (type) {
		irVars = vars;
		parent = timeline;
		while (parent && !("immediateRender" in irVars)) {
			irVars = parent.vars.defaults || {};
			parent = _isNotFalse(parent.vars.inherit) && parent.parent;
		}
		vars.immediateRender = _isNotFalse(irVars.immediateRender);
		type < 2 ? vars.runBackwards = 1 : vars.startAt = params[varsIndex - 1];
	}
	return new Tween(params[0], vars, params[varsIndex + 1]);
};
var _conditionalReturn = function _conditionalReturn(value, func) {
	return value || value === 0 ? func(value) : func;
};
var _clamp = function _clamp(min, max, value) {
	return value < min ? min : value > max ? max : value;
};
var getUnit = function getUnit(value, v) {
	return !_isString(value) || !(v = _unitExp.exec(value)) ? "" : v[1];
};
var clamp = function clamp(min, max, value) {
	return _conditionalReturn(value, function(v) {
		return _clamp(min, max, v);
	});
};
var _slice = [].slice;
var _isArrayLike = function _isArrayLike(value, nonEmpty) {
	return value && _isObject(value) && "length" in value && (!nonEmpty && !value.length || value.length - 1 in value && _isObject(value[0])) && !value.nodeType && value !== _win$1;
};
var _flatten = function _flatten(ar, leaveStrings, accumulator) {
	if (accumulator === void 0) accumulator = [];
	return ar.forEach(function(value) {
		var _accumulator;
		return _isString(value) && !leaveStrings || _isArrayLike(value, 1) ? (_accumulator = accumulator).push.apply(_accumulator, toArray(value)) : accumulator.push(value);
	}) || accumulator;
};
var toArray = function toArray(value, scope, leaveStrings) {
	return _context && !scope && _context.selector ? _context.selector(value) : _isString(value) && !leaveStrings && (_coreInitted || !_wake()) ? _slice.call((scope || _doc$1).querySelectorAll(value), 0) : _isArray(value) ? _flatten(value, leaveStrings) : _isArrayLike(value) ? _slice.call(value, 0) : value ? [value] : [];
};
var selector = function selector(value) {
	value = toArray(value)[0] || _warn("Invalid scope") || {};
	return function(v) {
		var el = value.current || value.nativeElement || value;
		return toArray(v, el.querySelectorAll ? el : el === value ? _warn("Invalid scope") || _doc$1.createElement("div") : value);
	};
};
var shuffle = function shuffle(a) {
	return a.sort(function() {
		return .5 - Math.random();
	});
};
var distribute = function distribute(v) {
	if (_isFunction(v)) return v;
	var vars = _isObject(v) ? v : { each: v }, ease = _parseEase(vars.ease), from = vars.from || 0, base = parseFloat(vars.base) || 0, cache = {}, isDecimal = from > 0 && from < 1, ratios = isNaN(from) || isDecimal, axis = vars.axis, ratioX = from, ratioY = from;
	if (_isString(from)) ratioX = ratioY = {
		center: .5,
		edges: .5,
		end: 1
	}[from] || 0;
	else if (!isDecimal && ratios) {
		ratioX = from[0];
		ratioY = from[1];
	}
	return function(i, target, a) {
		var l = (a || vars).length, distances = cache[l], originX, originY, x, y, d, j, max, min, wrapAt;
		if (!distances) {
			wrapAt = vars.grid === "auto" ? 0 : (vars.grid || [1, _bigNum$1])[1];
			if (!wrapAt) {
				max = -_bigNum$1;
				while (max < (max = a[wrapAt++].getBoundingClientRect().left) && wrapAt < l);
				wrapAt < l && wrapAt--;
			}
			distances = cache[l] = [];
			originX = ratios ? Math.min(wrapAt, l) * ratioX - .5 : from % wrapAt;
			originY = wrapAt === _bigNum$1 ? 0 : ratios ? l * ratioY / wrapAt - .5 : from / wrapAt | 0;
			max = 0;
			min = _bigNum$1;
			for (j = 0; j < l; j++) {
				x = j % wrapAt - originX;
				y = originY - (j / wrapAt | 0);
				distances[j] = d = !axis ? _sqrt(x * x + y * y) : Math.abs(axis === "y" ? y : x);
				d > max && (max = d);
				d < min && (min = d);
			}
			from === "random" && shuffle(distances);
			distances.max = max - min;
			distances.min = min;
			distances.v = l = (parseFloat(vars.amount) || parseFloat(vars.each) * (wrapAt > l ? l - 1 : !axis ? Math.max(wrapAt, l / wrapAt) : axis === "y" ? l / wrapAt : wrapAt) || 0) * (from === "edges" ? -1 : 1);
			distances.b = l < 0 ? base - l : base;
			distances.u = getUnit(vars.amount || vars.each) || 0;
			ease = ease && l < 0 ? _invertEase(ease) : ease;
		}
		l = (distances[i] - distances.min) / distances.max || 0;
		return _roundPrecise(distances.b + (ease ? ease(l) : l) * distances.v) + distances.u;
	};
};
var _roundModifier = function _roundModifier(v) {
	var p = Math.pow(10, ((v + "").split(".")[1] || "").length);
	return function(raw) {
		var n = _roundPrecise(Math.round(parseFloat(raw) / v) * v * p);
		return (n - n % 1) / p + (_isNumber(raw) ? 0 : getUnit(raw));
	};
};
var snap = function snap(snapTo, value) {
	var isArray = _isArray(snapTo), radius, is2D;
	if (!isArray && _isObject(snapTo)) {
		radius = isArray = snapTo.radius || _bigNum$1;
		if (snapTo.values) {
			snapTo = toArray(snapTo.values);
			if (is2D = !_isNumber(snapTo[0])) radius *= radius;
		} else snapTo = _roundModifier(snapTo.increment);
	}
	return _conditionalReturn(value, !isArray ? _roundModifier(snapTo) : _isFunction(snapTo) ? function(raw) {
		is2D = snapTo(raw);
		return Math.abs(is2D - raw) <= radius ? is2D : raw;
	} : function(raw) {
		var x = parseFloat(is2D ? raw.x : raw), y = parseFloat(is2D ? raw.y : 0), min = _bigNum$1, closest = 0, i = snapTo.length, dx, dy;
		while (i--) {
			if (is2D) {
				dx = snapTo[i].x - x;
				dy = snapTo[i].y - y;
				dx = dx * dx + dy * dy;
			} else dx = Math.abs(snapTo[i] - x);
			if (dx < min) {
				min = dx;
				closest = i;
			}
		}
		closest = !radius || min <= radius ? snapTo[closest] : raw;
		return is2D || closest === raw || _isNumber(raw) ? closest : closest + getUnit(raw);
	});
};
var random = function random(min, max, roundingIncrement, returnFunction) {
	return _conditionalReturn(_isArray(min) ? !max : roundingIncrement === true ? !!(roundingIncrement = 0) : !returnFunction, function() {
		return _isArray(min) ? min[~~(Math.random() * min.length)] : (roundingIncrement = roundingIncrement || 1e-5) && (returnFunction = roundingIncrement < 1 ? Math.pow(10, (roundingIncrement + "").length - 2) : 1) && Math.floor(Math.round((min - roundingIncrement / 2 + Math.random() * (max - min + roundingIncrement * .99)) / roundingIncrement) * roundingIncrement * returnFunction) / returnFunction;
	});
};
var pipe = function pipe() {
	for (var _len = arguments.length, functions = new Array(_len), _key = 0; _key < _len; _key++) functions[_key] = arguments[_key];
	return function(value) {
		return functions.reduce(function(v, f) {
			return f(v);
		}, value);
	};
};
var unitize = function unitize(func, unit) {
	return function(value) {
		return func(parseFloat(value)) + (unit || getUnit(value));
	};
};
var normalize = function normalize(min, max, value) {
	return mapRange(min, max, 0, 1, value);
};
var _wrapArray = function _wrapArray(a, wrapper, value) {
	return _conditionalReturn(value, function(index) {
		return a[~~wrapper(index)];
	});
};
var wrap = function wrap(min, max, value) {
	var range = max - min;
	return _isArray(min) ? _wrapArray(min, wrap(0, min.length), max) : _conditionalReturn(value, function(value) {
		return (range + (value - min) % range) % range + min;
	});
};
var wrapYoyo = function wrapYoyo(min, max, value) {
	var range = max - min, total = range * 2;
	return _isArray(min) ? _wrapArray(min, wrapYoyo(0, min.length - 1), max) : _conditionalReturn(value, function(value) {
		value = (total + (value - min) % total) % total || 0;
		return min + (value > range ? total - value : value);
	});
};
var _replaceRandom = function _replaceRandom(s) {
	return s.replace(_randomExp, function(match) {
		var arIndex = match.indexOf("[") + 1, values = match.substring(arIndex || 7, arIndex ? match.indexOf("]") : match.length - 1).split(_commaDelimExp);
		return random(arIndex ? values : +values[0], arIndex ? 0 : +values[1], +values[2] || 1e-5);
	});
};
var mapRange = function mapRange(inMin, inMax, outMin, outMax, value) {
	var inRange = inMax - inMin, outRange = outMax - outMin;
	return _conditionalReturn(value, function(value) {
		return outMin + ((value - inMin) / inRange * outRange || 0);
	});
};
var interpolate$1 = function interpolate(start, end, progress, mutate) {
	var func = isNaN(start + end) ? 0 : function(p) {
		return (1 - p) * start + p * end;
	};
	if (!func) {
		var isString = _isString(start), master = {}, p, i, interpolators, l, il;
		progress === true && (mutate = 1) && (progress = null);
		if (isString) {
			start = { p: start };
			end = { p: end };
		} else if (_isArray(start) && !_isArray(end)) {
			interpolators = [];
			l = start.length;
			il = l - 2;
			for (i = 1; i < l; i++) interpolators.push(interpolate(start[i - 1], start[i]));
			l--;
			func = function func(p) {
				p *= l;
				var i = Math.min(il, ~~p);
				return interpolators[i](p - i);
			};
			progress = end;
		} else if (!mutate) start = _merge(_isArray(start) ? [] : {}, start);
		if (!interpolators) {
			for (p in end) _addPropTween.call(master, start, p, "get", end[p]);
			func = function func(p) {
				return _renderPropTweens(p, master) || (isString ? start.p : start);
			};
		}
	}
	return _conditionalReturn(progress, func);
};
var _getLabelInDirection = function _getLabelInDirection(timeline, fromTime, backward) {
	var labels = timeline.labels, min = _bigNum$1, p, distance, label;
	for (p in labels) {
		distance = labels[p] - fromTime;
		if (distance < 0 === !!backward && distance && min > (distance = Math.abs(distance))) {
			label = p;
			min = distance;
		}
	}
	return label;
};
var _callback = function _callback(animation, type, executeLazyFirst) {
	var v = animation.vars, callback = v[type], prevContext = _context, context = animation._ctx, params, scope, result;
	if (!callback) return;
	params = v[type + "Params"];
	scope = v.callbackScope || animation;
	executeLazyFirst && _lazyTweens.length && _lazyRender();
	context && (_context = context);
	result = params ? callback.apply(scope, params) : callback.call(scope);
	_context = prevContext;
	return result;
};
var _interrupt = function _interrupt(animation) {
	_removeFromParent(animation);
	animation.scrollTrigger && animation.scrollTrigger.kill(!!_reverting$1);
	animation.progress() < 1 && _callback(animation, "onInterrupt");
	return animation;
};
var _quickTween;
var _registerPluginQueue = [];
var _createPlugin = function _createPlugin(config) {
	if (!config) return;
	config = !config.name && config["default"] || config;
	if (_windowExists$1() || config.headless) {
		var name = config.name, isFunc = _isFunction(config), Plugin = name && !isFunc && config.init ? function() {
			this._props = [];
		} : config, instanceDefaults = {
			init: _emptyFunc,
			render: _renderPropTweens,
			add: _addPropTween,
			kill: _killPropTweensOf,
			modifier: _addPluginModifier,
			rawVars: 0
		}, statics = {
			targetTest: 0,
			get: 0,
			getSetter: _getSetter,
			aliases: {},
			register: 0
		};
		_wake();
		if (config !== Plugin) {
			if (_plugins[name]) return;
			_setDefaults(Plugin, _setDefaults(_copyExcluding(config, instanceDefaults), statics));
			_merge(Plugin.prototype, _merge(instanceDefaults, _copyExcluding(config, statics)));
			_plugins[Plugin.prop = name] = Plugin;
			if (config.targetTest) {
				_harnessPlugins.push(Plugin);
				_reservedProps[name] = 1;
			}
			name = (name === "css" ? "CSS" : name.charAt(0).toUpperCase() + name.substr(1)) + "Plugin";
		}
		_addGlobal(name, Plugin);
		config.register && config.register(gsap, Plugin, PropTween);
	} else _registerPluginQueue.push(config);
};
var _255 = 255;
var _colorLookup = {
	aqua: [
		0,
		_255,
		_255
	],
	lime: [
		0,
		_255,
		0
	],
	silver: [
		192,
		192,
		192
	],
	black: [
		0,
		0,
		0
	],
	maroon: [
		128,
		0,
		0
	],
	teal: [
		0,
		128,
		128
	],
	blue: [
		0,
		0,
		_255
	],
	navy: [
		0,
		0,
		128
	],
	white: [
		_255,
		_255,
		_255
	],
	olive: [
		128,
		128,
		0
	],
	yellow: [
		_255,
		_255,
		0
	],
	orange: [
		_255,
		165,
		0
	],
	gray: [
		128,
		128,
		128
	],
	purple: [
		128,
		0,
		128
	],
	green: [
		0,
		128,
		0
	],
	red: [
		_255,
		0,
		0
	],
	pink: [
		_255,
		192,
		203
	],
	cyan: [
		0,
		_255,
		_255
	],
	transparent: [
		_255,
		_255,
		_255,
		0
	]
};
var _hue = function _hue(h, m1, m2) {
	h += h < 0 ? 1 : h > 1 ? -1 : 0;
	return (h * 6 < 1 ? m1 + (m2 - m1) * h * 6 : h < .5 ? m2 : h * 3 < 2 ? m1 + (m2 - m1) * (2 / 3 - h) * 6 : m1) * _255 + .5 | 0;
};
var splitColor = function splitColor(v, toHSL, forceAlpha) {
	var a = !v ? _colorLookup.black : _isNumber(v) ? [
		v >> 16,
		v >> 8 & _255,
		v & _255
	] : 0, r, g, b, h, s, l, max, min, d, wasHSL;
	if (!a) {
		if (v.substr(-1) === ",") v = v.substr(0, v.length - 1);
		if (_colorLookup[v]) a = _colorLookup[v];
		else if (v.charAt(0) === "#") {
			if (v.length < 6) {
				r = v.charAt(1);
				g = v.charAt(2);
				b = v.charAt(3);
				v = "#" + r + r + g + g + b + b + (v.length === 5 ? v.charAt(4) + v.charAt(4) : "");
			}
			if (v.length === 9) {
				a = parseInt(v.substr(1, 6), 16);
				return [
					a >> 16,
					a >> 8 & _255,
					a & _255,
					parseInt(v.substr(7), 16) / 255
				];
			}
			v = parseInt(v.substr(1), 16);
			a = [
				v >> 16,
				v >> 8 & _255,
				v & _255
			];
		} else if (v.substr(0, 3) === "hsl") {
			a = wasHSL = v.match(_strictNumExp);
			if (!toHSL) {
				h = +a[0] % 360 / 360;
				s = +a[1] / 100;
				l = +a[2] / 100;
				g = l <= .5 ? l * (s + 1) : l + s - l * s;
				r = l * 2 - g;
				a.length > 3 && (a[3] *= 1);
				a[0] = _hue(h + 1 / 3, r, g);
				a[1] = _hue(h, r, g);
				a[2] = _hue(h - 1 / 3, r, g);
			} else if (~v.indexOf("=")) {
				a = v.match(_numExp);
				forceAlpha && a.length < 4 && (a[3] = 1);
				return a;
			}
		} else a = v.match(_strictNumExp) || _colorLookup.transparent;
		a = a.map(Number);
	}
	if (toHSL && !wasHSL) {
		r = a[0] / _255;
		g = a[1] / _255;
		b = a[2] / _255;
		max = Math.max(r, g, b);
		min = Math.min(r, g, b);
		l = (max + min) / 2;
		if (max === min) h = s = 0;
		else {
			d = max - min;
			s = l > .5 ? d / (2 - max - min) : d / (max + min);
			h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
			h *= 60;
		}
		a[0] = ~~(h + .5);
		a[1] = ~~(s * 100 + .5);
		a[2] = ~~(l * 100 + .5);
	}
	forceAlpha && a.length < 4 && (a[3] = 1);
	return a;
};
var _colorOrderData = function _colorOrderData(v) {
	var values = [], c = [], i = -1;
	v.split(_colorExp).forEach(function(v) {
		var a = v.match(_numWithUnitExp) || [];
		values.push.apply(values, a);
		c.push(i += a.length + 1);
	});
	values.c = c;
	return values;
};
var _formatColors = function _formatColors(s, toHSL, orderMatchData) {
	var result = "", colors = (s + result).match(_colorExp), type = toHSL ? "hsla(" : "rgba(", i = 0, c, shell, d, l;
	if (!colors) return s;
	colors = colors.map(function(color) {
		return (color = splitColor(color, toHSL, 1)) && type + (toHSL ? color[0] + "," + color[1] + "%," + color[2] + "%," + color[3] : color.join(",")) + ")";
	});
	if (orderMatchData) {
		d = _colorOrderData(s);
		c = orderMatchData.c;
		if (c.join(result) !== d.c.join(result)) {
			shell = s.replace(_colorExp, "1").split(_numWithUnitExp);
			l = shell.length - 1;
			for (; i < l; i++) result += shell[i] + (~c.indexOf(i) ? colors.shift() || type + "0,0,0,0)" : (d.length ? d : colors.length ? colors : orderMatchData).shift());
		}
	}
	if (!shell) {
		shell = s.split(_colorExp);
		l = shell.length - 1;
		for (; i < l; i++) result += shell[i] + colors[i];
	}
	return result + shell[l];
};
var _colorExp = function() {
	var s = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b", p;
	for (p in _colorLookup) s += "|" + p + "\\b";
	return new RegExp(s + ")", "gi");
}();
var _hslExp = /hsl[a]?\(/;
var _colorStringFilter = function _colorStringFilter(a) {
	var combined = a.join(" "), toHSL;
	_colorExp.lastIndex = 0;
	if (_colorExp.test(combined)) {
		toHSL = _hslExp.test(combined);
		a[1] = _formatColors(a[1], toHSL);
		a[0] = _formatColors(a[0], toHSL, _colorOrderData(a[1]));
		return true;
	}
};
var _tickerActive;
var _ticker = function() {
	var _getTime = Date.now, _lagThreshold = 500, _adjustedLag = 33, _startTime = _getTime(), _lastUpdate = _startTime, _gap = 1e3 / 240, _nextTime = _gap, _listeners = [], _id, _req, _raf, _self, _delta, _i, _tick = function _tick(v) {
		var elapsed = _getTime() - _lastUpdate, manual = v === true, overlap, dispatch, time, frame;
		(elapsed > _lagThreshold || elapsed < 0) && (_startTime += elapsed - _adjustedLag);
		_lastUpdate += elapsed;
		time = _lastUpdate - _startTime;
		overlap = time - _nextTime;
		if (overlap > 0 || manual) {
			frame = ++_self.frame;
			_delta = time - _self.time * 1e3;
			_self.time = time = time / 1e3;
			_nextTime += overlap + (overlap >= _gap ? 4 : _gap - overlap);
			dispatch = 1;
		}
		manual || (_id = _req(_tick));
		if (dispatch) for (_i = 0; _i < _listeners.length; _i++) _listeners[_i](time, _delta, frame, v);
	};
	_self = {
		time: 0,
		frame: 0,
		tick: function tick() {
			_tick(true);
		},
		deltaRatio: function deltaRatio(fps) {
			return _delta / (1e3 / (fps || 60));
		},
		wake: function wake() {
			if (_coreReady) {
				if (!_coreInitted && _windowExists$1()) {
					_win$1 = _coreInitted = window;
					_doc$1 = _win$1.document || {};
					_globals.gsap = gsap;
					(_win$1.gsapVersions || (_win$1.gsapVersions = [])).push(gsap.version);
					_install(_installScope || _win$1.GreenSockGlobals || !_win$1.gsap && _win$1 || {});
					_registerPluginQueue.forEach(_createPlugin);
				}
				_raf = typeof requestAnimationFrame !== "undefined" && requestAnimationFrame;
				_id && _self.sleep();
				_req = _raf || function(f) {
					return setTimeout(f, _nextTime - _self.time * 1e3 + 1 | 0);
				};
				_tickerActive = 1;
				_tick(2);
			}
		},
		sleep: function sleep() {
			(_raf ? cancelAnimationFrame : clearTimeout)(_id);
			_tickerActive = 0;
			_req = _emptyFunc;
		},
		lagSmoothing: function lagSmoothing(threshold, adjustedLag) {
			_lagThreshold = threshold || Infinity;
			_adjustedLag = Math.min(adjustedLag || 33, _lagThreshold);
		},
		fps: function fps(_fps) {
			_gap = 1e3 / (_fps || 240);
			_nextTime = _self.time * 1e3 + _gap;
		},
		add: function add(callback, once, prioritize) {
			var func = once ? function(t, d, f, v) {
				callback(t, d, f, v);
				_self.remove(func);
			} : callback;
			_self.remove(callback);
			_listeners[prioritize ? "unshift" : "push"](func);
			_wake();
			return func;
		},
		remove: function remove(callback, i) {
			~(i = _listeners.indexOf(callback)) && _listeners.splice(i, 1) && _i >= i && _i--;
		},
		_listeners
	};
	return _self;
}();
var _wake = function _wake() {
	return !_tickerActive && _ticker.wake();
};
var _easeMap = {};
var _customEaseExp = /^[\d.\-M][\d.\-,\s]/;
var _quotesExp = /["']/g;
var _parseObjectInString = function _parseObjectInString(value) {
	var obj = {}, split = value.substr(1, value.length - 3).split(":"), key = split[0], i = 1, l = split.length, index, val, parsedVal;
	for (; i < l; i++) {
		val = split[i];
		index = i !== l - 1 ? val.lastIndexOf(",") : val.length;
		parsedVal = val.substr(0, index);
		obj[key] = isNaN(parsedVal) ? parsedVal.replace(_quotesExp, "").trim() : +parsedVal;
		key = val.substr(index + 1).trim();
	}
	return obj;
};
var _valueInParentheses = function _valueInParentheses(value) {
	var open = value.indexOf("(") + 1, close = value.indexOf(")"), nested = value.indexOf("(", open);
	return value.substring(open, ~nested && nested < close ? value.indexOf(")", close + 1) : close);
};
var _configEaseFromString = function _configEaseFromString(name) {
	var split = (name + "").split("("), ease = _easeMap[split[0]];
	return ease && split.length > 1 && ease.config ? ease.config.apply(null, ~name.indexOf("{") ? [_parseObjectInString(split[1])] : _valueInParentheses(name).split(",").map(_numericIfPossible)) : _easeMap._CE && _customEaseExp.test(name) ? _easeMap._CE("", name) : ease;
};
var _invertEase = function _invertEase(ease) {
	return function(p) {
		return 1 - ease(1 - p);
	};
};
var _parseEase = function _parseEase(ease, defaultEase) {
	return !ease ? defaultEase : (_isFunction(ease) ? ease : _easeMap[ease] || _configEaseFromString(ease)) || defaultEase;
};
var _insertEase = function _insertEase(names, easeIn, easeOut, easeInOut) {
	if (easeOut === void 0) easeOut = function easeOut(p) {
		return 1 - easeIn(1 - p);
	};
	if (easeInOut === void 0) easeInOut = function easeInOut(p) {
		return p < .5 ? easeIn(p * 2) / 2 : 1 - easeIn((1 - p) * 2) / 2;
	};
	var ease = {
		easeIn,
		easeOut,
		easeInOut
	}, lowercaseName;
	_forEachName(names, function(name) {
		_easeMap[name] = _globals[name] = ease;
		_easeMap[lowercaseName = name.toLowerCase()] = easeOut;
		for (var p in ease) _easeMap[lowercaseName + (p === "easeIn" ? ".in" : p === "easeOut" ? ".out" : ".inOut")] = _easeMap[name + "." + p] = ease[p];
	});
	return ease;
};
var _easeInOutFromOut = function _easeInOutFromOut(easeOut) {
	return function(p) {
		return p < .5 ? (1 - easeOut(1 - p * 2)) / 2 : .5 + easeOut((p - .5) * 2) / 2;
	};
};
var _configElastic = function _configElastic(type, amplitude, period) {
	var p1 = amplitude >= 1 ? amplitude : 1, p2 = (period || (type ? .3 : .45)) / (amplitude < 1 ? amplitude : 1), p3 = p2 / _2PI * (Math.asin(1 / p1) || 0), easeOut = function easeOut(p) {
		return p === 1 ? 1 : p1 * Math.pow(2, -10 * p) * _sin((p - p3) * p2) + 1;
	}, ease = type === "out" ? easeOut : type === "in" ? function(p) {
		return 1 - easeOut(1 - p);
	} : _easeInOutFromOut(easeOut);
	p2 = _2PI / p2;
	ease.config = function(amplitude, period) {
		return _configElastic(type, amplitude, period);
	};
	return ease;
};
var _configBack = function _configBack(type, overshoot) {
	if (overshoot === void 0) overshoot = 1.70158;
	var easeOut = function easeOut(p) {
		return p ? --p * p * ((overshoot + 1) * p + overshoot) + 1 : 0;
	}, ease = type === "out" ? easeOut : type === "in" ? function(p) {
		return 1 - easeOut(1 - p);
	} : _easeInOutFromOut(easeOut);
	ease.config = function(overshoot) {
		return _configBack(type, overshoot);
	};
	return ease;
};
_forEachName("Linear,Quad,Cubic,Quart,Quint,Strong", function(name, i) {
	var power = i < 5 ? i + 1 : i;
	_insertEase(name + ",Power" + (power - 1), i ? function(p) {
		return Math.pow(p, power);
	} : function(p) {
		return p;
	}, function(p) {
		return 1 - Math.pow(1 - p, power);
	}, function(p) {
		return p < .5 ? Math.pow(p * 2, power) / 2 : 1 - Math.pow((1 - p) * 2, power) / 2;
	});
});
_easeMap.Linear.easeNone = _easeMap.none = _easeMap.Linear.easeIn;
_insertEase("Elastic", _configElastic("in"), _configElastic("out"), _configElastic());
(function(n, c) {
	var n1 = 1 / c, n2 = 2 * n1, n3 = 2.5 * n1, easeOut = function easeOut(p) {
		return p < n1 ? n * p * p : p < n2 ? n * Math.pow(p - 1.5 / c, 2) + .75 : p < n3 ? n * (p -= 2.25 / c) * p + .9375 : n * Math.pow(p - 2.625 / c, 2) + .984375;
	};
	_insertEase("Bounce", function(p) {
		return 1 - easeOut(1 - p);
	}, easeOut);
})(7.5625, 2.75);
_insertEase("Expo", function(p) {
	return Math.pow(2, 10 * (p - 1)) * p + p * p * p * p * p * p * (1 - p);
});
_insertEase("Circ", function(p) {
	return -(_sqrt(1 - p * p) - 1);
});
_insertEase("Sine", function(p) {
	return p === 1 ? 1 : -_cos(p * _HALF_PI) + 1;
});
_insertEase("Back", _configBack("in"), _configBack("out"), _configBack());
_easeMap.SteppedEase = _easeMap.steps = _globals.SteppedEase = { config: function config(steps, immediateStart) {
	if (steps === void 0) steps = 1;
	var p1 = 1 / steps, p2 = steps + (immediateStart ? 0 : 1), p3 = immediateStart ? 1 : 0, max = 1 - _tinyNum;
	return function(p) {
		return ((p2 * _clamp(0, max, p) | 0) + p3) * p1;
	};
} };
_defaults.ease = _easeMap["quad.out"];
_forEachName("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(name) {
	return _callbackNames += name + "," + name + "Params,";
});
var GSCache = function GSCache(target, harness) {
	this.id = _gsID++;
	target._gsap = this;
	this.target = target;
	this.harness = harness;
	this.get = harness ? harness.get : _getProperty;
	this.set = harness ? harness.getSetter : _getSetter;
};
var Animation = /*#__PURE__*/ function() {
	function Animation(vars) {
		this.vars = vars;
		this._delay = +vars.delay || 0;
		if (this._repeat = vars.repeat === Infinity ? -2 : vars.repeat || 0) {
			this._rDelay = vars.repeatDelay || 0;
			this._yoyo = !!vars.yoyo || !!vars.yoyoEase;
		}
		this._ts = 1;
		_setDuration(this, +vars.duration, 1, 1);
		this.data = vars.data;
		if (_context) {
			this._ctx = _context;
			_context.data.push(this);
		}
		_tickerActive || _ticker.wake();
	}
	var _proto = Animation.prototype;
	_proto.delay = function delay(value) {
		if (value || value === 0) {
			this.parent && this.parent.smoothChildTiming && this.startTime(this._start + value - this._delay);
			this._delay = value;
			return this;
		}
		return this._delay;
	};
	_proto.duration = function duration(value) {
		return arguments.length ? this.totalDuration(this._repeat > 0 ? value + (value + this._rDelay) * this._repeat : value) : this.totalDuration() && this._dur;
	};
	_proto.totalDuration = function totalDuration(value) {
		if (!arguments.length) return this._tDur;
		this._dirty = 0;
		return _setDuration(this, this._repeat < 0 ? value : (value - this._repeat * this._rDelay) / (this._repeat + 1));
	};
	_proto.totalTime = function totalTime(_totalTime, suppressEvents) {
		_wake();
		if (!arguments.length) return this._tTime;
		var parent = this._dp;
		if (parent && parent.smoothChildTiming && this._ts) {
			_alignPlayhead(this, _totalTime);
			!parent._dp || parent.parent || _postAddChecks(parent, this);
			while (parent && parent.parent) {
				if (parent.parent._time !== parent._start + (parent._ts >= 0 ? parent._tTime / parent._ts : (parent.totalDuration() - parent._tTime) / -parent._ts)) parent.totalTime(parent._tTime, true);
				parent = parent.parent;
			}
			if (!this.parent && this._dp.autoRemoveChildren && (this._ts > 0 && _totalTime < this._tDur || this._ts < 0 && _totalTime > 0 || !this._tDur && !_totalTime)) _addToTimeline(this._dp, this, this._start - this._delay);
		}
		if (this._tTime !== _totalTime || !this._dur && !suppressEvents || this._initted && Math.abs(this._zTime) === _tinyNum || !this._initted && this._dur && _totalTime || !_totalTime && !this._initted && (this.add || this._ptLookup)) {
			this._ts || (this._pTime = _totalTime);
			_lazySafeRender(this, _totalTime, suppressEvents);
		}
		return this;
	};
	_proto.time = function time(value, suppressEvents) {
		return arguments.length ? this.totalTime(Math.min(this.totalDuration(), value + _elapsedCycleDuration(this)) % (this._dur + this._rDelay) || (value ? this._dur : 0), suppressEvents) : this._time;
	};
	_proto.totalProgress = function totalProgress(value, suppressEvents) {
		return arguments.length ? this.totalTime(this.totalDuration() * value, suppressEvents) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.rawTime() >= 0 && this._initted ? 1 : 0;
	};
	_proto.progress = function progress(value, suppressEvents) {
		return arguments.length ? this.totalTime(this.duration() * (this._yoyo && !(this.iteration() & 1) ? 1 - value : value) + _elapsedCycleDuration(this), suppressEvents) : this.duration() ? Math.min(1, this._time / this._dur) : this.rawTime() > 0 ? 1 : 0;
	};
	_proto.iteration = function iteration(value, suppressEvents) {
		var cycleDuration = this.duration() + this._rDelay;
		return arguments.length ? this.totalTime(this._time + (value - 1) * cycleDuration, suppressEvents) : this._repeat ? _animationCycle(this._tTime, cycleDuration) + 1 : 1;
	};
	_proto.timeScale = function timeScale(value, suppressEvents) {
		if (!arguments.length) return this._rts === -_tinyNum ? 0 : this._rts;
		if (this._rts === value) return this;
		var tTime = this.parent && this._ts ? _parentToChildTotalTime(this.parent._time, this) : this._tTime;
		this._rts = +value || 0;
		this._ts = this._ps || value === -_tinyNum ? 0 : this._rts;
		this.totalTime(_clamp(-Math.abs(this._delay), this.totalDuration(), tTime), suppressEvents !== false);
		_setEnd(this);
		return _recacheAncestors(this);
	};
	_proto.paused = function paused(value) {
		if (!arguments.length) return this._ps;
		if (this._ps !== value) {
			this._ps = value;
			if (value) {
				this._pTime = this._tTime || Math.max(-this._delay, this.rawTime());
				this._ts = this._act = 0;
			} else {
				_wake();
				this._ts = this._rts;
				this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, this.progress() === 1 && Math.abs(this._zTime) !== _tinyNum && (this._tTime -= _tinyNum));
			}
		}
		return this;
	};
	_proto.startTime = function startTime(value) {
		if (arguments.length) {
			this._start = _roundPrecise(value);
			var parent = this.parent || this._dp;
			parent && (parent._sort || !this.parent) && _addToTimeline(parent, this, this._start - this._delay);
			return this;
		}
		return this._start;
	};
	_proto.endTime = function endTime(includeRepeats) {
		return this._start + (_isNotFalse(includeRepeats) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1);
	};
	_proto.rawTime = function rawTime(wrapRepeats) {
		var parent = this.parent || this._dp;
		return !parent ? this._tTime : wrapRepeats && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : !this._ts ? this._tTime : _parentToChildTotalTime(parent.rawTime(wrapRepeats), this);
	};
	_proto.revert = function revert(config) {
		if (config === void 0) config = _revertConfig;
		var prevIsReverting = _reverting$1;
		_reverting$1 = config;
		if (_isRevertWorthy(this)) {
			this.timeline && this.timeline.revert(config);
			this.totalTime(-.01, config.suppressEvents);
		}
		this.data !== "nested" && config.kill !== false && this.kill();
		_reverting$1 = prevIsReverting;
		return this;
	};
	_proto.globalTime = function globalTime(rawTime) {
		var animation = this, time = arguments.length ? rawTime : animation.rawTime();
		while (animation) {
			time = animation._start + time / (Math.abs(animation._ts) || 1);
			animation = animation._dp;
		}
		return !this.parent && this._sat ? this._sat.globalTime(rawTime) : time;
	};
	_proto.repeat = function repeat(value) {
		if (arguments.length) {
			this._repeat = value === Infinity ? -2 : value;
			return _onUpdateTotalDuration(this);
		}
		return this._repeat === -2 ? Infinity : this._repeat;
	};
	_proto.repeatDelay = function repeatDelay(value) {
		if (arguments.length) {
			var time = this._time;
			this._rDelay = value;
			_onUpdateTotalDuration(this);
			return time ? this.time(time) : this;
		}
		return this._rDelay;
	};
	_proto.yoyo = function yoyo(value) {
		if (arguments.length) {
			this._yoyo = value;
			return this;
		}
		return this._yoyo;
	};
	_proto.seek = function seek(position, suppressEvents) {
		return this.totalTime(_parsePosition(this, position), _isNotFalse(suppressEvents));
	};
	_proto.restart = function restart(includeDelay, suppressEvents) {
		this.play().totalTime(includeDelay ? -this._delay : 0, _isNotFalse(suppressEvents));
		this._dur || (this._zTime = -_tinyNum);
		return this;
	};
	_proto.play = function play(from, suppressEvents) {
		from != null && this.seek(from, suppressEvents);
		return this.reversed(false).paused(false);
	};
	_proto.reverse = function reverse(from, suppressEvents) {
		from != null && this.seek(from || this.totalDuration(), suppressEvents);
		return this.reversed(true).paused(false);
	};
	_proto.pause = function pause(atTime, suppressEvents) {
		atTime != null && this.seek(atTime, suppressEvents);
		return this.paused(true);
	};
	_proto.resume = function resume() {
		return this.paused(false);
	};
	_proto.reversed = function reversed(value) {
		if (arguments.length) {
			!!value !== this.reversed() && this.timeScale(-this._rts || (value ? -_tinyNum : 0));
			return this;
		}
		return this._rts < 0;
	};
	_proto.invalidate = function invalidate() {
		this._initted = this._act = 0;
		this._zTime = -_tinyNum;
		return this;
	};
	_proto.isActive = function isActive() {
		var parent = this.parent || this._dp, start = this._start, rawTime;
		return !!(!parent || this._ts && this._initted && parent.isActive() && (rawTime = parent.rawTime(true)) >= start && rawTime < this.endTime(true) - _tinyNum);
	};
	_proto.eventCallback = function eventCallback(type, callback, params) {
		var vars = this.vars;
		if (arguments.length > 1) {
			if (!callback) delete vars[type];
			else {
				vars[type] = callback;
				params && (vars[type + "Params"] = params);
				type === "onUpdate" && (this._onUpdate = callback);
			}
			return this;
		}
		return vars[type];
	};
	_proto.then = function then(onFulfilled) {
		var self = this, prevProm = self._prom;
		return new Promise(function(resolve) {
			var f = _isFunction(onFulfilled) ? onFulfilled : _passThrough, _resolve = function _resolve() {
				var _then = self.then;
				self.then = null;
				prevProm && prevProm();
				_isFunction(f) && (f = f(self)) && (f.then || f === self) && (self.then = _then);
				resolve(f);
				self.then = _then;
			};
			if (self._initted && self.totalProgress() === 1 && self._ts >= 0 || !self._tTime && self._ts < 0) _resolve();
			else self._prom = _resolve;
		});
	};
	_proto.kill = function kill() {
		_interrupt(this);
	};
	return Animation;
}();
_setDefaults(Animation.prototype, {
	_time: 0,
	_start: 0,
	_end: 0,
	_tTime: 0,
	_tDur: 0,
	_dirty: 0,
	_repeat: 0,
	_yoyo: false,
	parent: null,
	_initted: false,
	_rDelay: 0,
	_ts: 1,
	_dp: 0,
	ratio: 0,
	_zTime: -_tinyNum,
	_prom: 0,
	_ps: false,
	_rts: 1
});
var Timeline = /*#__PURE__*/ function(_Animation) {
	_inheritsLoose(Timeline, _Animation);
	function Timeline(vars, position) {
		var _this;
		if (vars === void 0) vars = {};
		_this = _Animation.call(this, vars) || this;
		_this.labels = {};
		_this.smoothChildTiming = !!vars.smoothChildTiming;
		_this.autoRemoveChildren = !!vars.autoRemoveChildren;
		_this._sort = _isNotFalse(vars.sortChildren);
		_globalTimeline && _addToTimeline(vars.parent || _globalTimeline, _assertThisInitialized(_this), position);
		vars.reversed && _this.reverse();
		vars.paused && _this.paused(true);
		vars.scrollTrigger && _scrollTrigger(_assertThisInitialized(_this), vars.scrollTrigger);
		return _this;
	}
	var _proto2 = Timeline.prototype;
	_proto2.to = function to(targets, vars, position) {
		_createTweenType(0, arguments, this);
		return this;
	};
	_proto2.from = function from(targets, vars, position) {
		_createTweenType(1, arguments, this);
		return this;
	};
	_proto2.fromTo = function fromTo(targets, fromVars, toVars, position) {
		_createTweenType(2, arguments, this);
		return this;
	};
	_proto2.set = function set(targets, vars, position) {
		vars.duration = 0;
		vars.parent = this;
		_inheritDefaults(vars).repeatDelay || (vars.repeat = 0);
		vars.immediateRender = !!vars.immediateRender;
		new Tween(targets, vars, _parsePosition(this, position), 1);
		return this;
	};
	_proto2.call = function call(callback, params, position) {
		return _addToTimeline(this, Tween.delayedCall(0, callback, params), position);
	};
	_proto2.staggerTo = function staggerTo(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams) {
		vars.duration = duration;
		vars.stagger = vars.stagger || stagger;
		vars.onComplete = onCompleteAll;
		vars.onCompleteParams = onCompleteAllParams;
		vars.parent = this;
		new Tween(targets, vars, _parsePosition(this, position));
		return this;
	};
	_proto2.staggerFrom = function staggerFrom(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams) {
		vars.runBackwards = 1;
		_inheritDefaults(vars).immediateRender = _isNotFalse(vars.immediateRender);
		return this.staggerTo(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams);
	};
	_proto2.staggerFromTo = function staggerFromTo(targets, duration, fromVars, toVars, stagger, position, onCompleteAll, onCompleteAllParams) {
		toVars.startAt = fromVars;
		_inheritDefaults(toVars).immediateRender = _isNotFalse(toVars.immediateRender);
		return this.staggerTo(targets, duration, toVars, stagger, position, onCompleteAll, onCompleteAllParams);
	};
	_proto2.render = function render(totalTime, suppressEvents, force) {
		var prevTime = this._time, tDur = this._dirty ? this.totalDuration() : this._tDur, dur = this._dur, tTime = totalTime <= 0 ? 0 : _roundPrecise(totalTime), crossingStart = this._zTime < 0 !== totalTime < 0 && (this._initted || !dur), time, child, next, iteration, cycleDuration, prevPaused, pauseTween, timeScale, prevStart, prevIteration, yoyo, isYoyo;
		this !== _globalTimeline && tTime > tDur && totalTime >= 0 && (tTime = tDur);
		if (tTime !== this._tTime || force || crossingStart) {
			if (prevTime !== this._time && dur) {
				tTime += this._time - prevTime;
				totalTime += this._time - prevTime;
			}
			time = tTime;
			prevStart = this._start;
			timeScale = this._ts;
			prevPaused = !timeScale;
			if (crossingStart) {
				dur || (prevTime = this._zTime);
				(totalTime || !suppressEvents) && (this._zTime = totalTime);
			}
			if (this._repeat) {
				yoyo = this._yoyo;
				cycleDuration = dur + this._rDelay;
				if (this._repeat < -1 && totalTime < 0) return this.totalTime(cycleDuration * 100 + totalTime, suppressEvents, force);
				time = _roundPrecise(tTime % cycleDuration);
				if (tTime === tDur) {
					iteration = this._repeat;
					time = dur;
				} else {
					prevIteration = _roundPrecise(tTime / cycleDuration);
					iteration = ~~prevIteration;
					if (iteration && iteration === prevIteration) {
						time = dur;
						iteration--;
					}
					time > dur && (time = dur);
				}
				prevIteration = _animationCycle(this._tTime, cycleDuration);
				!prevTime && this._tTime && prevIteration !== iteration && this._tTime - prevIteration * cycleDuration - this._dur <= 0 && (prevIteration = iteration);
				if (yoyo && iteration & 1) {
					time = dur - time;
					isYoyo = 1;
				}
				if (iteration !== prevIteration && !this._lock) {
					var rewinding = yoyo && prevIteration & 1, doesWrap = rewinding === (yoyo && iteration & 1);
					iteration < prevIteration && (rewinding = !rewinding);
					prevTime = rewinding ? 0 : tTime % dur ? dur : tTime;
					this._lock = 1;
					this.render(prevTime || (isYoyo ? 0 : _roundPrecise(iteration * cycleDuration)), suppressEvents, !dur)._lock = 0;
					this._tTime = tTime;
					!suppressEvents && this.parent && _callback(this, "onRepeat");
					if (this.vars.repeatRefresh && !isYoyo) {
						this.invalidate()._lock = 1;
						prevIteration = iteration;
					}
					if (prevTime && prevTime !== this._time || prevPaused !== !this._ts || this.vars.onRepeat && !this.parent && !this._act) return this;
					dur = this._dur;
					tDur = this._tDur;
					if (doesWrap) {
						this._lock = 2;
						prevTime = rewinding ? dur : -1e-4;
						this.render(prevTime, true);
						this.vars.repeatRefresh && !isYoyo && this.invalidate();
					}
					this._lock = 0;
					if (!this._ts && !prevPaused) return this;
				}
			}
			if (this._hasPause && !this._forcing && this._lock < 2) {
				pauseTween = _findNextPauseTween(this, _roundPrecise(prevTime), _roundPrecise(time));
				if (pauseTween) tTime -= time - (time = pauseTween._start);
			}
			this._tTime = tTime;
			this._time = time;
			this._act = !!timeScale;
			if (!this._initted) {
				this._onUpdate = this.vars.onUpdate;
				this._initted = 1;
				this._zTime = totalTime;
				prevTime = 0;
			}
			if (!prevTime && tTime && dur && !suppressEvents && !prevIteration) {
				_callback(this, "onStart");
				if (this._tTime !== tTime) return this;
			}
			if (time >= prevTime && totalTime >= 0) {
				child = this._first;
				while (child) {
					next = child._next;
					if ((child._act || time >= child._start) && child._ts && pauseTween !== child) {
						if (child.parent !== this) return this.render(totalTime, suppressEvents, force);
						child.render(child._ts > 0 ? (time - child._start) * child._ts : (child._dirty ? child.totalDuration() : child._tDur) + (time - child._start) * child._ts, suppressEvents, force);
						if (time !== this._time || !this._ts && !prevPaused) {
							pauseTween = 0;
							next && (tTime += this._zTime = -_tinyNum);
							break;
						}
					}
					child = next;
				}
			} else {
				child = this._last;
				var adjustedTime = totalTime < 0 ? totalTime : time;
				while (child) {
					next = child._prev;
					if ((child._act || adjustedTime <= child._end) && child._ts && pauseTween !== child) {
						if (child.parent !== this) return this.render(totalTime, suppressEvents, force);
						child.render(child._ts > 0 ? (adjustedTime - child._start) * child._ts : (child._dirty ? child.totalDuration() : child._tDur) + (adjustedTime - child._start) * child._ts, suppressEvents, force || _reverting$1 && _isRevertWorthy(child));
						if (time !== this._time || !this._ts && !prevPaused) {
							pauseTween = 0;
							next && (tTime += this._zTime = adjustedTime ? -_tinyNum : _tinyNum);
							break;
						}
					}
					child = next;
				}
			}
			if (pauseTween && !suppressEvents) {
				this.pause();
				pauseTween.render(time >= prevTime ? 0 : -_tinyNum)._zTime = time >= prevTime ? 1 : -1;
				if (this._ts) {
					this._start = prevStart;
					_setEnd(this);
					return this.render(totalTime, suppressEvents, force);
				}
			}
			this._onUpdate && !suppressEvents && _callback(this, "onUpdate", true);
			if (tTime === tDur && this._tTime >= this.totalDuration() || !tTime && prevTime) {
				if (prevStart === this._start || Math.abs(timeScale) !== Math.abs(this._ts)) {
					if (!this._lock) {
						(totalTime || !dur) && (tTime === tDur && this._ts > 0 || !tTime && this._ts < 0) && _removeFromParent(this, 1);
						if (!suppressEvents && !(totalTime < 0 && !prevTime) && (tTime || prevTime || !tDur)) {
							_callback(this, tTime === tDur && totalTime >= 0 ? "onComplete" : "onReverseComplete", true);
							this._prom && !(tTime < tDur && this.timeScale() > 0) && this._prom();
						}
					}
				}
			}
		}
		return this;
	};
	_proto2.add = function add(child, position) {
		var _this2 = this;
		_isNumber(position) || (position = _parsePosition(this, position, child));
		if (!(child instanceof Animation)) {
			if (_isArray(child)) {
				child.forEach(function(obj) {
					return _this2.add(obj, position);
				});
				return this;
			}
			if (_isString(child)) return this.addLabel(child, position);
			if (_isFunction(child)) child = Tween.delayedCall(0, child);
			else return this;
		}
		return this !== child ? _addToTimeline(this, child, position) : this;
	};
	_proto2.getChildren = function getChildren(nested, tweens, timelines, ignoreBeforeTime) {
		if (nested === void 0) nested = true;
		if (tweens === void 0) tweens = true;
		if (timelines === void 0) timelines = true;
		if (ignoreBeforeTime === void 0) ignoreBeforeTime = -_bigNum$1;
		var a = [], child = this._first;
		while (child) {
			if (child._start >= ignoreBeforeTime) {
				if (child instanceof Tween) tweens && a.push(child);
				else {
					timelines && a.push(child);
					nested && a.push.apply(a, child.getChildren(true, tweens, timelines));
				}
			}
			child = child._next;
		}
		return a;
	};
	_proto2.getById = function getById(id) {
		var animations = this.getChildren(1, 1, 1), i = animations.length;
		while (i--) if (animations[i].vars.id === id) return animations[i];
	};
	_proto2.remove = function remove(child) {
		if (_isString(child)) return this.removeLabel(child);
		if (_isFunction(child)) return this.killTweensOf(child);
		child.parent === this && _removeLinkedListItem(this, child);
		if (child === this._recent) this._recent = this._last;
		return _uncache(this);
	};
	_proto2.totalTime = function totalTime(_totalTime2, suppressEvents) {
		if (!arguments.length) return this._tTime;
		this._forcing = 1;
		if (!this._dp && this._ts) this._start = _roundPrecise(_ticker.time - (this._ts > 0 ? _totalTime2 / this._ts : (this.totalDuration() - _totalTime2) / -this._ts));
		_Animation.prototype.totalTime.call(this, _totalTime2, suppressEvents);
		this._forcing = 0;
		return this;
	};
	_proto2.addLabel = function addLabel(label, position) {
		this.labels[label] = _parsePosition(this, position);
		return this;
	};
	_proto2.removeLabel = function removeLabel(label) {
		delete this.labels[label];
		return this;
	};
	_proto2.addPause = function addPause(position, callback, params) {
		var t = Tween.delayedCall(0, callback || _emptyFunc, params);
		t.data = "isPause";
		this._hasPause = 1;
		return _addToTimeline(this, t, _parsePosition(this, position));
	};
	_proto2.removePause = function removePause(position) {
		var child = this._first;
		position = _parsePosition(this, position);
		while (child) {
			if (child._start === position && child.data === "isPause") _removeFromParent(child);
			child = child._next;
		}
	};
	_proto2.killTweensOf = function killTweensOf(targets, props, onlyActive) {
		var tweens = this.getTweensOf(targets, onlyActive), i = tweens.length;
		while (i--) _overwritingTween !== tweens[i] && tweens[i].kill(targets, props);
		return this;
	};
	_proto2.getTweensOf = function getTweensOf(targets, onlyActive) {
		var a = [], parsedTargets = toArray(targets), child = this._first, isGlobalTime = _isNumber(onlyActive), children;
		while (child) {
			if (child instanceof Tween) {
				if (_arrayContainsAny(child._targets, parsedTargets) && (isGlobalTime ? (!_overwritingTween || child._initted && child._ts) && child.globalTime(0) <= onlyActive && child.globalTime(child.totalDuration()) > onlyActive : !onlyActive || child.isActive())) a.push(child);
			} else if ((children = child.getTweensOf(parsedTargets, onlyActive)).length) a.push.apply(a, children);
			child = child._next;
		}
		return a;
	};
	_proto2.tweenTo = function tweenTo(position, vars) {
		vars = vars || {};
		var tl = this, endTime = _parsePosition(tl, position), _vars = vars, startAt = _vars.startAt, _onStart = _vars.onStart, onStartParams = _vars.onStartParams, immediateRender = _vars.immediateRender, initted, tween = Tween.to(tl, _setDefaults({
			ease: vars.ease || "none",
			lazy: false,
			immediateRender: false,
			time: endTime,
			overwrite: "auto",
			duration: vars.duration || Math.abs((endTime - (startAt && "time" in startAt ? startAt.time : tl._time)) / tl.timeScale()) || _tinyNum,
			onStart: function onStart() {
				tl.pause();
				if (!initted) {
					var duration = vars.duration || Math.abs((endTime - (startAt && "time" in startAt ? startAt.time : tl._time)) / tl.timeScale());
					tween._dur !== duration && _setDuration(tween, duration, 0, 1).render(tween._time, true, true);
					initted = 1;
				}
				_onStart && _onStart.apply(tween, onStartParams || []);
			}
		}, vars));
		return immediateRender ? tween.render(0) : tween;
	};
	_proto2.tweenFromTo = function tweenFromTo(fromPosition, toPosition, vars) {
		return this.tweenTo(toPosition, _setDefaults({ startAt: { time: _parsePosition(this, fromPosition) } }, vars));
	};
	_proto2.recent = function recent() {
		return this._recent;
	};
	_proto2.nextLabel = function nextLabel(afterTime) {
		if (afterTime === void 0) afterTime = this._time;
		return _getLabelInDirection(this, _parsePosition(this, afterTime));
	};
	_proto2.previousLabel = function previousLabel(beforeTime) {
		if (beforeTime === void 0) beforeTime = this._time;
		return _getLabelInDirection(this, _parsePosition(this, beforeTime), 1);
	};
	_proto2.currentLabel = function currentLabel(value) {
		return arguments.length ? this.seek(value, true) : this.previousLabel(this._time + _tinyNum);
	};
	_proto2.shiftChildren = function shiftChildren(amount, adjustLabels, ignoreBeforeTime) {
		if (ignoreBeforeTime === void 0) ignoreBeforeTime = 0;
		var child = this._first, labels = this.labels, p;
		amount = _roundPrecise(amount);
		while (child) {
			if (child._start >= ignoreBeforeTime) {
				child._start += amount;
				child._end += amount;
			}
			child = child._next;
		}
		if (adjustLabels) {
			for (p in labels) if (labels[p] >= ignoreBeforeTime) labels[p] += amount;
		}
		return _uncache(this);
	};
	_proto2.invalidate = function invalidate(soft) {
		var child = this._first;
		this._lock = 0;
		while (child) {
			child.invalidate(soft);
			child = child._next;
		}
		return _Animation.prototype.invalidate.call(this, soft);
	};
	_proto2.clear = function clear(includeLabels) {
		if (includeLabels === void 0) includeLabels = true;
		var child = this._first, next;
		while (child) {
			next = child._next;
			this.remove(child);
			child = next;
		}
		this._dp && (this._time = this._tTime = this._pTime = 0);
		includeLabels && (this.labels = {});
		return _uncache(this);
	};
	_proto2.totalDuration = function totalDuration(value) {
		var max = 0, self = this, child = self._last, prevStart = _bigNum$1, prev, start, parent;
		if (arguments.length) return self.timeScale((self._repeat < 0 ? self.duration() : self.totalDuration()) / (self.reversed() ? -value : value));
		if (self._dirty) {
			parent = self.parent;
			while (child) {
				prev = child._prev;
				child._dirty && child.totalDuration();
				start = child._start;
				if (start > prevStart && self._sort && child._ts && !self._lock) {
					self._lock = 1;
					_addToTimeline(self, child, start - child._delay, 1)._lock = 0;
				} else prevStart = start;
				if (start < 0 && child._ts) {
					max -= start;
					if (!parent && !self._dp || parent && parent.smoothChildTiming) {
						self._start += _roundPrecise(start / self._ts);
						self._time -= start;
						self._tTime -= start;
					}
					self.shiftChildren(-start, false, -Infinity);
					prevStart = 0;
				}
				child._end > max && child._ts && (max = child._end);
				child = prev;
			}
			_setDuration(self, self === _globalTimeline && self._time > max ? self._time : max, 1, 1);
			self._dirty = 0;
		}
		return self._tDur;
	};
	Timeline.updateRoot = function updateRoot(time) {
		if (_globalTimeline._ts) {
			_lazySafeRender(_globalTimeline, _parentToChildTotalTime(time, _globalTimeline));
			_lastRenderedFrame = _ticker.frame;
		}
		if (_ticker.frame >= _nextGCFrame) {
			_nextGCFrame += _config.autoSleep || 120;
			var child = _globalTimeline._first;
			if (!child || !child._ts) {
				if (_config.autoSleep && _ticker._listeners.length < 2) {
					while (child && !child._ts) child = child._next;
					child || _ticker.sleep();
				}
			}
		}
	};
	return Timeline;
}(Animation);
_setDefaults(Timeline.prototype, {
	_lock: 0,
	_hasPause: 0,
	_forcing: 0
});
var _addComplexStringPropTween = function _addComplexStringPropTween(target, prop, start, end, setter, stringFilter, funcParam) {
	var pt = new PropTween(this._pt, target, prop, 0, 1, _renderComplexString, null, setter), index = 0, matchIndex = 0, result, startNums, color, endNum, chunk, startNum, hasRandom, a;
	pt.b = start;
	pt.e = end;
	start += "";
	end += "";
	if (hasRandom = ~end.indexOf("random(")) end = _replaceRandom(end);
	if (stringFilter) {
		a = [start, end];
		stringFilter(a, target, prop);
		start = a[0];
		end = a[1];
	}
	startNums = start.match(_complexStringNumExp) || [];
	while (result = _complexStringNumExp.exec(end)) {
		endNum = result[0];
		chunk = end.substring(index, result.index);
		if (color) color = (color + 1) % 5;
		else if (chunk.substr(-5) === "rgba(") color = 1;
		if (endNum !== startNums[matchIndex++]) {
			startNum = parseFloat(startNums[matchIndex - 1]) || 0;
			pt._pt = {
				_next: pt._pt,
				p: chunk || matchIndex === 1 ? chunk : ",",
				s: startNum,
				c: endNum.charAt(1) === "=" ? _parseRelative(startNum, endNum) - startNum : parseFloat(endNum) - startNum,
				m: color && color < 4 ? Math.round : 0
			};
			index = _complexStringNumExp.lastIndex;
		}
	}
	pt.c = index < end.length ? end.substring(index, end.length) : "";
	pt.fp = funcParam;
	if (_relExp.test(end) || hasRandom) pt.e = 0;
	this._pt = pt;
	return pt;
};
var _addPropTween = function _addPropTween(target, prop, start, end, index, targets, modifier, stringFilter, funcParam, optional) {
	_isFunction(end) && (end = end(index || 0, target, targets));
	var currentValue = target[prop], parsedStart = start !== "get" ? start : !_isFunction(currentValue) ? currentValue : funcParam ? target[prop.indexOf("set") || !_isFunction(target["get" + prop.substr(3)]) ? prop : "get" + prop.substr(3)](funcParam) : target[prop](), setter = !_isFunction(currentValue) ? _setterPlain : funcParam ? _setterFuncWithParam : _setterFunc, pt;
	if (_isString(end)) {
		if (~end.indexOf("random(")) end = _replaceRandom(end);
		if (end.charAt(1) === "=") {
			pt = _parseRelative(parsedStart, end) + (getUnit(parsedStart) || 0);
			if (pt || pt === 0) end = pt;
		}
	}
	if (!optional || parsedStart !== end || _forceAllPropTweens) {
		if (!isNaN(parsedStart * end) && end !== "") {
			pt = new PropTween(this._pt, target, prop, +parsedStart || 0, end - (parsedStart || 0), typeof currentValue === "boolean" ? _renderBoolean : _renderPlain, 0, setter);
			funcParam && (pt.fp = funcParam);
			modifier && pt.modifier(modifier, this, target);
			return this._pt = pt;
		}
		!currentValue && !(prop in target) && _missingPlugin(prop, end);
		return _addComplexStringPropTween.call(this, target, prop, parsedStart, end, setter, stringFilter || _config.stringFilter, funcParam);
	}
};
var _processVars = function _processVars(vars, index, target, targets, tween) {
	_isFunction(vars) && (vars = _parseFuncOrString(vars, tween, index, target, targets));
	if (!_isObject(vars) || vars.style && vars.nodeType || _isArray(vars) || _isTypedArray(vars)) return _isString(vars) ? _parseFuncOrString(vars, tween, index, target, targets) : vars;
	var copy = {}, p;
	for (p in vars) copy[p] = _parseFuncOrString(vars[p], tween, index, target, targets);
	return copy;
};
var _checkPlugin = function _checkPlugin(property, vars, tween, index, target, targets) {
	var plugin, pt, ptLookup, i;
	if (_plugins[property] && (plugin = new _plugins[property]()).init(target, plugin.rawVars ? vars[property] : _processVars(vars[property], index, target, targets, tween), tween, index, targets) !== false) {
		tween._pt = pt = new PropTween(tween._pt, target, property, 0, 1, plugin.render, plugin, 0, plugin.priority);
		if (tween !== _quickTween) {
			ptLookup = tween._ptLookup[tween._targets.indexOf(target)];
			i = plugin._props.length;
			while (i--) ptLookup[plugin._props[i]] = pt;
		}
	}
	return plugin;
};
var _overwritingTween;
var _forceAllPropTweens;
var _initTween = function _initTween(tween, time, tTime) {
	var vars = tween.vars, ease = vars.ease, startAt = vars.startAt, immediateRender = vars.immediateRender, lazy = vars.lazy, onUpdate = vars.onUpdate, runBackwards = vars.runBackwards, yoyoEase = vars.yoyoEase, keyframes = vars.keyframes, autoRevert = vars.autoRevert, dur = tween._dur, prevStartAt = tween._startAt, targets = tween._targets, parent = tween.parent, fullTargets = parent && parent.data === "nested" ? parent.vars.targets : targets, autoOverwrite = tween._overwrite === "auto" && !_suppressOverwrites, tl = tween.timeline, reverseEase = vars.easeReverse || yoyoEase, cleanVars, i, p, pt, target, hasPriority, gsData, harness, plugin, ptLookup, index, harnessVars, overwritten;
	tl && (!keyframes || !ease) && (ease = "none");
	tween._ease = _parseEase(ease, _defaults.ease);
	tween._rEase = reverseEase && (_parseEase(reverseEase) || tween._ease);
	tween._from = !tl && !!vars.runBackwards;
	if (tween._from) tween.ratio = 1;
	if (!tl || keyframes && !vars.stagger) {
		harness = targets[0] ? _getCache(targets[0]).harness : 0;
		harnessVars = harness && vars[harness.prop];
		cleanVars = _copyExcluding(vars, _reservedProps);
		if (prevStartAt) {
			prevStartAt._zTime < 0 && prevStartAt.progress(1);
			time < 0 && runBackwards && immediateRender && !autoRevert ? prevStartAt.render(-1, true) : prevStartAt.revert(runBackwards && dur ? _revertConfigNoKill : _startAtRevertConfig);
			prevStartAt._lazy = 0;
		}
		if (startAt) {
			_removeFromParent(tween._startAt = Tween.set(targets, _setDefaults({
				data: "isStart",
				overwrite: false,
				parent,
				immediateRender: true,
				lazy: !prevStartAt && _isNotFalse(lazy),
				startAt: null,
				delay: 0,
				onUpdate: onUpdate && function() {
					return _callback(tween, "onUpdate");
				},
				stagger: 0
			}, startAt)));
			tween._startAt._dp = 0;
			tween._startAt._sat = tween;
			time < 0 && (_reverting$1 || !immediateRender && !autoRevert) && tween._startAt.revert(_revertConfigNoKill);
			if (immediateRender) {
				if (dur && time <= 0 && tTime <= 0) {
					time && (tween._zTime = time);
					return;
				}
			}
		} else if (runBackwards && dur) {
			if (!prevStartAt) {
				time && (immediateRender = false);
				p = _setDefaults({
					overwrite: false,
					data: "isFromStart",
					lazy: immediateRender && !prevStartAt && _isNotFalse(lazy),
					immediateRender,
					stagger: 0,
					parent
				}, cleanVars);
				harnessVars && (p[harness.prop] = harnessVars);
				_removeFromParent(tween._startAt = Tween.set(targets, p));
				tween._startAt._dp = 0;
				tween._startAt._sat = tween;
				time < 0 && (_reverting$1 ? tween._startAt.revert(_revertConfigNoKill) : tween._startAt.render(-1, true));
				tween._zTime = time;
				if (!immediateRender) _initTween(tween._startAt, _tinyNum, _tinyNum);
				else if (!time) return;
			}
		}
		tween._pt = tween._ptCache = 0;
		lazy = dur && _isNotFalse(lazy) || lazy && !dur;
		for (i = 0; i < targets.length; i++) {
			target = targets[i];
			gsData = target._gsap || _harness(targets)[i]._gsap;
			tween._ptLookup[i] = ptLookup = {};
			_lazyLookup[gsData.id] && _lazyTweens.length && _lazyRender();
			index = fullTargets === targets ? i : fullTargets.indexOf(target);
			if (harness && (plugin = new harness()).init(target, harnessVars || cleanVars, tween, index, fullTargets) !== false) {
				tween._pt = pt = new PropTween(tween._pt, target, plugin.name, 0, 1, plugin.render, plugin, 0, plugin.priority);
				plugin._props.forEach(function(name) {
					ptLookup[name] = pt;
				});
				plugin.priority && (hasPriority = 1);
			}
			if (!harness || harnessVars) for (p in cleanVars) if (_plugins[p] && (plugin = _checkPlugin(p, cleanVars, tween, index, target, fullTargets))) plugin.priority && (hasPriority = 1);
			else ptLookup[p] = pt = _addPropTween.call(tween, target, p, "get", cleanVars[p], index, fullTargets, 0, vars.stringFilter);
			tween._op && tween._op[i] && tween.kill(target, tween._op[i]);
			if (autoOverwrite && tween._pt) {
				_overwritingTween = tween;
				_globalTimeline.killTweensOf(target, ptLookup, tween.globalTime(time));
				overwritten = !tween.parent;
				_overwritingTween = 0;
			}
			tween._pt && lazy && (_lazyLookup[gsData.id] = 1);
		}
		hasPriority && _sortPropTweensByPriority(tween);
		tween._onInit && tween._onInit(tween);
	}
	tween._onUpdate = onUpdate;
	tween._initted = (!tween._op || tween._pt) && !overwritten;
	keyframes && time <= 0 && tl.render(_bigNum$1, true, true);
};
var _updatePropTweens = function _updatePropTweens(tween, property, value, start, startIsRelative, ratio, time, skipRecursion) {
	var ptCache = (tween._pt && tween._ptCache || (tween._ptCache = {}))[property], pt, rootPT, lookup, i;
	if (!ptCache) {
		ptCache = tween._ptCache[property] = [];
		lookup = tween._ptLookup;
		i = tween._targets.length;
		while (i--) {
			pt = lookup[i][property];
			if (pt && pt.d && pt.d._pt) {
				pt = pt.d._pt;
				while (pt && pt.p !== property && pt.fp !== property) pt = pt._next;
			}
			if (!pt) {
				_forceAllPropTweens = 1;
				tween.vars[property] = "+=0";
				_initTween(tween, time);
				_forceAllPropTweens = 0;
				return skipRecursion ? _warn(property + " not eligible for reset. Try splitting into individual properties") : 1;
			}
			ptCache.push(pt);
		}
	}
	i = ptCache.length;
	while (i--) {
		rootPT = ptCache[i];
		pt = rootPT._pt || rootPT;
		pt.s = (start || start === 0) && !startIsRelative ? start : pt.s + (start || 0) + ratio * pt.c;
		pt.c = value - pt.s;
		rootPT.e && (rootPT.e = _round(value) + getUnit(rootPT.e));
		rootPT.b && (rootPT.b = pt.s + getUnit(rootPT.b));
	}
};
var _addAliasesToVars = function _addAliasesToVars(targets, vars) {
	var harness = targets[0] ? _getCache(targets[0]).harness : 0, propertyAliases = harness && harness.aliases, copy, p, i, aliases;
	if (!propertyAliases) return vars;
	copy = _merge({}, vars);
	for (p in propertyAliases) if (p in copy) {
		aliases = propertyAliases[p].split(",");
		i = aliases.length;
		while (i--) copy[aliases[i]] = copy[p];
	}
	return copy;
};
var _parseKeyframe = function _parseKeyframe(prop, obj, allProps, easeEach) {
	var ease = obj.ease || easeEach || "power1.inOut", p, a;
	if (_isArray(obj)) {
		a = allProps[prop] || (allProps[prop] = []);
		obj.forEach(function(value, i) {
			return a.push({
				t: i / (obj.length - 1) * 100,
				v: value,
				e: ease
			});
		});
	} else for (p in obj) {
		a = allProps[p] || (allProps[p] = []);
		p === "ease" || a.push({
			t: parseFloat(prop),
			v: obj[p],
			e: ease
		});
	}
};
var _parseFuncOrString = function _parseFuncOrString(value, tween, i, target, targets) {
	return _isFunction(value) ? value.call(tween, i, target, targets) : _isString(value) && ~value.indexOf("random(") ? _replaceRandom(value) : value;
};
var _staggerTweenProps = _callbackNames + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,easeReverse,autoRevert";
var _staggerPropsToSkip = {};
_forEachName(_staggerTweenProps + ",id,stagger,delay,duration,paused,scrollTrigger", function(name) {
	return _staggerPropsToSkip[name] = 1;
});
var Tween = /*#__PURE__*/ function(_Animation2) {
	_inheritsLoose(Tween, _Animation2);
	function Tween(targets, vars, position, skipInherit) {
		var _this3;
		if (typeof vars === "number") {
			position.duration = vars;
			vars = position;
			position = null;
		}
		_this3 = _Animation2.call(this, skipInherit ? vars : _inheritDefaults(vars)) || this;
		var _this3$vars = _this3.vars, duration = _this3$vars.duration, delay = _this3$vars.delay, immediateRender = _this3$vars.immediateRender, stagger = _this3$vars.stagger, overwrite = _this3$vars.overwrite, keyframes = _this3$vars.keyframes, defaults = _this3$vars.defaults, scrollTrigger = _this3$vars.scrollTrigger, parent = vars.parent || _globalTimeline, parsedTargets = (_isArray(targets) || _isTypedArray(targets) ? _isNumber(targets[0]) : "length" in vars) ? [targets] : toArray(targets), tl, i, copy, l, p, curTarget, staggerFunc, staggerVarsToMerge;
		_this3._targets = parsedTargets.length ? _harness(parsedTargets) : _warn("GSAP target " + targets + " not found. https://gsap.com", !_config.nullTargetWarn) || [];
		_this3._ptLookup = [];
		_this3._overwrite = overwrite;
		if (keyframes || stagger || _isFuncOrString(duration) || _isFuncOrString(delay)) {
			vars = _this3.vars;
			var easeReverse = vars.easeReverse || vars.yoyoEase;
			tl = _this3.timeline = new Timeline({
				data: "nested",
				defaults: defaults || {},
				targets: parent && parent.data === "nested" ? parent.vars.targets : parsedTargets
			});
			tl.kill();
			tl.parent = tl._dp = _assertThisInitialized(_this3);
			tl._start = 0;
			if (stagger || _isFuncOrString(duration) || _isFuncOrString(delay)) {
				l = parsedTargets.length;
				staggerFunc = stagger && distribute(stagger);
				if (_isObject(stagger)) {
					for (p in stagger) if (~_staggerTweenProps.indexOf(p)) {
						staggerVarsToMerge || (staggerVarsToMerge = {});
						staggerVarsToMerge[p] = stagger[p];
					}
				}
				for (i = 0; i < l; i++) {
					copy = _copyExcluding(vars, _staggerPropsToSkip);
					copy.stagger = 0;
					easeReverse && (copy.easeReverse = easeReverse);
					staggerVarsToMerge && _merge(copy, staggerVarsToMerge);
					curTarget = parsedTargets[i];
					copy.duration = +_parseFuncOrString(duration, _assertThisInitialized(_this3), i, curTarget, parsedTargets);
					copy.delay = (+_parseFuncOrString(delay, _assertThisInitialized(_this3), i, curTarget, parsedTargets) || 0) - _this3._delay;
					if (!stagger && l === 1 && copy.delay) {
						_this3._delay = delay = copy.delay;
						_this3._start += delay;
						copy.delay = 0;
					}
					tl.to(curTarget, copy, staggerFunc ? staggerFunc(i, curTarget, parsedTargets) : 0);
					tl._ease = _easeMap.none;
				}
				tl.duration() ? duration = delay = 0 : _this3.timeline = 0;
			} else if (keyframes) {
				_inheritDefaults(_setDefaults(tl.vars.defaults, { ease: "none" }));
				tl._ease = _parseEase(keyframes.ease || vars.ease || "none");
				var time = 0, a, kf, v;
				if (_isArray(keyframes)) {
					keyframes.forEach(function(frame) {
						return tl.to(parsedTargets, frame, ">");
					});
					tl.duration();
				} else {
					copy = {};
					for (p in keyframes) p === "ease" || p === "easeEach" || _parseKeyframe(p, keyframes[p], copy, keyframes.easeEach);
					for (p in copy) {
						a = copy[p].sort(function(a, b) {
							return a.t - b.t;
						});
						time = 0;
						for (i = 0; i < a.length; i++) {
							kf = a[i];
							v = {
								ease: kf.e,
								duration: (kf.t - (i ? a[i - 1].t : 0)) / 100 * duration
							};
							v[p] = kf.v;
							tl.to(parsedTargets, v, time);
							time += v.duration;
						}
					}
					tl.duration() < duration && tl.to({}, { duration: duration - tl.duration() });
				}
			}
			duration || _this3.duration(duration = tl.duration());
		} else _this3.timeline = 0;
		if (overwrite === true && !_suppressOverwrites) {
			_overwritingTween = _assertThisInitialized(_this3);
			_globalTimeline.killTweensOf(parsedTargets);
			_overwritingTween = 0;
		}
		_addToTimeline(parent, _assertThisInitialized(_this3), position);
		vars.reversed && _this3.reverse();
		vars.paused && _this3.paused(true);
		if (immediateRender || !duration && !keyframes && _this3._start === _roundPrecise(parent._time) && _isNotFalse(immediateRender) && _hasNoPausedAncestors(_assertThisInitialized(_this3)) && parent.data !== "nested") {
			_this3._tTime = -_tinyNum;
			_this3.render(Math.max(0, -delay) || 0);
		}
		scrollTrigger && _scrollTrigger(_assertThisInitialized(_this3), scrollTrigger);
		return _this3;
	}
	var _proto3 = Tween.prototype;
	_proto3.render = function render(totalTime, suppressEvents, force) {
		var prevTime = this._time, tDur = this._tDur, dur = this._dur, isNegative = totalTime < 0, tTime = totalTime > tDur - _tinyNum && !isNegative ? tDur : totalTime < _tinyNum ? 0 : totalTime, time, pt, iteration, cycleDuration, prevIteration, isYoyo, ratio, timeline;
		if (!dur) _renderZeroDurationTween(this, totalTime, suppressEvents, force);
		else if (tTime !== this._tTime || !totalTime || force || !this._initted && this._tTime || this._startAt && this._zTime < 0 !== isNegative || this._lazy) {
			time = tTime;
			timeline = this.timeline;
			if (this._repeat) {
				cycleDuration = dur + this._rDelay;
				if (this._repeat < -1 && isNegative) return this.totalTime(cycleDuration * 100 + totalTime, suppressEvents, force);
				time = _roundPrecise(tTime % cycleDuration);
				if (tTime === tDur) {
					iteration = this._repeat;
					time = dur;
				} else {
					prevIteration = _roundPrecise(tTime / cycleDuration);
					iteration = ~~prevIteration;
					if (iteration && iteration === prevIteration) {
						time = dur;
						iteration--;
					} else if (time > dur) time = dur;
				}
				isYoyo = this._yoyo && iteration & 1;
				if (isYoyo) time = dur - time;
				prevIteration = _animationCycle(this._tTime, cycleDuration);
				if (time === prevTime && !force && this._initted && iteration === prevIteration) {
					this._tTime = tTime;
					return this;
				}
				if (iteration !== prevIteration) {
					if (this.vars.repeatRefresh && !isYoyo && !this._lock && time !== cycleDuration && this._initted) {
						this._lock = force = 1;
						this.render(_roundPrecise(cycleDuration * iteration), true).invalidate()._lock = 0;
					}
				}
			}
			if (!this._initted) {
				if (_attemptInitTween(this, isNegative ? totalTime : time, force, suppressEvents, tTime)) {
					this._tTime = 0;
					return this;
				}
				if (prevTime !== this._time && !(force && this.vars.repeatRefresh && iteration !== prevIteration)) return this;
				if (dur !== this._dur) return this.render(totalTime, suppressEvents, force);
			}
			if (this._rEase) {
				var inv = time < prevTime;
				if (inv !== this._inv) {
					var segDur = inv ? prevTime : dur - prevTime;
					this._inv = inv;
					if (this._from) this.ratio = 1 - this.ratio;
					this._invRatio = this.ratio;
					this._invTime = prevTime;
					this._invRecip = segDur ? (inv ? -1 : 1) / segDur : 0;
					this._invScale = inv ? -this.ratio : 1 - this.ratio;
					this._invEase = inv ? this._rEase : this._ease;
				}
				this.ratio = ratio = this._invRatio + this._invScale * this._invEase((time - this._invTime) * this._invRecip);
			} else this.ratio = ratio = this._ease(time / dur);
			if (this._from) this.ratio = ratio = 1 - ratio;
			this._tTime = tTime;
			this._time = time;
			if (!this._act && this._ts) {
				this._act = 1;
				this._lazy = 0;
			}
			if (!prevTime && tTime && !suppressEvents && !prevIteration) {
				_callback(this, "onStart");
				if (this._tTime !== tTime) return this;
			}
			pt = this._pt;
			while (pt) {
				pt.r(ratio, pt.d);
				pt = pt._next;
			}
			timeline && timeline.render(totalTime < 0 ? totalTime : timeline._dur * timeline._ease(time / this._dur), suppressEvents, force) || this._startAt && (this._zTime = totalTime);
			if (this._onUpdate && !suppressEvents) {
				isNegative && _rewindStartAt(this, totalTime, suppressEvents, force);
				_callback(this, "onUpdate");
			}
			this._repeat && iteration !== prevIteration && this.vars.onRepeat && !suppressEvents && this.parent && _callback(this, "onRepeat");
			if ((tTime === this._tDur || !tTime) && this._tTime === tTime) {
				isNegative && !this._onUpdate && _rewindStartAt(this, totalTime, true, true);
				(totalTime || !dur) && (tTime === this._tDur && this._ts > 0 || !tTime && this._ts < 0) && _removeFromParent(this, 1);
				if (!suppressEvents && !(isNegative && !prevTime) && (tTime || prevTime || isYoyo)) {
					_callback(this, tTime === tDur ? "onComplete" : "onReverseComplete", true);
					this._prom && !(tTime < tDur && this.timeScale() > 0) && this._prom();
				}
			}
		}
		return this;
	};
	_proto3.targets = function targets() {
		return this._targets;
	};
	_proto3.invalidate = function invalidate(soft) {
		(!soft || !this.vars.runBackwards) && (this._startAt = 0);
		this._pt = this._op = this._onUpdate = this._lazy = this.ratio = 0;
		this._ptLookup = [];
		this.timeline && this.timeline.invalidate(soft);
		return _Animation2.prototype.invalidate.call(this, soft);
	};
	_proto3.resetTo = function resetTo(property, value, start, startIsRelative, skipRecursion) {
		_tickerActive || _ticker.wake();
		this._ts || this.play();
		var time = Math.min(this._dur, (this._dp._time - this._start) * this._ts), ratio;
		this._initted || _initTween(this, time);
		ratio = this._ease(time / this._dur);
		if (_updatePropTweens(this, property, value, start, startIsRelative, ratio, time, skipRecursion)) return this.resetTo(property, value, start, startIsRelative, 1);
		_alignPlayhead(this, 0);
		this.parent || _addLinkedListItem(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0);
		return this.render(0);
	};
	_proto3.kill = function kill(targets, vars) {
		if (vars === void 0) vars = "all";
		if (!targets && (!vars || vars === "all")) {
			this._lazy = this._pt = 0;
			this.parent ? _interrupt(this) : this.scrollTrigger && this.scrollTrigger.kill(!!_reverting$1);
			return this;
		}
		if (this.timeline) {
			var tDur = this.timeline.totalDuration();
			this.timeline.killTweensOf(targets, vars, _overwritingTween && _overwritingTween.vars.overwrite !== true)._first || _interrupt(this);
			this.parent && tDur !== this.timeline.totalDuration() && _setDuration(this, this._dur * this.timeline._tDur / tDur, 0, 1);
			return this;
		}
		var parsedTargets = this._targets, killingTargets = targets ? toArray(targets) : parsedTargets, propTweenLookup = this._ptLookup, firstPT = this._pt, overwrittenProps, curLookup, curOverwriteProps, props, p, pt, i;
		if ((!vars || vars === "all") && _arraysMatch(parsedTargets, killingTargets)) {
			vars === "all" && (this._pt = 0);
			return _interrupt(this);
		}
		overwrittenProps = this._op = this._op || [];
		if (vars !== "all") {
			if (_isString(vars)) {
				p = {};
				_forEachName(vars, function(name) {
					return p[name] = 1;
				});
				vars = p;
			}
			vars = _addAliasesToVars(parsedTargets, vars);
		}
		i = parsedTargets.length;
		while (i--) if (~killingTargets.indexOf(parsedTargets[i])) {
			curLookup = propTweenLookup[i];
			if (vars === "all") {
				overwrittenProps[i] = vars;
				props = curLookup;
				curOverwriteProps = {};
			} else {
				curOverwriteProps = overwrittenProps[i] = overwrittenProps[i] || {};
				props = vars;
			}
			for (p in props) {
				pt = curLookup && curLookup[p];
				if (pt) {
					if (!("kill" in pt.d) || pt.d.kill(p) === true) _removeLinkedListItem(this, pt, "_pt");
					delete curLookup[p];
				}
				if (curOverwriteProps !== "all") curOverwriteProps[p] = 1;
			}
		}
		this._initted && !this._pt && firstPT && _interrupt(this);
		return this;
	};
	Tween.to = function to(targets, vars) {
		return new Tween(targets, vars, arguments[2]);
	};
	Tween.from = function from(targets, vars) {
		return _createTweenType(1, arguments);
	};
	Tween.delayedCall = function delayedCall(delay, callback, params, scope) {
		return new Tween(callback, 0, {
			immediateRender: false,
			lazy: false,
			overwrite: false,
			delay,
			onComplete: callback,
			onReverseComplete: callback,
			onCompleteParams: params,
			onReverseCompleteParams: params,
			callbackScope: scope
		});
	};
	Tween.fromTo = function fromTo(targets, fromVars, toVars) {
		return _createTweenType(2, arguments);
	};
	Tween.set = function set(targets, vars) {
		vars.duration = 0;
		vars.repeatDelay || (vars.repeat = 0);
		return new Tween(targets, vars);
	};
	Tween.killTweensOf = function killTweensOf(targets, props, onlyActive) {
		return _globalTimeline.killTweensOf(targets, props, onlyActive);
	};
	return Tween;
}(Animation);
_setDefaults(Tween.prototype, {
	_targets: [],
	_lazy: 0,
	_startAt: 0,
	_op: 0,
	_onInit: 0
});
_forEachName("staggerTo,staggerFrom,staggerFromTo", function(name) {
	Tween[name] = function() {
		var tl = new Timeline(), params = _slice.call(arguments, 0);
		params.splice(name === "staggerFromTo" ? 5 : 4, 0, 0);
		return tl[name].apply(tl, params);
	};
});
var _setterPlain = function _setterPlain(target, property, value) {
	return target[property] = value;
};
var _setterFunc = function _setterFunc(target, property, value) {
	return target[property](value);
};
var _setterFuncWithParam = function _setterFuncWithParam(target, property, value, data) {
	return target[property](data.fp, value);
};
var _setterAttribute = function _setterAttribute(target, property, value) {
	return target.setAttribute(property, value);
};
var _getSetter = function _getSetter(target, property) {
	return _isFunction(target[property]) ? _setterFunc : _isUndefined(target[property]) && target.setAttribute ? _setterAttribute : _setterPlain;
};
var _renderPlain = function _renderPlain(ratio, data) {
	return data.set(data.t, data.p, Math.round((data.s + data.c * ratio) * 1e6) / 1e6, data);
};
var _renderBoolean = function _renderBoolean(ratio, data) {
	return data.set(data.t, data.p, !!(data.s + data.c * ratio), data);
};
var _renderComplexString = function _renderComplexString(ratio, data) {
	var pt = data._pt, s = "";
	if (!ratio && data.b) s = data.b;
	else if (ratio === 1 && data.e) s = data.e;
	else {
		while (pt) {
			s = pt.p + (pt.m ? pt.m(pt.s + pt.c * ratio) : Math.round((pt.s + pt.c * ratio) * 1e4) / 1e4) + s;
			pt = pt._next;
		}
		s += data.c;
	}
	data.set(data.t, data.p, s, data);
};
var _renderPropTweens = function _renderPropTweens(ratio, data) {
	var pt = data._pt;
	while (pt) {
		pt.r(ratio, pt.d);
		pt = pt._next;
	}
};
var _addPluginModifier = function _addPluginModifier(modifier, tween, target, property) {
	var pt = this._pt, next;
	while (pt) {
		next = pt._next;
		pt.p === property && pt.modifier(modifier, tween, target);
		pt = next;
	}
};
var _killPropTweensOf = function _killPropTweensOf(property) {
	var pt = this._pt, hasNonDependentRemaining, next;
	while (pt) {
		next = pt._next;
		if (pt.p === property && !pt.op || pt.op === property) _removeLinkedListItem(this, pt, "_pt");
		else if (!pt.dep) hasNonDependentRemaining = 1;
		pt = next;
	}
	return !hasNonDependentRemaining;
};
var _setterWithModifier = function _setterWithModifier(target, property, value, data) {
	data.mSet(target, property, data.m.call(data.tween, value, data.mt), data);
};
var _sortPropTweensByPriority = function _sortPropTweensByPriority(parent) {
	var pt = parent._pt, next, pt2, first, last;
	while (pt) {
		next = pt._next;
		pt2 = first;
		while (pt2 && pt2.pr > pt.pr) pt2 = pt2._next;
		if (pt._prev = pt2 ? pt2._prev : last) pt._prev._next = pt;
		else first = pt;
		if (pt._next = pt2) pt2._prev = pt;
		else last = pt;
		pt = next;
	}
	parent._pt = first;
};
var PropTween = /*#__PURE__*/ function() {
	function PropTween(next, target, prop, start, change, renderer, data, setter, priority) {
		this.t = target;
		this.s = start;
		this.c = change;
		this.p = prop;
		this.r = renderer || _renderPlain;
		this.d = data || this;
		this.set = setter || _setterPlain;
		this.pr = priority || 0;
		this._next = next;
		if (next) next._prev = this;
	}
	var _proto4 = PropTween.prototype;
	_proto4.modifier = function modifier(func, tween, target) {
		this.mSet = this.mSet || this.set;
		this.set = _setterWithModifier;
		this.m = func;
		this.mt = target;
		this.tween = tween;
	};
	return PropTween;
}();
_forEachName(_callbackNames + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger,easeReverse", function(name) {
	return _reservedProps[name] = 1;
});
_globals.TweenMax = _globals.TweenLite = Tween;
_globals.TimelineLite = _globals.TimelineMax = Timeline;
_globalTimeline = new Timeline({
	sortChildren: false,
	defaults: _defaults,
	autoRemoveChildren: true,
	id: "root",
	smoothChildTiming: true
});
_config.stringFilter = _colorStringFilter;
var _media = [];
var _listeners = {};
var _emptyArray = [];
var _lastMediaTime = 0;
var _contextID = 0;
var _dispatch = function _dispatch(type) {
	return (_listeners[type] || _emptyArray).map(function(f) {
		return f();
	});
};
var _onMediaChange = function _onMediaChange() {
	var time = Date.now(), matches = [];
	if (time - _lastMediaTime > 2) {
		_dispatch("matchMediaInit");
		_media.forEach(function(c) {
			var queries = c.queries, conditions = c.conditions, match, p, anyMatch, toggled;
			for (p in queries) {
				match = _win$1.matchMedia(queries[p]).matches;
				match && (anyMatch = 1);
				if (match !== conditions[p]) {
					conditions[p] = match;
					toggled = 1;
				}
			}
			if (toggled) {
				c.revert();
				anyMatch && matches.push(c);
			}
		});
		_dispatch("matchMediaRevert");
		matches.forEach(function(c) {
			return c.onMatch(c, function(func) {
				return c.add(null, func);
			});
		});
		_lastMediaTime = time;
		_dispatch("matchMedia");
	}
};
var Context = /*#__PURE__*/ function() {
	function Context(func, scope) {
		this.selector = scope && selector(scope);
		this.data = [];
		this._r = [];
		this.isReverted = false;
		this.id = _contextID++;
		func && this.add(func);
	}
	var _proto5 = Context.prototype;
	_proto5.add = function add(name, func, scope) {
		if (_isFunction(name)) {
			scope = func;
			func = name;
			name = _isFunction;
		}
		var self = this, f = function f() {
			var prev = _context, prevSelector = self.selector, result;
			prev && prev !== self && prev.data.push(self);
			scope && (self.selector = selector(scope));
			_context = self;
			result = func.apply(self, arguments);
			_isFunction(result) && self._r.push(result);
			_context = prev;
			self.selector = prevSelector;
			self.isReverted = false;
			return result;
		};
		self.last = f;
		return name === _isFunction ? f(self, function(func) {
			return self.add(null, func);
		}) : name ? self[name] = f : f;
	};
	_proto5.ignore = function ignore(func) {
		var prev = _context;
		_context = null;
		func(this);
		_context = prev;
	};
	_proto5.getTweens = function getTweens() {
		var a = [];
		this.data.forEach(function(e) {
			return e instanceof Context ? a.push.apply(a, e.getTweens()) : e instanceof Tween && !(e.parent && e.parent.data === "nested") && a.push(e);
		});
		return a;
	};
	_proto5.clear = function clear() {
		this._r.length = this.data.length = 0;
	};
	_proto5.kill = function kill(revert, matchMedia) {
		var _this4 = this;
		if (revert) (function() {
			var tweens = _this4.getTweens(), i = _this4.data.length, t;
			while (i--) {
				t = _this4.data[i];
				if (t.data === "isFlip") {
					t.revert();
					t.getChildren(true, true, false).forEach(function(tween) {
						return tweens.splice(tweens.indexOf(tween), 1);
					});
				}
			}
			tweens.map(function(t) {
				return {
					g: t._dur || t._delay || t._sat && !t._sat.vars.immediateRender ? t.globalTime(0) : -Infinity,
					t
				};
			}).sort(function(a, b) {
				return b.g - a.g || -Infinity;
			}).forEach(function(o) {
				return o.t.revert(revert);
			});
			i = _this4.data.length;
			while (i--) {
				t = _this4.data[i];
				if (t instanceof Timeline) {
					if (t.data !== "nested") {
						t.scrollTrigger && t.scrollTrigger.revert();
						t.kill();
					}
				} else !(t instanceof Tween) && t.revert && t.revert(revert);
			}
			_this4._r.forEach(function(f) {
				return f(revert, _this4);
			});
			_this4.isReverted = true;
		})();
		else this.data.forEach(function(e) {
			return e.kill && e.kill();
		});
		this.clear();
		if (matchMedia) {
			var i = _media.length;
			while (i--) _media[i].id === this.id && _media.splice(i, 1);
		}
	};
	_proto5.revert = function revert(config) {
		this.kill(config || {});
	};
	return Context;
}();
var MatchMedia = /*#__PURE__*/ function() {
	function MatchMedia(scope) {
		this.contexts = [];
		this.scope = scope;
		_context && _context.data.push(this);
	}
	var _proto6 = MatchMedia.prototype;
	_proto6.add = function add(conditions, func, scope) {
		_isObject(conditions) || (conditions = { matches: conditions });
		var context = new Context(0, scope || this.scope), cond = context.conditions = {}, mq, p, active;
		_context && !context.selector && (context.selector = _context.selector);
		this.contexts.push(context);
		func = context.add("onMatch", func);
		context.queries = conditions;
		for (p in conditions) if (p === "all") active = 1;
		else {
			mq = _win$1.matchMedia(conditions[p]);
			if (mq) {
				_media.indexOf(context) < 0 && _media.push(context);
				(cond[p] = mq.matches) && (active = 1);
				mq.addListener ? mq.addListener(_onMediaChange) : mq.addEventListener("change", _onMediaChange);
			}
		}
		active && func(context, function(f) {
			return context.add(null, f);
		});
		return this;
	};
	_proto6.revert = function revert(config) {
		this.kill(config || {});
	};
	_proto6.kill = function kill(revert) {
		this.contexts.forEach(function(c) {
			return c.kill(revert, true);
		});
	};
	return MatchMedia;
}();
var _gsap = {
	registerPlugin: function registerPlugin() {
		for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) args[_key2] = arguments[_key2];
		args.forEach(function(config) {
			return _createPlugin(config);
		});
	},
	timeline: function timeline(vars) {
		return new Timeline(vars);
	},
	getTweensOf: function getTweensOf(targets, onlyActive) {
		return _globalTimeline.getTweensOf(targets, onlyActive);
	},
	getProperty: function getProperty(target, property, unit, uncache) {
		_isString(target) && (target = toArray(target)[0]);
		var getter = _getCache(target || {}).get, format = unit ? _passThrough : _numericIfPossible;
		unit === "native" && (unit = "");
		return !target ? target : !property ? function(property, unit, uncache) {
			return format((_plugins[property] && _plugins[property].get || getter)(target, property, unit, uncache));
		} : format((_plugins[property] && _plugins[property].get || getter)(target, property, unit, uncache));
	},
	quickSetter: function quickSetter(target, property, unit) {
		target = toArray(target);
		if (target.length > 1) {
			var setters = target.map(function(t) {
				return gsap.quickSetter(t, property, unit);
			}), l = setters.length;
			return function(value) {
				var i = l;
				while (i--) setters[i](value);
			};
		}
		target = target[0] || {};
		var Plugin = _plugins[property], cache = _getCache(target), p = cache.harness && (cache.harness.aliases || {})[property] || property, setter = Plugin ? function(value) {
			var p = new Plugin();
			_quickTween._pt = 0;
			p.init(target, unit ? value + unit : value, _quickTween, 0, [target]);
			p.render(1, p);
			_quickTween._pt && _renderPropTweens(1, _quickTween);
		} : cache.set(target, p);
		return Plugin ? setter : function(value) {
			return setter(target, p, unit ? value + unit : value, cache, 1);
		};
	},
	quickTo: function quickTo(target, property, vars) {
		var _setDefaults2;
		var tween = gsap.to(target, _setDefaults((_setDefaults2 = {}, _setDefaults2[property] = "+=0.1", _setDefaults2.paused = true, _setDefaults2.stagger = 0, _setDefaults2), vars || {})), func = function func(value, start, startIsRelative) {
			return tween.resetTo(property, value, start, startIsRelative);
		};
		func.tween = tween;
		return func;
	},
	isTweening: function isTweening(targets) {
		return _globalTimeline.getTweensOf(targets, true).length > 0;
	},
	defaults: function defaults(value) {
		value && value.ease && (value.ease = _parseEase(value.ease, _defaults.ease));
		return _mergeDeep(_defaults, value || {});
	},
	config: function config(value) {
		return _mergeDeep(_config, value || {});
	},
	registerEffect: function registerEffect(_ref3) {
		var name = _ref3.name, effect = _ref3.effect, plugins = _ref3.plugins, defaults = _ref3.defaults, extendTimeline = _ref3.extendTimeline;
		(plugins || "").split(",").forEach(function(pluginName) {
			return pluginName && !_plugins[pluginName] && !_globals[pluginName] && _warn(name + " effect requires " + pluginName + " plugin.");
		});
		_effects[name] = function(targets, vars, tl) {
			return effect(toArray(targets), _setDefaults(vars || {}, defaults), tl);
		};
		if (extendTimeline) Timeline.prototype[name] = function(targets, vars, position) {
			return this.add(_effects[name](targets, _isObject(vars) ? vars : (position = vars) && {}, this), position);
		};
	},
	registerEase: function registerEase(name, ease) {
		_easeMap[name] = _parseEase(ease);
	},
	parseEase: function parseEase(ease, defaultEase) {
		return arguments.length ? _parseEase(ease, defaultEase) : _easeMap;
	},
	getById: function getById(id) {
		return _globalTimeline.getById(id);
	},
	exportRoot: function exportRoot(vars, includeDelayedCalls) {
		if (vars === void 0) vars = {};
		var tl = new Timeline(vars), child, next;
		tl.smoothChildTiming = _isNotFalse(vars.smoothChildTiming);
		_globalTimeline.remove(tl);
		tl._dp = 0;
		tl._time = tl._tTime = _globalTimeline._time;
		child = _globalTimeline._first;
		while (child) {
			next = child._next;
			if (includeDelayedCalls || !(!child._dur && child instanceof Tween && child.vars.onComplete === child._targets[0])) _addToTimeline(tl, child, child._start - child._delay);
			child = next;
		}
		_addToTimeline(_globalTimeline, tl, 0);
		return tl;
	},
	context: function context(func, scope) {
		return func ? new Context(func, scope) : _context;
	},
	matchMedia: function matchMedia(scope) {
		return new MatchMedia(scope);
	},
	matchMediaRefresh: function matchMediaRefresh() {
		return _media.forEach(function(c) {
			var cond = c.conditions, found, p;
			for (p in cond) if (cond[p]) {
				cond[p] = false;
				found = 1;
			}
			found && c.revert();
		}) || _onMediaChange();
	},
	addEventListener: function addEventListener(type, callback) {
		var a = _listeners[type] || (_listeners[type] = []);
		~a.indexOf(callback) || a.push(callback);
	},
	removeEventListener: function removeEventListener(type, callback) {
		var a = _listeners[type], i = a && a.indexOf(callback);
		i >= 0 && a.splice(i, 1);
	},
	utils: {
		wrap,
		wrapYoyo,
		distribute,
		random,
		snap,
		normalize,
		getUnit,
		clamp,
		splitColor,
		toArray,
		selector,
		mapRange,
		pipe,
		unitize,
		interpolate: interpolate$1,
		shuffle
	},
	install: _install,
	effects: _effects,
	ticker: _ticker,
	updateRoot: Timeline.updateRoot,
	plugins: _plugins,
	globalTimeline: _globalTimeline,
	core: {
		PropTween,
		globals: _addGlobal,
		Tween,
		Timeline,
		Animation,
		getCache: _getCache,
		_removeLinkedListItem,
		reverting: function reverting() {
			return _reverting$1;
		},
		context: function context(toAdd) {
			if (toAdd && _context) {
				_context.data.push(toAdd);
				toAdd._ctx = _context;
			}
			return _context;
		},
		suppressOverwrites: function suppressOverwrites(value) {
			return _suppressOverwrites = value;
		}
	}
};
_forEachName("to,from,fromTo,delayedCall,set,killTweensOf", function(name) {
	return _gsap[name] = Tween[name];
});
_ticker.add(Timeline.updateRoot);
_quickTween = _gsap.to({}, { duration: 0 });
var _getPluginPropTween = function _getPluginPropTween(plugin, prop) {
	var pt = plugin._pt;
	while (pt && pt.p !== prop && pt.op !== prop && pt.fp !== prop) pt = pt._next;
	return pt;
};
var _addModifiers = function _addModifiers(tween, modifiers) {
	var targets = tween._targets, p, i, pt;
	for (p in modifiers) {
		i = targets.length;
		while (i--) {
			pt = tween._ptLookup[i][p];
			if (pt && (pt = pt.d)) {
				if (pt._pt) pt = _getPluginPropTween(pt, p);
				pt && pt.modifier && pt.modifier(modifiers[p], tween, targets[i], p);
			}
		}
	}
};
var _buildModifierPlugin = function _buildModifierPlugin(name, modifier) {
	return {
		name,
		headless: 1,
		rawVars: 1,
		init: function init(target, vars, tween) {
			tween._onInit = function(tween) {
				var temp, p;
				if (_isString(vars)) {
					temp = {};
					_forEachName(vars, function(name) {
						return temp[name] = 1;
					});
					vars = temp;
				}
				if (modifier) {
					temp = {};
					for (p in vars) temp[p] = modifier(vars[p]);
					vars = temp;
				}
				_addModifiers(tween, vars);
			};
		}
	};
};
var gsap = _gsap.registerPlugin({
	name: "attr",
	init: function init(target, vars, tween, index, targets) {
		var p, pt, v;
		this.tween = tween;
		for (p in vars) {
			v = target.getAttribute(p) || "";
			pt = this.add(target, "setAttribute", (v || 0) + "", vars[p], index, targets, 0, 0, p);
			pt.op = p;
			pt.b = v;
			this._props.push(p);
		}
	},
	render: function render(ratio, data) {
		var pt = data._pt;
		while (pt) {
			_reverting$1 ? pt.set(pt.t, pt.p, pt.b, pt) : pt.r(ratio, pt.d);
			pt = pt._next;
		}
	}
}, {
	name: "endArray",
	headless: 1,
	init: function init(target, value) {
		var i = value.length;
		while (i--) this.add(target, i, target[i] || 0, value[i], 0, 0, 0, 0, 0, 1);
	}
}, _buildModifierPlugin("roundProps", _roundModifier), _buildModifierPlugin("modifiers"), _buildModifierPlugin("snap", snap)) || _gsap;
Tween.version = Timeline.version = gsap.version = "3.15.0";
_coreReady = 1;
_windowExists$1() && _wake();
_easeMap.Power0;
_easeMap.Power1;
_easeMap.Power2;
_easeMap.Power3;
_easeMap.Power4;
_easeMap.Linear;
_easeMap.Quad;
_easeMap.Cubic;
_easeMap.Quart;
_easeMap.Quint;
_easeMap.Strong;
_easeMap.Elastic;
_easeMap.Back;
_easeMap.SteppedEase;
_easeMap.Bounce;
_easeMap.Sine;
_easeMap.Expo;
_easeMap.Circ;
//#endregion
//#region ../../node_modules/gsap/CSSPlugin.js
/*!
* CSSPlugin 3.15.0
* https://gsap.com
*
* Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var _win;
var _doc;
var _docElement;
var _pluginInitted;
var _tempDiv;
var _recentSetterPlugin;
var _reverting;
var _windowExists = function _windowExists() {
	return typeof window !== "undefined";
};
var _transformProps = {};
var _RAD2DEG = 180 / Math.PI;
var _DEG2RAD = Math.PI / 180;
var _atan2 = Math.atan2;
var _bigNum = 1e8;
var _capsExp = /([A-Z])/g;
var _horizontalExp = /(left|right|width|margin|padding|x)/i;
var _complexExp = /[\s,\(]\S/;
var _propertyAliases = {
	autoAlpha: "opacity,visibility",
	scale: "scaleX,scaleY",
	alpha: "opacity"
};
var _renderCSSProp = function _renderCSSProp(ratio, data) {
	return data.set(data.t, data.p, Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u, data);
};
var _renderPropWithEnd = function _renderPropWithEnd(ratio, data) {
	return data.set(data.t, data.p, ratio === 1 ? data.e : Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u, data);
};
var _renderCSSPropWithBeginning = function _renderCSSPropWithBeginning(ratio, data) {
	return data.set(data.t, data.p, ratio ? Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u : data.b, data);
};
var _renderCSSPropWithBeginningAndEnd = function _renderCSSPropWithBeginningAndEnd(ratio, data) {
	return data.set(data.t, data.p, ratio === 1 ? data.e : ratio ? Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u : data.b, data);
};
var _renderRoundedCSSProp = function _renderRoundedCSSProp(ratio, data) {
	var value = data.s + data.c * ratio;
	data.set(data.t, data.p, ~~(value + (value < 0 ? -.5 : .5)) + data.u, data);
};
var _renderNonTweeningValue = function _renderNonTweeningValue(ratio, data) {
	return data.set(data.t, data.p, ratio ? data.e : data.b, data);
};
var _renderNonTweeningValueOnlyAtEnd = function _renderNonTweeningValueOnlyAtEnd(ratio, data) {
	return data.set(data.t, data.p, ratio !== 1 ? data.b : data.e, data);
};
var _setterCSSStyle = function _setterCSSStyle(target, property, value) {
	return target.style[property] = value;
};
var _setterCSSProp = function _setterCSSProp(target, property, value) {
	return target.style.setProperty(property, value);
};
var _setterTransform = function _setterTransform(target, property, value) {
	return target._gsap[property] = value;
};
var _setterScale = function _setterScale(target, property, value) {
	return target._gsap.scaleX = target._gsap.scaleY = value;
};
var _setterScaleWithRender = function _setterScaleWithRender(target, property, value, data, ratio) {
	var cache = target._gsap;
	cache.scaleX = cache.scaleY = value;
	cache.renderTransform(ratio, cache);
};
var _setterTransformWithRender = function _setterTransformWithRender(target, property, value, data, ratio) {
	var cache = target._gsap;
	cache[property] = value;
	cache.renderTransform(ratio, cache);
};
var _transformProp = "transform";
var _transformOriginProp = _transformProp + "Origin";
var _saveStyle = function _saveStyle(property, isNotCSS) {
	var _this = this;
	var target = this.target, style = target.style, cache = target._gsap;
	if (property in _transformProps && style) {
		this.tfm = this.tfm || {};
		if (property !== "transform") {
			property = _propertyAliases[property] || property;
			~property.indexOf(",") ? property.split(",").forEach(function(a) {
				return _this.tfm[a] = _get(target, a);
			}) : this.tfm[property] = cache.x ? cache[property] : _get(target, property);
			property === _transformOriginProp && (this.tfm.zOrigin = cache.zOrigin);
		} else return _propertyAliases.transform.split(",").forEach(function(p) {
			return _saveStyle.call(_this, p, isNotCSS);
		});
		if (this.props.indexOf(_transformProp) >= 0) return;
		if (cache.svg) {
			this.svgo = target.getAttribute("data-svg-origin");
			this.props.push(_transformOriginProp, isNotCSS, "");
		}
		property = _transformProp;
	}
	(style || isNotCSS) && this.props.push(property, isNotCSS, style[property]);
};
var _removeIndependentTransforms = function _removeIndependentTransforms(style) {
	if (style.translate) {
		style.removeProperty("translate");
		style.removeProperty("scale");
		style.removeProperty("rotate");
	}
};
var _revertStyle = function _revertStyle() {
	var props = this.props, target = this.target, style = target.style, cache = target._gsap, i, p;
	for (i = 0; i < props.length; i += 3) if (!props[i + 1]) props[i + 2] ? style[props[i]] = props[i + 2] : style.removeProperty(props[i].substr(0, 2) === "--" ? props[i] : props[i].replace(_capsExp, "-$1").toLowerCase());
	else if (props[i + 1] === 2) target[props[i]](props[i + 2]);
	else target[props[i]] = props[i + 2];
	if (this.tfm) {
		for (p in this.tfm) cache[p] = this.tfm[p];
		if (cache.svg) {
			cache.renderTransform();
			target.setAttribute("data-svg-origin", this.svgo || "");
		}
		i = _reverting();
		if ((!i || !i.isStart) && !style[_transformProp]) {
			_removeIndependentTransforms(style);
			if (cache.zOrigin && style[_transformOriginProp]) {
				style[_transformOriginProp] += " " + cache.zOrigin + "px";
				cache.zOrigin = 0;
				cache.renderTransform();
			}
			cache.uncache = 1;
		}
	}
};
var _getStyleSaver = function _getStyleSaver(target, properties) {
	var saver = {
		target,
		props: [],
		revert: _revertStyle,
		save: _saveStyle
	};
	target._gsap || gsap.core.getCache(target);
	properties && target.style && target.nodeType && properties.split(",").forEach(function(p) {
		return saver.save(p);
	});
	return saver;
};
var _supports3D;
var _createElement = function _createElement(type, ns) {
	var e = _doc.createElementNS ? _doc.createElementNS((ns || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), type) : _doc.createElement(type);
	return e && e.style ? e : _doc.createElement(type);
};
var _getComputedProperty = function _getComputedProperty(target, property, skipPrefixFallback) {
	var cs = getComputedStyle(target);
	return cs[property] || cs.getPropertyValue(property.replace(_capsExp, "-$1").toLowerCase()) || cs.getPropertyValue(property) || !skipPrefixFallback && _getComputedProperty(target, _checkPropPrefix(property) || property, 1) || "";
};
var _prefixes = "O,Moz,ms,Ms,Webkit".split(",");
var _checkPropPrefix = function _checkPropPrefix(property, element, preferPrefix) {
	var s = (element || _tempDiv).style, i = 5;
	if (property in s && !preferPrefix) return property;
	property = property.charAt(0).toUpperCase() + property.substr(1);
	while (i-- && !(_prefixes[i] + property in s));
	return i < 0 ? null : (i === 3 ? "ms" : i >= 0 ? _prefixes[i] : "") + property;
};
var _initCore = function _initCore() {
	if (_windowExists() && window.document) {
		_win = window;
		_doc = _win.document;
		_docElement = _doc.documentElement;
		_tempDiv = _createElement("div") || { style: {} };
		_createElement("div");
		_transformProp = _checkPropPrefix(_transformProp);
		_transformOriginProp = _transformProp + "Origin";
		_tempDiv.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0";
		_supports3D = !!_checkPropPrefix("perspective");
		_reverting = gsap.core.reverting;
		_pluginInitted = 1;
	}
};
var _getReparentedCloneBBox = function _getReparentedCloneBBox(target) {
	var owner = target.ownerSVGElement, svg = _createElement("svg", owner && owner.getAttribute("xmlns") || "http://www.w3.org/2000/svg"), clone = target.cloneNode(true), bbox;
	clone.style.display = "block";
	svg.appendChild(clone);
	_docElement.appendChild(svg);
	try {
		bbox = clone.getBBox();
	} catch (e) {}
	svg.removeChild(clone);
	_docElement.removeChild(svg);
	return bbox;
};
var _getAttributeFallbacks = function _getAttributeFallbacks(target, attributesArray) {
	var i = attributesArray.length;
	while (i--) if (target.hasAttribute(attributesArray[i])) return target.getAttribute(attributesArray[i]);
};
var _getBBox = function _getBBox(target) {
	var bounds, cloned;
	try {
		bounds = target.getBBox();
	} catch (error) {
		bounds = _getReparentedCloneBBox(target);
		cloned = 1;
	}
	bounds && (bounds.width || bounds.height) || cloned || (bounds = _getReparentedCloneBBox(target));
	return bounds && !bounds.width && !bounds.x && !bounds.y ? {
		x: +_getAttributeFallbacks(target, [
			"x",
			"cx",
			"x1"
		]) || 0,
		y: +_getAttributeFallbacks(target, [
			"y",
			"cy",
			"y1"
		]) || 0,
		width: 0,
		height: 0
	} : bounds;
};
var _isSVG = function _isSVG(e) {
	return !!(e.getCTM && (!e.parentNode || e.ownerSVGElement) && _getBBox(e));
};
var _removeProperty = function _removeProperty(target, property) {
	if (property) {
		var style = target.style, first2Chars;
		if (property in _transformProps && property !== _transformOriginProp) property = _transformProp;
		if (style.removeProperty) {
			first2Chars = property.substr(0, 2);
			if (first2Chars === "ms" || property.substr(0, 6) === "webkit") property = "-" + property;
			style.removeProperty(first2Chars === "--" ? property : property.replace(_capsExp, "-$1").toLowerCase());
		} else style.removeAttribute(property);
	}
};
var _addNonTweeningPT = function _addNonTweeningPT(plugin, target, property, beginning, end, onlySetAtEnd) {
	var pt = new PropTween(plugin._pt, target, property, 0, 1, onlySetAtEnd ? _renderNonTweeningValueOnlyAtEnd : _renderNonTweeningValue);
	plugin._pt = pt;
	pt.b = beginning;
	pt.e = end;
	plugin._props.push(property);
	return pt;
};
var _nonConvertibleUnits = {
	deg: 1,
	rad: 1,
	turn: 1
};
var _nonStandardLayouts = {
	grid: 1,
	flex: 1
};
var _convertToUnit = function _convertToUnit(target, property, value, unit) {
	var curValue = parseFloat(value) || 0, curUnit = (value + "").trim().substr((curValue + "").length) || "px", style = _tempDiv.style, horizontal = _horizontalExp.test(property), isRootSVG = target.tagName.toLowerCase() === "svg", measureProperty = (isRootSVG ? "client" : "offset") + (horizontal ? "Width" : "Height"), amount = 100, toPixels = unit === "px", toPercent = unit === "%", px, parent, cache, isSVG;
	if (unit === curUnit || !curValue || _nonConvertibleUnits[unit] || _nonConvertibleUnits[curUnit]) return curValue;
	curUnit !== "px" && !toPixels && (curValue = _convertToUnit(target, property, value, "px"));
	isSVG = target.getCTM && _isSVG(target);
	if ((toPercent || curUnit === "%") && (_transformProps[property] || ~property.indexOf("adius"))) {
		px = isSVG ? target.getBBox()[horizontal ? "width" : "height"] : target[measureProperty];
		return _round(toPercent ? curValue / px * amount : curValue / 100 * px);
	}
	style[horizontal ? "width" : "height"] = amount + (toPixels ? curUnit : unit);
	parent = unit !== "rem" && ~property.indexOf("adius") || unit === "em" && target.appendChild && !isRootSVG ? target : target.parentNode;
	if (isSVG) parent = (target.ownerSVGElement || {}).parentNode;
	if (!parent || parent === _doc || !parent.appendChild) parent = _doc.body;
	cache = parent._gsap;
	if (cache && toPercent && cache.width && horizontal && cache.time === _ticker.time && !cache.uncache) return _round(curValue / cache.width * amount);
	else {
		if (toPercent && (property === "height" || property === "width")) {
			var v = target.style[property];
			target.style[property] = amount + unit;
			px = target[measureProperty];
			v ? target.style[property] = v : _removeProperty(target, property);
		} else {
			(toPercent || curUnit === "%") && !_nonStandardLayouts[_getComputedProperty(parent, "display")] && (style.position = _getComputedProperty(target, "position"));
			parent === target && (style.position = "static");
			parent.appendChild(_tempDiv);
			px = _tempDiv[measureProperty];
			parent.removeChild(_tempDiv);
			style.position = "absolute";
		}
		if (horizontal && toPercent) {
			cache = _getCache(parent);
			cache.time = _ticker.time;
			cache.width = parent[measureProperty];
		}
	}
	return _round(toPixels ? px * curValue / amount : px && curValue ? amount / px * curValue : 0);
};
var _get = function _get(target, property, unit, uncache) {
	var value;
	_pluginInitted || _initCore();
	if (property in _propertyAliases && property !== "transform") {
		property = _propertyAliases[property];
		if (~property.indexOf(",")) property = property.split(",")[0];
	}
	if (_transformProps[property] && property !== "transform") {
		value = _parseTransform(target, uncache);
		value = property !== "transformOrigin" ? value[property] : value.svg ? value.origin : _firstTwoOnly(_getComputedProperty(target, _transformOriginProp)) + " " + value.zOrigin + "px";
	} else {
		value = target.style[property];
		if (!value || value === "auto" || uncache || ~(value + "").indexOf("calc(")) value = _specialProps[property] && _specialProps[property](target, property, unit) || _getComputedProperty(target, property) || _getProperty(target, property) || (property === "opacity" ? 1 : 0);
	}
	return unit && !~(value + "").trim().indexOf(" ") ? _convertToUnit(target, property, value, unit) + unit : value;
};
var _tweenComplexCSSString = function _tweenComplexCSSString(target, prop, start, end) {
	if (!start || start === "none") {
		var p = _checkPropPrefix(prop, target, 1), s = p && _getComputedProperty(target, p, 1);
		if (s && s !== start) {
			prop = p;
			start = s;
		} else if (prop === "borderColor") start = _getComputedProperty(target, "borderTopColor");
	}
	var pt = new PropTween(this._pt, target.style, prop, 0, 1, _renderComplexString), index = 0, matchIndex = 0, a, result, startValues, startNum, color, startValue, endValue, endNum, chunk, endUnit, startUnit, endValues;
	pt.b = start;
	pt.e = end;
	start += "";
	end += "";
	if (end.substring(0, 6) === "var(--") end = _getComputedProperty(target, end.substring(4, end.indexOf(")")));
	if (end === "auto") {
		startValue = target.style[prop];
		target.style[prop] = end;
		end = _getComputedProperty(target, prop) || end;
		startValue ? target.style[prop] = startValue : _removeProperty(target, prop);
	}
	a = [start, end];
	_colorStringFilter(a);
	start = a[0];
	end = a[1];
	startValues = start.match(_numWithUnitExp) || [];
	endValues = end.match(_numWithUnitExp) || [];
	if (endValues.length) {
		while (result = _numWithUnitExp.exec(end)) {
			endValue = result[0];
			chunk = end.substring(index, result.index);
			if (color) color = (color + 1) % 5;
			else if (chunk.substr(-5) === "rgba(" || chunk.substr(-5) === "hsla(") color = 1;
			if (endValue !== (startValue = startValues[matchIndex++] || "")) {
				startNum = parseFloat(startValue) || 0;
				startUnit = startValue.substr((startNum + "").length);
				endValue.charAt(1) === "=" && (endValue = _parseRelative(startNum, endValue) + startUnit);
				endNum = parseFloat(endValue);
				endUnit = endValue.substr((endNum + "").length);
				index = _numWithUnitExp.lastIndex - endUnit.length;
				if (!endUnit) {
					endUnit = endUnit || _config.units[prop] || startUnit;
					if (index === end.length) {
						end += endUnit;
						pt.e += endUnit;
					}
				}
				if (startUnit !== endUnit) startNum = _convertToUnit(target, prop, startValue, endUnit) || 0;
				pt._pt = {
					_next: pt._pt,
					p: chunk || matchIndex === 1 ? chunk : ",",
					s: startNum,
					c: endNum - startNum,
					m: color && color < 4 || prop === "zIndex" ? Math.round : 0
				};
			}
		}
		pt.c = index < end.length ? end.substring(index, end.length) : "";
	} else pt.r = prop === "display" && end === "none" ? _renderNonTweeningValueOnlyAtEnd : _renderNonTweeningValue;
	_relExp.test(end) && (pt.e = 0);
	this._pt = pt;
	return pt;
};
var _keywordToPercent = {
	top: "0%",
	bottom: "100%",
	left: "0%",
	right: "100%",
	center: "50%"
};
var _convertKeywordsToPercentages = function _convertKeywordsToPercentages(value) {
	var split = value.split(" "), x = split[0], y = split[1] || "50%";
	if (x === "top" || x === "bottom" || y === "left" || y === "right") {
		value = x;
		x = y;
		y = value;
	}
	split[0] = _keywordToPercent[x] || x;
	split[1] = _keywordToPercent[y] || y;
	return split.join(" ");
};
var _renderClearProps = function _renderClearProps(ratio, data) {
	if (data.tween && data.tween._time === data.tween._dur) {
		var target = data.t, style = target.style, props = data.u, cache = target._gsap, prop, clearTransforms, i;
		if (props === "all" || props === true) {
			style.cssText = "";
			clearTransforms = 1;
		} else {
			props = props.split(",");
			i = props.length;
			while (--i > -1) {
				prop = props[i];
				if (_transformProps[prop]) {
					clearTransforms = 1;
					prop = prop === "transformOrigin" ? _transformOriginProp : _transformProp;
				}
				_removeProperty(target, prop);
			}
		}
		if (clearTransforms) {
			_removeProperty(target, _transformProp);
			if (cache) {
				cache.svg && target.removeAttribute("transform");
				style.scale = style.rotate = style.translate = "none";
				_parseTransform(target, 1);
				cache.uncache = 1;
				_removeIndependentTransforms(style);
			}
		}
	}
};
var _specialProps = { clearProps: function clearProps(plugin, target, property, endValue, tween) {
	if (tween.data !== "isFromStart") {
		var pt = plugin._pt = new PropTween(plugin._pt, target, property, 0, 0, _renderClearProps);
		pt.u = endValue;
		pt.pr = -10;
		pt.tween = tween;
		plugin._props.push(property);
		return 1;
	}
} };
var _identity2DMatrix = [
	1,
	0,
	0,
	1,
	0,
	0
];
var _rotationalProperties = {};
var _isNullTransform = function _isNullTransform(value) {
	return value === "matrix(1, 0, 0, 1, 0, 0)" || value === "none" || !value;
};
var _getComputedTransformMatrixAsArray = function _getComputedTransformMatrixAsArray(target) {
	var matrixString = _getComputedProperty(target, _transformProp);
	return _isNullTransform(matrixString) ? _identity2DMatrix : matrixString.substr(7).match(_numExp).map(_round);
};
var _getMatrix = function _getMatrix(target, force2D) {
	var cache = target._gsap || _getCache(target), style = target.style, matrix = _getComputedTransformMatrixAsArray(target), parent, nextSibling, temp, addedToDOM;
	if (cache.svg && target.getAttribute("transform")) {
		temp = target.transform.baseVal.consolidate().matrix;
		matrix = [
			temp.a,
			temp.b,
			temp.c,
			temp.d,
			temp.e,
			temp.f
		];
		return matrix.join(",") === "1,0,0,1,0,0" ? _identity2DMatrix : matrix;
	} else if (matrix === _identity2DMatrix && !target.offsetParent && target !== _docElement && !cache.svg) {
		temp = style.display;
		style.display = "block";
		parent = target.parentNode;
		if (!parent || !target.offsetParent && !target.getBoundingClientRect().width) {
			addedToDOM = 1;
			nextSibling = target.nextElementSibling;
			_docElement.appendChild(target);
		}
		matrix = _getComputedTransformMatrixAsArray(target);
		temp ? style.display = temp : _removeProperty(target, "display");
		if (addedToDOM) nextSibling ? parent.insertBefore(target, nextSibling) : parent ? parent.appendChild(target) : _docElement.removeChild(target);
	}
	return force2D && matrix.length > 6 ? [
		matrix[0],
		matrix[1],
		matrix[4],
		matrix[5],
		matrix[12],
		matrix[13]
	] : matrix;
};
var _applySVGOrigin = function _applySVGOrigin(target, origin, originIsAbsolute, smooth, matrixArray, pluginToAddPropTweensTo) {
	var cache = target._gsap, matrix = matrixArray || _getMatrix(target, true), xOriginOld = cache.xOrigin || 0, yOriginOld = cache.yOrigin || 0, xOffsetOld = cache.xOffset || 0, yOffsetOld = cache.yOffset || 0, a = matrix[0], b = matrix[1], c = matrix[2], d = matrix[3], tx = matrix[4], ty = matrix[5], originSplit = origin.split(" "), xOrigin = parseFloat(originSplit[0]) || 0, yOrigin = parseFloat(originSplit[1]) || 0, bounds, determinant, x, y;
	if (!originIsAbsolute) {
		bounds = _getBBox(target);
		xOrigin = bounds.x + (~originSplit[0].indexOf("%") ? xOrigin / 100 * bounds.width : xOrigin);
		yOrigin = bounds.y + (~(originSplit[1] || originSplit[0]).indexOf("%") ? yOrigin / 100 * bounds.height : yOrigin);
	} else if (matrix !== _identity2DMatrix && (determinant = a * d - b * c)) {
		x = xOrigin * (d / determinant) + yOrigin * (-c / determinant) + (c * ty - d * tx) / determinant;
		y = xOrigin * (-b / determinant) + yOrigin * (a / determinant) - (a * ty - b * tx) / determinant;
		xOrigin = x;
		yOrigin = y;
	}
	if (smooth || smooth !== false && cache.smooth) {
		tx = xOrigin - xOriginOld;
		ty = yOrigin - yOriginOld;
		cache.xOffset = xOffsetOld + (tx * a + ty * c) - tx;
		cache.yOffset = yOffsetOld + (tx * b + ty * d) - ty;
	} else cache.xOffset = cache.yOffset = 0;
	cache.xOrigin = xOrigin;
	cache.yOrigin = yOrigin;
	cache.smooth = !!smooth;
	cache.origin = origin;
	cache.originIsAbsolute = !!originIsAbsolute;
	target.style[_transformOriginProp] = "0px 0px";
	if (pluginToAddPropTweensTo) {
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "xOrigin", xOriginOld, xOrigin);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "yOrigin", yOriginOld, yOrigin);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "xOffset", xOffsetOld, cache.xOffset);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "yOffset", yOffsetOld, cache.yOffset);
	}
	target.setAttribute("data-svg-origin", xOrigin + " " + yOrigin);
};
var _parseTransform = function _parseTransform(target, uncache) {
	var cache = target._gsap || new GSCache(target);
	if ("x" in cache && !uncache && !cache.uncache) return cache;
	var style = target.style, invertedScaleX = cache.scaleX < 0, px = "px", deg = "deg", cs = getComputedStyle(target), origin = _getComputedProperty(target, _transformOriginProp) || "0", x = y = z = rotation = rotationX = rotationY = skewX = skewY = perspective = 0, y, z, scaleX = scaleY = 1, scaleY, rotation, rotationX, rotationY, skewX, skewY, perspective, xOrigin, yOrigin, matrix, angle, cos, sin, a, b, c, d, a12, a22, t1, t2, t3, a13, a23, a33, a42, a43, a32;
	cache.svg = !!(target.getCTM && _isSVG(target));
	if (cs.translate) {
		if (cs.translate !== "none" || cs.scale !== "none" || cs.rotate !== "none") style[_transformProp] = (cs.translate !== "none" ? "translate3d(" + (cs.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + (cs.rotate !== "none" ? "rotate(" + cs.rotate + ") " : "") + (cs.scale !== "none" ? "scale(" + cs.scale.split(" ").join(",") + ") " : "") + (cs[_transformProp] !== "none" ? cs[_transformProp] : "");
		style.scale = style.rotate = style.translate = "none";
	}
	matrix = _getMatrix(target, cache.svg);
	if (cache.svg) {
		if (cache.uncache) {
			t2 = target.getBBox();
			origin = cache.xOrigin - t2.x + "px " + (cache.yOrigin - t2.y) + "px";
			t1 = "";
		} else t1 = !uncache && target.getAttribute("data-svg-origin");
		_applySVGOrigin(target, t1 || origin, !!t1 || cache.originIsAbsolute, cache.smooth !== false, matrix);
	}
	xOrigin = cache.xOrigin || 0;
	yOrigin = cache.yOrigin || 0;
	if (matrix !== _identity2DMatrix) {
		a = matrix[0];
		b = matrix[1];
		c = matrix[2];
		d = matrix[3];
		x = a12 = matrix[4];
		y = a22 = matrix[5];
		if (matrix.length === 6) {
			scaleX = Math.sqrt(a * a + b * b);
			scaleY = Math.sqrt(d * d + c * c);
			rotation = a || b ? _atan2(b, a) * _RAD2DEG : 0;
			skewX = c || d ? _atan2(c, d) * _RAD2DEG + rotation : 0;
			skewX && (scaleY *= Math.abs(Math.cos(skewX * _DEG2RAD)));
			if (cache.svg) {
				x -= xOrigin - (xOrigin * a + yOrigin * c);
				y -= yOrigin - (xOrigin * b + yOrigin * d);
			}
		} else {
			a32 = matrix[6];
			a42 = matrix[7];
			a13 = matrix[8];
			a23 = matrix[9];
			a33 = matrix[10];
			a43 = matrix[11];
			x = matrix[12];
			y = matrix[13];
			z = matrix[14];
			angle = _atan2(a32, a33);
			rotationX = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(-angle);
				sin = Math.sin(-angle);
				t1 = a12 * cos + a13 * sin;
				t2 = a22 * cos + a23 * sin;
				t3 = a32 * cos + a33 * sin;
				a13 = a12 * -sin + a13 * cos;
				a23 = a22 * -sin + a23 * cos;
				a33 = a32 * -sin + a33 * cos;
				a43 = a42 * -sin + a43 * cos;
				a12 = t1;
				a22 = t2;
				a32 = t3;
			}
			angle = _atan2(-c, a33);
			rotationY = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(-angle);
				sin = Math.sin(-angle);
				t1 = a * cos - a13 * sin;
				t2 = b * cos - a23 * sin;
				t3 = c * cos - a33 * sin;
				a43 = d * sin + a43 * cos;
				a = t1;
				b = t2;
				c = t3;
			}
			angle = _atan2(b, a);
			rotation = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(angle);
				sin = Math.sin(angle);
				t1 = a * cos + b * sin;
				t2 = a12 * cos + a22 * sin;
				b = b * cos - a * sin;
				a22 = a22 * cos - a12 * sin;
				a = t1;
				a12 = t2;
			}
			if (rotationX && Math.abs(rotationX) + Math.abs(rotation) > 359.9) {
				rotationX = rotation = 0;
				rotationY = 180 - rotationY;
			}
			scaleX = _round(Math.sqrt(a * a + b * b + c * c));
			scaleY = _round(Math.sqrt(a22 * a22 + a32 * a32));
			angle = _atan2(a12, a22);
			skewX = Math.abs(angle) > 2e-4 ? angle * _RAD2DEG : 0;
			perspective = a43 ? 1 / (a43 < 0 ? -a43 : a43) : 0;
		}
		if (cache.svg) {
			t1 = target.getAttribute("transform");
			cache.forceCSS = target.setAttribute("transform", "") || !_isNullTransform(_getComputedProperty(target, _transformProp));
			t1 && target.setAttribute("transform", t1);
		}
	}
	if (Math.abs(skewX) > 90 && Math.abs(skewX) < 270) {
		if (invertedScaleX) {
			scaleX *= -1;
			skewX += rotation <= 0 ? 180 : -180;
			rotation += rotation <= 0 ? 180 : -180;
		} else {
			scaleY *= -1;
			skewX += skewX <= 0 ? 180 : -180;
		}
	}
	uncache = uncache || cache.uncache;
	cache.x = x - ((cache.xPercent = x && (!uncache && cache.xPercent || (Math.round(target.offsetWidth / 2) === Math.round(-x) ? -50 : 0))) ? target.offsetWidth * cache.xPercent / 100 : 0) + px;
	cache.y = y - ((cache.yPercent = y && (!uncache && cache.yPercent || (Math.round(target.offsetHeight / 2) === Math.round(-y) ? -50 : 0))) ? target.offsetHeight * cache.yPercent / 100 : 0) + px;
	cache.z = z + px;
	cache.scaleX = _round(scaleX);
	cache.scaleY = _round(scaleY);
	cache.rotation = _round(rotation) + deg;
	cache.rotationX = _round(rotationX) + deg;
	cache.rotationY = _round(rotationY) + deg;
	cache.skewX = skewX + deg;
	cache.skewY = skewY + deg;
	cache.transformPerspective = perspective + px;
	if (cache.zOrigin = parseFloat(origin.split(" ")[2]) || !uncache && cache.zOrigin || 0) style[_transformOriginProp] = _firstTwoOnly(origin);
	cache.xOffset = cache.yOffset = 0;
	cache.force3D = _config.force3D;
	cache.renderTransform = cache.svg ? _renderSVGTransforms : _supports3D ? _renderCSSTransforms : _renderNon3DTransforms;
	cache.uncache = 0;
	return cache;
};
var _firstTwoOnly = function _firstTwoOnly(value) {
	return (value = value.split(" "))[0] + " " + value[1];
};
var _addPxTranslate = function _addPxTranslate(target, start, value) {
	var unit = getUnit(start);
	return _round(parseFloat(start) + parseFloat(_convertToUnit(target, "x", value + "px", unit))) + unit;
};
var _renderNon3DTransforms = function _renderNon3DTransforms(ratio, cache) {
	cache.z = "0px";
	cache.rotationY = cache.rotationX = "0deg";
	cache.force3D = 0;
	_renderCSSTransforms(ratio, cache);
};
var _zeroDeg = "0deg";
var _zeroPx = "0px";
var _endParenthesis = ") ";
var _renderCSSTransforms = function _renderCSSTransforms(ratio, cache) {
	var _ref = cache || this, xPercent = _ref.xPercent, yPercent = _ref.yPercent, x = _ref.x, y = _ref.y, z = _ref.z, rotation = _ref.rotation, rotationY = _ref.rotationY, rotationX = _ref.rotationX, skewX = _ref.skewX, skewY = _ref.skewY, scaleX = _ref.scaleX, scaleY = _ref.scaleY, transformPerspective = _ref.transformPerspective, force3D = _ref.force3D, target = _ref.target, zOrigin = _ref.zOrigin, transforms = "", use3D = force3D === "auto" && ratio && ratio !== 1 || force3D === true;
	if (zOrigin && (rotationX !== _zeroDeg || rotationY !== _zeroDeg)) {
		var angle = parseFloat(rotationY) * _DEG2RAD, a13 = Math.sin(angle), a33 = Math.cos(angle), cos;
		angle = parseFloat(rotationX) * _DEG2RAD;
		cos = Math.cos(angle);
		x = _addPxTranslate(target, x, a13 * cos * -zOrigin);
		y = _addPxTranslate(target, y, -Math.sin(angle) * -zOrigin);
		z = _addPxTranslate(target, z, a33 * cos * -zOrigin + zOrigin);
	}
	if (transformPerspective !== _zeroPx) transforms += "perspective(" + transformPerspective + _endParenthesis;
	if (xPercent || yPercent) transforms += "translate(" + xPercent + "%, " + yPercent + "%) ";
	if (use3D || x !== _zeroPx || y !== _zeroPx || z !== _zeroPx) transforms += z !== _zeroPx || use3D ? "translate3d(" + x + ", " + y + ", " + z + ") " : "translate(" + x + ", " + y + _endParenthesis;
	if (rotation !== _zeroDeg) transforms += "rotate(" + rotation + _endParenthesis;
	if (rotationY !== _zeroDeg) transforms += "rotateY(" + rotationY + _endParenthesis;
	if (rotationX !== _zeroDeg) transforms += "rotateX(" + rotationX + _endParenthesis;
	if (skewX !== _zeroDeg || skewY !== _zeroDeg) transforms += "skew(" + skewX + ", " + skewY + _endParenthesis;
	if (scaleX !== 1 || scaleY !== 1) transforms += "scale(" + scaleX + ", " + scaleY + _endParenthesis;
	target.style[_transformProp] = transforms || "translate(0, 0)";
};
var _renderSVGTransforms = function _renderSVGTransforms(ratio, cache) {
	var _ref2 = cache || this, xPercent = _ref2.xPercent, yPercent = _ref2.yPercent, x = _ref2.x, y = _ref2.y, rotation = _ref2.rotation, skewX = _ref2.skewX, skewY = _ref2.skewY, scaleX = _ref2.scaleX, scaleY = _ref2.scaleY, target = _ref2.target, xOrigin = _ref2.xOrigin, yOrigin = _ref2.yOrigin, xOffset = _ref2.xOffset, yOffset = _ref2.yOffset, forceCSS = _ref2.forceCSS, tx = parseFloat(x), ty = parseFloat(y), a11, a21, a12, a22, temp;
	rotation = parseFloat(rotation);
	skewX = parseFloat(skewX);
	skewY = parseFloat(skewY);
	if (skewY) {
		skewY = parseFloat(skewY);
		skewX += skewY;
		rotation += skewY;
	}
	if (rotation || skewX) {
		rotation *= _DEG2RAD;
		skewX *= _DEG2RAD;
		a11 = Math.cos(rotation) * scaleX;
		a21 = Math.sin(rotation) * scaleX;
		a12 = Math.sin(rotation - skewX) * -scaleY;
		a22 = Math.cos(rotation - skewX) * scaleY;
		if (skewX) {
			skewY *= _DEG2RAD;
			temp = Math.tan(skewX - skewY);
			temp = Math.sqrt(1 + temp * temp);
			a12 *= temp;
			a22 *= temp;
			if (skewY) {
				temp = Math.tan(skewY);
				temp = Math.sqrt(1 + temp * temp);
				a11 *= temp;
				a21 *= temp;
			}
		}
		a11 = _round(a11);
		a21 = _round(a21);
		a12 = _round(a12);
		a22 = _round(a22);
	} else {
		a11 = scaleX;
		a22 = scaleY;
		a21 = a12 = 0;
	}
	if (tx && !~(x + "").indexOf("px") || ty && !~(y + "").indexOf("px")) {
		tx = _convertToUnit(target, "x", x, "px");
		ty = _convertToUnit(target, "y", y, "px");
	}
	if (xOrigin || yOrigin || xOffset || yOffset) {
		tx = _round(tx + xOrigin - (xOrigin * a11 + yOrigin * a12) + xOffset);
		ty = _round(ty + yOrigin - (xOrigin * a21 + yOrigin * a22) + yOffset);
	}
	if (xPercent || yPercent) {
		temp = target.getBBox();
		tx = _round(tx + xPercent / 100 * temp.width);
		ty = _round(ty + yPercent / 100 * temp.height);
	}
	temp = "matrix(" + a11 + "," + a21 + "," + a12 + "," + a22 + "," + tx + "," + ty + ")";
	target.setAttribute("transform", temp);
	forceCSS && (target.style[_transformProp] = temp);
};
var _addRotationalPropTween = function _addRotationalPropTween(plugin, target, property, startNum, endValue) {
	var cap = 360, isString = _isString(endValue), change = parseFloat(endValue) * (isString && ~endValue.indexOf("rad") ? _RAD2DEG : 1) - startNum, finalValue = startNum + change + "deg", direction, pt;
	if (isString) {
		direction = endValue.split("_")[1];
		if (direction === "short") {
			change %= cap;
			if (change !== change % (cap / 2)) change += change < 0 ? cap : -cap;
		}
		if (direction === "cw" && change < 0) change = (change + cap * _bigNum) % cap - ~~(change / cap) * cap;
		else if (direction === "ccw" && change > 0) change = (change - cap * _bigNum) % cap - ~~(change / cap) * cap;
	}
	plugin._pt = pt = new PropTween(plugin._pt, target, property, startNum, change, _renderPropWithEnd);
	pt.e = finalValue;
	pt.u = "deg";
	plugin._props.push(property);
	return pt;
};
var _assign = function _assign(target, source) {
	for (var p in source) target[p] = source[p];
	return target;
};
var _addRawTransformPTs = function _addRawTransformPTs(plugin, transforms, target) {
	var startCache = _assign({}, target._gsap), exclude = "perspective,force3D,transformOrigin,svgOrigin", style = target.style, endCache, p, startValue, endValue, startNum, endNum, startUnit, endUnit;
	if (startCache.svg) {
		startValue = target.getAttribute("transform");
		target.setAttribute("transform", "");
		style[_transformProp] = transforms;
		endCache = _parseTransform(target, 1);
		_removeProperty(target, _transformProp);
		target.setAttribute("transform", startValue);
	} else {
		startValue = getComputedStyle(target)[_transformProp];
		style[_transformProp] = transforms;
		endCache = _parseTransform(target, 1);
		style[_transformProp] = startValue;
	}
	for (p in _transformProps) {
		startValue = startCache[p];
		endValue = endCache[p];
		if (startValue !== endValue && exclude.indexOf(p) < 0) {
			startUnit = getUnit(startValue);
			endUnit = getUnit(endValue);
			startNum = startUnit !== endUnit ? _convertToUnit(target, p, startValue, endUnit) : parseFloat(startValue);
			endNum = parseFloat(endValue);
			plugin._pt = new PropTween(plugin._pt, endCache, p, startNum, endNum - startNum, _renderCSSProp);
			plugin._pt.u = endUnit || 0;
			plugin._props.push(p);
		}
	}
	_assign(endCache, startCache);
};
_forEachName("padding,margin,Width,Radius", function(name, index) {
	var t = "Top", r = "Right", b = "Bottom", l = "Left", props = (index < 3 ? [
		t,
		r,
		b,
		l
	] : [
		t + l,
		t + r,
		b + r,
		b + l
	]).map(function(side) {
		return index < 2 ? name + side : "border" + side + name;
	});
	_specialProps[index > 1 ? "border" + name : name] = function(plugin, target, property, endValue, tween) {
		var a, vars;
		if (arguments.length < 4) {
			a = props.map(function(prop) {
				return _get(plugin, prop, property);
			});
			vars = a.join(" ");
			return vars.split(a[0]).length === 5 ? a[0] : vars;
		}
		a = (endValue + "").split(" ");
		vars = {};
		props.forEach(function(prop, i) {
			return vars[prop] = a[i] = a[i] || a[(i - 1) / 2 | 0];
		});
		plugin.init(target, vars, tween);
	};
});
var CSSPlugin = {
	name: "css",
	register: _initCore,
	targetTest: function targetTest(target) {
		return target.style && target.nodeType;
	},
	init: function init(target, vars, tween, index, targets) {
		var props = this._props, style = target.style, startAt = tween.vars.startAt, startValue, endValue, endNum, startNum, type, specialProp, p, startUnit, endUnit, relative, isTransformRelated, transformPropTween, cache, smooth, hasPriority, inlineProps, finalTransformValue;
		_pluginInitted || _initCore();
		this.styles = this.styles || _getStyleSaver(target);
		inlineProps = this.styles.props;
		this.tween = tween;
		for (p in vars) {
			if (p === "autoRound") continue;
			endValue = vars[p];
			if (_plugins[p] && _checkPlugin(p, vars, tween, index, target, targets)) continue;
			type = typeof endValue;
			specialProp = _specialProps[p];
			if (type === "function") {
				endValue = endValue.call(tween, index, target, targets);
				type = typeof endValue;
			}
			if (type === "string" && ~endValue.indexOf("random(")) endValue = _replaceRandom(endValue);
			if (specialProp) specialProp(this, target, p, endValue, tween) && (hasPriority = 1);
			else if (p.substr(0, 2) === "--") {
				startValue = (getComputedStyle(target).getPropertyValue(p) + "").trim();
				endValue += "";
				_colorExp.lastIndex = 0;
				if (!_colorExp.test(startValue)) {
					startUnit = getUnit(startValue);
					endUnit = getUnit(endValue);
					endUnit ? startUnit !== endUnit && (startValue = _convertToUnit(target, p, startValue, endUnit) + endUnit) : startUnit && (endValue += startUnit);
				}
				this.add(style, "setProperty", startValue, endValue, index, targets, 0, 0, p);
				props.push(p);
				inlineProps.push(p, 0, style[p]);
			} else if (type !== "undefined") {
				if (startAt && p in startAt) {
					startValue = typeof startAt[p] === "function" ? startAt[p].call(tween, index, target, targets) : startAt[p];
					_isString(startValue) && ~startValue.indexOf("random(") && (startValue = _replaceRandom(startValue));
					getUnit(startValue + "") || startValue === "auto" || (startValue += _config.units[p] || getUnit(_get(target, p)) || "");
					(startValue + "").charAt(1) === "=" && (startValue = _get(target, p));
				} else startValue = _get(target, p);
				startNum = parseFloat(startValue);
				relative = type === "string" && endValue.charAt(1) === "=" && endValue.substr(0, 2);
				relative && (endValue = endValue.substr(2));
				endNum = parseFloat(endValue);
				if (p in _propertyAliases) {
					if (p === "autoAlpha") {
						if (startNum === 1 && _get(target, "visibility") === "hidden" && endNum) startNum = 0;
						inlineProps.push("visibility", 0, style.visibility);
						_addNonTweeningPT(this, style, "visibility", startNum ? "inherit" : "hidden", endNum ? "inherit" : "hidden", !endNum);
					}
					if (p !== "scale" && p !== "transform") {
						p = _propertyAliases[p];
						~p.indexOf(",") && (p = p.split(",")[0]);
					}
				}
				isTransformRelated = p in _transformProps;
				if (isTransformRelated) {
					this.styles.save(p);
					finalTransformValue = endValue;
					if (type === "string" && endValue.substring(0, 6) === "var(--") {
						endValue = _getComputedProperty(target, endValue.substring(4, endValue.indexOf(")")));
						if (endValue.substring(0, 5) === "calc(") {
							var origPerspective = target.style.perspective;
							target.style.perspective = endValue;
							endValue = _getComputedProperty(target, "perspective");
							origPerspective ? target.style.perspective = origPerspective : _removeProperty(target, "perspective");
						}
						endNum = parseFloat(endValue);
					}
					if (!transformPropTween) {
						cache = target._gsap;
						cache.renderTransform && !vars.parseTransform || _parseTransform(target, vars.parseTransform);
						smooth = vars.smoothOrigin !== false && cache.smooth;
						transformPropTween = this._pt = new PropTween(this._pt, style, _transformProp, 0, 1, cache.renderTransform, cache, 0, -1);
						transformPropTween.dep = 1;
					}
					if (p === "scale") {
						this._pt = new PropTween(this._pt, cache, "scaleY", cache.scaleY, (relative ? _parseRelative(cache.scaleY, relative + endNum) : endNum) - cache.scaleY || 0, _renderCSSProp);
						this._pt.u = 0;
						props.push("scaleY", p);
						p += "X";
					} else if (p === "transformOrigin") {
						inlineProps.push(_transformOriginProp, 0, style[_transformOriginProp]);
						endValue = _convertKeywordsToPercentages(endValue);
						if (cache.svg) _applySVGOrigin(target, endValue, 0, smooth, 0, this);
						else {
							endUnit = parseFloat(endValue.split(" ")[2]) || 0;
							endUnit !== cache.zOrigin && _addNonTweeningPT(this, cache, "zOrigin", cache.zOrigin, endUnit);
							_addNonTweeningPT(this, style, p, _firstTwoOnly(startValue), _firstTwoOnly(endValue));
						}
						continue;
					} else if (p === "svgOrigin") {
						_applySVGOrigin(target, endValue, 1, smooth, 0, this);
						continue;
					} else if (p in _rotationalProperties) {
						_addRotationalPropTween(this, cache, p, startNum, relative ? _parseRelative(startNum, relative + endValue) : endValue);
						continue;
					} else if (p === "smoothOrigin") {
						_addNonTweeningPT(this, cache, "smooth", cache.smooth, endValue);
						continue;
					} else if (p === "force3D") {
						cache[p] = endValue;
						continue;
					} else if (p === "transform") {
						_addRawTransformPTs(this, endValue, target);
						continue;
					}
				} else if (!(p in style)) p = _checkPropPrefix(p) || p;
				if (isTransformRelated || (endNum || endNum === 0) && (startNum || startNum === 0) && !_complexExp.test(endValue) && p in style) {
					startUnit = (startValue + "").substr((startNum + "").length);
					endNum || (endNum = 0);
					endUnit = getUnit(endValue) || (p in _config.units ? _config.units[p] : startUnit);
					startUnit !== endUnit && (startNum = _convertToUnit(target, p, startValue, endUnit));
					this._pt = new PropTween(this._pt, isTransformRelated ? cache : style, p, startNum, (relative ? _parseRelative(startNum, relative + endNum) : endNum) - startNum, !isTransformRelated && (endUnit === "px" || p === "zIndex") && vars.autoRound !== false ? _renderRoundedCSSProp : _renderCSSProp);
					this._pt.u = endUnit || 0;
					if (isTransformRelated && finalTransformValue !== endValue) {
						this._pt.b = startValue;
						this._pt.e = finalTransformValue;
						this._pt.r = _renderCSSPropWithBeginningAndEnd;
					} else if (startUnit !== endUnit && endUnit !== "%") {
						this._pt.b = startValue;
						this._pt.r = _renderCSSPropWithBeginning;
					}
				} else if (!(p in style)) {
					if (p in target) this.add(target, p, startValue || target[p], relative ? relative + endValue : endValue, index, targets);
					else if (p !== "parseTransform") {
						_missingPlugin(p, endValue);
						continue;
					}
				} else _tweenComplexCSSString.call(this, target, p, startValue, relative ? relative + endValue : endValue);
				isTransformRelated || (p in style ? inlineProps.push(p, 0, style[p]) : typeof target[p] === "function" ? inlineProps.push(p, 2, target[p]()) : inlineProps.push(p, 1, startValue || target[p]));
				props.push(p);
			}
		}
		hasPriority && _sortPropTweensByPriority(this);
	},
	render: function render(ratio, data) {
		if (data.tween._time || !_reverting()) {
			var pt = data._pt;
			while (pt) {
				pt.r(ratio, pt.d);
				pt = pt._next;
			}
		} else data.styles.revert();
	},
	get: _get,
	aliases: _propertyAliases,
	getSetter: function getSetter(target, property, plugin) {
		var p = _propertyAliases[property];
		p && p.indexOf(",") < 0 && (property = p);
		return property in _transformProps && property !== _transformOriginProp && (target._gsap.x || _get(target, "x")) ? plugin && _recentSetterPlugin === plugin ? property === "scale" ? _setterScale : _setterTransform : (_recentSetterPlugin = plugin || {}) && (property === "scale" ? _setterScaleWithRender : _setterTransformWithRender) : target.style && !_isUndefined(target.style[property]) ? _setterCSSStyle : ~property.indexOf("-") ? _setterCSSProp : _getSetter(target, property);
	},
	core: {
		_removeProperty,
		_getMatrix
	}
};
gsap.utils.checkPrefix = _checkPropPrefix;
gsap.core.getStyleSaver = _getStyleSaver;
(function(positionAndScale, rotation, others, aliases) {
	var all = _forEachName(positionAndScale + "," + rotation + "," + others, function(name) {
		_transformProps[name] = 1;
	});
	_forEachName(rotation, function(name) {
		_config.units[name] = "deg";
		_rotationalProperties[name] = 1;
	});
	_propertyAliases[all[13]] = positionAndScale + "," + rotation;
	_forEachName(aliases, function(name) {
		var split = name.split(":");
		_propertyAliases[split[1]] = all[split[0]];
	});
})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");
_forEachName("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(name) {
	_config.units[name] = "px";
});
gsap.registerPlugin(CSSPlugin);
//#endregion
//#region ../../node_modules/gsap/index.js
var gsapWithCSS = gsap.registerPlugin(CSSPlugin) || gsap;
gsapWithCSS.core.Tween;
//#endregion
//#region ../scene-model/src/paint.ts
function stopColor(stop) {
	const opacity = Math.max(0, Math.min(1, stop.opacity));
	const match = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(stop.color);
	if (match) return `rgba(${Number.parseInt(match[1], 16)}, ${Number.parseInt(match[2], 16)}, ${Number.parseInt(match[3], 16)}, ${opacity})`;
	return opacity >= 1 ? stop.color : `color-mix(in srgb, ${stop.color} ${opacity * 100}%, transparent)`;
}
function paintToCss(paint) {
	if (typeof paint === "string") return paint;
	const stops = [...paint.stops].sort((a, b) => a.offset - b.offset).map((stop) => `${stopColor(stop)} ${Math.max(0, Math.min(1, stop.offset)) * 100}%`).join(", ");
	if (paint.type === "radial") return `radial-gradient(circle, ${stops})`;
	if (paint.type === "conic") return `conic-gradient(from ${paint.angle}deg, ${stops})`;
	return `linear-gradient(${paint.angle}deg, ${stops})`;
}
//#endregion
//#region ../scene-model/src/layerEffects.ts
function colorWithOpacity(color, opacity) {
	const match = /^#([0-9a-f]{6})$/i.exec(color);
	if (!match) return color;
	const value = Number.parseInt(match[1], 16);
	return `rgba(${value >> 16 & 255}, ${value >> 8 & 255}, ${value & 255}, ${opacity})`;
}
function layerEffectsToCssFilter(effects) {
	const filters = [];
	if (effects.blur > 0) filters.push(`blur(${effects.blur}px)`);
	if (effects.dropShadowEnabled) filters.push(`drop-shadow(${effects.dropShadowOffsetX}px ${effects.dropShadowOffsetY}px ${effects.dropShadowBlur}px ${colorWithOpacity(effects.dropShadowColor, effects.dropShadowOpacity)})`);
	return filters.length > 0 ? filters.join(" ") : "none";
}
//#endregion
//#region ../scene-model/src/layerAnimation.ts
var TRANSFORM_ANIMATION_PROPERTIES = [
	"x",
	"y",
	"width",
	"height",
	"rotation",
	"opacity",
	"transformOriginX",
	"transformOriginY"
];
var EFFECT_ANIMATION_PROPERTIES = [
	"blur",
	"dropShadowOpacity",
	"dropShadowOffsetX",
	"dropShadowOffsetY",
	"dropShadowBlur"
];
[...TRANSFORM_ANIMATION_PROPERTIES, ...EFFECT_ANIMATION_PROPERTIES];
var GRADIENT_STOP_OFFSET_PROPERTY = /^fill\.stops\[(0|[1-9]\d*)\]\.offset$/;
function gradientStopOffsetProperty(index) {
	if (!Number.isInteger(index) || index < 0) throw new Error("Gradient stop index must be non-negative.");
	return `fill.stops[${index}].offset`;
}
function gradientStopIndexForProperty(property) {
	const match = GRADIENT_STOP_OFFSET_PROPERTY.exec(property);
	return match ? Number(match[1]) : null;
}
function isGradientStopOffsetProperty(property) {
	return gradientStopIndexForProperty(property) !== null;
}
function bounceOut(progress) {
	const n1 = 7.5625;
	const d1 = 2.75;
	if (progress < 1 / d1) return n1 * progress * progress;
	if (progress < 2 / d1) {
		const shifted = progress - 1.5 / d1;
		return n1 * shifted * shifted + .75;
	}
	if (progress < 2.5 / d1) {
		const shifted = progress - 2.25 / d1;
		return n1 * shifted * shifted + .9375;
	}
	const shifted = progress - 2.625 / d1;
	return n1 * shifted * shifted + .984375;
}
/** Shared deterministic easing sampler used by editor evaluation and the GSAP runtime. */
function easedProgress(progress, easing) {
	const inverse = 1 - progress;
	switch (easing) {
		case "linear": return progress;
		case "ease-in":
		case "quad-in": return progress * progress;
		case "ease-out":
		case "quad-out": return 1 - (1 - progress) * (1 - progress);
		case "ease-in-out":
		case "quad-in-out": return progress < .5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
		case "cubic-in": return progress ** 3;
		case "cubic-out": return 1 - inverse ** 3;
		case "cubic-in-out": return progress < .5 ? 4 * progress ** 3 : 1 - (-2 * progress + 2) ** 3 / 2;
		case "quart-in": return progress ** 4;
		case "quart-out": return 1 - inverse ** 4;
		case "quart-in-out": return progress < .5 ? 8 * progress ** 4 : 1 - (-2 * progress + 2) ** 4 / 2;
		case "quint-in": return progress ** 5;
		case "quint-out": return 1 - inverse ** 5;
		case "quint-in-out": return progress < .5 ? 16 * progress ** 5 : 1 - (-2 * progress + 2) ** 5 / 2;
		case "sine-in": return 1 - Math.cos(progress * Math.PI / 2);
		case "sine-out": return Math.sin(progress * Math.PI / 2);
		case "sine-in-out": return -(Math.cos(Math.PI * progress) - 1) / 2;
		case "expo-in": return progress === 0 ? 0 : 2 ** (10 * progress - 10);
		case "expo-out": return progress === 1 ? 1 : 1 - 2 ** (-10 * progress);
		case "expo-in-out":
			if (progress === 0 || progress === 1) return progress;
			return progress < .5 ? 2 ** (20 * progress - 10) / 2 : (2 - 2 ** (-20 * progress + 10)) / 2;
		case "circ-in": return 1 - Math.sqrt(1 - progress ** 2);
		case "circ-out": return Math.sqrt(1 - (progress - 1) ** 2);
		case "circ-in-out": return progress < .5 ? (1 - Math.sqrt(1 - (2 * progress) ** 2)) / 2 : (Math.sqrt(1 - (-2 * progress + 2) ** 2) + 1) / 2;
		case "back-in": return 2.70158 * progress ** 3 - 1.70158 * progress ** 2;
		case "back-out": return 1 + 2.70158 * (progress - 1) ** 3 + 1.70158 * (progress - 1) ** 2;
		case "back-in-out": {
			const c2 = 2.5949095;
			return progress < .5 ? (2 * progress) ** 2 * (7.189819 * progress - c2) / 2 : ((2 * progress - 2) ** 2 * (3.5949095 * (progress * 2 - 2) + c2) + 2) / 2;
		}
		case "bounce-in": return 1 - bounceOut(1 - progress);
		case "bounce-out": return bounceOut(progress);
		case "bounce-in-out": return progress < .5 ? (1 - bounceOut(1 - 2 * progress)) / 2 : (1 + bounceOut(2 * progress - 1)) / 2;
		case "elastic-in": {
			if (progress === 0 || progress === 1) return progress;
			const c4 = 2 * Math.PI / 3;
			return -(2 ** (10 * progress - 10)) * Math.sin((progress * 10 - 10.75) * c4);
		}
		case "elastic-out": {
			if (progress === 0 || progress === 1) return progress;
			const c4 = 2 * Math.PI / 3;
			return 2 ** (-10 * progress) * Math.sin((progress * 10 - .75) * c4) + 1;
		}
		case "elastic-in-out": {
			if (progress === 0 || progress === 1) return progress;
			const c5 = 2 * Math.PI / 4.5;
			return progress < .5 ? -(2 ** (20 * progress - 10) * Math.sin((20 * progress - 11.125) * c5)) / 2 : 2 ** (-20 * progress + 10) * Math.sin((20 * progress - 11.125) * c5) / 2 + 1;
		}
	}
}
/** CSS cubic-bezier sampler: solve x(t)=progress, then return y(t). */
function cubicBezierProgress(progress, curve) {
	const sample = (t, a, b) => {
		const inverse = 1 - t;
		return 3 * inverse * inverse * t * a + 3 * inverse * t * t * b + t * t * t;
	};
	let low = 0;
	let high = 1;
	let t = progress;
	for (let index = 0; index < 14; index++) {
		const x = sample(t, curve.x1, curve.x2);
		if (Math.abs(x - progress) < 1e-5) break;
		if (x < progress) low = t;
		else high = t;
		t = (low + high) / 2;
	}
	return sample(t, curve.y1, curve.y2);
}
function sortLayerPropertyKeyframes(keyframes) {
	return [...keyframes].sort((a, b) => a.frame - b.frame || a.id.localeCompare(b.id));
}
function getTrackValueAtFrame(keyframes, frame, fallback) {
	const sorted = sortLayerPropertyKeyframes(keyframes);
	const first = sorted[0];
	if (!first) return fallback;
	if (frame <= first.frame) return first.value;
	const last = sorted.at(-1);
	if (frame >= last.frame) return last.value;
	const nextIndex = sorted.findIndex((keyframe) => keyframe.frame >= frame);
	const next = sorted[nextIndex];
	if (next.frame === frame) return next.value;
	const previous = sorted[nextIndex - 1];
	const rawProgress = (frame - previous.frame) / (next.frame - previous.frame);
	const progress = next.curve ? cubicBezierProgress(rawProgress, next.curve) : easedProgress(rawProgress, next.easing);
	return previous.value + (next.value - previous.value) * progress;
}
/** Applies canonical stop-offset tracks without mutating the authored or data-bound paint. */
function getPaintAtFrame(paint, tracks, frame) {
	if (typeof paint === "string") return paint;
	return {
		...paint,
		stops: paint.stops.map((stop, index) => {
			const offset = getTrackValueAtFrame(tracks[gradientStopOffsetProperty(index)] ?? [], frame, stop.offset);
			return {
				...stop,
				offset: Math.max(0, Math.min(1, offset))
			};
		})
	};
}
//#endregion
//#region ../scene-model/src/clipping.ts
var EPSILON = 1e-6;
var rounded = (value) => Math.round(value * 1e3) / 1e3;
var pointText = (point) => `${rounded(point.x)} ${rounded(point.y)}`;
function localToWorld(point, transform) {
	const originX = transform.transformOriginX * transform.width;
	const originY = transform.transformOriginY * transform.height;
	const radians = transform.rotation * Math.PI / 180;
	const cosine = Math.cos(radians);
	const sine = Math.sin(radians);
	const x = point.x - originX;
	const y = point.y - originY;
	return {
		x: transform.x + originX + x * cosine - y * sine,
		y: transform.y + originY + x * sine + y * cosine
	};
}
function worldToLocal(point, transform) {
	const originX = transform.transformOriginX * transform.width;
	const originY = transform.transformOriginY * transform.height;
	const radians = -transform.rotation * Math.PI / 180;
	const cosine = Math.cos(radians);
	const sine = Math.sin(radians);
	const x = point.x - transform.x - originX;
	const y = point.y - transform.y - originY;
	return {
		x: originX + x * cosine - y * sine,
		y: originY + x * sine + y * cosine
	};
}
function parentPointInChild(point, child, parent) {
	return worldToLocal(localToWorld(point, parent), child);
}
/** SVG path in the child's local coordinate system for a transformed rounded parent rectangle. */
function clipPathSvgForParentBounds(child, parent, borderRadius = 0) {
	const radius = Math.max(0, Math.min(borderRadius, parent.width / 2, parent.height / 2));
	const convert = (x, y) => parentPointInChild({
		x,
		y
	}, child, parent);
	const topLeftStart = convert(radius, 0);
	const topRightStart = convert(parent.width - radius, 0);
	const topRightControl = convert(parent.width, 0);
	const topRightEnd = convert(parent.width, radius);
	const bottomRightStart = convert(parent.width, parent.height - radius);
	const bottomRightControl = convert(parent.width, parent.height);
	const bottomRightEnd = convert(parent.width - radius, parent.height);
	const bottomLeftStart = convert(radius, parent.height);
	const bottomLeftControl = convert(0, parent.height);
	const bottomLeftEnd = convert(0, parent.height - radius);
	const topLeftEdge = convert(0, radius);
	const topLeftControl = convert(0, 0);
	if (radius <= EPSILON) return `M ${[
		convert(0, 0),
		convert(parent.width, 0),
		convert(parent.width, parent.height),
		convert(0, parent.height)
	].map(pointText).join(" L ")} Z`;
	return [
		`M ${pointText(topLeftStart)}`,
		`L ${pointText(topRightStart)}`,
		`Q ${pointText(topRightControl)} ${pointText(topRightEnd)}`,
		`L ${pointText(bottomRightStart)}`,
		`Q ${pointText(bottomRightControl)} ${pointText(bottomRightEnd)}`,
		`L ${pointText(bottomLeftStart)}`,
		`Q ${pointText(bottomLeftControl)} ${pointText(bottomLeftEnd)}`,
		`L ${pointText(topLeftEdge)}`,
		`Q ${pointText(topLeftControl)} ${pointText(topLeftStart)}`,
		"Z"
	].join(" ");
}
/** CSS clipping path for a parent rectangle expressed in the transformed child's local box. */
function clipPathForParentBounds(child, parent, borderRadius = 0) {
	return `path("${clipPathSvgForParentBounds(child, parent, borderRadius)}")`;
}
//#endregion
//#region ../scene-model/src/loopAnimation.ts
/** Local clip position derived from absolute elapsed frames; never advances by mutable ticks. */
function getLoopFrameAtElapsed(loop, elapsedFrames) {
	const duration = Math.max(1, Math.round(loop.durationFrames));
	const shifted = Math.max(0, elapsedFrames + Math.round(loop.phaseOffsetFrames));
	if (loop.repeatCount !== null && shifted >= duration * Math.max(1, loop.repeatCount)) return duration;
	return (shifted % duration + duration) % duration;
}
//#endregion
//#region ../scene-model/src/lottie.ts
/** Raw Lottie frame for an absolute elapsed time; independent of callback cadence. */
function lottieFrameAtTime(element, elapsedMs) {
	const data = element.animationData;
	if (!data) return 0;
	const duration = data.op - data.ip;
	if (!(duration > 0) || !(data.fr > 0)) return data.ip;
	const elapsedFrames = Math.max(0, elapsedMs) * .001 * data.fr * Math.max(0, element.speed);
	return data.ip + (elapsedFrames % duration + duration) % duration;
}
//#endregion
//#region ../scene-model/src/fieldSchema.ts
function valueAtSourcePath(value, sourcePath = []) {
	let current = value;
	for (const segment of sourcePath) {
		if (!current || typeof current !== "object" || Array.isArray(current)) return void 0;
		current = current[segment];
	}
	return current;
}
//#endregion
//#region src/easing.ts
/** GSAP accepts an easing function; sharing the scene-model sampler prevents preview/runtime drift. */
function easingForGsap(easing, curve) {
	return curve ? (progress) => cubicBezierProgress(progress, curve) : (progress) => easedProgress(progress, easing);
}
/*!
Transformation Matrix v2.0
(c) Epistemex 2014-2015
www.epistemex.com
By Ken Fyrstenberg
Contributions by leeoniya.
License: MIT, header required.
*/
//#endregion
//#region src/renderElement.ts
var import_lottie_light_canvas = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	typeof document !== "undefined" && typeof navigator !== "undefined" && (function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory() : typeof define === "function" && define.amd ? define(factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, global.lottie = factory());
	})(exports, (function() {
		"use strict";
		var svgNS = "http://www.w3.org/2000/svg";
		var locationHref = "";
		var _useWebWorker = false;
		var initialDefaultFrame = -999999;
		var setWebWorker = function setWebWorker(flag) {
			_useWebWorker = !!flag;
		};
		var getWebWorker = function getWebWorker() {
			return _useWebWorker;
		};
		var setLocationHref = function setLocationHref(value) {
			locationHref = value;
		};
		var getLocationHref = function getLocationHref() {
			return locationHref;
		};
		function createTag(type) {
			return document.createElement(type);
		}
		function extendPrototype(sources, destination) {
			var i;
			var len = sources.length;
			var sourcePrototype;
			for (i = 0; i < len; i += 1) {
				sourcePrototype = sources[i].prototype;
				for (var attr in sourcePrototype) if (Object.prototype.hasOwnProperty.call(sourcePrototype, attr)) destination.prototype[attr] = sourcePrototype[attr];
			}
		}
		function createProxyFunction(prototype) {
			function ProxyFunction() {}
			ProxyFunction.prototype = prototype;
			return ProxyFunction;
		}
		var audioControllerFactory = function() {
			function AudioController(audioFactory) {
				this.audios = [];
				this.audioFactory = audioFactory;
				this._volume = 1;
				this._isMuted = false;
			}
			AudioController.prototype = {
				addAudio: function addAudio(audio) {
					this.audios.push(audio);
				},
				pause: function pause() {
					var i;
					var len = this.audios.length;
					for (i = 0; i < len; i += 1) this.audios[i].pause();
				},
				resume: function resume() {
					var i;
					var len = this.audios.length;
					for (i = 0; i < len; i += 1) this.audios[i].resume();
				},
				setRate: function setRate(rateValue) {
					var i;
					var len = this.audios.length;
					for (i = 0; i < len; i += 1) this.audios[i].setRate(rateValue);
				},
				createAudio: function createAudio(assetPath) {
					if (this.audioFactory) return this.audioFactory(assetPath);
					if (window.Howl) return new window.Howl({ src: [assetPath] });
					return {
						isPlaying: false,
						play: function play() {
							this.isPlaying = true;
						},
						seek: function seek() {
							this.isPlaying = false;
						},
						playing: function playing() {},
						rate: function rate() {},
						setVolume: function setVolume() {}
					};
				},
				setAudioFactory: function setAudioFactory(audioFactory) {
					this.audioFactory = audioFactory;
				},
				setVolume: function setVolume(value) {
					this._volume = value;
					this._updateVolume();
				},
				mute: function mute() {
					this._isMuted = true;
					this._updateVolume();
				},
				unmute: function unmute() {
					this._isMuted = false;
					this._updateVolume();
				},
				getVolume: function getVolume() {
					return this._volume;
				},
				_updateVolume: function _updateVolume() {
					var i;
					var len = this.audios.length;
					for (i = 0; i < len; i += 1) this.audios[i].volume(this._volume * (this._isMuted ? 0 : 1));
				}
			};
			return function() {
				return new AudioController();
			};
		}();
		var createTypedArray = function() {
			function createRegularArray(type, len) {
				var i = 0;
				var arr = [];
				var value;
				switch (type) {
					case "int16":
					case "uint8c":
						value = 1;
						break;
					default: value = 1.1;
				}
				for (i = 0; i < len; i += 1) arr.push(value);
				return arr;
			}
			function createTypedArrayFactory(type, len) {
				if (type === "float32") return new Float32Array(len);
				if (type === "int16") return new Int16Array(len);
				if (type === "uint8c") return new Uint8ClampedArray(len);
				return createRegularArray(type, len);
			}
			if (typeof Uint8ClampedArray === "function" && typeof Float32Array === "function") return createTypedArrayFactory;
			return createRegularArray;
		}();
		function createSizedArray(len) {
			return Array.apply(null, { length: len });
		}
		function _typeof$3(o) {
			"@babel/helpers - typeof";
			return _typeof$3 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
				return typeof o;
			} : function(o) {
				return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
			}, _typeof$3(o);
		}
		var subframeEnabled = true;
		var expressionsPlugin = null;
		var expressionsInterfaces = null;
		var idPrefix$1 = "";
		var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
		var bmPow = Math.pow;
		var bmSqrt = Math.sqrt;
		var bmFloor = Math.floor;
		var bmMin = Math.min;
		var BMMath = {};
		(function() {
			var propertyNames = [
				"abs",
				"acos",
				"acosh",
				"asin",
				"asinh",
				"atan",
				"atanh",
				"atan2",
				"ceil",
				"cbrt",
				"expm1",
				"clz32",
				"cos",
				"cosh",
				"exp",
				"floor",
				"fround",
				"hypot",
				"imul",
				"log",
				"log1p",
				"log2",
				"log10",
				"max",
				"min",
				"pow",
				"random",
				"round",
				"sign",
				"sin",
				"sinh",
				"sqrt",
				"tan",
				"tanh",
				"trunc",
				"E",
				"LN10",
				"LN2",
				"LOG10E",
				"LOG2E",
				"PI",
				"SQRT1_2",
				"SQRT2"
			];
			var i;
			var len = propertyNames.length;
			for (i = 0; i < len; i += 1) BMMath[propertyNames[i]] = Math[propertyNames[i]];
		})();
		BMMath.random = Math.random;
		BMMath.abs = function(val) {
			if (_typeof$3(val) === "object" && val.length) {
				var absArr = createSizedArray(val.length);
				var i;
				var len = val.length;
				for (i = 0; i < len; i += 1) absArr[i] = Math.abs(val[i]);
				return absArr;
			}
			return Math.abs(val);
		};
		var defaultCurveSegments = 150;
		var degToRads = Math.PI / 180;
		var roundCorner = .5519;
		function BMEnterFrameEvent(type, currentTime, totalTime, frameMultiplier) {
			this.type = type;
			this.currentTime = currentTime;
			this.totalTime = totalTime;
			this.direction = frameMultiplier < 0 ? -1 : 1;
		}
		function BMCompleteEvent(type, frameMultiplier) {
			this.type = type;
			this.direction = frameMultiplier < 0 ? -1 : 1;
		}
		function BMCompleteLoopEvent(type, totalLoops, currentLoop, frameMultiplier) {
			this.type = type;
			this.currentLoop = currentLoop;
			this.totalLoops = totalLoops;
			this.direction = frameMultiplier < 0 ? -1 : 1;
		}
		function BMSegmentStartEvent(type, firstFrame, totalFrames) {
			this.type = type;
			this.firstFrame = firstFrame;
			this.totalFrames = totalFrames;
		}
		function BMDestroyEvent(type, target) {
			this.type = type;
			this.target = target;
		}
		function BMRenderFrameErrorEvent(nativeError, currentTime) {
			this.type = "renderFrameError";
			this.nativeError = nativeError;
			this.currentTime = currentTime;
		}
		function BMConfigErrorEvent(nativeError) {
			this.type = "configError";
			this.nativeError = nativeError;
		}
		var createElementID = function() {
			var _count = 0;
			return function createID() {
				_count += 1;
				return idPrefix$1 + "__lottie_element_" + _count;
			};
		}();
		function HSVtoRGB(h, s, v) {
			var r;
			var g;
			var b;
			var i;
			var f;
			var p;
			var q;
			var t;
			i = Math.floor(h * 6);
			f = h * 6 - i;
			p = v * (1 - s);
			q = v * (1 - f * s);
			t = v * (1 - (1 - f) * s);
			switch (i % 6) {
				case 0:
					r = v;
					g = t;
					b = p;
					break;
				case 1:
					r = q;
					g = v;
					b = p;
					break;
				case 2:
					r = p;
					g = v;
					b = t;
					break;
				case 3:
					r = p;
					g = q;
					b = v;
					break;
				case 4:
					r = t;
					g = p;
					b = v;
					break;
				case 5:
					r = v;
					g = p;
					b = q;
			}
			return [
				r,
				g,
				b
			];
		}
		function RGBtoHSV(r, g, b) {
			var max = Math.max(r, g, b);
			var min = Math.min(r, g, b);
			var d = max - min;
			var h;
			var s = max === 0 ? 0 : d / max;
			var v = max / 255;
			switch (max) {
				case min:
					h = 0;
					break;
				case r:
					h = g - b + d * (g < b ? 6 : 0);
					h /= 6 * d;
					break;
				case g:
					h = b - r + d * 2;
					h /= 6 * d;
					break;
				case b:
					h = r - g + d * 4;
					h /= 6 * d;
			}
			return [
				h,
				s,
				v
			];
		}
		function addSaturationToRGB(color, offset) {
			var hsv = RGBtoHSV(color[0] * 255, color[1] * 255, color[2] * 255);
			hsv[1] += offset;
			if (hsv[1] > 1) hsv[1] = 1;
			else if (hsv[1] <= 0) hsv[1] = 0;
			return HSVtoRGB(hsv[0], hsv[1], hsv[2]);
		}
		function addBrightnessToRGB(color, offset) {
			var hsv = RGBtoHSV(color[0] * 255, color[1] * 255, color[2] * 255);
			hsv[2] += offset;
			if (hsv[2] > 1) hsv[2] = 1;
			else if (hsv[2] < 0) hsv[2] = 0;
			return HSVtoRGB(hsv[0], hsv[1], hsv[2]);
		}
		function addHueToRGB(color, offset) {
			var hsv = RGBtoHSV(color[0] * 255, color[1] * 255, color[2] * 255);
			hsv[0] += offset / 360;
			if (hsv[0] > 1) hsv[0] -= 1;
			else if (hsv[0] < 0) hsv[0] += 1;
			return HSVtoRGB(hsv[0], hsv[1], hsv[2]);
		}
		(function() {
			var colorMap = [];
			var i;
			var hex;
			for (i = 0; i < 256; i += 1) {
				hex = i.toString(16);
				colorMap[i] = hex.length === 1 ? "0" + hex : hex;
			}
			return function(r, g, b) {
				if (r < 0) r = 0;
				if (g < 0) g = 0;
				if (b < 0) b = 0;
				return "#" + colorMap[r] + colorMap[g] + colorMap[b];
			};
		})();
		var setSubframeEnabled = function setSubframeEnabled(flag) {
			subframeEnabled = !!flag;
		};
		var getSubframeEnabled = function getSubframeEnabled() {
			return subframeEnabled;
		};
		var setExpressionsPlugin = function setExpressionsPlugin(value) {
			expressionsPlugin = value;
		};
		var getExpressionsPlugin = function getExpressionsPlugin() {
			return expressionsPlugin;
		};
		var getExpressionInterfaces = function getExpressionInterfaces() {
			return expressionsInterfaces;
		};
		var setDefaultCurveSegments = function setDefaultCurveSegments(value) {
			defaultCurveSegments = value;
		};
		var getDefaultCurveSegments = function getDefaultCurveSegments() {
			return defaultCurveSegments;
		};
		var setIdPrefix = function setIdPrefix(value) {
			idPrefix$1 = value;
		};
		function createNS(type) {
			return document.createElementNS(svgNS, type);
		}
		function _typeof$2(o) {
			"@babel/helpers - typeof";
			return _typeof$2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
				return typeof o;
			} : function(o) {
				return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
			}, _typeof$2(o);
		}
		var dataManager = function() {
			var _counterId = 1;
			var processes = [];
			var workerFn;
			var workerInstance;
			var workerProxy = {
				onmessage: function onmessage() {},
				postMessage: function postMessage(path) {
					workerFn({ data: path });
				}
			};
			var _workerSelf = { postMessage: function postMessage(data) {
				workerProxy.onmessage({ data });
			} };
			function createWorker(fn) {
				if (window.Worker && window.Blob && getWebWorker()) {
					var blob = new Blob(["var _workerSelf = self; self.onmessage = ", fn.toString()], { type: "text/javascript" });
					var url = URL.createObjectURL(blob);
					return new Worker(url);
				}
				workerFn = fn;
				return workerProxy;
			}
			function setupWorker() {
				if (!workerInstance) {
					workerInstance = createWorker(function workerStart(e) {
						function dataFunctionManager() {
							function completeLayers(layers, comps) {
								var layerData;
								var i;
								var len = layers.length;
								var j;
								var jLen;
								var k;
								var kLen;
								for (i = 0; i < len; i += 1) {
									layerData = layers[i];
									if ("ks" in layerData && !layerData.completed) {
										layerData.completed = true;
										if (layerData.hasMask) {
											var maskProps = layerData.masksProperties;
											jLen = maskProps.length;
											for (j = 0; j < jLen; j += 1) if (maskProps[j].pt.k.i) convertPathsToAbsoluteValues(maskProps[j].pt.k);
											else {
												kLen = maskProps[j].pt.k.length;
												for (k = 0; k < kLen; k += 1) {
													if (maskProps[j].pt.k[k].s) convertPathsToAbsoluteValues(maskProps[j].pt.k[k].s[0]);
													if (maskProps[j].pt.k[k].e) convertPathsToAbsoluteValues(maskProps[j].pt.k[k].e[0]);
												}
											}
										}
										if (layerData.ty === 0) {
											layerData.layers = findCompLayers(layerData.refId, comps);
											completeLayers(layerData.layers, comps);
										} else if (layerData.ty === 4) completeShapes(layerData.shapes);
										else if (layerData.ty === 5) completeText(layerData);
									}
								}
							}
							function completeChars(chars, assets) {
								if (chars) {
									var i = 0;
									var len = chars.length;
									for (i = 0; i < len; i += 1) if (chars[i].t === 1) {
										chars[i].data.layers = findCompLayers(chars[i].data.refId, assets);
										completeLayers(chars[i].data.layers, assets);
									}
								}
							}
							function findComp(id, comps) {
								var i = 0;
								var len = comps.length;
								while (i < len) {
									if (comps[i].id === id) return comps[i];
									i += 1;
								}
								return null;
							}
							function findCompLayers(id, comps) {
								var comp = findComp(id, comps);
								if (comp) {
									if (!comp.layers.__used) {
										comp.layers.__used = true;
										return comp.layers;
									}
									return JSON.parse(JSON.stringify(comp.layers));
								}
								return null;
							}
							function completeShapes(arr) {
								var i;
								var len = arr.length;
								var j;
								var jLen;
								for (i = len - 1; i >= 0; i -= 1) if (arr[i].ty === "sh") {
									if (arr[i].ks.k.i) convertPathsToAbsoluteValues(arr[i].ks.k);
									else {
										jLen = arr[i].ks.k.length;
										for (j = 0; j < jLen; j += 1) {
											if (arr[i].ks.k[j].s) convertPathsToAbsoluteValues(arr[i].ks.k[j].s[0]);
											if (arr[i].ks.k[j].e) convertPathsToAbsoluteValues(arr[i].ks.k[j].e[0]);
										}
									}
								} else if (arr[i].ty === "gr") completeShapes(arr[i].it);
							}
							function convertPathsToAbsoluteValues(path) {
								var i;
								var len = path.i.length;
								for (i = 0; i < len; i += 1) {
									path.i[i][0] += path.v[i][0];
									path.i[i][1] += path.v[i][1];
									path.o[i][0] += path.v[i][0];
									path.o[i][1] += path.v[i][1];
								}
							}
							function checkVersion(minimum, animVersionString) {
								var animVersion = animVersionString ? animVersionString.split(".") : [
									100,
									100,
									100
								];
								if (minimum[0] > animVersion[0]) return true;
								if (animVersion[0] > minimum[0]) return false;
								if (minimum[1] > animVersion[1]) return true;
								if (animVersion[1] > minimum[1]) return false;
								if (minimum[2] > animVersion[2]) return true;
								if (animVersion[2] > minimum[2]) return false;
								return null;
							}
							var checkText = function() {
								var minimumVersion = [
									4,
									4,
									14
								];
								function updateTextLayer(textLayer) {
									var documentData = textLayer.t.d;
									textLayer.t.d = { k: [{
										s: documentData,
										t: 0
									}] };
								}
								function iterateLayers(layers) {
									var i;
									var len = layers.length;
									for (i = 0; i < len; i += 1) if (layers[i].ty === 5) updateTextLayer(layers[i]);
								}
								return function(animationData) {
									if (checkVersion(minimumVersion, animationData.v)) {
										iterateLayers(animationData.layers);
										if (animationData.assets) {
											var i;
											var len = animationData.assets.length;
											for (i = 0; i < len; i += 1) if (animationData.assets[i].layers) iterateLayers(animationData.assets[i].layers);
										}
									}
								};
							}();
							var checkChars = function() {
								var minimumVersion = [
									4,
									7,
									99
								];
								return function(animationData) {
									if (animationData.chars && !checkVersion(minimumVersion, animationData.v)) {
										var i;
										var len = animationData.chars.length;
										for (i = 0; i < len; i += 1) {
											var charData = animationData.chars[i];
											if (charData.data && charData.data.shapes) {
												completeShapes(charData.data.shapes);
												charData.data.ip = 0;
												charData.data.op = 99999;
												charData.data.st = 0;
												charData.data.sr = 1;
												charData.data.ks = {
													p: {
														k: [0, 0],
														a: 0
													},
													s: {
														k: [100, 100],
														a: 0
													},
													a: {
														k: [0, 0],
														a: 0
													},
													r: {
														k: 0,
														a: 0
													},
													o: {
														k: 100,
														a: 0
													}
												};
												if (!animationData.chars[i].t) {
													charData.data.shapes.push({ ty: "no" });
													charData.data.shapes[0].it.push({
														p: {
															k: [0, 0],
															a: 0
														},
														s: {
															k: [100, 100],
															a: 0
														},
														a: {
															k: [0, 0],
															a: 0
														},
														r: {
															k: 0,
															a: 0
														},
														o: {
															k: 100,
															a: 0
														},
														sk: {
															k: 0,
															a: 0
														},
														sa: {
															k: 0,
															a: 0
														},
														ty: "tr"
													});
												}
											}
										}
									}
								};
							}();
							var checkPathProperties = function() {
								var minimumVersion = [
									5,
									7,
									15
								];
								function updateTextLayer(textLayer) {
									var pathData = textLayer.t.p;
									if (typeof pathData.a === "number") pathData.a = {
										a: 0,
										k: pathData.a
									};
									if (typeof pathData.p === "number") pathData.p = {
										a: 0,
										k: pathData.p
									};
									if (typeof pathData.r === "number") pathData.r = {
										a: 0,
										k: pathData.r
									};
								}
								function iterateLayers(layers) {
									var i;
									var len = layers.length;
									for (i = 0; i < len; i += 1) if (layers[i].ty === 5) updateTextLayer(layers[i]);
								}
								return function(animationData) {
									if (checkVersion(minimumVersion, animationData.v)) {
										iterateLayers(animationData.layers);
										if (animationData.assets) {
											var i;
											var len = animationData.assets.length;
											for (i = 0; i < len; i += 1) if (animationData.assets[i].layers) iterateLayers(animationData.assets[i].layers);
										}
									}
								};
							}();
							var checkColors = function() {
								var minimumVersion = [
									4,
									1,
									9
								];
								function iterateShapes(shapes) {
									var i;
									var len = shapes.length;
									var j;
									var jLen;
									for (i = 0; i < len; i += 1) if (shapes[i].ty === "gr") iterateShapes(shapes[i].it);
									else if (shapes[i].ty === "fl" || shapes[i].ty === "st") {
										if (shapes[i].c.k && shapes[i].c.k[0].i) {
											jLen = shapes[i].c.k.length;
											for (j = 0; j < jLen; j += 1) {
												if (shapes[i].c.k[j].s) {
													shapes[i].c.k[j].s[0] /= 255;
													shapes[i].c.k[j].s[1] /= 255;
													shapes[i].c.k[j].s[2] /= 255;
													shapes[i].c.k[j].s[3] /= 255;
												}
												if (shapes[i].c.k[j].e) {
													shapes[i].c.k[j].e[0] /= 255;
													shapes[i].c.k[j].e[1] /= 255;
													shapes[i].c.k[j].e[2] /= 255;
													shapes[i].c.k[j].e[3] /= 255;
												}
											}
										} else {
											shapes[i].c.k[0] /= 255;
											shapes[i].c.k[1] /= 255;
											shapes[i].c.k[2] /= 255;
											shapes[i].c.k[3] /= 255;
										}
									}
								}
								function iterateLayers(layers) {
									var i;
									var len = layers.length;
									for (i = 0; i < len; i += 1) if (layers[i].ty === 4) iterateShapes(layers[i].shapes);
								}
								return function(animationData) {
									if (checkVersion(minimumVersion, animationData.v)) {
										iterateLayers(animationData.layers);
										if (animationData.assets) {
											var i;
											var len = animationData.assets.length;
											for (i = 0; i < len; i += 1) if (animationData.assets[i].layers) iterateLayers(animationData.assets[i].layers);
										}
									}
								};
							}();
							var checkShapes = function() {
								var minimumVersion = [
									4,
									4,
									18
								];
								function completeClosingShapes(arr) {
									var i;
									var len = arr.length;
									var j;
									var jLen;
									for (i = len - 1; i >= 0; i -= 1) if (arr[i].ty === "sh") {
										if (arr[i].ks.k.i) arr[i].ks.k.c = arr[i].closed;
										else {
											jLen = arr[i].ks.k.length;
											for (j = 0; j < jLen; j += 1) {
												if (arr[i].ks.k[j].s) arr[i].ks.k[j].s[0].c = arr[i].closed;
												if (arr[i].ks.k[j].e) arr[i].ks.k[j].e[0].c = arr[i].closed;
											}
										}
									} else if (arr[i].ty === "gr") completeClosingShapes(arr[i].it);
								}
								function iterateLayers(layers) {
									var layerData;
									var i;
									var len = layers.length;
									var j;
									var jLen;
									var k;
									var kLen;
									for (i = 0; i < len; i += 1) {
										layerData = layers[i];
										if (layerData.hasMask) {
											var maskProps = layerData.masksProperties;
											jLen = maskProps.length;
											for (j = 0; j < jLen; j += 1) if (maskProps[j].pt.k.i) maskProps[j].pt.k.c = maskProps[j].cl;
											else {
												kLen = maskProps[j].pt.k.length;
												for (k = 0; k < kLen; k += 1) {
													if (maskProps[j].pt.k[k].s) maskProps[j].pt.k[k].s[0].c = maskProps[j].cl;
													if (maskProps[j].pt.k[k].e) maskProps[j].pt.k[k].e[0].c = maskProps[j].cl;
												}
											}
										}
										if (layerData.ty === 4) completeClosingShapes(layerData.shapes);
									}
								}
								return function(animationData) {
									if (checkVersion(minimumVersion, animationData.v)) {
										iterateLayers(animationData.layers);
										if (animationData.assets) {
											var i;
											var len = animationData.assets.length;
											for (i = 0; i < len; i += 1) if (animationData.assets[i].layers) iterateLayers(animationData.assets[i].layers);
										}
									}
								};
							}();
							function completeData(animationData) {
								if (animationData.__complete) return;
								checkColors(animationData);
								checkText(animationData);
								checkChars(animationData);
								checkPathProperties(animationData);
								checkShapes(animationData);
								completeLayers(animationData.layers, animationData.assets);
								completeChars(animationData.chars, animationData.assets);
								animationData.__complete = true;
							}
							function completeText(data) {
								if (data.t.a.length === 0 && !("m" in data.t.p)) {}
							}
							var moduleOb = {};
							moduleOb.completeData = completeData;
							moduleOb.checkColors = checkColors;
							moduleOb.checkChars = checkChars;
							moduleOb.checkPathProperties = checkPathProperties;
							moduleOb.checkShapes = checkShapes;
							moduleOb.completeLayers = completeLayers;
							return moduleOb;
						}
						if (!_workerSelf.dataManager) _workerSelf.dataManager = dataFunctionManager();
						if (!_workerSelf.assetLoader) _workerSelf.assetLoader = function() {
							function formatResponse(xhr) {
								var contentTypeHeader = xhr.getResponseHeader("content-type");
								if (contentTypeHeader && xhr.responseType === "json" && contentTypeHeader.indexOf("json") !== -1) return xhr.response;
								if (xhr.response && _typeof$2(xhr.response) === "object") return xhr.response;
								if (xhr.response && typeof xhr.response === "string") return JSON.parse(xhr.response);
								if (xhr.responseText) return JSON.parse(xhr.responseText);
								return null;
							}
							function loadAsset(path, fullPath, callback, errorCallback) {
								var response;
								var xhr = new XMLHttpRequest();
								try {
									xhr.responseType = "json";
								} catch (err) {}
								xhr.onreadystatechange = function() {
									if (xhr.readyState === 4) {
										if (xhr.status === 200) {
											response = formatResponse(xhr);
											callback(response);
										} else try {
											response = formatResponse(xhr);
											callback(response);
										} catch (err) {
											if (errorCallback) errorCallback(err);
										}
									}
								};
								try {
									xhr.open([
										"G",
										"E",
										"T"
									].join(""), path, true);
								} catch (error) {
									xhr.open([
										"G",
										"E",
										"T"
									].join(""), fullPath + "/" + path, true);
								}
								xhr.send();
							}
							return { load: loadAsset };
						}();
						if (e.data.type === "loadAnimation") _workerSelf.assetLoader.load(e.data.path, e.data.fullPath, function(data) {
							_workerSelf.dataManager.completeData(data);
							_workerSelf.postMessage({
								id: e.data.id,
								payload: data,
								status: "success"
							});
						}, function() {
							_workerSelf.postMessage({
								id: e.data.id,
								status: "error"
							});
						});
						else if (e.data.type === "complete") {
							var animation = e.data.animation;
							_workerSelf.dataManager.completeData(animation);
							_workerSelf.postMessage({
								id: e.data.id,
								payload: animation,
								status: "success"
							});
						} else if (e.data.type === "loadData") _workerSelf.assetLoader.load(e.data.path, e.data.fullPath, function(data) {
							_workerSelf.postMessage({
								id: e.data.id,
								payload: data,
								status: "success"
							});
						}, function() {
							_workerSelf.postMessage({
								id: e.data.id,
								status: "error"
							});
						});
					});
					workerInstance.onmessage = function(event) {
						var data = event.data;
						var id = data.id;
						var process = processes[id];
						processes[id] = null;
						if (data.status === "success") process.onComplete(data.payload);
						else if (process.onError) process.onError();
					};
				}
			}
			function createProcess(onComplete, onError) {
				_counterId += 1;
				var id = "processId_" + _counterId;
				processes[id] = {
					onComplete,
					onError
				};
				return id;
			}
			function loadAnimation(path, onComplete, onError) {
				setupWorker();
				var processId = createProcess(onComplete, onError);
				workerInstance.postMessage({
					type: "loadAnimation",
					path,
					fullPath: window.location.origin + window.location.pathname,
					id: processId
				});
			}
			function loadData(path, onComplete, onError) {
				setupWorker();
				var processId = createProcess(onComplete, onError);
				workerInstance.postMessage({
					type: "loadData",
					path,
					fullPath: window.location.origin + window.location.pathname,
					id: processId
				});
			}
			function completeAnimation(anim, onComplete, onError) {
				setupWorker();
				var processId = createProcess(onComplete, onError);
				workerInstance.postMessage({
					type: "complete",
					animation: anim,
					id: processId
				});
			}
			return {
				loadAnimation,
				loadData,
				completeAnimation
			};
		}();
		var ImagePreloader = function() {
			var proxyImage = function() {
				var canvas = createTag("canvas");
				canvas.width = 1;
				canvas.height = 1;
				var ctx = canvas.getContext("2d");
				ctx.fillStyle = "rgba(0,0,0,0)";
				ctx.fillRect(0, 0, 1, 1);
				return canvas;
			}();
			function imageLoaded() {
				this.loadedAssets += 1;
				if (this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages) {
					if (this.imagesLoadedCb) this.imagesLoadedCb(null);
				}
			}
			function footageLoaded() {
				this.loadedFootagesCount += 1;
				if (this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages) {
					if (this.imagesLoadedCb) this.imagesLoadedCb(null);
				}
			}
			function getAssetsPath(assetData, assetsPath, originalPath) {
				var path = "";
				if (assetData.e) path = assetData.p;
				else if (assetsPath) {
					var imagePath = assetData.p;
					if (imagePath.indexOf("images/") !== -1) imagePath = imagePath.split("/")[1];
					path = assetsPath + imagePath;
				} else {
					path = originalPath;
					path += assetData.u ? assetData.u : "";
					path += assetData.p;
				}
				return path;
			}
			function testImageLoaded(img) {
				var _count = 0;
				var intervalId = setInterval(function() {
					if (img.getBBox().width || _count > 500) {
						this._imageLoaded();
						clearInterval(intervalId);
					}
					_count += 1;
				}.bind(this), 50);
			}
			function createImageData(assetData) {
				var path = getAssetsPath(assetData, this.assetsPath, this.path);
				var img = createNS("image");
				if (isSafari) this.testImageLoaded(img);
				else img.addEventListener("load", this._imageLoaded, false);
				img.addEventListener("error", function() {
					ob.img = proxyImage;
					this._imageLoaded();
				}.bind(this), false);
				img.setAttributeNS("http://www.w3.org/1999/xlink", "href", path);
				if (this._elementHelper.append) this._elementHelper.append(img);
				else this._elementHelper.appendChild(img);
				var ob = {
					img,
					assetData
				};
				return ob;
			}
			function createImgData(assetData) {
				var path = getAssetsPath(assetData, this.assetsPath, this.path);
				var img = createTag("img");
				img.crossOrigin = "anonymous";
				img.addEventListener("load", this._imageLoaded, false);
				img.addEventListener("error", function() {
					ob.img = proxyImage;
					this._imageLoaded();
				}.bind(this), false);
				img.src = path;
				var ob = {
					img,
					assetData
				};
				return ob;
			}
			function createFootageData(data) {
				var ob = { assetData: data };
				var path = getAssetsPath(data, this.assetsPath, this.path);
				dataManager.loadData(path, function(footageData) {
					ob.img = footageData;
					this._footageLoaded();
				}.bind(this), function() {
					ob.img = {};
					this._footageLoaded();
				}.bind(this));
				return ob;
			}
			function loadAssets(assets, cb) {
				this.imagesLoadedCb = cb;
				var i;
				var len = assets.length;
				for (i = 0; i < len; i += 1) if (!assets[i].layers) {
					if (!assets[i].t || assets[i].t === "seq") {
						this.totalImages += 1;
						this.images.push(this._createImageData(assets[i]));
					} else if (assets[i].t === 3) {
						this.totalFootages += 1;
						this.images.push(this.createFootageData(assets[i]));
					}
				}
			}
			function setPath(path) {
				this.path = path || "";
			}
			function setAssetsPath(path) {
				this.assetsPath = path || "";
			}
			function getAsset(assetData) {
				var i = 0;
				var len = this.images.length;
				while (i < len) {
					if (this.images[i].assetData === assetData) return this.images[i].img;
					i += 1;
				}
				return null;
			}
			function destroy() {
				this.imagesLoadedCb = null;
				this.images.length = 0;
			}
			function loadedImages() {
				return this.totalImages === this.loadedAssets;
			}
			function loadedFootages() {
				return this.totalFootages === this.loadedFootagesCount;
			}
			function setCacheType(type, elementHelper) {
				if (type === "svg") {
					this._elementHelper = elementHelper;
					this._createImageData = this.createImageData.bind(this);
				} else this._createImageData = this.createImgData.bind(this);
			}
			function ImagePreloaderFactory() {
				this._imageLoaded = imageLoaded.bind(this);
				this._footageLoaded = footageLoaded.bind(this);
				this.testImageLoaded = testImageLoaded.bind(this);
				this.createFootageData = createFootageData.bind(this);
				this.assetsPath = "";
				this.path = "";
				this.totalImages = 0;
				this.totalFootages = 0;
				this.loadedAssets = 0;
				this.loadedFootagesCount = 0;
				this.imagesLoadedCb = null;
				this.images = [];
			}
			ImagePreloaderFactory.prototype = {
				loadAssets,
				setAssetsPath,
				setPath,
				loadedImages,
				loadedFootages,
				destroy,
				getAsset,
				createImgData,
				createImageData,
				imageLoaded,
				footageLoaded,
				setCacheType
			};
			return ImagePreloaderFactory;
		}();
		function BaseEvent() {}
		BaseEvent.prototype = {
			triggerEvent: function triggerEvent(eventName, args) {
				if (this._cbs[eventName]) {
					var callbacks = this._cbs[eventName];
					for (var i = 0; i < callbacks.length; i += 1) callbacks[i](args);
				}
			},
			addEventListener: function addEventListener(eventName, callback) {
				if (!this._cbs[eventName]) this._cbs[eventName] = [];
				this._cbs[eventName].push(callback);
				return function() {
					this.removeEventListener(eventName, callback);
				}.bind(this);
			},
			removeEventListener: function removeEventListener(eventName, callback) {
				if (!callback) this._cbs[eventName] = null;
				else if (this._cbs[eventName]) {
					var i = 0;
					var len = this._cbs[eventName].length;
					while (i < len) {
						if (this._cbs[eventName][i] === callback) {
							this._cbs[eventName].splice(i, 1);
							i -= 1;
							len -= 1;
						}
						i += 1;
					}
					if (!this._cbs[eventName].length) this._cbs[eventName] = null;
				}
			}
		};
		var markerParser = function() {
			function parsePayloadLines(payload) {
				var lines = payload.split("\r\n");
				var keys = {};
				var line;
				var keysCount = 0;
				for (var i = 0; i < lines.length; i += 1) {
					line = lines[i].split(":");
					if (line.length === 2) {
						keys[line[0]] = line[1].trim();
						keysCount += 1;
					}
				}
				if (keysCount === 0) throw new Error();
				return keys;
			}
			return function(_markers) {
				var markers = [];
				for (var i = 0; i < _markers.length; i += 1) {
					var _marker = _markers[i];
					var markerData = {
						time: _marker.tm,
						duration: _marker.dr
					};
					try {
						markerData.payload = JSON.parse(_markers[i].cm);
					} catch (_) {
						try {
							markerData.payload = parsePayloadLines(_markers[i].cm);
						} catch (__) {
							markerData.payload = { name: _markers[i].cm };
						}
					}
					markers.push(markerData);
				}
				return markers;
			};
		}();
		var ProjectInterface = function() {
			function registerComposition(comp) {
				this.compositions.push(comp);
			}
			return function() {
				function _thisProjectFunction(name) {
					var i = 0;
					var len = this.compositions.length;
					while (i < len) {
						if (this.compositions[i].data && this.compositions[i].data.nm === name) {
							if (this.compositions[i].prepareFrame && this.compositions[i].data.xt) this.compositions[i].prepareFrame(this.currentFrame);
							return this.compositions[i].compInterface;
						}
						i += 1;
					}
					return null;
				}
				_thisProjectFunction.compositions = [];
				_thisProjectFunction.currentFrame = 0;
				_thisProjectFunction.registerComposition = registerComposition;
				return _thisProjectFunction;
			};
		}();
		var renderers = {};
		var registerRenderer = function registerRenderer(key, value) {
			renderers[key] = value;
		};
		function getRenderer(key) {
			return renderers[key];
		}
		function getRegisteredRenderer() {
			if (renderers.canvas) return "canvas";
			for (var key in renderers) if (renderers[key]) return key;
			return "";
		}
		function _typeof$1(o) {
			"@babel/helpers - typeof";
			return _typeof$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
				return typeof o;
			} : function(o) {
				return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
			}, _typeof$1(o);
		}
		var AnimationItem = function AnimationItem() {
			this._cbs = [];
			this.name = "";
			this.path = "";
			this.isLoaded = false;
			this.currentFrame = 0;
			this.currentRawFrame = 0;
			this.firstFrame = 0;
			this.totalFrames = 0;
			this.frameRate = 0;
			this.frameMult = 0;
			this.playSpeed = 1;
			this.playDirection = 1;
			this.playCount = 0;
			this.animationData = {};
			this.assets = [];
			this.isPaused = true;
			this.autoplay = false;
			this.loop = true;
			this.renderer = null;
			this.animationID = createElementID();
			this.assetsPath = "";
			this.timeCompleted = 0;
			this.segmentPos = 0;
			this.isSubframeEnabled = getSubframeEnabled();
			this.segments = [];
			this._idle = true;
			this._completedLoop = false;
			this.projectInterface = ProjectInterface();
			this.imagePreloader = new ImagePreloader();
			this.audioController = audioControllerFactory();
			this.markers = [];
			this.configAnimation = this.configAnimation.bind(this);
			this.onSetupError = this.onSetupError.bind(this);
			this.onSegmentComplete = this.onSegmentComplete.bind(this);
			this.drawnFrameEvent = new BMEnterFrameEvent("drawnFrame", 0, 0, 0);
			this.expressionsPlugin = getExpressionsPlugin();
		};
		extendPrototype([BaseEvent], AnimationItem);
		AnimationItem.prototype.setParams = function(params) {
			if (params.wrapper || params.container) this.wrapper = params.wrapper || params.container;
			var animType = "svg";
			if (params.animType) animType = params.animType;
			else if (params.renderer) animType = params.renderer;
			var RendererClass = getRenderer(animType);
			this.renderer = new RendererClass(this, params.rendererSettings);
			this.imagePreloader.setCacheType(animType, this.renderer.globalData.defs);
			this.renderer.setProjectInterface(this.projectInterface);
			this.animType = animType;
			if (params.loop === "" || params.loop === null || params.loop === void 0 || params.loop === true) this.loop = true;
			else if (params.loop === false) this.loop = false;
			else this.loop = parseInt(params.loop, 10);
			this.autoplay = "autoplay" in params ? params.autoplay : true;
			this.name = params.name ? params.name : "";
			this.autoloadSegments = Object.prototype.hasOwnProperty.call(params, "autoloadSegments") ? params.autoloadSegments : true;
			this.assetsPath = params.assetsPath;
			this.initialSegment = params.initialSegment;
			if (params.audioFactory) this.audioController.setAudioFactory(params.audioFactory);
			if (params.animationData) this.setupAnimation(params.animationData);
			else if (params.path) {
				if (params.path.lastIndexOf("\\") !== -1) this.path = params.path.substr(0, params.path.lastIndexOf("\\") + 1);
				else this.path = params.path.substr(0, params.path.lastIndexOf("/") + 1);
				this.fileName = params.path.substr(params.path.lastIndexOf("/") + 1);
				this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json"));
				dataManager.loadAnimation(params.path, this.configAnimation, this.onSetupError);
			}
		};
		AnimationItem.prototype.onSetupError = function() {
			this.trigger("data_failed");
		};
		AnimationItem.prototype.setupAnimation = function(data) {
			dataManager.completeAnimation(data, this.configAnimation);
		};
		AnimationItem.prototype.setData = function(wrapper, animationData) {
			if (animationData) {
				if (_typeof$1(animationData) !== "object") animationData = JSON.parse(animationData);
			}
			var params = {
				wrapper,
				animationData
			};
			var wrapperAttributes = wrapper.attributes;
			params.path = wrapperAttributes.getNamedItem("data-animation-path") ? wrapperAttributes.getNamedItem("data-animation-path").value : wrapperAttributes.getNamedItem("data-bm-path") ? wrapperAttributes.getNamedItem("data-bm-path").value : wrapperAttributes.getNamedItem("bm-path") ? wrapperAttributes.getNamedItem("bm-path").value : "";
			params.animType = wrapperAttributes.getNamedItem("data-anim-type") ? wrapperAttributes.getNamedItem("data-anim-type").value : wrapperAttributes.getNamedItem("data-bm-type") ? wrapperAttributes.getNamedItem("data-bm-type").value : wrapperAttributes.getNamedItem("bm-type") ? wrapperAttributes.getNamedItem("bm-type").value : wrapperAttributes.getNamedItem("data-bm-renderer") ? wrapperAttributes.getNamedItem("data-bm-renderer").value : wrapperAttributes.getNamedItem("bm-renderer") ? wrapperAttributes.getNamedItem("bm-renderer").value : getRegisteredRenderer() || "canvas";
			var loop = wrapperAttributes.getNamedItem("data-anim-loop") ? wrapperAttributes.getNamedItem("data-anim-loop").value : wrapperAttributes.getNamedItem("data-bm-loop") ? wrapperAttributes.getNamedItem("data-bm-loop").value : wrapperAttributes.getNamedItem("bm-loop") ? wrapperAttributes.getNamedItem("bm-loop").value : "";
			if (loop === "false") params.loop = false;
			else if (loop === "true") params.loop = true;
			else if (loop !== "") params.loop = parseInt(loop, 10);
			params.autoplay = (wrapperAttributes.getNamedItem("data-anim-autoplay") ? wrapperAttributes.getNamedItem("data-anim-autoplay").value : wrapperAttributes.getNamedItem("data-bm-autoplay") ? wrapperAttributes.getNamedItem("data-bm-autoplay").value : wrapperAttributes.getNamedItem("bm-autoplay") ? wrapperAttributes.getNamedItem("bm-autoplay").value : true) !== "false";
			params.name = wrapperAttributes.getNamedItem("data-name") ? wrapperAttributes.getNamedItem("data-name").value : wrapperAttributes.getNamedItem("data-bm-name") ? wrapperAttributes.getNamedItem("data-bm-name").value : wrapperAttributes.getNamedItem("bm-name") ? wrapperAttributes.getNamedItem("bm-name").value : "";
			if ((wrapperAttributes.getNamedItem("data-anim-prerender") ? wrapperAttributes.getNamedItem("data-anim-prerender").value : wrapperAttributes.getNamedItem("data-bm-prerender") ? wrapperAttributes.getNamedItem("data-bm-prerender").value : wrapperAttributes.getNamedItem("bm-prerender") ? wrapperAttributes.getNamedItem("bm-prerender").value : "") === "false") params.prerender = false;
			if (!params.path) this.trigger("destroy");
			else this.setParams(params);
		};
		AnimationItem.prototype.includeLayers = function(data) {
			if (data.op > this.animationData.op) {
				this.animationData.op = data.op;
				this.totalFrames = Math.floor(data.op - this.animationData.ip);
			}
			var layers = this.animationData.layers;
			var i;
			var len = layers.length;
			var newLayers = data.layers;
			var j;
			var jLen = newLayers.length;
			for (j = 0; j < jLen; j += 1) {
				i = 0;
				while (i < len) {
					if (layers[i].id === newLayers[j].id) {
						layers[i] = newLayers[j];
						break;
					}
					i += 1;
				}
			}
			if (data.chars || data.fonts) {
				this.renderer.globalData.fontManager.addChars(data.chars);
				this.renderer.globalData.fontManager.addFonts(data.fonts, this.renderer.globalData.defs);
			}
			if (data.assets) {
				len = data.assets.length;
				for (i = 0; i < len; i += 1) this.animationData.assets.push(data.assets[i]);
			}
			this.animationData.__complete = false;
			dataManager.completeAnimation(this.animationData, this.onSegmentComplete);
		};
		AnimationItem.prototype.onSegmentComplete = function(data) {
			this.animationData = data;
			var expressionsPlugin = getExpressionsPlugin();
			if (expressionsPlugin) expressionsPlugin.initExpressions(this);
			this.loadNextSegment();
		};
		AnimationItem.prototype.loadNextSegment = function() {
			var segments = this.animationData.segments;
			if (!segments || segments.length === 0 || !this.autoloadSegments) {
				this.trigger("data_ready");
				this.timeCompleted = this.totalFrames;
				return;
			}
			var segment = segments.shift();
			this.timeCompleted = segment.time * this.frameRate;
			var segmentPath = this.path + this.fileName + "_" + this.segmentPos + ".json";
			this.segmentPos += 1;
			dataManager.loadData(segmentPath, this.includeLayers.bind(this), function() {
				this.trigger("data_failed");
			}.bind(this));
		};
		AnimationItem.prototype.loadSegments = function() {
			if (!this.animationData.segments) this.timeCompleted = this.totalFrames;
			this.loadNextSegment();
		};
		AnimationItem.prototype.imagesLoaded = function() {
			this.trigger("loaded_images");
			this.checkLoaded();
		};
		AnimationItem.prototype.preloadImages = function() {
			this.imagePreloader.setAssetsPath(this.assetsPath);
			this.imagePreloader.setPath(this.path);
			this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this));
		};
		AnimationItem.prototype.configAnimation = function(animData) {
			if (!this.renderer) return;
			try {
				this.animationData = animData;
				if (this.initialSegment) {
					this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]);
					this.firstFrame = Math.round(this.initialSegment[0]);
				} else {
					this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip);
					this.firstFrame = Math.round(this.animationData.ip);
				}
				this.renderer.configAnimation(animData);
				if (!animData.assets) animData.assets = [];
				this.assets = this.animationData.assets;
				this.frameRate = this.animationData.fr;
				this.frameMult = this.animationData.fr / 1e3;
				this.renderer.searchExtraCompositions(animData.assets);
				this.markers = markerParser(animData.markers || []);
				this.trigger("config_ready");
				this.preloadImages();
				this.loadSegments();
				this.updaFrameModifier();
				this.waitForFontsLoaded();
				if (this.isPaused) this.audioController.pause();
			} catch (error) {
				this.triggerConfigError(error);
			}
		};
		AnimationItem.prototype.waitForFontsLoaded = function() {
			if (!this.renderer) return;
			if (this.renderer.globalData.fontManager.isLoaded) this.checkLoaded();
			else setTimeout(this.waitForFontsLoaded.bind(this), 20);
		};
		AnimationItem.prototype.checkLoaded = function() {
			if (!this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || this.renderer.rendererType !== "canvas") && this.imagePreloader.loadedFootages()) {
				this.isLoaded = true;
				var expressionsPlugin = getExpressionsPlugin();
				if (expressionsPlugin) expressionsPlugin.initExpressions(this);
				this.renderer.initItems();
				setTimeout(function() {
					this.trigger("DOMLoaded");
				}.bind(this), 0);
				this.gotoFrame();
				if (this.autoplay) this.play();
			}
		};
		AnimationItem.prototype.resize = function(width, height) {
			var _width = typeof width === "number" ? width : void 0;
			var _height = typeof height === "number" ? height : void 0;
			this.renderer.updateContainerSize(_width, _height);
		};
		AnimationItem.prototype.setSubframe = function(flag) {
			this.isSubframeEnabled = !!flag;
		};
		AnimationItem.prototype.gotoFrame = function() {
			this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame;
			if (this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted) this.currentFrame = this.timeCompleted;
			this.trigger("enterFrame");
			this.renderFrame();
			this.trigger("drawnFrame");
		};
		AnimationItem.prototype.renderFrame = function() {
			if (this.isLoaded === false || !this.renderer) return;
			try {
				if (this.expressionsPlugin) this.expressionsPlugin.resetFrame();
				this.renderer.renderFrame(this.currentFrame + this.firstFrame);
			} catch (error) {
				this.triggerRenderFrameError(error);
			}
		};
		AnimationItem.prototype.play = function(name) {
			if (name && this.name !== name) return;
			if (this.isPaused === true) {
				this.isPaused = false;
				this.trigger("_play");
				this.audioController.resume();
				if (this._idle) {
					this._idle = false;
					this.trigger("_active");
				}
			}
		};
		AnimationItem.prototype.pause = function(name) {
			if (name && this.name !== name) return;
			if (this.isPaused === false) {
				this.isPaused = true;
				this.trigger("_pause");
				this._idle = true;
				this.trigger("_idle");
				this.audioController.pause();
			}
		};
		AnimationItem.prototype.togglePause = function(name) {
			if (name && this.name !== name) return;
			if (this.isPaused === true) this.play();
			else this.pause();
		};
		AnimationItem.prototype.stop = function(name) {
			if (name && this.name !== name) return;
			this.pause();
			this.playCount = 0;
			this._completedLoop = false;
			this.setCurrentRawFrameValue(0);
		};
		AnimationItem.prototype.getMarkerData = function(markerName) {
			var marker;
			for (var i = 0; i < this.markers.length; i += 1) {
				marker = this.markers[i];
				if (marker.payload && marker.payload.name === markerName) return marker;
			}
			return null;
		};
		AnimationItem.prototype.goToAndStop = function(value, isFrame, name) {
			if (name && this.name !== name) return;
			var numValue = Number(value);
			if (isNaN(numValue)) {
				var marker = this.getMarkerData(value);
				if (marker) this.goToAndStop(marker.time, true);
			} else if (isFrame) this.setCurrentRawFrameValue(value);
			else this.setCurrentRawFrameValue(value * this.frameModifier);
			this.pause();
		};
		AnimationItem.prototype.goToAndPlay = function(value, isFrame, name) {
			if (name && this.name !== name) return;
			var numValue = Number(value);
			if (isNaN(numValue)) {
				var marker = this.getMarkerData(value);
				if (marker) {
					if (!marker.duration) this.goToAndStop(marker.time, true);
					else this.playSegments([marker.time, marker.time + marker.duration], true);
				}
			} else this.goToAndStop(numValue, isFrame, name);
			this.play();
		};
		AnimationItem.prototype.advanceTime = function(value) {
			if (this.isPaused === true || this.isLoaded === false) return;
			var nextValue = this.currentRawFrame + value * this.frameModifier;
			var _isComplete = false;
			if (nextValue >= this.totalFrames - 1 && this.frameModifier > 0) {
				if (!this.loop || this.playCount === this.loop) {
					if (!this.checkSegments(nextValue > this.totalFrames ? nextValue % this.totalFrames : 0)) {
						_isComplete = true;
						nextValue = this.totalFrames - 1;
					}
				} else if (nextValue >= this.totalFrames) {
					this.playCount += 1;
					if (!this.checkSegments(nextValue % this.totalFrames)) {
						this.setCurrentRawFrameValue(nextValue % this.totalFrames);
						this._completedLoop = true;
						this.trigger("loopComplete");
					}
				} else this.setCurrentRawFrameValue(nextValue);
			} else if (nextValue < 0) {
				if (!this.checkSegments(nextValue % this.totalFrames)) {
					if (this.loop && !(this.playCount-- <= 0 && this.loop !== true)) {
						this.setCurrentRawFrameValue(this.totalFrames + nextValue % this.totalFrames);
						if (!this._completedLoop) this._completedLoop = true;
						else this.trigger("loopComplete");
					} else {
						_isComplete = true;
						nextValue = 0;
					}
				}
			} else this.setCurrentRawFrameValue(nextValue);
			if (_isComplete) {
				this.setCurrentRawFrameValue(nextValue);
				this.pause();
				this.trigger("complete");
			}
		};
		AnimationItem.prototype.adjustSegment = function(arr, offset) {
			this.playCount = 0;
			if (arr[1] < arr[0]) {
				if (this.frameModifier > 0) {
					if (this.playSpeed < 0) this.setSpeed(-this.playSpeed);
					else this.setDirection(-1);
				}
				this.totalFrames = arr[0] - arr[1];
				this.timeCompleted = this.totalFrames;
				this.firstFrame = arr[1];
				this.setCurrentRawFrameValue(this.totalFrames - .001 - offset);
			} else if (arr[1] > arr[0]) {
				if (this.frameModifier < 0) {
					if (this.playSpeed < 0) this.setSpeed(-this.playSpeed);
					else this.setDirection(1);
				}
				this.totalFrames = arr[1] - arr[0];
				this.timeCompleted = this.totalFrames;
				this.firstFrame = arr[0];
				this.setCurrentRawFrameValue(.001 + offset);
			}
			this.trigger("segmentStart");
		};
		AnimationItem.prototype.setSegment = function(init, end) {
			var pendingFrame = -1;
			if (this.isPaused) {
				if (this.currentRawFrame + this.firstFrame < init) pendingFrame = init;
				else if (this.currentRawFrame + this.firstFrame > end) pendingFrame = end - init;
			}
			this.firstFrame = init;
			this.totalFrames = end - init;
			this.timeCompleted = this.totalFrames;
			if (pendingFrame !== -1) this.goToAndStop(pendingFrame, true);
		};
		AnimationItem.prototype.playSegments = function(arr, forceFlag) {
			if (forceFlag) this.segments.length = 0;
			if (_typeof$1(arr[0]) === "object") {
				var i;
				var len = arr.length;
				for (i = 0; i < len; i += 1) this.segments.push(arr[i]);
			} else this.segments.push(arr);
			if (this.segments.length && forceFlag) this.adjustSegment(this.segments.shift(), 0);
			if (this.isPaused) this.play();
		};
		AnimationItem.prototype.resetSegments = function(forceFlag) {
			this.segments.length = 0;
			this.segments.push([this.animationData.ip, this.animationData.op]);
			if (forceFlag) this.checkSegments(0);
		};
		AnimationItem.prototype.checkSegments = function(offset) {
			if (this.segments.length) {
				this.adjustSegment(this.segments.shift(), offset);
				return true;
			}
			return false;
		};
		AnimationItem.prototype.destroy = function(name) {
			if (name && this.name !== name || !this.renderer) return;
			this.renderer.destroy();
			this.imagePreloader.destroy();
			this.trigger("destroy");
			this._cbs = null;
			this.onEnterFrame = null;
			this.onLoopComplete = null;
			this.onComplete = null;
			this.onSegmentStart = null;
			this.onDestroy = null;
			this.renderer = null;
			this.expressionsPlugin = null;
			this.imagePreloader = null;
			this.projectInterface = null;
		};
		AnimationItem.prototype.setCurrentRawFrameValue = function(value) {
			this.currentRawFrame = value;
			this.gotoFrame();
		};
		AnimationItem.prototype.setSpeed = function(val) {
			this.playSpeed = val;
			this.updaFrameModifier();
		};
		AnimationItem.prototype.setDirection = function(val) {
			this.playDirection = val < 0 ? -1 : 1;
			this.updaFrameModifier();
		};
		AnimationItem.prototype.setLoop = function(isLooping) {
			this.loop = isLooping;
		};
		AnimationItem.prototype.setVolume = function(val, name) {
			if (name && this.name !== name) return;
			this.audioController.setVolume(val);
		};
		AnimationItem.prototype.getVolume = function() {
			return this.audioController.getVolume();
		};
		AnimationItem.prototype.mute = function(name) {
			if (name && this.name !== name) return;
			this.audioController.mute();
		};
		AnimationItem.prototype.unmute = function(name) {
			if (name && this.name !== name) return;
			this.audioController.unmute();
		};
		AnimationItem.prototype.updaFrameModifier = function() {
			this.frameModifier = this.frameMult * this.playSpeed * this.playDirection;
			this.audioController.setRate(this.playSpeed * this.playDirection);
		};
		AnimationItem.prototype.getPath = function() {
			return this.path;
		};
		AnimationItem.prototype.getAssetsPath = function(assetData) {
			var path = "";
			if (assetData.e) path = assetData.p;
			else if (this.assetsPath) {
				var imagePath = assetData.p;
				if (imagePath.indexOf("images/") !== -1) imagePath = imagePath.split("/")[1];
				path = this.assetsPath + imagePath;
			} else {
				path = this.path;
				path += assetData.u ? assetData.u : "";
				path += assetData.p;
			}
			return path;
		};
		AnimationItem.prototype.getAssetData = function(id) {
			var i = 0;
			var len = this.assets.length;
			while (i < len) {
				if (id === this.assets[i].id) return this.assets[i];
				i += 1;
			}
			return null;
		};
		AnimationItem.prototype.hide = function() {
			this.renderer.hide();
		};
		AnimationItem.prototype.show = function() {
			this.renderer.show();
		};
		AnimationItem.prototype.getDuration = function(isFrame) {
			return isFrame ? this.totalFrames : this.totalFrames / this.frameRate;
		};
		AnimationItem.prototype.updateDocumentData = function(path, documentData, index) {
			try {
				this.renderer.getElementByPath(path).updateDocumentData(documentData, index);
			} catch (error) {}
		};
		AnimationItem.prototype.trigger = function(name) {
			if (this._cbs && this._cbs[name]) switch (name) {
				case "enterFrame":
					this.triggerEvent(name, new BMEnterFrameEvent(name, this.currentFrame, this.totalFrames, this.frameModifier));
					break;
				case "drawnFrame":
					this.drawnFrameEvent.currentTime = this.currentFrame;
					this.drawnFrameEvent.totalTime = this.totalFrames;
					this.drawnFrameEvent.direction = this.frameModifier;
					this.triggerEvent(name, this.drawnFrameEvent);
					break;
				case "loopComplete":
					this.triggerEvent(name, new BMCompleteLoopEvent(name, this.loop, this.playCount, this.frameMult));
					break;
				case "complete":
					this.triggerEvent(name, new BMCompleteEvent(name, this.frameMult));
					break;
				case "segmentStart":
					this.triggerEvent(name, new BMSegmentStartEvent(name, this.firstFrame, this.totalFrames));
					break;
				case "destroy":
					this.triggerEvent(name, new BMDestroyEvent(name, this));
					break;
				default: this.triggerEvent(name);
			}
			if (name === "enterFrame" && this.onEnterFrame) this.onEnterFrame.call(this, new BMEnterFrameEvent(name, this.currentFrame, this.totalFrames, this.frameMult));
			if (name === "loopComplete" && this.onLoopComplete) this.onLoopComplete.call(this, new BMCompleteLoopEvent(name, this.loop, this.playCount, this.frameMult));
			if (name === "complete" && this.onComplete) this.onComplete.call(this, new BMCompleteEvent(name, this.frameMult));
			if (name === "segmentStart" && this.onSegmentStart) this.onSegmentStart.call(this, new BMSegmentStartEvent(name, this.firstFrame, this.totalFrames));
			if (name === "destroy" && this.onDestroy) this.onDestroy.call(this, new BMDestroyEvent(name, this));
		};
		AnimationItem.prototype.triggerRenderFrameError = function(nativeError) {
			var error = new BMRenderFrameErrorEvent(nativeError, this.currentFrame);
			this.triggerEvent("error", error);
			if (this.onError) this.onError.call(this, error);
		};
		AnimationItem.prototype.triggerConfigError = function(nativeError) {
			var error = new BMConfigErrorEvent(nativeError, this.currentFrame);
			this.triggerEvent("error", error);
			if (this.onError) this.onError.call(this, error);
		};
		var animationManager = function() {
			var moduleOb = {};
			var registeredAnimations = [];
			var initTime = 0;
			var len = 0;
			var playingAnimationsNum = 0;
			var _stopped = true;
			var _isFrozen = false;
			function removeElement(ev) {
				var i = 0;
				var animItem = ev.target;
				while (i < len) {
					if (registeredAnimations[i].animation === animItem) {
						registeredAnimations.splice(i, 1);
						i -= 1;
						len -= 1;
						if (!animItem.isPaused) subtractPlayingCount();
					}
					i += 1;
				}
			}
			function registerAnimation(element, animationData) {
				if (!element) return null;
				var i = 0;
				while (i < len) {
					if (registeredAnimations[i].elem === element && registeredAnimations[i].elem !== null) return registeredAnimations[i].animation;
					i += 1;
				}
				var animItem = new AnimationItem();
				setupAnimation(animItem, element);
				animItem.setData(element, animationData);
				return animItem;
			}
			function getRegisteredAnimations() {
				var i;
				var lenAnims = registeredAnimations.length;
				var animations = [];
				for (i = 0; i < lenAnims; i += 1) animations.push(registeredAnimations[i].animation);
				return animations;
			}
			function addPlayingCount() {
				playingAnimationsNum += 1;
				activate();
			}
			function subtractPlayingCount() {
				playingAnimationsNum -= 1;
			}
			function setupAnimation(animItem, element) {
				animItem.addEventListener("destroy", removeElement);
				animItem.addEventListener("_active", addPlayingCount);
				animItem.addEventListener("_idle", subtractPlayingCount);
				registeredAnimations.push({
					elem: element,
					animation: animItem
				});
				len += 1;
			}
			function loadAnimation(params) {
				var animItem = new AnimationItem();
				setupAnimation(animItem, null);
				animItem.setParams(params);
				return animItem;
			}
			function setSpeed(val, animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.setSpeed(val, animation);
			}
			function setDirection(val, animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.setDirection(val, animation);
			}
			function play(animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.play(animation);
			}
			function resume(nowTime) {
				var elapsedTime = nowTime - initTime;
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.advanceTime(elapsedTime);
				initTime = nowTime;
				if (playingAnimationsNum && !_isFrozen) window.requestAnimationFrame(resume);
				else _stopped = true;
			}
			function first(nowTime) {
				initTime = nowTime;
				window.requestAnimationFrame(resume);
			}
			function pause(animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.pause(animation);
			}
			function goToAndStop(value, isFrame, animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.goToAndStop(value, isFrame, animation);
			}
			function stop(animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.stop(animation);
			}
			function togglePause(animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.togglePause(animation);
			}
			function destroy(animation) {
				var i;
				for (i = len - 1; i >= 0; i -= 1) registeredAnimations[i].animation.destroy(animation);
			}
			function searchAnimations(animationData, standalone, renderer) {
				var animElements = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin")));
				var i;
				var lenAnims = animElements.length;
				for (i = 0; i < lenAnims; i += 1) {
					if (renderer) animElements[i].setAttribute("data-bm-type", renderer);
					registerAnimation(animElements[i], animationData);
				}
				if (standalone && lenAnims === 0) {
					if (!renderer) renderer = "svg";
					var body = document.getElementsByTagName("body")[0];
					body.innerText = "";
					var div = createTag("div");
					div.style.width = "100%";
					div.style.height = "100%";
					div.setAttribute("data-bm-type", renderer);
					body.appendChild(div);
					registerAnimation(div, animationData);
				}
			}
			function resize() {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.resize();
			}
			function activate() {
				if (!_isFrozen && playingAnimationsNum) {
					if (_stopped) {
						window.requestAnimationFrame(first);
						_stopped = false;
					}
				}
			}
			function freeze() {
				_isFrozen = true;
			}
			function unfreeze() {
				_isFrozen = false;
				activate();
			}
			function setVolume(val, animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.setVolume(val, animation);
			}
			function mute(animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.mute(animation);
			}
			function unmute(animation) {
				var i;
				for (i = 0; i < len; i += 1) registeredAnimations[i].animation.unmute(animation);
			}
			moduleOb.registerAnimation = registerAnimation;
			moduleOb.loadAnimation = loadAnimation;
			moduleOb.setSpeed = setSpeed;
			moduleOb.setDirection = setDirection;
			moduleOb.play = play;
			moduleOb.pause = pause;
			moduleOb.stop = stop;
			moduleOb.togglePause = togglePause;
			moduleOb.searchAnimations = searchAnimations;
			moduleOb.resize = resize;
			moduleOb.goToAndStop = goToAndStop;
			moduleOb.destroy = destroy;
			moduleOb.freeze = freeze;
			moduleOb.unfreeze = unfreeze;
			moduleOb.setVolume = setVolume;
			moduleOb.mute = mute;
			moduleOb.unmute = unmute;
			moduleOb.getRegisteredAnimations = getRegisteredAnimations;
			return moduleOb;
		}();
		var BezierFactory = function() {
			/**
			* BezierEasing - use bezier curve for transition easing function
			* by Gaëtan Renaudeau 2014 - 2015 – MIT License
			*
			* Credits: is based on Firefox's nsSMILKeySpline.cpp
			* Usage:
			* var spline = BezierEasing([ 0.25, 0.1, 0.25, 1.0 ])
			* spline.get(x) => returns the easing value | x must be in [0, 1] range
			*
			*/
			var ob = {};
			ob.getBezierEasing = getBezierEasing;
			var beziers = {};
			function getBezierEasing(a, b, c, d, nm) {
				var str = nm || ("bez_" + a + "_" + b + "_" + c + "_" + d).replace(/\./g, "p");
				if (beziers[str]) return beziers[str];
				var bezEasing = new BezierEasing([
					a,
					b,
					c,
					d
				]);
				beziers[str] = bezEasing;
				return bezEasing;
			}
			var NEWTON_ITERATIONS = 4;
			var NEWTON_MIN_SLOPE = .001;
			var SUBDIVISION_PRECISION = 1e-7;
			var SUBDIVISION_MAX_ITERATIONS = 10;
			var kSplineTableSize = 11;
			var kSampleStepSize = 1 / (kSplineTableSize - 1);
			var float32ArraySupported = typeof Float32Array === "function";
			function A(aA1, aA2) {
				return 1 - 3 * aA2 + 3 * aA1;
			}
			function B(aA1, aA2) {
				return 3 * aA2 - 6 * aA1;
			}
			function C(aA1) {
				return 3 * aA1;
			}
			function calcBezier(aT, aA1, aA2) {
				return ((A(aA1, aA2) * aT + B(aA1, aA2)) * aT + C(aA1)) * aT;
			}
			function getSlope(aT, aA1, aA2) {
				return 3 * A(aA1, aA2) * aT * aT + 2 * B(aA1, aA2) * aT + C(aA1);
			}
			function binarySubdivide(aX, aA, aB, mX1, mX2) {
				var currentX, currentT, i = 0;
				do {
					currentT = aA + (aB - aA) / 2;
					currentX = calcBezier(currentT, mX1, mX2) - aX;
					if (currentX > 0) aB = currentT;
					else aA = currentT;
				} while (Math.abs(currentX) > SUBDIVISION_PRECISION && ++i < SUBDIVISION_MAX_ITERATIONS);
				return currentT;
			}
			function newtonRaphsonIterate(aX, aGuessT, mX1, mX2) {
				for (var i = 0; i < NEWTON_ITERATIONS; ++i) {
					var currentSlope = getSlope(aGuessT, mX1, mX2);
					if (currentSlope === 0) return aGuessT;
					var currentX = calcBezier(aGuessT, mX1, mX2) - aX;
					aGuessT -= currentX / currentSlope;
				}
				return aGuessT;
			}
			/**
			* points is an array of [ mX1, mY1, mX2, mY2 ]
			*/
			function BezierEasing(points) {
				this._p = points;
				this._mSampleValues = float32ArraySupported ? new Float32Array(kSplineTableSize) : new Array(kSplineTableSize);
				this._precomputed = false;
				this.get = this.get.bind(this);
			}
			BezierEasing.prototype = {
				get: function get(x) {
					var mX1 = this._p[0], mY1 = this._p[1], mX2 = this._p[2], mY2 = this._p[3];
					if (!this._precomputed) this._precompute();
					if (mX1 === mY1 && mX2 === mY2) return x;
					if (x === 0) return 0;
					if (x === 1) return 1;
					return calcBezier(this._getTForX(x), mY1, mY2);
				},
				_precompute: function _precompute() {
					var mX1 = this._p[0], mY1 = this._p[1], mX2 = this._p[2], mY2 = this._p[3];
					this._precomputed = true;
					if (mX1 !== mY1 || mX2 !== mY2) this._calcSampleValues();
				},
				_calcSampleValues: function _calcSampleValues() {
					var mX1 = this._p[0], mX2 = this._p[2];
					for (var i = 0; i < kSplineTableSize; ++i) this._mSampleValues[i] = calcBezier(i * kSampleStepSize, mX1, mX2);
				},
				/**
				* getTForX chose the fastest heuristic to determine the percentage value precisely from a given X projection.
				*/
				_getTForX: function _getTForX(aX) {
					var mX1 = this._p[0], mX2 = this._p[2], mSampleValues = this._mSampleValues;
					var intervalStart = 0;
					var currentSample = 1;
					var lastSample = kSplineTableSize - 1;
					for (; currentSample !== lastSample && mSampleValues[currentSample] <= aX; ++currentSample) intervalStart += kSampleStepSize;
					--currentSample;
					var dist = (aX - mSampleValues[currentSample]) / (mSampleValues[currentSample + 1] - mSampleValues[currentSample]);
					var guessForT = intervalStart + dist * kSampleStepSize;
					var initialSlope = getSlope(guessForT, mX1, mX2);
					if (initialSlope >= NEWTON_MIN_SLOPE) return newtonRaphsonIterate(aX, guessForT, mX1, mX2);
					if (initialSlope === 0) return guessForT;
					return binarySubdivide(aX, intervalStart, intervalStart + kSampleStepSize, mX1, mX2);
				}
			};
			return ob;
		}();
		var pooling = function() {
			function _double(arr) {
				return arr.concat(createSizedArray(arr.length));
			}
			return { "double": _double };
		}();
		var poolFactory = function() {
			return function(initialLength, _create, _release) {
				var _length = 0;
				var _maxLength = initialLength;
				var pool = createSizedArray(_maxLength);
				var ob = {
					newElement,
					release
				};
				function newElement() {
					var element;
					if (_length) {
						_length -= 1;
						element = pool[_length];
					} else element = _create();
					return element;
				}
				function release(element) {
					if (_length === _maxLength) {
						pool = pooling["double"](pool);
						_maxLength *= 2;
					}
					if (_release) _release(element);
					pool[_length] = element;
					_length += 1;
				}
				return ob;
			};
		}();
		var bezierLengthPool = function() {
			function create() {
				return {
					addedLength: 0,
					percents: createTypedArray("float32", getDefaultCurveSegments()),
					lengths: createTypedArray("float32", getDefaultCurveSegments())
				};
			}
			return poolFactory(8, create);
		}();
		var segmentsLengthPool = function() {
			function create() {
				return {
					lengths: [],
					totalLength: 0
				};
			}
			function release(element) {
				var i;
				var len = element.lengths.length;
				for (i = 0; i < len; i += 1) bezierLengthPool.release(element.lengths[i]);
				element.lengths.length = 0;
			}
			return poolFactory(8, create, release);
		}();
		function bezFunction() {
			var math = Math;
			function pointOnLine2D(x1, y1, x2, y2, x3, y3) {
				var det1 = x1 * y2 + y1 * x3 + x2 * y3 - x3 * y2 - y3 * x1 - x2 * y1;
				return det1 > -.001 && det1 < .001;
			}
			function pointOnLine3D(x1, y1, z1, x2, y2, z2, x3, y3, z3) {
				if (z1 === 0 && z2 === 0 && z3 === 0) return pointOnLine2D(x1, y1, x2, y2, x3, y3);
				var dist1 = math.sqrt(math.pow(x2 - x1, 2) + math.pow(y2 - y1, 2) + math.pow(z2 - z1, 2));
				var dist2 = math.sqrt(math.pow(x3 - x1, 2) + math.pow(y3 - y1, 2) + math.pow(z3 - z1, 2));
				var dist3 = math.sqrt(math.pow(x3 - x2, 2) + math.pow(y3 - y2, 2) + math.pow(z3 - z2, 2));
				var diffDist;
				if (dist1 > dist2) {
					if (dist1 > dist3) diffDist = dist1 - dist2 - dist3;
					else diffDist = dist3 - dist2 - dist1;
				} else if (dist3 > dist2) diffDist = dist3 - dist2 - dist1;
				else diffDist = dist2 - dist1 - dist3;
				return diffDist > -1e-4 && diffDist < 1e-4;
			}
			var getBezierLength = function() {
				return function(pt1, pt2, pt3, pt4) {
					var curveSegments = getDefaultCurveSegments();
					var k;
					var i;
					var len;
					var ptCoord;
					var perc;
					var addedLength = 0;
					var ptDistance;
					var point = [];
					var lastPoint = [];
					var lengthData = bezierLengthPool.newElement();
					len = pt3.length;
					for (k = 0; k < curveSegments; k += 1) {
						perc = k / (curveSegments - 1);
						ptDistance = 0;
						for (i = 0; i < len; i += 1) {
							ptCoord = bmPow(1 - perc, 3) * pt1[i] + 3 * bmPow(1 - perc, 2) * perc * pt3[i] + 3 * (1 - perc) * bmPow(perc, 2) * pt4[i] + bmPow(perc, 3) * pt2[i];
							point[i] = ptCoord;
							if (lastPoint[i] !== null) ptDistance += bmPow(point[i] - lastPoint[i], 2);
							lastPoint[i] = point[i];
						}
						if (ptDistance) {
							ptDistance = bmSqrt(ptDistance);
							addedLength += ptDistance;
						}
						lengthData.percents[k] = perc;
						lengthData.lengths[k] = addedLength;
					}
					lengthData.addedLength = addedLength;
					return lengthData;
				};
			}();
			function getSegmentsLength(shapeData) {
				var segmentsLength = segmentsLengthPool.newElement();
				var closed = shapeData.c;
				var pathV = shapeData.v;
				var pathO = shapeData.o;
				var pathI = shapeData.i;
				var i;
				var len = shapeData._length;
				var lengths = segmentsLength.lengths;
				var totalLength = 0;
				for (i = 0; i < len - 1; i += 1) {
					lengths[i] = getBezierLength(pathV[i], pathV[i + 1], pathO[i], pathI[i + 1]);
					totalLength += lengths[i].addedLength;
				}
				if (closed && len) {
					lengths[i] = getBezierLength(pathV[i], pathV[0], pathO[i], pathI[0]);
					totalLength += lengths[i].addedLength;
				}
				segmentsLength.totalLength = totalLength;
				return segmentsLength;
			}
			function BezierData(length) {
				this.segmentLength = 0;
				this.points = new Array(length);
			}
			function PointData(partial, point) {
				this.partialLength = partial;
				this.point = point;
			}
			var buildBezierData = function() {
				var storedData = {};
				return function(pt1, pt2, pt3, pt4) {
					var bezierName = (pt1[0] + "_" + pt1[1] + "_" + pt2[0] + "_" + pt2[1] + "_" + pt3[0] + "_" + pt3[1] + "_" + pt4[0] + "_" + pt4[1]).replace(/\./g, "p");
					if (!storedData[bezierName]) {
						var curveSegments = getDefaultCurveSegments();
						var k;
						var i;
						var len;
						var ptCoord;
						var perc;
						var addedLength = 0;
						var ptDistance;
						var point;
						var lastPoint = null;
						if (pt1.length === 2 && (pt1[0] !== pt2[0] || pt1[1] !== pt2[1]) && pointOnLine2D(pt1[0], pt1[1], pt2[0], pt2[1], pt1[0] + pt3[0], pt1[1] + pt3[1]) && pointOnLine2D(pt1[0], pt1[1], pt2[0], pt2[1], pt2[0] + pt4[0], pt2[1] + pt4[1])) curveSegments = 2;
						var bezierData = new BezierData(curveSegments);
						len = pt3.length;
						for (k = 0; k < curveSegments; k += 1) {
							point = createSizedArray(len);
							perc = k / (curveSegments - 1);
							ptDistance = 0;
							for (i = 0; i < len; i += 1) {
								ptCoord = bmPow(1 - perc, 3) * pt1[i] + 3 * bmPow(1 - perc, 2) * perc * (pt1[i] + pt3[i]) + 3 * (1 - perc) * bmPow(perc, 2) * (pt2[i] + pt4[i]) + bmPow(perc, 3) * pt2[i];
								point[i] = ptCoord;
								if (lastPoint !== null) ptDistance += bmPow(point[i] - lastPoint[i], 2);
							}
							ptDistance = bmSqrt(ptDistance);
							addedLength += ptDistance;
							bezierData.points[k] = new PointData(ptDistance, point);
							lastPoint = point;
						}
						bezierData.segmentLength = addedLength;
						storedData[bezierName] = bezierData;
					}
					return storedData[bezierName];
				};
			}();
			function getDistancePerc(perc, bezierData) {
				var percents = bezierData.percents;
				var lengths = bezierData.lengths;
				var len = percents.length;
				var initPos = bmFloor((len - 1) * perc);
				var lengthPos = perc * bezierData.addedLength;
				var lPerc = 0;
				if (initPos === len - 1 || initPos === 0 || lengthPos === lengths[initPos]) return percents[initPos];
				var dir = lengths[initPos] > lengthPos ? -1 : 1;
				var flag = true;
				while (flag) {
					if (lengths[initPos] <= lengthPos && lengths[initPos + 1] > lengthPos) {
						lPerc = (lengthPos - lengths[initPos]) / (lengths[initPos + 1] - lengths[initPos]);
						flag = false;
					} else initPos += dir;
					if (initPos < 0 || initPos >= len - 1) {
						if (initPos === len - 1) return percents[initPos];
						flag = false;
					}
				}
				return percents[initPos] + (percents[initPos + 1] - percents[initPos]) * lPerc;
			}
			function getPointInSegment(pt1, pt2, pt3, pt4, percent, bezierData) {
				var t1 = getDistancePerc(percent, bezierData);
				var u1 = 1 - t1;
				return [math.round((u1 * u1 * u1 * pt1[0] + (t1 * u1 * u1 + u1 * t1 * u1 + u1 * u1 * t1) * pt3[0] + (t1 * t1 * u1 + u1 * t1 * t1 + t1 * u1 * t1) * pt4[0] + t1 * t1 * t1 * pt2[0]) * 1e3) / 1e3, math.round((u1 * u1 * u1 * pt1[1] + (t1 * u1 * u1 + u1 * t1 * u1 + u1 * u1 * t1) * pt3[1] + (t1 * t1 * u1 + u1 * t1 * t1 + t1 * u1 * t1) * pt4[1] + t1 * t1 * t1 * pt2[1]) * 1e3) / 1e3];
			}
			var bezierSegmentPoints = createTypedArray("float32", 8);
			function getNewSegment(pt1, pt2, pt3, pt4, startPerc, endPerc, bezierData) {
				if (startPerc < 0) startPerc = 0;
				else if (startPerc > 1) startPerc = 1;
				var t0 = getDistancePerc(startPerc, bezierData);
				endPerc = endPerc > 1 ? 1 : endPerc;
				var t1 = getDistancePerc(endPerc, bezierData);
				var i;
				var len = pt1.length;
				var u0 = 1 - t0;
				var u1 = 1 - t1;
				var u0u0u0 = u0 * u0 * u0;
				var t0u0u0_3 = t0 * u0 * u0 * 3;
				var t0t0u0_3 = t0 * t0 * u0 * 3;
				var t0t0t0 = t0 * t0 * t0;
				var u0u0u1 = u0 * u0 * u1;
				var t0u0u1_3 = t0 * u0 * u1 + u0 * t0 * u1 + u0 * u0 * t1;
				var t0t0u1_3 = t0 * t0 * u1 + u0 * t0 * t1 + t0 * u0 * t1;
				var t0t0t1 = t0 * t0 * t1;
				var u0u1u1 = u0 * u1 * u1;
				var t0u1u1_3 = t0 * u1 * u1 + u0 * t1 * u1 + u0 * u1 * t1;
				var t0t1u1_3 = t0 * t1 * u1 + u0 * t1 * t1 + t0 * u1 * t1;
				var t0t1t1 = t0 * t1 * t1;
				var u1u1u1 = u1 * u1 * u1;
				var t1u1u1_3 = t1 * u1 * u1 + u1 * t1 * u1 + u1 * u1 * t1;
				var t1t1u1_3 = t1 * t1 * u1 + u1 * t1 * t1 + t1 * u1 * t1;
				var t1t1t1 = t1 * t1 * t1;
				for (i = 0; i < len; i += 1) {
					bezierSegmentPoints[i * 4] = math.round((u0u0u0 * pt1[i] + t0u0u0_3 * pt3[i] + t0t0u0_3 * pt4[i] + t0t0t0 * pt2[i]) * 1e3) / 1e3;
					bezierSegmentPoints[i * 4 + 1] = math.round((u0u0u1 * pt1[i] + t0u0u1_3 * pt3[i] + t0t0u1_3 * pt4[i] + t0t0t1 * pt2[i]) * 1e3) / 1e3;
					bezierSegmentPoints[i * 4 + 2] = math.round((u0u1u1 * pt1[i] + t0u1u1_3 * pt3[i] + t0t1u1_3 * pt4[i] + t0t1t1 * pt2[i]) * 1e3) / 1e3;
					bezierSegmentPoints[i * 4 + 3] = math.round((u1u1u1 * pt1[i] + t1u1u1_3 * pt3[i] + t1t1u1_3 * pt4[i] + t1t1t1 * pt2[i]) * 1e3) / 1e3;
				}
				return bezierSegmentPoints;
			}
			return {
				getSegmentsLength,
				getNewSegment,
				getPointInSegment,
				buildBezierData,
				pointOnLine2D,
				pointOnLine3D
			};
		}
		var bez = bezFunction();
		var initFrame = initialDefaultFrame;
		var mathAbs = Math.abs;
		function interpolateValue(frameNum, caching) {
			var offsetTime = this.offsetTime;
			var newValue;
			if (this.propType === "multidimensional") newValue = createTypedArray("float32", this.pv.length);
			var iterationIndex = caching.lastIndex;
			var i = iterationIndex;
			var len = this.keyframes.length - 1;
			var flag = true;
			var keyData;
			var nextKeyData;
			var keyframeMetadata;
			while (flag) {
				keyData = this.keyframes[i];
				nextKeyData = this.keyframes[i + 1];
				if (i === len - 1 && frameNum >= nextKeyData.t - offsetTime) {
					if (keyData.h) keyData = nextKeyData;
					iterationIndex = 0;
					break;
				}
				if (nextKeyData.t - offsetTime > frameNum) {
					iterationIndex = i;
					break;
				}
				if (i < len - 1) i += 1;
				else {
					iterationIndex = 0;
					flag = false;
				}
			}
			keyframeMetadata = this.keyframesMetadata[i] || {};
			var k;
			var kLen;
			var perc;
			var jLen;
			var j;
			var fnc;
			var nextKeyTime = nextKeyData.t - offsetTime;
			var keyTime = keyData.t - offsetTime;
			var endValue;
			if (keyData.to) {
				if (!keyframeMetadata.bezierData) keyframeMetadata.bezierData = bez.buildBezierData(keyData.s, nextKeyData.s || keyData.e, keyData.to, keyData.ti);
				var bezierData = keyframeMetadata.bezierData;
				if (frameNum >= nextKeyTime || frameNum < keyTime) {
					var ind = frameNum >= nextKeyTime ? bezierData.points.length - 1 : 0;
					kLen = bezierData.points[ind].point.length;
					for (k = 0; k < kLen; k += 1) newValue[k] = bezierData.points[ind].point[k];
				} else {
					if (keyframeMetadata.__fnct) fnc = keyframeMetadata.__fnct;
					else {
						fnc = BezierFactory.getBezierEasing(keyData.o.x, keyData.o.y, keyData.i.x, keyData.i.y, keyData.n).get;
						keyframeMetadata.__fnct = fnc;
					}
					perc = fnc((frameNum - keyTime) / (nextKeyTime - keyTime));
					var distanceInLine = bezierData.segmentLength * perc;
					var segmentPerc;
					var addedLength = caching.lastFrame < frameNum && caching._lastKeyframeIndex === i ? caching._lastAddedLength : 0;
					j = caching.lastFrame < frameNum && caching._lastKeyframeIndex === i ? caching._lastPoint : 0;
					flag = true;
					jLen = bezierData.points.length;
					while (flag) {
						addedLength += bezierData.points[j].partialLength;
						if (distanceInLine === 0 || perc === 0 || j === bezierData.points.length - 1) {
							kLen = bezierData.points[j].point.length;
							for (k = 0; k < kLen; k += 1) newValue[k] = bezierData.points[j].point[k];
							break;
						} else if (distanceInLine >= addedLength && distanceInLine < addedLength + bezierData.points[j + 1].partialLength) {
							segmentPerc = (distanceInLine - addedLength) / bezierData.points[j + 1].partialLength;
							kLen = bezierData.points[j].point.length;
							for (k = 0; k < kLen; k += 1) newValue[k] = bezierData.points[j].point[k] + (bezierData.points[j + 1].point[k] - bezierData.points[j].point[k]) * segmentPerc;
							break;
						}
						if (j < jLen - 1) j += 1;
						else flag = false;
					}
					caching._lastPoint = j;
					caching._lastAddedLength = addedLength - bezierData.points[j].partialLength;
					caching._lastKeyframeIndex = i;
				}
			} else {
				var outX;
				var outY;
				var inX;
				var inY;
				var keyValue;
				len = keyData.s.length;
				endValue = nextKeyData.s || keyData.e;
				if (this.sh && keyData.h !== 1) {
					if (frameNum >= nextKeyTime) {
						newValue[0] = endValue[0];
						newValue[1] = endValue[1];
						newValue[2] = endValue[2];
					} else if (frameNum <= keyTime) {
						newValue[0] = keyData.s[0];
						newValue[1] = keyData.s[1];
						newValue[2] = keyData.s[2];
					} else {
						var quatStart = createQuaternion(keyData.s);
						var quatEnd = createQuaternion(endValue);
						var time = (frameNum - keyTime) / (nextKeyTime - keyTime);
						quaternionToEuler(newValue, slerp(quatStart, quatEnd, time));
					}
				} else for (i = 0; i < len; i += 1) {
					if (keyData.h !== 1) {
						if (frameNum >= nextKeyTime) perc = 1;
						else if (frameNum < keyTime) perc = 0;
						else {
							if (keyData.o.x.constructor === Array) {
								if (!keyframeMetadata.__fnct) keyframeMetadata.__fnct = [];
								if (!keyframeMetadata.__fnct[i]) {
									outX = keyData.o.x[i] === void 0 ? keyData.o.x[0] : keyData.o.x[i];
									outY = keyData.o.y[i] === void 0 ? keyData.o.y[0] : keyData.o.y[i];
									inX = keyData.i.x[i] === void 0 ? keyData.i.x[0] : keyData.i.x[i];
									inY = keyData.i.y[i] === void 0 ? keyData.i.y[0] : keyData.i.y[i];
									fnc = BezierFactory.getBezierEasing(outX, outY, inX, inY).get;
									keyframeMetadata.__fnct[i] = fnc;
								} else fnc = keyframeMetadata.__fnct[i];
							} else if (!keyframeMetadata.__fnct) {
								outX = keyData.o.x;
								outY = keyData.o.y;
								inX = keyData.i.x;
								inY = keyData.i.y;
								fnc = BezierFactory.getBezierEasing(outX, outY, inX, inY).get;
								keyData.keyframeMetadata = fnc;
							} else fnc = keyframeMetadata.__fnct;
							perc = fnc((frameNum - keyTime) / (nextKeyTime - keyTime));
						}
					}
					endValue = nextKeyData.s || keyData.e;
					keyValue = keyData.h === 1 ? keyData.s[i] : keyData.s[i] + (endValue[i] - keyData.s[i]) * perc;
					if (this.propType === "multidimensional") newValue[i] = keyValue;
					else newValue = keyValue;
				}
			}
			caching.lastIndex = iterationIndex;
			return newValue;
		}
		function slerp(a, b, t) {
			var out = [];
			var ax = a[0];
			var ay = a[1];
			var az = a[2];
			var aw = a[3];
			var bx = b[0];
			var by = b[1];
			var bz = b[2];
			var bw = b[3];
			var omega;
			var cosom;
			var sinom;
			var scale0;
			var scale1;
			cosom = ax * bx + ay * by + az * bz + aw * bw;
			if (cosom < 0) {
				cosom = -cosom;
				bx = -bx;
				by = -by;
				bz = -bz;
				bw = -bw;
			}
			if (1 - cosom > 1e-6) {
				omega = Math.acos(cosom);
				sinom = Math.sin(omega);
				scale0 = Math.sin((1 - t) * omega) / sinom;
				scale1 = Math.sin(t * omega) / sinom;
			} else {
				scale0 = 1 - t;
				scale1 = t;
			}
			out[0] = scale0 * ax + scale1 * bx;
			out[1] = scale0 * ay + scale1 * by;
			out[2] = scale0 * az + scale1 * bz;
			out[3] = scale0 * aw + scale1 * bw;
			return out;
		}
		function quaternionToEuler(out, quat) {
			var qx = quat[0];
			var qy = quat[1];
			var qz = quat[2];
			var qw = quat[3];
			var heading = Math.atan2(2 * qy * qw - 2 * qx * qz, 1 - 2 * qy * qy - 2 * qz * qz);
			var attitude = Math.asin(2 * qx * qy + 2 * qz * qw);
			var bank = Math.atan2(2 * qx * qw - 2 * qy * qz, 1 - 2 * qx * qx - 2 * qz * qz);
			out[0] = heading / degToRads;
			out[1] = attitude / degToRads;
			out[2] = bank / degToRads;
		}
		function createQuaternion(values) {
			var heading = values[0] * degToRads;
			var attitude = values[1] * degToRads;
			var bank = values[2] * degToRads;
			var c1 = Math.cos(heading / 2);
			var c2 = Math.cos(attitude / 2);
			var c3 = Math.cos(bank / 2);
			var s1 = Math.sin(heading / 2);
			var s2 = Math.sin(attitude / 2);
			var s3 = Math.sin(bank / 2);
			var w = c1 * c2 * c3 - s1 * s2 * s3;
			return [
				s1 * s2 * c3 + c1 * c2 * s3,
				s1 * c2 * c3 + c1 * s2 * s3,
				c1 * s2 * c3 - s1 * c2 * s3,
				w
			];
		}
		function getValueAtCurrentTime() {
			var frameNum = this.comp.renderedFrame - this.offsetTime;
			var initTime = this.keyframes[0].t - this.offsetTime;
			var endTime = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
			if (!(frameNum === this._caching.lastFrame || this._caching.lastFrame !== initFrame && (this._caching.lastFrame >= endTime && frameNum >= endTime || this._caching.lastFrame < initTime && frameNum < initTime))) {
				if (this._caching.lastFrame >= frameNum) {
					this._caching._lastKeyframeIndex = -1;
					this._caching.lastIndex = 0;
				}
				var renderResult = this.interpolateValue(frameNum, this._caching);
				this.pv = renderResult;
			}
			this._caching.lastFrame = frameNum;
			return this.pv;
		}
		function setVValue(val) {
			var multipliedValue;
			if (this.propType === "unidimensional") {
				multipliedValue = val * this.mult;
				if (mathAbs(this.v - multipliedValue) > 1e-5) {
					this.v = multipliedValue;
					this._mdf = true;
				}
			} else {
				var i = 0;
				var len = this.v.length;
				while (i < len) {
					multipliedValue = val[i] * this.mult;
					if (mathAbs(this.v[i] - multipliedValue) > 1e-5) {
						this.v[i] = multipliedValue;
						this._mdf = true;
					}
					i += 1;
				}
			}
		}
		function processEffectsSequence() {
			if (this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length) return;
			if (this.lock) {
				this.setVValue(this.pv);
				return;
			}
			this.lock = true;
			this._mdf = this._isFirstFrame;
			var i;
			var len = this.effectsSequence.length;
			var finalValue = this.kf ? this.pv : this.data.k;
			for (i = 0; i < len; i += 1) finalValue = this.effectsSequence[i](finalValue);
			this.setVValue(finalValue);
			this._isFirstFrame = false;
			this.lock = false;
			this.frameId = this.elem.globalData.frameId;
		}
		function addEffect(effectFunction) {
			this.effectsSequence.push(effectFunction);
			this.container.addDynamicProperty(this);
		}
		function ValueProperty(elem, data, mult, container) {
			this.propType = "unidimensional";
			this.mult = mult || 1;
			this.data = data;
			this.v = mult ? data.k * mult : data.k;
			this.pv = data.k;
			this._mdf = false;
			this.elem = elem;
			this.container = container;
			this.comp = elem.comp;
			this.k = false;
			this.kf = false;
			this.vel = 0;
			this.effectsSequence = [];
			this._isFirstFrame = true;
			this.getValue = processEffectsSequence;
			this.setVValue = setVValue;
			this.addEffect = addEffect;
		}
		function MultiDimensionalProperty(elem, data, mult, container) {
			this.propType = "multidimensional";
			this.mult = mult || 1;
			this.data = data;
			this._mdf = false;
			this.elem = elem;
			this.container = container;
			this.comp = elem.comp;
			this.k = false;
			this.kf = false;
			this.frameId = -1;
			var i;
			var len = data.k.length;
			this.v = createTypedArray("float32", len);
			this.pv = createTypedArray("float32", len);
			this.vel = createTypedArray("float32", len);
			for (i = 0; i < len; i += 1) {
				this.v[i] = data.k[i] * this.mult;
				this.pv[i] = data.k[i];
			}
			this._isFirstFrame = true;
			this.effectsSequence = [];
			this.getValue = processEffectsSequence;
			this.setVValue = setVValue;
			this.addEffect = addEffect;
		}
		function KeyframedValueProperty(elem, data, mult, container) {
			this.propType = "unidimensional";
			this.keyframes = data.k;
			this.keyframesMetadata = [];
			this.offsetTime = elem.data.st;
			this.frameId = -1;
			this._caching = {
				lastFrame: initFrame,
				lastIndex: 0,
				value: 0,
				_lastKeyframeIndex: -1
			};
			this.k = true;
			this.kf = true;
			this.data = data;
			this.mult = mult || 1;
			this.elem = elem;
			this.container = container;
			this.comp = elem.comp;
			this.v = initFrame;
			this.pv = initFrame;
			this._isFirstFrame = true;
			this.getValue = processEffectsSequence;
			this.setVValue = setVValue;
			this.interpolateValue = interpolateValue;
			this.effectsSequence = [getValueAtCurrentTime.bind(this)];
			this.addEffect = addEffect;
		}
		function KeyframedMultidimensionalProperty(elem, data, mult, container) {
			this.propType = "multidimensional";
			var i;
			var len = data.k.length;
			var s;
			var e;
			var to;
			var ti;
			for (i = 0; i < len - 1; i += 1) if (data.k[i].to && data.k[i].s && data.k[i + 1] && data.k[i + 1].s) {
				s = data.k[i].s;
				e = data.k[i + 1].s;
				to = data.k[i].to;
				ti = data.k[i].ti;
				if (s.length === 2 && !(s[0] === e[0] && s[1] === e[1]) && bez.pointOnLine2D(s[0], s[1], e[0], e[1], s[0] + to[0], s[1] + to[1]) && bez.pointOnLine2D(s[0], s[1], e[0], e[1], e[0] + ti[0], e[1] + ti[1]) || s.length === 3 && !(s[0] === e[0] && s[1] === e[1] && s[2] === e[2]) && bez.pointOnLine3D(s[0], s[1], s[2], e[0], e[1], e[2], s[0] + to[0], s[1] + to[1], s[2] + to[2]) && bez.pointOnLine3D(s[0], s[1], s[2], e[0], e[1], e[2], e[0] + ti[0], e[1] + ti[1], e[2] + ti[2])) {
					data.k[i].to = null;
					data.k[i].ti = null;
				}
				if (s[0] === e[0] && s[1] === e[1] && to[0] === 0 && to[1] === 0 && ti[0] === 0 && ti[1] === 0) {
					if (s.length === 2 || s[2] === e[2] && to[2] === 0 && ti[2] === 0) {
						data.k[i].to = null;
						data.k[i].ti = null;
					}
				}
			}
			this.effectsSequence = [getValueAtCurrentTime.bind(this)];
			this.data = data;
			this.keyframes = data.k;
			this.keyframesMetadata = [];
			this.offsetTime = elem.data.st;
			this.k = true;
			this.kf = true;
			this._isFirstFrame = true;
			this.mult = mult || 1;
			this.elem = elem;
			this.container = container;
			this.comp = elem.comp;
			this.getValue = processEffectsSequence;
			this.setVValue = setVValue;
			this.interpolateValue = interpolateValue;
			this.frameId = -1;
			var arrLen = data.k[0].s.length;
			this.v = createTypedArray("float32", arrLen);
			this.pv = createTypedArray("float32", arrLen);
			for (i = 0; i < arrLen; i += 1) {
				this.v[i] = initFrame;
				this.pv[i] = initFrame;
			}
			this._caching = {
				lastFrame: initFrame,
				lastIndex: 0,
				value: createTypedArray("float32", arrLen)
			};
			this.addEffect = addEffect;
		}
		var PropertyFactory = function() {
			function getProp(elem, data, type, mult, container) {
				if (data.sid) data = elem.globalData.slotManager.getProp(data);
				var p;
				if (!data.k.length) p = new ValueProperty(elem, data, mult, container);
				else if (typeof data.k[0] === "number") p = new MultiDimensionalProperty(elem, data, mult, container);
				else switch (type) {
					case 0:
						p = new KeyframedValueProperty(elem, data, mult, container);
						break;
					case 1: p = new KeyframedMultidimensionalProperty(elem, data, mult, container);
				}
				if (p.effectsSequence.length) container.addDynamicProperty(p);
				return p;
			}
			return { getProp };
		}();
		function DynamicPropertyContainer() {}
		DynamicPropertyContainer.prototype = {
			addDynamicProperty: function addDynamicProperty(prop) {
				if (this.dynamicProperties.indexOf(prop) === -1) {
					this.dynamicProperties.push(prop);
					this.container.addDynamicProperty(this);
					this._isAnimated = true;
				}
			},
			iterateDynamicProperties: function iterateDynamicProperties() {
				this._mdf = false;
				var i;
				var len = this.dynamicProperties.length;
				for (i = 0; i < len; i += 1) {
					this.dynamicProperties[i].getValue();
					if (this.dynamicProperties[i]._mdf) this._mdf = true;
				}
			},
			initDynamicPropertyContainer: function initDynamicPropertyContainer(container) {
				this.container = container;
				this.dynamicProperties = [];
				this._mdf = false;
				this._isAnimated = false;
			}
		};
		var pointPool = function() {
			function create() {
				return createTypedArray("float32", 2);
			}
			return poolFactory(8, create);
		}();
		function ShapePath() {
			this.c = false;
			this._length = 0;
			this._maxLength = 8;
			this.v = createSizedArray(this._maxLength);
			this.o = createSizedArray(this._maxLength);
			this.i = createSizedArray(this._maxLength);
		}
		ShapePath.prototype.setPathData = function(closed, len) {
			this.c = closed;
			this.setLength(len);
			var i = 0;
			while (i < len) {
				this.v[i] = pointPool.newElement();
				this.o[i] = pointPool.newElement();
				this.i[i] = pointPool.newElement();
				i += 1;
			}
		};
		ShapePath.prototype.setLength = function(len) {
			while (this._maxLength < len) this.doubleArrayLength();
			this._length = len;
		};
		ShapePath.prototype.doubleArrayLength = function() {
			this.v = this.v.concat(createSizedArray(this._maxLength));
			this.i = this.i.concat(createSizedArray(this._maxLength));
			this.o = this.o.concat(createSizedArray(this._maxLength));
			this._maxLength *= 2;
		};
		ShapePath.prototype.setXYAt = function(x, y, type, pos, replace) {
			var arr;
			this._length = Math.max(this._length, pos + 1);
			if (this._length >= this._maxLength) this.doubleArrayLength();
			switch (type) {
				case "v":
					arr = this.v;
					break;
				case "i":
					arr = this.i;
					break;
				case "o":
					arr = this.o;
					break;
				default: arr = [];
			}
			if (!arr[pos] || arr[pos] && !replace) arr[pos] = pointPool.newElement();
			arr[pos][0] = x;
			arr[pos][1] = y;
		};
		ShapePath.prototype.setTripleAt = function(vX, vY, oX, oY, iX, iY, pos, replace) {
			this.setXYAt(vX, vY, "v", pos, replace);
			this.setXYAt(oX, oY, "o", pos, replace);
			this.setXYAt(iX, iY, "i", pos, replace);
		};
		ShapePath.prototype.reverse = function() {
			var newPath = new ShapePath();
			newPath.setPathData(this.c, this._length);
			var vertices = this.v;
			var outPoints = this.o;
			var inPoints = this.i;
			var init = 0;
			if (this.c) {
				newPath.setTripleAt(vertices[0][0], vertices[0][1], inPoints[0][0], inPoints[0][1], outPoints[0][0], outPoints[0][1], 0, false);
				init = 1;
			}
			var cnt = this._length - 1;
			var len = this._length;
			var i;
			for (i = init; i < len; i += 1) {
				newPath.setTripleAt(vertices[cnt][0], vertices[cnt][1], inPoints[cnt][0], inPoints[cnt][1], outPoints[cnt][0], outPoints[cnt][1], i, false);
				cnt -= 1;
			}
			return newPath;
		};
		ShapePath.prototype.length = function() {
			return this._length;
		};
		var shapePool = function() {
			function create() {
				return new ShapePath();
			}
			function release(shapePath) {
				var len = shapePath._length;
				var i;
				for (i = 0; i < len; i += 1) {
					pointPool.release(shapePath.v[i]);
					pointPool.release(shapePath.i[i]);
					pointPool.release(shapePath.o[i]);
					shapePath.v[i] = null;
					shapePath.i[i] = null;
					shapePath.o[i] = null;
				}
				shapePath._length = 0;
				shapePath.c = false;
			}
			function clone(shape) {
				var cloned = factory.newElement();
				var i;
				var len = shape._length === void 0 ? shape.v.length : shape._length;
				cloned.setLength(len);
				cloned.c = shape.c;
				for (i = 0; i < len; i += 1) cloned.setTripleAt(shape.v[i][0], shape.v[i][1], shape.o[i][0], shape.o[i][1], shape.i[i][0], shape.i[i][1], i);
				return cloned;
			}
			var factory = poolFactory(4, create, release);
			factory.clone = clone;
			return factory;
		}();
		function ShapeCollection() {
			this._length = 0;
			this._maxLength = 4;
			this.shapes = createSizedArray(this._maxLength);
		}
		ShapeCollection.prototype.addShape = function(shapeData) {
			if (this._length === this._maxLength) {
				this.shapes = this.shapes.concat(createSizedArray(this._maxLength));
				this._maxLength *= 2;
			}
			this.shapes[this._length] = shapeData;
			this._length += 1;
		};
		ShapeCollection.prototype.releaseShapes = function() {
			var i;
			for (i = 0; i < this._length; i += 1) shapePool.release(this.shapes[i]);
			this._length = 0;
		};
		var shapeCollectionPool = function() {
			var ob = {
				newShapeCollection,
				release
			};
			var _length = 0;
			var _maxLength = 4;
			var pool = createSizedArray(_maxLength);
			function newShapeCollection() {
				var shapeCollection;
				if (_length) {
					_length -= 1;
					shapeCollection = pool[_length];
				} else shapeCollection = new ShapeCollection();
				return shapeCollection;
			}
			function release(shapeCollection) {
				var i;
				var len = shapeCollection._length;
				for (i = 0; i < len; i += 1) shapePool.release(shapeCollection.shapes[i]);
				shapeCollection._length = 0;
				if (_length === _maxLength) {
					pool = pooling["double"](pool);
					_maxLength *= 2;
				}
				pool[_length] = shapeCollection;
				_length += 1;
			}
			return ob;
		}();
		var ShapePropertyFactory = function() {
			var initFrame = -999999;
			function interpolateShape(frameNum, previousValue, caching) {
				var iterationIndex = caching.lastIndex;
				var keyPropS;
				var keyPropE;
				var isHold;
				var j;
				var k;
				var jLen;
				var kLen;
				var perc;
				var vertexValue;
				var kf = this.keyframes;
				if (frameNum < kf[0].t - this.offsetTime) {
					keyPropS = kf[0].s[0];
					isHold = true;
					iterationIndex = 0;
				} else if (frameNum >= kf[kf.length - 1].t - this.offsetTime) {
					keyPropS = kf[kf.length - 1].s ? kf[kf.length - 1].s[0] : kf[kf.length - 2].e[0];
					isHold = true;
				} else {
					var i = iterationIndex;
					var len = kf.length - 1;
					var flag = true;
					var keyData;
					var nextKeyData;
					var keyframeMetadata;
					while (flag) {
						keyData = kf[i];
						nextKeyData = kf[i + 1];
						if (nextKeyData.t - this.offsetTime > frameNum) break;
						if (i < len - 1) i += 1;
						else flag = false;
					}
					keyframeMetadata = this.keyframesMetadata[i] || {};
					isHold = keyData.h === 1;
					iterationIndex = i;
					if (!isHold) {
						if (frameNum >= nextKeyData.t - this.offsetTime) perc = 1;
						else if (frameNum < keyData.t - this.offsetTime) perc = 0;
						else {
							var fnc;
							if (keyframeMetadata.__fnct) fnc = keyframeMetadata.__fnct;
							else {
								fnc = BezierFactory.getBezierEasing(keyData.o.x, keyData.o.y, keyData.i.x, keyData.i.y).get;
								keyframeMetadata.__fnct = fnc;
							}
							perc = fnc((frameNum - (keyData.t - this.offsetTime)) / (nextKeyData.t - this.offsetTime - (keyData.t - this.offsetTime)));
						}
						keyPropE = nextKeyData.s ? nextKeyData.s[0] : keyData.e[0];
					}
					keyPropS = keyData.s[0];
				}
				jLen = previousValue._length;
				kLen = keyPropS.i[0].length;
				caching.lastIndex = iterationIndex;
				for (j = 0; j < jLen; j += 1) for (k = 0; k < kLen; k += 1) {
					vertexValue = isHold ? keyPropS.i[j][k] : keyPropS.i[j][k] + (keyPropE.i[j][k] - keyPropS.i[j][k]) * perc;
					previousValue.i[j][k] = vertexValue;
					vertexValue = isHold ? keyPropS.o[j][k] : keyPropS.o[j][k] + (keyPropE.o[j][k] - keyPropS.o[j][k]) * perc;
					previousValue.o[j][k] = vertexValue;
					vertexValue = isHold ? keyPropS.v[j][k] : keyPropS.v[j][k] + (keyPropE.v[j][k] - keyPropS.v[j][k]) * perc;
					previousValue.v[j][k] = vertexValue;
				}
			}
			function interpolateShapeCurrentTime() {
				var frameNum = this.comp.renderedFrame - this.offsetTime;
				var initTime = this.keyframes[0].t - this.offsetTime;
				var endTime = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
				var lastFrame = this._caching.lastFrame;
				if (!(lastFrame !== initFrame && (lastFrame < initTime && frameNum < initTime || lastFrame > endTime && frameNum > endTime))) {
					this._caching.lastIndex = lastFrame < frameNum ? this._caching.lastIndex : 0;
					this.interpolateShape(frameNum, this.pv, this._caching);
				}
				this._caching.lastFrame = frameNum;
				return this.pv;
			}
			function resetShape() {
				this.paths = this.localShapeCollection;
			}
			function shapesEqual(shape1, shape2) {
				if (shape1._length !== shape2._length || shape1.c !== shape2.c) return false;
				var i;
				var len = shape1._length;
				for (i = 0; i < len; i += 1) if (shape1.v[i][0] !== shape2.v[i][0] || shape1.v[i][1] !== shape2.v[i][1] || shape1.o[i][0] !== shape2.o[i][0] || shape1.o[i][1] !== shape2.o[i][1] || shape1.i[i][0] !== shape2.i[i][0] || shape1.i[i][1] !== shape2.i[i][1]) return false;
				return true;
			}
			function setVValue(newPath) {
				if (!shapesEqual(this.v, newPath)) {
					this.v = shapePool.clone(newPath);
					this.localShapeCollection.releaseShapes();
					this.localShapeCollection.addShape(this.v);
					this._mdf = true;
					this.paths = this.localShapeCollection;
				}
			}
			function processEffectsSequence() {
				if (this.elem.globalData.frameId === this.frameId) return;
				if (!this.effectsSequence.length) {
					this._mdf = false;
					return;
				}
				if (this.lock) {
					this.setVValue(this.pv);
					return;
				}
				this.lock = true;
				this._mdf = false;
				var finalValue;
				if (this.kf) finalValue = this.pv;
				else if (this.data.ks) finalValue = this.data.ks.k;
				else finalValue = this.data.pt.k;
				var i;
				var len = this.effectsSequence.length;
				for (i = 0; i < len; i += 1) finalValue = this.effectsSequence[i](finalValue);
				this.setVValue(finalValue);
				this.lock = false;
				this.frameId = this.elem.globalData.frameId;
			}
			function ShapeProperty(elem, data, type) {
				this.propType = "shape";
				this.comp = elem.comp;
				this.container = elem;
				this.elem = elem;
				this.data = data;
				this.k = false;
				this.kf = false;
				this._mdf = false;
				var pathData = type === 3 ? data.pt.k : data.ks.k;
				this.v = shapePool.clone(pathData);
				this.pv = shapePool.clone(this.v);
				this.localShapeCollection = shapeCollectionPool.newShapeCollection();
				this.paths = this.localShapeCollection;
				this.paths.addShape(this.v);
				this.reset = resetShape;
				this.effectsSequence = [];
			}
			function addEffect(effectFunction) {
				this.effectsSequence.push(effectFunction);
				this.container.addDynamicProperty(this);
			}
			ShapeProperty.prototype.interpolateShape = interpolateShape;
			ShapeProperty.prototype.getValue = processEffectsSequence;
			ShapeProperty.prototype.setVValue = setVValue;
			ShapeProperty.prototype.addEffect = addEffect;
			function KeyframedShapeProperty(elem, data, type) {
				this.propType = "shape";
				this.comp = elem.comp;
				this.elem = elem;
				this.container = elem;
				this.offsetTime = elem.data.st;
				this.keyframes = type === 3 ? data.pt.k : data.ks.k;
				this.keyframesMetadata = [];
				this.k = true;
				this.kf = true;
				var len = this.keyframes[0].s[0].i.length;
				this.v = shapePool.newElement();
				this.v.setPathData(this.keyframes[0].s[0].c, len);
				this.pv = shapePool.clone(this.v);
				this.localShapeCollection = shapeCollectionPool.newShapeCollection();
				this.paths = this.localShapeCollection;
				this.paths.addShape(this.v);
				this.lastFrame = initFrame;
				this.reset = resetShape;
				this._caching = {
					lastFrame: initFrame,
					lastIndex: 0
				};
				this.effectsSequence = [interpolateShapeCurrentTime.bind(this)];
			}
			KeyframedShapeProperty.prototype.getValue = processEffectsSequence;
			KeyframedShapeProperty.prototype.interpolateShape = interpolateShape;
			KeyframedShapeProperty.prototype.setVValue = setVValue;
			KeyframedShapeProperty.prototype.addEffect = addEffect;
			var EllShapeProperty = function() {
				var cPoint = roundCorner;
				function EllShapePropertyFactory(elem, data) {
					this.v = shapePool.newElement();
					this.v.setPathData(true, 4);
					this.localShapeCollection = shapeCollectionPool.newShapeCollection();
					this.paths = this.localShapeCollection;
					this.localShapeCollection.addShape(this.v);
					this.d = data.d;
					this.elem = elem;
					this.comp = elem.comp;
					this.frameId = -1;
					this.initDynamicPropertyContainer(elem);
					this.p = PropertyFactory.getProp(elem, data.p, 1, 0, this);
					this.s = PropertyFactory.getProp(elem, data.s, 1, 0, this);
					if (this.dynamicProperties.length) this.k = true;
					else {
						this.k = false;
						this.convertEllToPath();
					}
				}
				EllShapePropertyFactory.prototype = {
					reset: resetShape,
					getValue: function getValue() {
						if (this.elem.globalData.frameId === this.frameId) return;
						this.frameId = this.elem.globalData.frameId;
						this.iterateDynamicProperties();
						if (this._mdf) this.convertEllToPath();
					},
					convertEllToPath: function convertEllToPath() {
						var p0 = this.p.v[0];
						var p1 = this.p.v[1];
						var s0 = this.s.v[0] / 2;
						var s1 = this.s.v[1] / 2;
						var _cw = this.d !== 3;
						var _v = this.v;
						_v.v[0][0] = p0;
						_v.v[0][1] = p1 - s1;
						_v.v[1][0] = _cw ? p0 + s0 : p0 - s0;
						_v.v[1][1] = p1;
						_v.v[2][0] = p0;
						_v.v[2][1] = p1 + s1;
						_v.v[3][0] = _cw ? p0 - s0 : p0 + s0;
						_v.v[3][1] = p1;
						_v.i[0][0] = _cw ? p0 - s0 * cPoint : p0 + s0 * cPoint;
						_v.i[0][1] = p1 - s1;
						_v.i[1][0] = _cw ? p0 + s0 : p0 - s0;
						_v.i[1][1] = p1 - s1 * cPoint;
						_v.i[2][0] = _cw ? p0 + s0 * cPoint : p0 - s0 * cPoint;
						_v.i[2][1] = p1 + s1;
						_v.i[3][0] = _cw ? p0 - s0 : p0 + s0;
						_v.i[3][1] = p1 + s1 * cPoint;
						_v.o[0][0] = _cw ? p0 + s0 * cPoint : p0 - s0 * cPoint;
						_v.o[0][1] = p1 - s1;
						_v.o[1][0] = _cw ? p0 + s0 : p0 - s0;
						_v.o[1][1] = p1 + s1 * cPoint;
						_v.o[2][0] = _cw ? p0 - s0 * cPoint : p0 + s0 * cPoint;
						_v.o[2][1] = p1 + s1;
						_v.o[3][0] = _cw ? p0 - s0 : p0 + s0;
						_v.o[3][1] = p1 - s1 * cPoint;
					}
				};
				extendPrototype([DynamicPropertyContainer], EllShapePropertyFactory);
				return EllShapePropertyFactory;
			}();
			var StarShapeProperty = function() {
				function StarShapePropertyFactory(elem, data) {
					this.v = shapePool.newElement();
					this.v.setPathData(true, 0);
					this.elem = elem;
					this.comp = elem.comp;
					this.data = data;
					this.frameId = -1;
					this.d = data.d;
					this.initDynamicPropertyContainer(elem);
					if (data.sy === 1) {
						this.ir = PropertyFactory.getProp(elem, data.ir, 0, 0, this);
						this.is = PropertyFactory.getProp(elem, data.is, 0, .01, this);
						this.convertToPath = this.convertStarToPath;
					} else this.convertToPath = this.convertPolygonToPath;
					this.pt = PropertyFactory.getProp(elem, data.pt, 0, 0, this);
					this.p = PropertyFactory.getProp(elem, data.p, 1, 0, this);
					this.r = PropertyFactory.getProp(elem, data.r, 0, degToRads, this);
					this.or = PropertyFactory.getProp(elem, data.or, 0, 0, this);
					this.os = PropertyFactory.getProp(elem, data.os, 0, .01, this);
					this.localShapeCollection = shapeCollectionPool.newShapeCollection();
					this.localShapeCollection.addShape(this.v);
					this.paths = this.localShapeCollection;
					if (this.dynamicProperties.length) this.k = true;
					else {
						this.k = false;
						this.convertToPath();
					}
				}
				StarShapePropertyFactory.prototype = {
					reset: resetShape,
					getValue: function getValue() {
						if (this.elem.globalData.frameId === this.frameId) return;
						this.frameId = this.elem.globalData.frameId;
						this.iterateDynamicProperties();
						if (this._mdf) this.convertToPath();
					},
					convertStarToPath: function convertStarToPath() {
						var numPts = Math.floor(this.pt.v) * 2;
						var angle = Math.PI * 2 / numPts;
						var longFlag = true;
						var longRad = this.or.v;
						var shortRad = this.ir.v;
						var longRound = this.os.v;
						var shortRound = this.is.v;
						var longPerimSegment = 2 * Math.PI * longRad / (numPts * 2);
						var shortPerimSegment = 2 * Math.PI * shortRad / (numPts * 2);
						var i;
						var rad;
						var roundness;
						var perimSegment;
						var currentAng = -Math.PI / 2;
						currentAng += this.r.v;
						var dir = this.data.d === 3 ? -1 : 1;
						this.v._length = 0;
						for (i = 0; i < numPts; i += 1) {
							rad = longFlag ? longRad : shortRad;
							roundness = longFlag ? longRound : shortRound;
							perimSegment = longFlag ? longPerimSegment : shortPerimSegment;
							var x = rad * Math.cos(currentAng);
							var y = rad * Math.sin(currentAng);
							var ox = x === 0 && y === 0 ? 0 : y / Math.sqrt(x * x + y * y);
							var oy = x === 0 && y === 0 ? 0 : -x / Math.sqrt(x * x + y * y);
							x += +this.p.v[0];
							y += +this.p.v[1];
							this.v.setTripleAt(x, y, x - ox * perimSegment * roundness * dir, y - oy * perimSegment * roundness * dir, x + ox * perimSegment * roundness * dir, y + oy * perimSegment * roundness * dir, i, true);
							longFlag = !longFlag;
							currentAng += angle * dir;
						}
					},
					convertPolygonToPath: function convertPolygonToPath() {
						var numPts = Math.floor(this.pt.v);
						var angle = Math.PI * 2 / numPts;
						var rad = this.or.v;
						var roundness = this.os.v;
						var perimSegment = 2 * Math.PI * rad / (numPts * 4);
						var i;
						var currentAng = -Math.PI * .5;
						var dir = this.data.d === 3 ? -1 : 1;
						currentAng += this.r.v;
						this.v._length = 0;
						for (i = 0; i < numPts; i += 1) {
							var x = rad * Math.cos(currentAng);
							var y = rad * Math.sin(currentAng);
							var ox = x === 0 && y === 0 ? 0 : y / Math.sqrt(x * x + y * y);
							var oy = x === 0 && y === 0 ? 0 : -x / Math.sqrt(x * x + y * y);
							x += +this.p.v[0];
							y += +this.p.v[1];
							this.v.setTripleAt(x, y, x - ox * perimSegment * roundness * dir, y - oy * perimSegment * roundness * dir, x + ox * perimSegment * roundness * dir, y + oy * perimSegment * roundness * dir, i, true);
							currentAng += angle * dir;
						}
						this.paths.length = 0;
						this.paths[0] = this.v;
					}
				};
				extendPrototype([DynamicPropertyContainer], StarShapePropertyFactory);
				return StarShapePropertyFactory;
			}();
			var RectShapeProperty = function() {
				function RectShapePropertyFactory(elem, data) {
					this.v = shapePool.newElement();
					this.v.c = true;
					this.localShapeCollection = shapeCollectionPool.newShapeCollection();
					this.localShapeCollection.addShape(this.v);
					this.paths = this.localShapeCollection;
					this.elem = elem;
					this.comp = elem.comp;
					this.frameId = -1;
					this.d = data.d;
					this.initDynamicPropertyContainer(elem);
					this.p = PropertyFactory.getProp(elem, data.p, 1, 0, this);
					this.s = PropertyFactory.getProp(elem, data.s, 1, 0, this);
					this.r = PropertyFactory.getProp(elem, data.r, 0, 0, this);
					if (this.dynamicProperties.length) this.k = true;
					else {
						this.k = false;
						this.convertRectToPath();
					}
				}
				RectShapePropertyFactory.prototype = {
					convertRectToPath: function convertRectToPath() {
						var p0 = this.p.v[0];
						var p1 = this.p.v[1];
						var v0 = this.s.v[0] / 2;
						var v1 = this.s.v[1] / 2;
						var round = bmMin(v0, v1, this.r.v);
						var cPoint = round * (1 - roundCorner);
						this.v._length = 0;
						if (this.d === 2 || this.d === 1) {
							this.v.setTripleAt(p0 + v0, p1 - v1 + round, p0 + v0, p1 - v1 + round, p0 + v0, p1 - v1 + cPoint, 0, true);
							this.v.setTripleAt(p0 + v0, p1 + v1 - round, p0 + v0, p1 + v1 - cPoint, p0 + v0, p1 + v1 - round, 1, true);
							if (round !== 0) {
								this.v.setTripleAt(p0 + v0 - round, p1 + v1, p0 + v0 - round, p1 + v1, p0 + v0 - cPoint, p1 + v1, 2, true);
								this.v.setTripleAt(p0 - v0 + round, p1 + v1, p0 - v0 + cPoint, p1 + v1, p0 - v0 + round, p1 + v1, 3, true);
								this.v.setTripleAt(p0 - v0, p1 + v1 - round, p0 - v0, p1 + v1 - round, p0 - v0, p1 + v1 - cPoint, 4, true);
								this.v.setTripleAt(p0 - v0, p1 - v1 + round, p0 - v0, p1 - v1 + cPoint, p0 - v0, p1 - v1 + round, 5, true);
								this.v.setTripleAt(p0 - v0 + round, p1 - v1, p0 - v0 + round, p1 - v1, p0 - v0 + cPoint, p1 - v1, 6, true);
								this.v.setTripleAt(p0 + v0 - round, p1 - v1, p0 + v0 - cPoint, p1 - v1, p0 + v0 - round, p1 - v1, 7, true);
							} else {
								this.v.setTripleAt(p0 - v0, p1 + v1, p0 - v0 + cPoint, p1 + v1, p0 - v0, p1 + v1, 2);
								this.v.setTripleAt(p0 - v0, p1 - v1, p0 - v0, p1 - v1 + cPoint, p0 - v0, p1 - v1, 3);
							}
						} else {
							this.v.setTripleAt(p0 + v0, p1 - v1 + round, p0 + v0, p1 - v1 + cPoint, p0 + v0, p1 - v1 + round, 0, true);
							if (round !== 0) {
								this.v.setTripleAt(p0 + v0 - round, p1 - v1, p0 + v0 - round, p1 - v1, p0 + v0 - cPoint, p1 - v1, 1, true);
								this.v.setTripleAt(p0 - v0 + round, p1 - v1, p0 - v0 + cPoint, p1 - v1, p0 - v0 + round, p1 - v1, 2, true);
								this.v.setTripleAt(p0 - v0, p1 - v1 + round, p0 - v0, p1 - v1 + round, p0 - v0, p1 - v1 + cPoint, 3, true);
								this.v.setTripleAt(p0 - v0, p1 + v1 - round, p0 - v0, p1 + v1 - cPoint, p0 - v0, p1 + v1 - round, 4, true);
								this.v.setTripleAt(p0 - v0 + round, p1 + v1, p0 - v0 + round, p1 + v1, p0 - v0 + cPoint, p1 + v1, 5, true);
								this.v.setTripleAt(p0 + v0 - round, p1 + v1, p0 + v0 - cPoint, p1 + v1, p0 + v0 - round, p1 + v1, 6, true);
								this.v.setTripleAt(p0 + v0, p1 + v1 - round, p0 + v0, p1 + v1 - round, p0 + v0, p1 + v1 - cPoint, 7, true);
							} else {
								this.v.setTripleAt(p0 - v0, p1 - v1, p0 - v0 + cPoint, p1 - v1, p0 - v0, p1 - v1, 1, true);
								this.v.setTripleAt(p0 - v0, p1 + v1, p0 - v0, p1 + v1 - cPoint, p0 - v0, p1 + v1, 2, true);
								this.v.setTripleAt(p0 + v0, p1 + v1, p0 + v0 - cPoint, p1 + v1, p0 + v0, p1 + v1, 3, true);
							}
						}
					},
					getValue: function getValue() {
						if (this.elem.globalData.frameId === this.frameId) return;
						this.frameId = this.elem.globalData.frameId;
						this.iterateDynamicProperties();
						if (this._mdf) this.convertRectToPath();
					},
					reset: resetShape
				};
				extendPrototype([DynamicPropertyContainer], RectShapePropertyFactory);
				return RectShapePropertyFactory;
			}();
			function getShapeProp(elem, data, type) {
				var prop;
				if (type === 3 || type === 4) {
					if ((type === 3 ? data.pt : data.ks).k.length) prop = new KeyframedShapeProperty(elem, data, type);
					else prop = new ShapeProperty(elem, data, type);
				} else if (type === 5) prop = new RectShapeProperty(elem, data);
				else if (type === 6) prop = new EllShapeProperty(elem, data);
				else if (type === 7) prop = new StarShapeProperty(elem, data);
				if (prop.k) elem.addDynamicProperty(prop);
				return prop;
			}
			function getConstructorFunction() {
				return ShapeProperty;
			}
			function getKeyframedConstructorFunction() {
				return KeyframedShapeProperty;
			}
			var ob = {};
			ob.getShapeProp = getShapeProp;
			ob.getConstructorFunction = getConstructorFunction;
			ob.getKeyframedConstructorFunction = getKeyframedConstructorFunction;
			return ob;
		}();
		/**
		* 2D transformation matrix object initialized with identity matrix.
		*
		* The matrix can synchronize a canvas context by supplying the context
		* as an argument, or later apply current absolute transform to an
		* existing context.
		*
		* All values are handled as floating point values.
		*
		* @param {CanvasRenderingContext2D} [context] - Optional context to sync with Matrix
		* @prop {number} a - scale x
		* @prop {number} b - shear y
		* @prop {number} c - shear x
		* @prop {number} d - scale y
		* @prop {number} e - translate x
		* @prop {number} f - translate y
		* @prop {CanvasRenderingContext2D|null} [context=null] - set or get current canvas context
		* @constructor
		*/
		var Matrix = function() {
			var _cos = Math.cos;
			var _sin = Math.sin;
			var _tan = Math.tan;
			var _rnd = Math.round;
			function reset() {
				this.props[0] = 1;
				this.props[1] = 0;
				this.props[2] = 0;
				this.props[3] = 0;
				this.props[4] = 0;
				this.props[5] = 1;
				this.props[6] = 0;
				this.props[7] = 0;
				this.props[8] = 0;
				this.props[9] = 0;
				this.props[10] = 1;
				this.props[11] = 0;
				this.props[12] = 0;
				this.props[13] = 0;
				this.props[14] = 0;
				this.props[15] = 1;
				return this;
			}
			function rotate(angle) {
				if (angle === 0) return this;
				var mCos = _cos(angle);
				var mSin = _sin(angle);
				return this._t(mCos, -mSin, 0, 0, mSin, mCos, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
			}
			function rotateX(angle) {
				if (angle === 0) return this;
				var mCos = _cos(angle);
				var mSin = _sin(angle);
				return this._t(1, 0, 0, 0, 0, mCos, -mSin, 0, 0, mSin, mCos, 0, 0, 0, 0, 1);
			}
			function rotateY(angle) {
				if (angle === 0) return this;
				var mCos = _cos(angle);
				var mSin = _sin(angle);
				return this._t(mCos, 0, mSin, 0, 0, 1, 0, 0, -mSin, 0, mCos, 0, 0, 0, 0, 1);
			}
			function rotateZ(angle) {
				if (angle === 0) return this;
				var mCos = _cos(angle);
				var mSin = _sin(angle);
				return this._t(mCos, -mSin, 0, 0, mSin, mCos, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
			}
			function shear(sx, sy) {
				return this._t(1, sy, sx, 1, 0, 0);
			}
			function skew(ax, ay) {
				return this.shear(_tan(ax), _tan(ay));
			}
			function skewFromAxis(ax, angle) {
				var mCos = _cos(angle);
				var mSin = _sin(angle);
				return this._t(mCos, mSin, 0, 0, -mSin, mCos, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, _tan(ax), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(mCos, -mSin, 0, 0, mSin, mCos, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
			}
			function scale(sx, sy, sz) {
				if (!sz && sz !== 0) sz = 1;
				if (sx === 1 && sy === 1 && sz === 1) return this;
				return this._t(sx, 0, 0, 0, 0, sy, 0, 0, 0, 0, sz, 0, 0, 0, 0, 1);
			}
			function setTransform(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p) {
				this.props[0] = a;
				this.props[1] = b;
				this.props[2] = c;
				this.props[3] = d;
				this.props[4] = e;
				this.props[5] = f;
				this.props[6] = g;
				this.props[7] = h;
				this.props[8] = i;
				this.props[9] = j;
				this.props[10] = k;
				this.props[11] = l;
				this.props[12] = m;
				this.props[13] = n;
				this.props[14] = o;
				this.props[15] = p;
				return this;
			}
			function translate(tx, ty, tz) {
				tz = tz || 0;
				if (tx !== 0 || ty !== 0 || tz !== 0) return this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, tx, ty, tz, 1);
				return this;
			}
			function transform(a2, b2, c2, d2, e2, f2, g2, h2, i2, j2, k2, l2, m2, n2, o2, p2) {
				var _p = this.props;
				if (a2 === 1 && b2 === 0 && c2 === 0 && d2 === 0 && e2 === 0 && f2 === 1 && g2 === 0 && h2 === 0 && i2 === 0 && j2 === 0 && k2 === 1 && l2 === 0) {
					_p[12] = _p[12] * a2 + _p[15] * m2;
					_p[13] = _p[13] * f2 + _p[15] * n2;
					_p[14] = _p[14] * k2 + _p[15] * o2;
					_p[15] *= p2;
					this._identityCalculated = false;
					return this;
				}
				var a1 = _p[0];
				var b1 = _p[1];
				var c1 = _p[2];
				var d1 = _p[3];
				var e1 = _p[4];
				var f1 = _p[5];
				var g1 = _p[6];
				var h1 = _p[7];
				var i1 = _p[8];
				var j1 = _p[9];
				var k1 = _p[10];
				var l1 = _p[11];
				var m1 = _p[12];
				var n1 = _p[13];
				var o1 = _p[14];
				var p1 = _p[15];
				_p[0] = a1 * a2 + b1 * e2 + c1 * i2 + d1 * m2;
				_p[1] = a1 * b2 + b1 * f2 + c1 * j2 + d1 * n2;
				_p[2] = a1 * c2 + b1 * g2 + c1 * k2 + d1 * o2;
				_p[3] = a1 * d2 + b1 * h2 + c1 * l2 + d1 * p2;
				_p[4] = e1 * a2 + f1 * e2 + g1 * i2 + h1 * m2;
				_p[5] = e1 * b2 + f1 * f2 + g1 * j2 + h1 * n2;
				_p[6] = e1 * c2 + f1 * g2 + g1 * k2 + h1 * o2;
				_p[7] = e1 * d2 + f1 * h2 + g1 * l2 + h1 * p2;
				_p[8] = i1 * a2 + j1 * e2 + k1 * i2 + l1 * m2;
				_p[9] = i1 * b2 + j1 * f2 + k1 * j2 + l1 * n2;
				_p[10] = i1 * c2 + j1 * g2 + k1 * k2 + l1 * o2;
				_p[11] = i1 * d2 + j1 * h2 + k1 * l2 + l1 * p2;
				_p[12] = m1 * a2 + n1 * e2 + o1 * i2 + p1 * m2;
				_p[13] = m1 * b2 + n1 * f2 + o1 * j2 + p1 * n2;
				_p[14] = m1 * c2 + n1 * g2 + o1 * k2 + p1 * o2;
				_p[15] = m1 * d2 + n1 * h2 + o1 * l2 + p1 * p2;
				this._identityCalculated = false;
				return this;
			}
			function multiply(matrix) {
				var matrixProps = matrix.props;
				return this.transform(matrixProps[0], matrixProps[1], matrixProps[2], matrixProps[3], matrixProps[4], matrixProps[5], matrixProps[6], matrixProps[7], matrixProps[8], matrixProps[9], matrixProps[10], matrixProps[11], matrixProps[12], matrixProps[13], matrixProps[14], matrixProps[15]);
			}
			function isIdentity() {
				if (!this._identityCalculated) {
					this._identity = !(this.props[0] !== 1 || this.props[1] !== 0 || this.props[2] !== 0 || this.props[3] !== 0 || this.props[4] !== 0 || this.props[5] !== 1 || this.props[6] !== 0 || this.props[7] !== 0 || this.props[8] !== 0 || this.props[9] !== 0 || this.props[10] !== 1 || this.props[11] !== 0 || this.props[12] !== 0 || this.props[13] !== 0 || this.props[14] !== 0 || this.props[15] !== 1);
					this._identityCalculated = true;
				}
				return this._identity;
			}
			function equals(matr) {
				var i = 0;
				while (i < 16) {
					if (matr.props[i] !== this.props[i]) return false;
					i += 1;
				}
				return true;
			}
			function clone(matr) {
				var i;
				for (i = 0; i < 16; i += 1) matr.props[i] = this.props[i];
				return matr;
			}
			function cloneFromProps(props) {
				var i;
				for (i = 0; i < 16; i += 1) this.props[i] = props[i];
			}
			function applyToPoint(x, y, z) {
				return {
					x: x * this.props[0] + y * this.props[4] + z * this.props[8] + this.props[12],
					y: x * this.props[1] + y * this.props[5] + z * this.props[9] + this.props[13],
					z: x * this.props[2] + y * this.props[6] + z * this.props[10] + this.props[14]
				};
			}
			function applyToX(x, y, z) {
				return x * this.props[0] + y * this.props[4] + z * this.props[8] + this.props[12];
			}
			function applyToY(x, y, z) {
				return x * this.props[1] + y * this.props[5] + z * this.props[9] + this.props[13];
			}
			function applyToZ(x, y, z) {
				return x * this.props[2] + y * this.props[6] + z * this.props[10] + this.props[14];
			}
			function getInverseMatrix() {
				var determinant = this.props[0] * this.props[5] - this.props[1] * this.props[4];
				var a = this.props[5] / determinant;
				var b = -this.props[1] / determinant;
				var c = -this.props[4] / determinant;
				var d = this.props[0] / determinant;
				var e = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / determinant;
				var f = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / determinant;
				var inverseMatrix = new Matrix();
				inverseMatrix.props[0] = a;
				inverseMatrix.props[1] = b;
				inverseMatrix.props[4] = c;
				inverseMatrix.props[5] = d;
				inverseMatrix.props[12] = e;
				inverseMatrix.props[13] = f;
				return inverseMatrix;
			}
			function inversePoint(pt) {
				return this.getInverseMatrix().applyToPointArray(pt[0], pt[1], pt[2] || 0);
			}
			function inversePoints(pts) {
				var i;
				var len = pts.length;
				var retPts = [];
				for (i = 0; i < len; i += 1) retPts[i] = inversePoint(pts[i]);
				return retPts;
			}
			function applyToTriplePoints(pt1, pt2, pt3) {
				var arr = createTypedArray("float32", 6);
				if (this.isIdentity()) {
					arr[0] = pt1[0];
					arr[1] = pt1[1];
					arr[2] = pt2[0];
					arr[3] = pt2[1];
					arr[4] = pt3[0];
					arr[5] = pt3[1];
				} else {
					var p0 = this.props[0];
					var p1 = this.props[1];
					var p4 = this.props[4];
					var p5 = this.props[5];
					var p12 = this.props[12];
					var p13 = this.props[13];
					arr[0] = pt1[0] * p0 + pt1[1] * p4 + p12;
					arr[1] = pt1[0] * p1 + pt1[1] * p5 + p13;
					arr[2] = pt2[0] * p0 + pt2[1] * p4 + p12;
					arr[3] = pt2[0] * p1 + pt2[1] * p5 + p13;
					arr[4] = pt3[0] * p0 + pt3[1] * p4 + p12;
					arr[5] = pt3[0] * p1 + pt3[1] * p5 + p13;
				}
				return arr;
			}
			function applyToPointArray(x, y, z) {
				var arr;
				if (this.isIdentity()) arr = [
					x,
					y,
					z
				];
				else arr = [
					x * this.props[0] + y * this.props[4] + z * this.props[8] + this.props[12],
					x * this.props[1] + y * this.props[5] + z * this.props[9] + this.props[13],
					x * this.props[2] + y * this.props[6] + z * this.props[10] + this.props[14]
				];
				return arr;
			}
			function applyToPointStringified(x, y) {
				if (this.isIdentity()) return x + "," + y;
				var _p = this.props;
				return Math.round((x * _p[0] + y * _p[4] + _p[12]) * 100) / 100 + "," + Math.round((x * _p[1] + y * _p[5] + _p[13]) * 100) / 100;
			}
			function toCSS() {
				var i = 0;
				var props = this.props;
				var cssValue = "matrix3d(";
				var v = 1e4;
				while (i < 16) {
					cssValue += _rnd(props[i] * v) / v;
					cssValue += i === 15 ? ")" : ",";
					i += 1;
				}
				return cssValue;
			}
			function roundMatrixProperty(val) {
				var v = 1e4;
				if (val < 1e-6 && val > 0 || val > -1e-6 && val < 0) return _rnd(val * v) / v;
				return val;
			}
			function to2dCSS() {
				var props = this.props;
				var _a = roundMatrixProperty(props[0]);
				var _b = roundMatrixProperty(props[1]);
				var _c = roundMatrixProperty(props[4]);
				var _d = roundMatrixProperty(props[5]);
				var _e = roundMatrixProperty(props[12]);
				var _f = roundMatrixProperty(props[13]);
				return "matrix(" + _a + "," + _b + "," + _c + "," + _d + "," + _e + "," + _f + ")";
			}
			return function() {
				this.reset = reset;
				this.rotate = rotate;
				this.rotateX = rotateX;
				this.rotateY = rotateY;
				this.rotateZ = rotateZ;
				this.skew = skew;
				this.skewFromAxis = skewFromAxis;
				this.shear = shear;
				this.scale = scale;
				this.setTransform = setTransform;
				this.translate = translate;
				this.transform = transform;
				this.multiply = multiply;
				this.applyToPoint = applyToPoint;
				this.applyToX = applyToX;
				this.applyToY = applyToY;
				this.applyToZ = applyToZ;
				this.applyToPointArray = applyToPointArray;
				this.applyToTriplePoints = applyToTriplePoints;
				this.applyToPointStringified = applyToPointStringified;
				this.toCSS = toCSS;
				this.to2dCSS = to2dCSS;
				this.clone = clone;
				this.cloneFromProps = cloneFromProps;
				this.equals = equals;
				this.inversePoints = inversePoints;
				this.inversePoint = inversePoint;
				this.getInverseMatrix = getInverseMatrix;
				this._t = this.transform;
				this.isIdentity = isIdentity;
				this._identity = true;
				this._identityCalculated = false;
				this.props = createTypedArray("float32", 16);
				this.reset();
			};
		}();
		function _typeof(o) {
			"@babel/helpers - typeof";
			return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
				return typeof o;
			} : function(o) {
				return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
			}, _typeof(o);
		}
		var lottie = {};
		var standalone = "__[STANDALONE]__";
		var animationData = "__[ANIMATIONDATA]__";
		var renderer = "";
		function setLocation(href) {
			setLocationHref(href);
		}
		function searchAnimations() {
			if (standalone === true) animationManager.searchAnimations(animationData, standalone, renderer);
			else animationManager.searchAnimations();
		}
		function setSubframeRendering(flag) {
			setSubframeEnabled(flag);
		}
		function setPrefix(prefix) {
			setIdPrefix(prefix);
		}
		function loadAnimation(params) {
			if (standalone === true) params.animationData = JSON.parse(animationData);
			return animationManager.loadAnimation(params);
		}
		function setQuality(value) {
			if (typeof value === "string") switch (value) {
				case "high":
					setDefaultCurveSegments(200);
					break;
				default:
				case "medium":
					setDefaultCurveSegments(50);
					break;
				case "low": setDefaultCurveSegments(10);
			}
			else if (!isNaN(value) && value > 1) setDefaultCurveSegments(value);
			if (getDefaultCurveSegments() >= 50);
		}
		function inBrowser() {
			return typeof navigator !== "undefined";
		}
		function installPlugin(type, plugin) {
			if (type === "expressions") setExpressionsPlugin(plugin);
		}
		function getFactory(name) {
			switch (name) {
				case "propertyFactory": return PropertyFactory;
				case "shapePropertyFactory": return ShapePropertyFactory;
				case "matrix": return Matrix;
				default: return null;
			}
		}
		lottie.play = animationManager.play;
		lottie.pause = animationManager.pause;
		lottie.setLocationHref = setLocation;
		lottie.togglePause = animationManager.togglePause;
		lottie.setSpeed = animationManager.setSpeed;
		lottie.setDirection = animationManager.setDirection;
		lottie.stop = animationManager.stop;
		lottie.searchAnimations = searchAnimations;
		lottie.registerAnimation = animationManager.registerAnimation;
		lottie.loadAnimation = loadAnimation;
		lottie.setSubframeRendering = setSubframeRendering;
		lottie.resize = animationManager.resize;
		lottie.goToAndStop = animationManager.goToAndStop;
		lottie.destroy = animationManager.destroy;
		lottie.setQuality = setQuality;
		lottie.inBrowser = inBrowser;
		lottie.installPlugin = installPlugin;
		lottie.freeze = animationManager.freeze;
		lottie.unfreeze = animationManager.unfreeze;
		lottie.setVolume = animationManager.setVolume;
		lottie.mute = animationManager.mute;
		lottie.unmute = animationManager.unmute;
		lottie.getRegisteredAnimations = animationManager.getRegisteredAnimations;
		lottie.useWebWorker = setWebWorker;
		lottie.setIDPrefix = setPrefix;
		lottie.__getFactory = getFactory;
		lottie.version = "5.13.0";
		function checkReady() {
			if (document.readyState === "complete") {
				clearInterval(readyStateCheckInterval);
				searchAnimations();
			}
		}
		function getQueryVariable(variable) {
			var vars = queryString.split("&");
			for (var i = 0; i < vars.length; i += 1) {
				var pair = vars[i].split("=");
				if (decodeURIComponent(pair[0]) == variable) return decodeURIComponent(pair[1]);
			}
			return null;
		}
		var queryString = "";
		if (standalone) {
			var scripts = document.getElementsByTagName("script");
			var myScript = scripts[scripts.length - 1] || { src: "" };
			queryString = myScript.src ? myScript.src.replace(/^[^\?]+\??/, "") : "";
			renderer = getQueryVariable("renderer");
		}
		var readyStateCheckInterval = setInterval(checkReady, 100);
		try {
			if (!((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") && !(typeof define === "function" && define.amd)) window.bodymovin = lottie;
		} catch (err) {}
		var ShapeModifiers = function() {
			var ob = {};
			var modifiers = {};
			ob.registerModifier = registerModifier;
			ob.getModifier = getModifier;
			function registerModifier(nm, factory) {
				if (!modifiers[nm]) modifiers[nm] = factory;
			}
			function getModifier(nm, elem, data) {
				return new modifiers[nm](elem, data);
			}
			return ob;
		}();
		function ShapeModifier() {}
		ShapeModifier.prototype.initModifierProperties = function() {};
		ShapeModifier.prototype.addShapeToModifier = function() {};
		ShapeModifier.prototype.addShape = function(data) {
			if (!this.closed) {
				data.sh.container.addDynamicProperty(data.sh);
				var shapeData = {
					shape: data.sh,
					data,
					localShapeCollection: shapeCollectionPool.newShapeCollection()
				};
				this.shapes.push(shapeData);
				this.addShapeToModifier(shapeData);
				if (this._isAnimated) data.setAsAnimated();
			}
		};
		ShapeModifier.prototype.init = function(elem, data) {
			this.shapes = [];
			this.elem = elem;
			this.initDynamicPropertyContainer(elem);
			this.initModifierProperties(elem, data);
			this.frameId = initialDefaultFrame;
			this.closed = false;
			this.k = false;
			if (this.dynamicProperties.length) this.k = true;
			else this.getValue(true);
		};
		ShapeModifier.prototype.processKeys = function() {
			if (this.elem.globalData.frameId === this.frameId) return;
			this.frameId = this.elem.globalData.frameId;
			this.iterateDynamicProperties();
		};
		extendPrototype([DynamicPropertyContainer], ShapeModifier);
		function TrimModifier() {}
		extendPrototype([ShapeModifier], TrimModifier);
		TrimModifier.prototype.initModifierProperties = function(elem, data) {
			this.s = PropertyFactory.getProp(elem, data.s, 0, .01, this);
			this.e = PropertyFactory.getProp(elem, data.e, 0, .01, this);
			this.o = PropertyFactory.getProp(elem, data.o, 0, 0, this);
			this.sValue = 0;
			this.eValue = 0;
			this.getValue = this.processKeys;
			this.m = data.m;
			this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length;
		};
		TrimModifier.prototype.addShapeToModifier = function(shapeData) {
			shapeData.pathsData = [];
		};
		TrimModifier.prototype.calculateShapeEdges = function(s, e, shapeLength, addedLength, totalModifierLength) {
			var segments = [];
			if (e <= 1) segments.push({
				s,
				e
			});
			else if (s >= 1) segments.push({
				s: s - 1,
				e: e - 1
			});
			else {
				segments.push({
					s,
					e: 1
				});
				segments.push({
					s: 0,
					e: e - 1
				});
			}
			var shapeSegments = [];
			var i;
			var len = segments.length;
			var segmentOb;
			for (i = 0; i < len; i += 1) {
				segmentOb = segments[i];
				if (!(segmentOb.e * totalModifierLength < addedLength || segmentOb.s * totalModifierLength > addedLength + shapeLength)) {
					var shapeS;
					var shapeE;
					if (segmentOb.s * totalModifierLength <= addedLength) shapeS = 0;
					else shapeS = (segmentOb.s * totalModifierLength - addedLength) / shapeLength;
					if (segmentOb.e * totalModifierLength >= addedLength + shapeLength) shapeE = 1;
					else shapeE = (segmentOb.e * totalModifierLength - addedLength) / shapeLength;
					shapeSegments.push([shapeS, shapeE]);
				}
			}
			if (!shapeSegments.length) shapeSegments.push([0, 0]);
			return shapeSegments;
		};
		TrimModifier.prototype.releasePathsData = function(pathsData) {
			var i;
			var len = pathsData.length;
			for (i = 0; i < len; i += 1) segmentsLengthPool.release(pathsData[i]);
			pathsData.length = 0;
			return pathsData;
		};
		TrimModifier.prototype.processShapes = function(_isFirstFrame) {
			var s;
			var e;
			if (this._mdf || _isFirstFrame) {
				var o = this.o.v % 360 / 360;
				if (o < 0) o += 1;
				if (this.s.v > 1) s = 1 + o;
				else if (this.s.v < 0) s = 0 + o;
				else s = this.s.v + o;
				if (this.e.v > 1) e = 1 + o;
				else if (this.e.v < 0) e = 0 + o;
				else e = this.e.v + o;
				if (s > e) {
					var _s = s;
					s = e;
					e = _s;
				}
				s = Math.round(s * 1e4) * 1e-4;
				e = Math.round(e * 1e4) * 1e-4;
				this.sValue = s;
				this.eValue = e;
			} else {
				s = this.sValue;
				e = this.eValue;
			}
			var shapePaths;
			var i;
			var len = this.shapes.length;
			var j;
			var jLen;
			var pathsData;
			var pathData;
			var totalShapeLength;
			var totalModifierLength = 0;
			if (e === s) for (i = 0; i < len; i += 1) {
				this.shapes[i].localShapeCollection.releaseShapes();
				this.shapes[i].shape._mdf = true;
				this.shapes[i].shape.paths = this.shapes[i].localShapeCollection;
				if (this._mdf) this.shapes[i].pathsData.length = 0;
			}
			else if (!(e === 1 && s === 0 || e === 0 && s === 1)) {
				var segments = [];
				var shapeData;
				var localShapeCollection;
				for (i = 0; i < len; i += 1) {
					shapeData = this.shapes[i];
					if (!shapeData.shape._mdf && !this._mdf && !_isFirstFrame && this.m !== 2) shapeData.shape.paths = shapeData.localShapeCollection;
					else {
						shapePaths = shapeData.shape.paths;
						jLen = shapePaths._length;
						totalShapeLength = 0;
						if (!shapeData.shape._mdf && shapeData.pathsData.length) totalShapeLength = shapeData.totalShapeLength;
						else {
							pathsData = this.releasePathsData(shapeData.pathsData);
							for (j = 0; j < jLen; j += 1) {
								pathData = bez.getSegmentsLength(shapePaths.shapes[j]);
								pathsData.push(pathData);
								totalShapeLength += pathData.totalLength;
							}
							shapeData.totalShapeLength = totalShapeLength;
							shapeData.pathsData = pathsData;
						}
						totalModifierLength += totalShapeLength;
						shapeData.shape._mdf = true;
					}
				}
				var shapeS = s;
				var shapeE = e;
				var addedLength = 0;
				var edges;
				for (i = len - 1; i >= 0; i -= 1) {
					shapeData = this.shapes[i];
					if (shapeData.shape._mdf) {
						localShapeCollection = shapeData.localShapeCollection;
						localShapeCollection.releaseShapes();
						if (this.m === 2 && len > 1) {
							edges = this.calculateShapeEdges(s, e, shapeData.totalShapeLength, addedLength, totalModifierLength);
							addedLength += shapeData.totalShapeLength;
						} else edges = [[shapeS, shapeE]];
						jLen = edges.length;
						for (j = 0; j < jLen; j += 1) {
							shapeS = edges[j][0];
							shapeE = edges[j][1];
							segments.length = 0;
							if (shapeE <= 1) segments.push({
								s: shapeData.totalShapeLength * shapeS,
								e: shapeData.totalShapeLength * shapeE
							});
							else if (shapeS >= 1) segments.push({
								s: shapeData.totalShapeLength * (shapeS - 1),
								e: shapeData.totalShapeLength * (shapeE - 1)
							});
							else {
								segments.push({
									s: shapeData.totalShapeLength * shapeS,
									e: shapeData.totalShapeLength
								});
								segments.push({
									s: 0,
									e: shapeData.totalShapeLength * (shapeE - 1)
								});
							}
							var newShapesData = this.addShapes(shapeData, segments[0]);
							if (segments[0].s !== segments[0].e) {
								if (segments.length > 1) {
									if (shapeData.shape.paths.shapes[shapeData.shape.paths._length - 1].c) {
										var lastShape = newShapesData.pop();
										this.addPaths(newShapesData, localShapeCollection);
										newShapesData = this.addShapes(shapeData, segments[1], lastShape);
									} else {
										this.addPaths(newShapesData, localShapeCollection);
										newShapesData = this.addShapes(shapeData, segments[1]);
									}
								}
								this.addPaths(newShapesData, localShapeCollection);
							}
						}
						shapeData.shape.paths = localShapeCollection;
					}
				}
			} else if (this._mdf) for (i = 0; i < len; i += 1) {
				this.shapes[i].pathsData.length = 0;
				this.shapes[i].shape._mdf = true;
			}
		};
		TrimModifier.prototype.addPaths = function(newPaths, localShapeCollection) {
			var i;
			var len = newPaths.length;
			for (i = 0; i < len; i += 1) localShapeCollection.addShape(newPaths[i]);
		};
		TrimModifier.prototype.addSegment = function(pt1, pt2, pt3, pt4, shapePath, pos, newShape) {
			shapePath.setXYAt(pt2[0], pt2[1], "o", pos);
			shapePath.setXYAt(pt3[0], pt3[1], "i", pos + 1);
			if (newShape) shapePath.setXYAt(pt1[0], pt1[1], "v", pos);
			shapePath.setXYAt(pt4[0], pt4[1], "v", pos + 1);
		};
		TrimModifier.prototype.addSegmentFromArray = function(points, shapePath, pos, newShape) {
			shapePath.setXYAt(points[1], points[5], "o", pos);
			shapePath.setXYAt(points[2], points[6], "i", pos + 1);
			if (newShape) shapePath.setXYAt(points[0], points[4], "v", pos);
			shapePath.setXYAt(points[3], points[7], "v", pos + 1);
		};
		TrimModifier.prototype.addShapes = function(shapeData, shapeSegment, shapePath) {
			var pathsData = shapeData.pathsData;
			var shapePaths = shapeData.shape.paths.shapes;
			var i;
			var len = shapeData.shape.paths._length;
			var j;
			var jLen;
			var addedLength = 0;
			var currentLengthData;
			var segmentCount;
			var lengths;
			var segment;
			var shapes = [];
			var initPos;
			var newShape = true;
			if (!shapePath) {
				shapePath = shapePool.newElement();
				segmentCount = 0;
				initPos = 0;
			} else {
				segmentCount = shapePath._length;
				initPos = shapePath._length;
			}
			shapes.push(shapePath);
			for (i = 0; i < len; i += 1) {
				lengths = pathsData[i].lengths;
				shapePath.c = shapePaths[i].c;
				jLen = shapePaths[i].c ? lengths.length : lengths.length + 1;
				for (j = 1; j < jLen; j += 1) {
					currentLengthData = lengths[j - 1];
					if (addedLength + currentLengthData.addedLength < shapeSegment.s) {
						addedLength += currentLengthData.addedLength;
						shapePath.c = false;
					} else if (addedLength > shapeSegment.e) {
						shapePath.c = false;
						break;
					} else {
						if (shapeSegment.s <= addedLength && shapeSegment.e >= addedLength + currentLengthData.addedLength) {
							this.addSegment(shapePaths[i].v[j - 1], shapePaths[i].o[j - 1], shapePaths[i].i[j], shapePaths[i].v[j], shapePath, segmentCount, newShape);
							newShape = false;
						} else {
							segment = bez.getNewSegment(shapePaths[i].v[j - 1], shapePaths[i].v[j], shapePaths[i].o[j - 1], shapePaths[i].i[j], (shapeSegment.s - addedLength) / currentLengthData.addedLength, (shapeSegment.e - addedLength) / currentLengthData.addedLength, lengths[j - 1]);
							this.addSegmentFromArray(segment, shapePath, segmentCount, newShape);
							newShape = false;
							shapePath.c = false;
						}
						addedLength += currentLengthData.addedLength;
						segmentCount += 1;
					}
				}
				if (shapePaths[i].c && lengths.length) {
					currentLengthData = lengths[j - 1];
					if (addedLength <= shapeSegment.e) {
						var segmentLength = lengths[j - 1].addedLength;
						if (shapeSegment.s <= addedLength && shapeSegment.e >= addedLength + segmentLength) {
							this.addSegment(shapePaths[i].v[j - 1], shapePaths[i].o[j - 1], shapePaths[i].i[0], shapePaths[i].v[0], shapePath, segmentCount, newShape);
							newShape = false;
						} else {
							segment = bez.getNewSegment(shapePaths[i].v[j - 1], shapePaths[i].v[0], shapePaths[i].o[j - 1], shapePaths[i].i[0], (shapeSegment.s - addedLength) / segmentLength, (shapeSegment.e - addedLength) / segmentLength, lengths[j - 1]);
							this.addSegmentFromArray(segment, shapePath, segmentCount, newShape);
							newShape = false;
							shapePath.c = false;
						}
					} else shapePath.c = false;
					addedLength += currentLengthData.addedLength;
					segmentCount += 1;
				}
				if (shapePath._length) {
					shapePath.setXYAt(shapePath.v[initPos][0], shapePath.v[initPos][1], "i", initPos);
					shapePath.setXYAt(shapePath.v[shapePath._length - 1][0], shapePath.v[shapePath._length - 1][1], "o", shapePath._length - 1);
				}
				if (addedLength > shapeSegment.e) break;
				if (i < len - 1) {
					shapePath = shapePool.newElement();
					newShape = true;
					shapes.push(shapePath);
					segmentCount = 0;
				}
			}
			return shapes;
		};
		function PuckerAndBloatModifier() {}
		extendPrototype([ShapeModifier], PuckerAndBloatModifier);
		PuckerAndBloatModifier.prototype.initModifierProperties = function(elem, data) {
			this.getValue = this.processKeys;
			this.amount = PropertyFactory.getProp(elem, data.a, 0, null, this);
			this._isAnimated = !!this.amount.effectsSequence.length;
		};
		PuckerAndBloatModifier.prototype.processPath = function(path, amount) {
			var percent = amount / 100;
			var centerPoint = [0, 0];
			var pathLength = path._length;
			var i = 0;
			for (i = 0; i < pathLength; i += 1) {
				centerPoint[0] += path.v[i][0];
				centerPoint[1] += path.v[i][1];
			}
			centerPoint[0] /= pathLength;
			centerPoint[1] /= pathLength;
			var clonedPath = shapePool.newElement();
			clonedPath.c = path.c;
			var vX;
			var vY;
			var oX;
			var oY;
			var iX;
			var iY;
			for (i = 0; i < pathLength; i += 1) {
				vX = path.v[i][0] + (centerPoint[0] - path.v[i][0]) * percent;
				vY = path.v[i][1] + (centerPoint[1] - path.v[i][1]) * percent;
				oX = path.o[i][0] + (centerPoint[0] - path.o[i][0]) * -percent;
				oY = path.o[i][1] + (centerPoint[1] - path.o[i][1]) * -percent;
				iX = path.i[i][0] + (centerPoint[0] - path.i[i][0]) * -percent;
				iY = path.i[i][1] + (centerPoint[1] - path.i[i][1]) * -percent;
				clonedPath.setTripleAt(vX, vY, oX, oY, iX, iY, i);
			}
			return clonedPath;
		};
		PuckerAndBloatModifier.prototype.processShapes = function(_isFirstFrame) {
			var shapePaths;
			var i;
			var len = this.shapes.length;
			var j;
			var jLen;
			var amount = this.amount.v;
			if (amount !== 0) {
				var shapeData;
				var localShapeCollection;
				for (i = 0; i < len; i += 1) {
					shapeData = this.shapes[i];
					localShapeCollection = shapeData.localShapeCollection;
					if (!(!shapeData.shape._mdf && !this._mdf && !_isFirstFrame)) {
						localShapeCollection.releaseShapes();
						shapeData.shape._mdf = true;
						shapePaths = shapeData.shape.paths.shapes;
						jLen = shapeData.shape.paths._length;
						for (j = 0; j < jLen; j += 1) localShapeCollection.addShape(this.processPath(shapePaths[j], amount));
					}
					shapeData.shape.paths = shapeData.localShapeCollection;
				}
			}
			if (!this.dynamicProperties.length) this._mdf = false;
		};
		var TransformPropertyFactory = function() {
			var defaultVector = [0, 0];
			function applyToMatrix(mat) {
				var _mdf = this._mdf;
				this.iterateDynamicProperties();
				this._mdf = this._mdf || _mdf;
				if (this.a) mat.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]);
				if (this.s) mat.scale(this.s.v[0], this.s.v[1], this.s.v[2]);
				if (this.sk) mat.skewFromAxis(-this.sk.v, this.sa.v);
				if (this.r) mat.rotate(-this.r.v);
				else mat.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]);
				if (this.data.p.s) {
					if (this.data.p.z) mat.translate(this.px.v, this.py.v, -this.pz.v);
					else mat.translate(this.px.v, this.py.v, 0);
				} else mat.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
			}
			function processKeys(forceRender) {
				if (this.elem.globalData.frameId === this.frameId) return;
				if (this._isDirty) {
					this.precalculateMatrix();
					this._isDirty = false;
				}
				this.iterateDynamicProperties();
				if (this._mdf || forceRender) {
					var frameRate;
					this.v.cloneFromProps(this.pre.props);
					if (this.appliedTransformations < 1) this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]);
					if (this.appliedTransformations < 2) this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]);
					if (this.sk && this.appliedTransformations < 3) this.v.skewFromAxis(-this.sk.v, this.sa.v);
					if (this.r && this.appliedTransformations < 4) this.v.rotate(-this.r.v);
					else if (!this.r && this.appliedTransformations < 4) this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]);
					if (this.autoOriented) {
						var v1;
						var v2;
						frameRate = this.elem.globalData.frameRate;
						if (this.p && this.p.keyframes && this.p.getValueAtTime) {
							if (this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t) {
								v1 = this.p.getValueAtTime((this.p.keyframes[0].t + .01) / frameRate, 0);
								v2 = this.p.getValueAtTime(this.p.keyframes[0].t / frameRate, 0);
							} else if (this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t) {
								v1 = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / frameRate, 0);
								v2 = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - .05) / frameRate, 0);
							} else {
								v1 = this.p.pv;
								v2 = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - .01) / frameRate, this.p.offsetTime);
							}
						} else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
							v1 = [];
							v2 = [];
							var px = this.px;
							var py = this.py;
							if (px._caching.lastFrame + px.offsetTime <= px.keyframes[0].t) {
								v1[0] = px.getValueAtTime((px.keyframes[0].t + .01) / frameRate, 0);
								v1[1] = py.getValueAtTime((py.keyframes[0].t + .01) / frameRate, 0);
								v2[0] = px.getValueAtTime(px.keyframes[0].t / frameRate, 0);
								v2[1] = py.getValueAtTime(py.keyframes[0].t / frameRate, 0);
							} else if (px._caching.lastFrame + px.offsetTime >= px.keyframes[px.keyframes.length - 1].t) {
								v1[0] = px.getValueAtTime(px.keyframes[px.keyframes.length - 1].t / frameRate, 0);
								v1[1] = py.getValueAtTime(py.keyframes[py.keyframes.length - 1].t / frameRate, 0);
								v2[0] = px.getValueAtTime((px.keyframes[px.keyframes.length - 1].t - .01) / frameRate, 0);
								v2[1] = py.getValueAtTime((py.keyframes[py.keyframes.length - 1].t - .01) / frameRate, 0);
							} else {
								v1 = [px.pv, py.pv];
								v2[0] = px.getValueAtTime((px._caching.lastFrame + px.offsetTime - .01) / frameRate, px.offsetTime);
								v2[1] = py.getValueAtTime((py._caching.lastFrame + py.offsetTime - .01) / frameRate, py.offsetTime);
							}
						} else {
							v2 = defaultVector;
							v1 = v2;
						}
						this.v.rotate(-Math.atan2(v1[1] - v2[1], v1[0] - v2[0]));
					}
					if (this.data.p && this.data.p.s) {
						if (this.data.p.z) this.v.translate(this.px.v, this.py.v, -this.pz.v);
						else this.v.translate(this.px.v, this.py.v, 0);
					} else this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
				}
				this.frameId = this.elem.globalData.frameId;
			}
			function precalculateMatrix() {
				this.appliedTransformations = 0;
				this.pre.reset();
				if (!this.a.effectsSequence.length) {
					this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]);
					this.appliedTransformations = 1;
				} else return;
				if (!this.s.effectsSequence.length) {
					this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]);
					this.appliedTransformations = 2;
				} else return;
				if (this.sk) {
					if (!this.sk.effectsSequence.length && !this.sa.effectsSequence.length) {
						this.pre.skewFromAxis(-this.sk.v, this.sa.v);
						this.appliedTransformations = 3;
					} else return;
				}
				if (this.r) {
					if (!this.r.effectsSequence.length) {
						this.pre.rotate(-this.r.v);
						this.appliedTransformations = 4;
					}
				} else if (!this.rz.effectsSequence.length && !this.ry.effectsSequence.length && !this.rx.effectsSequence.length && !this.or.effectsSequence.length) {
					this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]);
					this.appliedTransformations = 4;
				}
			}
			function autoOrient() {}
			function addDynamicProperty(prop) {
				this._addDynamicProperty(prop);
				this.elem.addDynamicProperty(prop);
				this._isDirty = true;
			}
			function TransformProperty(elem, data, container) {
				this.elem = elem;
				this.frameId = -1;
				this.propType = "transform";
				this.data = data;
				this.v = new Matrix();
				this.pre = new Matrix();
				this.appliedTransformations = 0;
				this.initDynamicPropertyContainer(container || elem);
				if (data.p && data.p.s) {
					this.px = PropertyFactory.getProp(elem, data.p.x, 0, 0, this);
					this.py = PropertyFactory.getProp(elem, data.p.y, 0, 0, this);
					if (data.p.z) this.pz = PropertyFactory.getProp(elem, data.p.z, 0, 0, this);
				} else this.p = PropertyFactory.getProp(elem, data.p || { k: [
					0,
					0,
					0
				] }, 1, 0, this);
				if (data.rx) {
					this.rx = PropertyFactory.getProp(elem, data.rx, 0, degToRads, this);
					this.ry = PropertyFactory.getProp(elem, data.ry, 0, degToRads, this);
					this.rz = PropertyFactory.getProp(elem, data.rz, 0, degToRads, this);
					if (data.or.k[0].ti) {
						var i;
						var len = data.or.k.length;
						for (i = 0; i < len; i += 1) {
							data.or.k[i].to = null;
							data.or.k[i].ti = null;
						}
					}
					this.or = PropertyFactory.getProp(elem, data.or, 1, degToRads, this);
					this.or.sh = true;
				} else this.r = PropertyFactory.getProp(elem, data.r || { k: 0 }, 0, degToRads, this);
				if (data.sk) {
					this.sk = PropertyFactory.getProp(elem, data.sk, 0, degToRads, this);
					this.sa = PropertyFactory.getProp(elem, data.sa, 0, degToRads, this);
				}
				this.a = PropertyFactory.getProp(elem, data.a || { k: [
					0,
					0,
					0
				] }, 1, 0, this);
				this.s = PropertyFactory.getProp(elem, data.s || { k: [
					100,
					100,
					100
				] }, 1, .01, this);
				if (data.o) this.o = PropertyFactory.getProp(elem, data.o, 0, .01, elem);
				else this.o = {
					_mdf: false,
					v: 1
				};
				this._isDirty = true;
				if (!this.dynamicProperties.length) this.getValue(true);
			}
			TransformProperty.prototype = {
				applyToMatrix,
				getValue: processKeys,
				precalculateMatrix,
				autoOrient
			};
			extendPrototype([DynamicPropertyContainer], TransformProperty);
			TransformProperty.prototype.addDynamicProperty = addDynamicProperty;
			TransformProperty.prototype._addDynamicProperty = DynamicPropertyContainer.prototype.addDynamicProperty;
			function getTransformProperty(elem, data, container) {
				return new TransformProperty(elem, data, container);
			}
			return { getTransformProperty };
		}();
		function RepeaterModifier() {}
		extendPrototype([ShapeModifier], RepeaterModifier);
		RepeaterModifier.prototype.initModifierProperties = function(elem, data) {
			this.getValue = this.processKeys;
			this.c = PropertyFactory.getProp(elem, data.c, 0, null, this);
			this.o = PropertyFactory.getProp(elem, data.o, 0, null, this);
			this.tr = TransformPropertyFactory.getTransformProperty(elem, data.tr, this);
			this.so = PropertyFactory.getProp(elem, data.tr.so, 0, .01, this);
			this.eo = PropertyFactory.getProp(elem, data.tr.eo, 0, .01, this);
			this.data = data;
			if (!this.dynamicProperties.length) this.getValue(true);
			this._isAnimated = !!this.dynamicProperties.length;
			this.pMatrix = new Matrix();
			this.rMatrix = new Matrix();
			this.sMatrix = new Matrix();
			this.tMatrix = new Matrix();
			this.matrix = new Matrix();
		};
		RepeaterModifier.prototype.applyTransforms = function(pMatrix, rMatrix, sMatrix, transform, perc, inv) {
			var dir = inv ? -1 : 1;
			var scaleX = transform.s.v[0] + (1 - transform.s.v[0]) * (1 - perc);
			var scaleY = transform.s.v[1] + (1 - transform.s.v[1]) * (1 - perc);
			pMatrix.translate(transform.p.v[0] * dir * perc, transform.p.v[1] * dir * perc, transform.p.v[2]);
			rMatrix.translate(-transform.a.v[0], -transform.a.v[1], transform.a.v[2]);
			rMatrix.rotate(-transform.r.v * dir * perc);
			rMatrix.translate(transform.a.v[0], transform.a.v[1], transform.a.v[2]);
			sMatrix.translate(-transform.a.v[0], -transform.a.v[1], transform.a.v[2]);
			sMatrix.scale(inv ? 1 / scaleX : scaleX, inv ? 1 / scaleY : scaleY);
			sMatrix.translate(transform.a.v[0], transform.a.v[1], transform.a.v[2]);
		};
		RepeaterModifier.prototype.init = function(elem, arr, pos, elemsData) {
			this.elem = elem;
			this.arr = arr;
			this.pos = pos;
			this.elemsData = elemsData;
			this._currentCopies = 0;
			this._elements = [];
			this._groups = [];
			this.frameId = -1;
			this.initDynamicPropertyContainer(elem);
			this.initModifierProperties(elem, arr[pos]);
			while (pos > 0) {
				pos -= 1;
				this._elements.unshift(arr[pos]);
			}
			if (this.dynamicProperties.length) this.k = true;
			else this.getValue(true);
		};
		RepeaterModifier.prototype.resetElements = function(elements) {
			var i;
			var len = elements.length;
			for (i = 0; i < len; i += 1) {
				elements[i]._processed = false;
				if (elements[i].ty === "gr") this.resetElements(elements[i].it);
			}
		};
		RepeaterModifier.prototype.cloneElements = function(elements) {
			var newElements = JSON.parse(JSON.stringify(elements));
			this.resetElements(newElements);
			return newElements;
		};
		RepeaterModifier.prototype.changeGroupRender = function(elements, renderFlag) {
			var i;
			var len = elements.length;
			for (i = 0; i < len; i += 1) {
				elements[i]._render = renderFlag;
				if (elements[i].ty === "gr") this.changeGroupRender(elements[i].it, renderFlag);
			}
		};
		RepeaterModifier.prototype.processShapes = function(_isFirstFrame) {
			var items;
			var itemsTransform;
			var i;
			var dir;
			var cont;
			var hasReloaded = false;
			if (this._mdf || _isFirstFrame) {
				var copies = Math.ceil(this.c.v);
				if (this._groups.length < copies) {
					while (this._groups.length < copies) {
						var group = {
							it: this.cloneElements(this._elements),
							ty: "gr"
						};
						group.it.push({
							a: {
								a: 0,
								ix: 1,
								k: [0, 0]
							},
							nm: "Transform",
							o: {
								a: 0,
								ix: 7,
								k: 100
							},
							p: {
								a: 0,
								ix: 2,
								k: [0, 0]
							},
							r: {
								a: 1,
								ix: 6,
								k: [{
									s: 0,
									e: 0,
									t: 0
								}, {
									s: 0,
									e: 0,
									t: 1
								}]
							},
							s: {
								a: 0,
								ix: 3,
								k: [100, 100]
							},
							sa: {
								a: 0,
								ix: 5,
								k: 0
							},
							sk: {
								a: 0,
								ix: 4,
								k: 0
							},
							ty: "tr"
						});
						this.arr.splice(0, 0, group);
						this._groups.splice(0, 0, group);
						this._currentCopies += 1;
					}
					this.elem.reloadShapes();
					hasReloaded = true;
				}
				cont = 0;
				var renderFlag;
				for (i = 0; i <= this._groups.length - 1; i += 1) {
					renderFlag = cont < copies;
					this._groups[i]._render = renderFlag;
					this.changeGroupRender(this._groups[i].it, renderFlag);
					if (!renderFlag) {
						var elems = this.elemsData[i].it;
						var transformData = elems[elems.length - 1];
						if (transformData.transform.op.v !== 0) {
							transformData.transform.op._mdf = true;
							transformData.transform.op.v = 0;
						} else transformData.transform.op._mdf = false;
					}
					cont += 1;
				}
				this._currentCopies = copies;
				var offset = this.o.v;
				var offsetModulo = offset % 1;
				var roundOffset = offset > 0 ? Math.floor(offset) : Math.ceil(offset);
				var pProps = this.pMatrix.props;
				var rProps = this.rMatrix.props;
				var sProps = this.sMatrix.props;
				this.pMatrix.reset();
				this.rMatrix.reset();
				this.sMatrix.reset();
				this.tMatrix.reset();
				this.matrix.reset();
				var iteration = 0;
				if (offset > 0) {
					while (iteration < roundOffset) {
						this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, false);
						iteration += 1;
					}
					if (offsetModulo) {
						this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, offsetModulo, false);
						iteration += offsetModulo;
					}
				} else if (offset < 0) {
					while (iteration > roundOffset) {
						this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, true);
						iteration -= 1;
					}
					if (offsetModulo) {
						this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -offsetModulo, true);
						iteration -= offsetModulo;
					}
				}
				i = this.data.m === 1 ? 0 : this._currentCopies - 1;
				dir = this.data.m === 1 ? 1 : -1;
				cont = this._currentCopies;
				var j;
				var jLen;
				while (cont) {
					items = this.elemsData[i].it;
					itemsTransform = items[items.length - 1].transform.mProps.v.props;
					jLen = itemsTransform.length;
					items[items.length - 1].transform.mProps._mdf = true;
					items[items.length - 1].transform.op._mdf = true;
					items[items.length - 1].transform.op.v = this._currentCopies === 1 ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (i / (this._currentCopies - 1));
					if (iteration !== 0) {
						if (i !== 0 && dir === 1 || i !== this._currentCopies - 1 && dir === -1) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, false);
						this.matrix.transform(rProps[0], rProps[1], rProps[2], rProps[3], rProps[4], rProps[5], rProps[6], rProps[7], rProps[8], rProps[9], rProps[10], rProps[11], rProps[12], rProps[13], rProps[14], rProps[15]);
						this.matrix.transform(sProps[0], sProps[1], sProps[2], sProps[3], sProps[4], sProps[5], sProps[6], sProps[7], sProps[8], sProps[9], sProps[10], sProps[11], sProps[12], sProps[13], sProps[14], sProps[15]);
						this.matrix.transform(pProps[0], pProps[1], pProps[2], pProps[3], pProps[4], pProps[5], pProps[6], pProps[7], pProps[8], pProps[9], pProps[10], pProps[11], pProps[12], pProps[13], pProps[14], pProps[15]);
						for (j = 0; j < jLen; j += 1) itemsTransform[j] = this.matrix.props[j];
						this.matrix.reset();
					} else {
						this.matrix.reset();
						for (j = 0; j < jLen; j += 1) itemsTransform[j] = this.matrix.props[j];
					}
					iteration += 1;
					cont -= 1;
					i += dir;
				}
			} else {
				cont = this._currentCopies;
				i = 0;
				dir = 1;
				while (cont) {
					items = this.elemsData[i].it;
					itemsTransform = items[items.length - 1].transform.mProps.v.props;
					items[items.length - 1].transform.mProps._mdf = false;
					items[items.length - 1].transform.op._mdf = false;
					cont -= 1;
					i += dir;
				}
			}
			return hasReloaded;
		};
		RepeaterModifier.prototype.addShape = function() {};
		function RoundCornersModifier() {}
		extendPrototype([ShapeModifier], RoundCornersModifier);
		RoundCornersModifier.prototype.initModifierProperties = function(elem, data) {
			this.getValue = this.processKeys;
			this.rd = PropertyFactory.getProp(elem, data.r, 0, null, this);
			this._isAnimated = !!this.rd.effectsSequence.length;
		};
		RoundCornersModifier.prototype.processPath = function(path, round) {
			var clonedPath = shapePool.newElement();
			clonedPath.c = path.c;
			var i;
			var len = path._length;
			var currentV;
			var currentI;
			var currentO;
			var closerV;
			var distance;
			var newPosPerc;
			var index = 0;
			var vX;
			var vY;
			var oX;
			var oY;
			var iX;
			var iY;
			for (i = 0; i < len; i += 1) {
				currentV = path.v[i];
				currentO = path.o[i];
				currentI = path.i[i];
				if (currentV[0] === currentO[0] && currentV[1] === currentO[1] && currentV[0] === currentI[0] && currentV[1] === currentI[1]) {
					if ((i === 0 || i === len - 1) && !path.c) {
						clonedPath.setTripleAt(currentV[0], currentV[1], currentO[0], currentO[1], currentI[0], currentI[1], index);
						index += 1;
					} else {
						if (i === 0) closerV = path.v[len - 1];
						else closerV = path.v[i - 1];
						distance = Math.sqrt(Math.pow(currentV[0] - closerV[0], 2) + Math.pow(currentV[1] - closerV[1], 2));
						newPosPerc = distance ? Math.min(distance / 2, round) / distance : 0;
						iX = currentV[0] + (closerV[0] - currentV[0]) * newPosPerc;
						vX = iX;
						iY = currentV[1] - (currentV[1] - closerV[1]) * newPosPerc;
						vY = iY;
						oX = vX - (vX - currentV[0]) * roundCorner;
						oY = vY - (vY - currentV[1]) * roundCorner;
						clonedPath.setTripleAt(vX, vY, oX, oY, iX, iY, index);
						index += 1;
						if (i === len - 1) closerV = path.v[0];
						else closerV = path.v[i + 1];
						distance = Math.sqrt(Math.pow(currentV[0] - closerV[0], 2) + Math.pow(currentV[1] - closerV[1], 2));
						newPosPerc = distance ? Math.min(distance / 2, round) / distance : 0;
						oX = currentV[0] + (closerV[0] - currentV[0]) * newPosPerc;
						vX = oX;
						oY = currentV[1] + (closerV[1] - currentV[1]) * newPosPerc;
						vY = oY;
						iX = vX - (vX - currentV[0]) * roundCorner;
						iY = vY - (vY - currentV[1]) * roundCorner;
						clonedPath.setTripleAt(vX, vY, oX, oY, iX, iY, index);
						index += 1;
					}
				} else {
					clonedPath.setTripleAt(path.v[i][0], path.v[i][1], path.o[i][0], path.o[i][1], path.i[i][0], path.i[i][1], index);
					index += 1;
				}
			}
			return clonedPath;
		};
		RoundCornersModifier.prototype.processShapes = function(_isFirstFrame) {
			var shapePaths;
			var i;
			var len = this.shapes.length;
			var j;
			var jLen;
			var rd = this.rd.v;
			if (rd !== 0) {
				var shapeData;
				var localShapeCollection;
				for (i = 0; i < len; i += 1) {
					shapeData = this.shapes[i];
					localShapeCollection = shapeData.localShapeCollection;
					if (!(!shapeData.shape._mdf && !this._mdf && !_isFirstFrame)) {
						localShapeCollection.releaseShapes();
						shapeData.shape._mdf = true;
						shapePaths = shapeData.shape.paths.shapes;
						jLen = shapeData.shape.paths._length;
						for (j = 0; j < jLen; j += 1) localShapeCollection.addShape(this.processPath(shapePaths[j], rd));
					}
					shapeData.shape.paths = shapeData.localShapeCollection;
				}
			}
			if (!this.dynamicProperties.length) this._mdf = false;
		};
		function floatEqual(a, b) {
			return Math.abs(a - b) * 1e5 <= Math.min(Math.abs(a), Math.abs(b));
		}
		function floatZero(f) {
			return Math.abs(f) <= 1e-5;
		}
		function lerp(p0, p1, amount) {
			return p0 * (1 - amount) + p1 * amount;
		}
		function lerpPoint(p0, p1, amount) {
			return [lerp(p0[0], p1[0], amount), lerp(p0[1], p1[1], amount)];
		}
		function quadRoots(a, b, c) {
			if (a === 0) return [];
			var s = b * b - 4 * a * c;
			if (s < 0) return [];
			var singleRoot = -b / (2 * a);
			if (s === 0) return [singleRoot];
			var delta = Math.sqrt(s) / (2 * a);
			return [singleRoot - delta, singleRoot + delta];
		}
		function polynomialCoefficients(p0, p1, p2, p3) {
			return [
				-p0 + 3 * p1 - 3 * p2 + p3,
				3 * p0 - 6 * p1 + 3 * p2,
				-3 * p0 + 3 * p1,
				p0
			];
		}
		function singlePoint(p) {
			return new PolynomialBezier(p, p, p, p, false);
		}
		function PolynomialBezier(p0, p1, p2, p3, linearize) {
			if (linearize && pointEqual(p0, p1)) p1 = lerpPoint(p0, p3, 1 / 3);
			if (linearize && pointEqual(p2, p3)) p2 = lerpPoint(p0, p3, 2 / 3);
			var coeffx = polynomialCoefficients(p0[0], p1[0], p2[0], p3[0]);
			var coeffy = polynomialCoefficients(p0[1], p1[1], p2[1], p3[1]);
			this.a = [coeffx[0], coeffy[0]];
			this.b = [coeffx[1], coeffy[1]];
			this.c = [coeffx[2], coeffy[2]];
			this.d = [coeffx[3], coeffy[3]];
			this.points = [
				p0,
				p1,
				p2,
				p3
			];
		}
		PolynomialBezier.prototype.point = function(t) {
			return [((this.a[0] * t + this.b[0]) * t + this.c[0]) * t + this.d[0], ((this.a[1] * t + this.b[1]) * t + this.c[1]) * t + this.d[1]];
		};
		PolynomialBezier.prototype.derivative = function(t) {
			return [(3 * t * this.a[0] + 2 * this.b[0]) * t + this.c[0], (3 * t * this.a[1] + 2 * this.b[1]) * t + this.c[1]];
		};
		PolynomialBezier.prototype.tangentAngle = function(t) {
			var p = this.derivative(t);
			return Math.atan2(p[1], p[0]);
		};
		PolynomialBezier.prototype.normalAngle = function(t) {
			var p = this.derivative(t);
			return Math.atan2(p[0], p[1]);
		};
		PolynomialBezier.prototype.inflectionPoints = function() {
			var denom = this.a[1] * this.b[0] - this.a[0] * this.b[1];
			if (floatZero(denom)) return [];
			var tcusp = -.5 * (this.a[1] * this.c[0] - this.a[0] * this.c[1]) / denom;
			var square = tcusp * tcusp - 1 / 3 * (this.b[1] * this.c[0] - this.b[0] * this.c[1]) / denom;
			if (square < 0) return [];
			var root = Math.sqrt(square);
			if (floatZero(root)) {
				if (root > 0 && root < 1) return [tcusp];
				return [];
			}
			return [tcusp - root, tcusp + root].filter(function(r) {
				return r > 0 && r < 1;
			});
		};
		PolynomialBezier.prototype.split = function(t) {
			if (t <= 0) return [singlePoint(this.points[0]), this];
			if (t >= 1) return [this, singlePoint(this.points[this.points.length - 1])];
			var p10 = lerpPoint(this.points[0], this.points[1], t);
			var p11 = lerpPoint(this.points[1], this.points[2], t);
			var p12 = lerpPoint(this.points[2], this.points[3], t);
			var p20 = lerpPoint(p10, p11, t);
			var p21 = lerpPoint(p11, p12, t);
			var p3 = lerpPoint(p20, p21, t);
			return [new PolynomialBezier(this.points[0], p10, p20, p3, true), new PolynomialBezier(p3, p21, p12, this.points[3], true)];
		};
		function extrema(bez, comp) {
			var min = bez.points[0][comp];
			var max = bez.points[bez.points.length - 1][comp];
			if (min > max) {
				var e = max;
				max = min;
				min = e;
			}
			var f = quadRoots(3 * bez.a[comp], 2 * bez.b[comp], bez.c[comp]);
			for (var i = 0; i < f.length; i += 1) if (f[i] > 0 && f[i] < 1) {
				var val = bez.point(f[i])[comp];
				if (val < min) min = val;
				else if (val > max) max = val;
			}
			return {
				min,
				max
			};
		}
		PolynomialBezier.prototype.bounds = function() {
			return {
				x: extrema(this, 0),
				y: extrema(this, 1)
			};
		};
		PolynomialBezier.prototype.boundingBox = function() {
			var bounds = this.bounds();
			return {
				left: bounds.x.min,
				right: bounds.x.max,
				top: bounds.y.min,
				bottom: bounds.y.max,
				width: bounds.x.max - bounds.x.min,
				height: bounds.y.max - bounds.y.min,
				cx: (bounds.x.max + bounds.x.min) / 2,
				cy: (bounds.y.max + bounds.y.min) / 2
			};
		};
		function intersectData(bez, t1, t2) {
			var box = bez.boundingBox();
			return {
				cx: box.cx,
				cy: box.cy,
				width: box.width,
				height: box.height,
				bez,
				t: (t1 + t2) / 2,
				t1,
				t2
			};
		}
		function splitData(data) {
			var split = data.bez.split(.5);
			return [intersectData(split[0], data.t1, data.t), intersectData(split[1], data.t, data.t2)];
		}
		function boxIntersect(b1, b2) {
			return Math.abs(b1.cx - b2.cx) * 2 < b1.width + b2.width && Math.abs(b1.cy - b2.cy) * 2 < b1.height + b2.height;
		}
		function intersectsImpl(d1, d2, depth, tolerance, intersections, maxRecursion) {
			if (!boxIntersect(d1, d2)) return;
			if (depth >= maxRecursion || d1.width <= tolerance && d1.height <= tolerance && d2.width <= tolerance && d2.height <= tolerance) {
				intersections.push([d1.t, d2.t]);
				return;
			}
			var d1s = splitData(d1);
			var d2s = splitData(d2);
			intersectsImpl(d1s[0], d2s[0], depth + 1, tolerance, intersections, maxRecursion);
			intersectsImpl(d1s[0], d2s[1], depth + 1, tolerance, intersections, maxRecursion);
			intersectsImpl(d1s[1], d2s[0], depth + 1, tolerance, intersections, maxRecursion);
			intersectsImpl(d1s[1], d2s[1], depth + 1, tolerance, intersections, maxRecursion);
		}
		PolynomialBezier.prototype.intersections = function(other, tolerance, maxRecursion) {
			if (tolerance === void 0) tolerance = 2;
			if (maxRecursion === void 0) maxRecursion = 7;
			var intersections = [];
			intersectsImpl(intersectData(this, 0, 1), intersectData(other, 0, 1), 0, tolerance, intersections, maxRecursion);
			return intersections;
		};
		PolynomialBezier.shapeSegment = function(shapePath, index) {
			var nextIndex = (index + 1) % shapePath.length();
			return new PolynomialBezier(shapePath.v[index], shapePath.o[index], shapePath.i[nextIndex], shapePath.v[nextIndex], true);
		};
		PolynomialBezier.shapeSegmentInverted = function(shapePath, index) {
			var nextIndex = (index + 1) % shapePath.length();
			return new PolynomialBezier(shapePath.v[nextIndex], shapePath.i[nextIndex], shapePath.o[index], shapePath.v[index], true);
		};
		function crossProduct(a, b) {
			return [
				a[1] * b[2] - a[2] * b[1],
				a[2] * b[0] - a[0] * b[2],
				a[0] * b[1] - a[1] * b[0]
			];
		}
		function lineIntersection(start1, end1, start2, end2) {
			var v1 = [
				start1[0],
				start1[1],
				1
			];
			var v2 = [
				end1[0],
				end1[1],
				1
			];
			var v3 = [
				start2[0],
				start2[1],
				1
			];
			var v4 = [
				end2[0],
				end2[1],
				1
			];
			var r = crossProduct(crossProduct(v1, v2), crossProduct(v3, v4));
			if (floatZero(r[2])) return null;
			return [r[0] / r[2], r[1] / r[2]];
		}
		function polarOffset(p, angle, length) {
			return [p[0] + Math.cos(angle) * length, p[1] - Math.sin(angle) * length];
		}
		function pointDistance(p1, p2) {
			return Math.hypot(p1[0] - p2[0], p1[1] - p2[1]);
		}
		function pointEqual(p1, p2) {
			return floatEqual(p1[0], p2[0]) && floatEqual(p1[1], p2[1]);
		}
		function ZigZagModifier() {}
		extendPrototype([ShapeModifier], ZigZagModifier);
		ZigZagModifier.prototype.initModifierProperties = function(elem, data) {
			this.getValue = this.processKeys;
			this.amplitude = PropertyFactory.getProp(elem, data.s, 0, null, this);
			this.frequency = PropertyFactory.getProp(elem, data.r, 0, null, this);
			this.pointsType = PropertyFactory.getProp(elem, data.pt, 0, null, this);
			this._isAnimated = this.amplitude.effectsSequence.length !== 0 || this.frequency.effectsSequence.length !== 0 || this.pointsType.effectsSequence.length !== 0;
		};
		function setPoint(outputBezier, point, angle, direction, amplitude, outAmplitude, inAmplitude) {
			var angO = angle - Math.PI / 2;
			var angI = angle + Math.PI / 2;
			var px = point[0] + Math.cos(angle) * direction * amplitude;
			var py = point[1] - Math.sin(angle) * direction * amplitude;
			outputBezier.setTripleAt(px, py, px + Math.cos(angO) * outAmplitude, py - Math.sin(angO) * outAmplitude, px + Math.cos(angI) * inAmplitude, py - Math.sin(angI) * inAmplitude, outputBezier.length());
		}
		function getPerpendicularVector(pt1, pt2) {
			var vector = [pt2[0] - pt1[0], pt2[1] - pt1[1]];
			var rot = -Math.PI * .5;
			return [Math.cos(rot) * vector[0] - Math.sin(rot) * vector[1], Math.sin(rot) * vector[0] + Math.cos(rot) * vector[1]];
		}
		function getProjectingAngle(path, cur) {
			var prevIndex = cur === 0 ? path.length() - 1 : cur - 1;
			var nextIndex = (cur + 1) % path.length();
			var prevPoint = path.v[prevIndex];
			var nextPoint = path.v[nextIndex];
			var pVector = getPerpendicularVector(prevPoint, nextPoint);
			return Math.atan2(0, 1) - Math.atan2(pVector[1], pVector[0]);
		}
		function zigZagCorner(outputBezier, path, cur, amplitude, frequency, pointType, direction) {
			var angle = getProjectingAngle(path, cur);
			var point = path.v[cur % path._length];
			var prevPoint = path.v[cur === 0 ? path._length - 1 : cur - 1];
			var nextPoint = path.v[(cur + 1) % path._length];
			var prevDist = pointType === 2 ? Math.sqrt(Math.pow(point[0] - prevPoint[0], 2) + Math.pow(point[1] - prevPoint[1], 2)) : 0;
			var nextDist = pointType === 2 ? Math.sqrt(Math.pow(point[0] - nextPoint[0], 2) + Math.pow(point[1] - nextPoint[1], 2)) : 0;
			setPoint(outputBezier, path.v[cur % path._length], angle, direction, amplitude, nextDist / ((frequency + 1) * 2), prevDist / ((frequency + 1) * 2), pointType);
		}
		function zigZagSegment(outputBezier, segment, amplitude, frequency, pointType, direction) {
			for (var i = 0; i < frequency; i += 1) {
				var t = (i + 1) / (frequency + 1);
				var dist = pointType === 2 ? Math.sqrt(Math.pow(segment.points[3][0] - segment.points[0][0], 2) + Math.pow(segment.points[3][1] - segment.points[0][1], 2)) : 0;
				var angle = segment.normalAngle(t);
				setPoint(outputBezier, segment.point(t), angle, direction, amplitude, dist / ((frequency + 1) * 2), dist / ((frequency + 1) * 2), pointType);
				direction = -direction;
			}
			return direction;
		}
		ZigZagModifier.prototype.processPath = function(path, amplitude, frequency, pointType) {
			var count = path._length;
			var clonedPath = shapePool.newElement();
			clonedPath.c = path.c;
			if (!path.c) count -= 1;
			if (count === 0) return clonedPath;
			var direction = -1;
			var segment = PolynomialBezier.shapeSegment(path, 0);
			zigZagCorner(clonedPath, path, 0, amplitude, frequency, pointType, direction);
			for (var i = 0; i < count; i += 1) {
				direction = zigZagSegment(clonedPath, segment, amplitude, frequency, pointType, -direction);
				if (i === count - 1 && !path.c) segment = null;
				else segment = PolynomialBezier.shapeSegment(path, (i + 1) % count);
				zigZagCorner(clonedPath, path, i + 1, amplitude, frequency, pointType, direction);
			}
			return clonedPath;
		};
		ZigZagModifier.prototype.processShapes = function(_isFirstFrame) {
			var shapePaths;
			var i;
			var len = this.shapes.length;
			var j;
			var jLen;
			var amplitude = this.amplitude.v;
			var frequency = Math.max(0, Math.round(this.frequency.v));
			var pointType = this.pointsType.v;
			if (amplitude !== 0) {
				var shapeData;
				var localShapeCollection;
				for (i = 0; i < len; i += 1) {
					shapeData = this.shapes[i];
					localShapeCollection = shapeData.localShapeCollection;
					if (!(!shapeData.shape._mdf && !this._mdf && !_isFirstFrame)) {
						localShapeCollection.releaseShapes();
						shapeData.shape._mdf = true;
						shapePaths = shapeData.shape.paths.shapes;
						jLen = shapeData.shape.paths._length;
						for (j = 0; j < jLen; j += 1) localShapeCollection.addShape(this.processPath(shapePaths[j], amplitude, frequency, pointType));
					}
					shapeData.shape.paths = shapeData.localShapeCollection;
				}
			}
			if (!this.dynamicProperties.length) this._mdf = false;
		};
		function linearOffset(p1, p2, amount) {
			var angle = Math.atan2(p2[0] - p1[0], p2[1] - p1[1]);
			return [polarOffset(p1, angle, amount), polarOffset(p2, angle, amount)];
		}
		function offsetSegment(segment, amount) {
			var p0;
			var p1a;
			var p1b;
			var p2b;
			var p2a;
			var p3;
			var e = linearOffset(segment.points[0], segment.points[1], amount);
			p0 = e[0];
			p1a = e[1];
			e = linearOffset(segment.points[1], segment.points[2], amount);
			p1b = e[0];
			p2b = e[1];
			e = linearOffset(segment.points[2], segment.points[3], amount);
			p2a = e[0];
			p3 = e[1];
			var p1 = lineIntersection(p0, p1a, p1b, p2b);
			if (p1 === null) p1 = p1a;
			var p2 = lineIntersection(p2a, p3, p1b, p2b);
			if (p2 === null) p2 = p2a;
			return new PolynomialBezier(p0, p1, p2, p3);
		}
		function joinLines(outputBezier, seg1, seg2, lineJoin, miterLimit) {
			var p0 = seg1.points[3];
			var p1 = seg2.points[0];
			if (lineJoin === 3) return p0;
			if (pointEqual(p0, p1)) return p0;
			if (lineJoin === 2) {
				var angleOut = -seg1.tangentAngle(1);
				var angleIn = -seg2.tangentAngle(0) + Math.PI;
				var center = lineIntersection(p0, polarOffset(p0, angleOut + Math.PI / 2, 100), p1, polarOffset(p1, angleOut + Math.PI / 2, 100));
				var radius = center ? pointDistance(center, p0) : pointDistance(p0, p1) / 2;
				var tan = polarOffset(p0, angleOut, 2 * radius * roundCorner);
				outputBezier.setXYAt(tan[0], tan[1], "o", outputBezier.length() - 1);
				tan = polarOffset(p1, angleIn, 2 * radius * roundCorner);
				outputBezier.setTripleAt(p1[0], p1[1], p1[0], p1[1], tan[0], tan[1], outputBezier.length());
				return p1;
			}
			var intersection = lineIntersection(pointEqual(p0, seg1.points[2]) ? seg1.points[0] : seg1.points[2], p0, p1, pointEqual(p1, seg2.points[1]) ? seg2.points[3] : seg2.points[1]);
			if (intersection && pointDistance(intersection, p0) < miterLimit) {
				outputBezier.setTripleAt(intersection[0], intersection[1], intersection[0], intersection[1], intersection[0], intersection[1], outputBezier.length());
				return intersection;
			}
			return p0;
		}
		function getIntersection(a, b) {
			var intersect = a.intersections(b);
			if (intersect.length && floatEqual(intersect[0][0], 1)) intersect.shift();
			if (intersect.length) return intersect[0];
			return null;
		}
		function pruneSegmentIntersection(a, b) {
			var outa = a.slice();
			var outb = b.slice();
			var intersect = getIntersection(a[a.length - 1], b[0]);
			if (intersect) {
				outa[a.length - 1] = a[a.length - 1].split(intersect[0])[0];
				outb[0] = b[0].split(intersect[1])[1];
			}
			if (a.length > 1 && b.length > 1) {
				intersect = getIntersection(a[0], b[b.length - 1]);
				if (intersect) return [[a[0].split(intersect[0])[0]], [b[b.length - 1].split(intersect[1])[1]]];
			}
			return [outa, outb];
		}
		function pruneIntersections(segments) {
			var e;
			for (var i = 1; i < segments.length; i += 1) {
				e = pruneSegmentIntersection(segments[i - 1], segments[i]);
				segments[i - 1] = e[0];
				segments[i] = e[1];
			}
			if (segments.length > 1) {
				e = pruneSegmentIntersection(segments[segments.length - 1], segments[0]);
				segments[segments.length - 1] = e[0];
				segments[0] = e[1];
			}
			return segments;
		}
		function offsetSegmentSplit(segment, amount) {
			var flex = segment.inflectionPoints();
			var left;
			var right;
			var split;
			var mid;
			if (flex.length === 0) return [offsetSegment(segment, amount)];
			if (flex.length === 1 || floatEqual(flex[1], 1)) {
				split = segment.split(flex[0]);
				left = split[0];
				right = split[1];
				return [offsetSegment(left, amount), offsetSegment(right, amount)];
			}
			split = segment.split(flex[0]);
			left = split[0];
			var t = (flex[1] - flex[0]) / (1 - flex[0]);
			split = split[1].split(t);
			mid = split[0];
			right = split[1];
			return [
				offsetSegment(left, amount),
				offsetSegment(mid, amount),
				offsetSegment(right, amount)
			];
		}
		function OffsetPathModifier() {}
		extendPrototype([ShapeModifier], OffsetPathModifier);
		OffsetPathModifier.prototype.initModifierProperties = function(elem, data) {
			this.getValue = this.processKeys;
			this.amount = PropertyFactory.getProp(elem, data.a, 0, null, this);
			this.miterLimit = PropertyFactory.getProp(elem, data.ml, 0, null, this);
			this.lineJoin = data.lj;
			this._isAnimated = this.amount.effectsSequence.length !== 0;
		};
		OffsetPathModifier.prototype.processPath = function(inputBezier, amount, lineJoin, miterLimit) {
			var outputBezier = shapePool.newElement();
			outputBezier.c = inputBezier.c;
			var count = inputBezier.length();
			if (!inputBezier.c) count -= 1;
			var i;
			var j;
			var segment;
			var multiSegments = [];
			for (i = 0; i < count; i += 1) {
				segment = PolynomialBezier.shapeSegment(inputBezier, i);
				multiSegments.push(offsetSegmentSplit(segment, amount));
			}
			if (!inputBezier.c) for (i = count - 1; i >= 0; i -= 1) {
				segment = PolynomialBezier.shapeSegmentInverted(inputBezier, i);
				multiSegments.push(offsetSegmentSplit(segment, amount));
			}
			multiSegments = pruneIntersections(multiSegments);
			var lastPoint = null;
			var lastSeg = null;
			for (i = 0; i < multiSegments.length; i += 1) {
				var multiSegment = multiSegments[i];
				if (lastSeg) lastPoint = joinLines(outputBezier, lastSeg, multiSegment[0], lineJoin, miterLimit);
				lastSeg = multiSegment[multiSegment.length - 1];
				for (j = 0; j < multiSegment.length; j += 1) {
					segment = multiSegment[j];
					if (lastPoint && pointEqual(segment.points[0], lastPoint)) outputBezier.setXYAt(segment.points[1][0], segment.points[1][1], "o", outputBezier.length() - 1);
					else outputBezier.setTripleAt(segment.points[0][0], segment.points[0][1], segment.points[1][0], segment.points[1][1], segment.points[0][0], segment.points[0][1], outputBezier.length());
					outputBezier.setTripleAt(segment.points[3][0], segment.points[3][1], segment.points[3][0], segment.points[3][1], segment.points[2][0], segment.points[2][1], outputBezier.length());
					lastPoint = segment.points[3];
				}
			}
			if (multiSegments.length) joinLines(outputBezier, lastSeg, multiSegments[0][0], lineJoin, miterLimit);
			return outputBezier;
		};
		OffsetPathModifier.prototype.processShapes = function(_isFirstFrame) {
			var shapePaths;
			var i;
			var len = this.shapes.length;
			var j;
			var jLen;
			var amount = this.amount.v;
			var miterLimit = this.miterLimit.v;
			var lineJoin = this.lineJoin;
			if (amount !== 0) {
				var shapeData;
				var localShapeCollection;
				for (i = 0; i < len; i += 1) {
					shapeData = this.shapes[i];
					localShapeCollection = shapeData.localShapeCollection;
					if (!(!shapeData.shape._mdf && !this._mdf && !_isFirstFrame)) {
						localShapeCollection.releaseShapes();
						shapeData.shape._mdf = true;
						shapePaths = shapeData.shape.paths.shapes;
						jLen = shapeData.shape.paths._length;
						for (j = 0; j < jLen; j += 1) localShapeCollection.addShape(this.processPath(shapePaths[j], amount, lineJoin, miterLimit));
					}
					shapeData.shape.paths = shapeData.localShapeCollection;
				}
			}
			if (!this.dynamicProperties.length) this._mdf = false;
		};
		function getFontProperties(fontData) {
			var styles = fontData.fStyle ? fontData.fStyle.split(" ") : [];
			var fWeight = "normal";
			var fStyle = "normal";
			var len = styles.length;
			var styleName;
			for (var i = 0; i < len; i += 1) {
				styleName = styles[i].toLowerCase();
				switch (styleName) {
					case "italic":
						fStyle = "italic";
						break;
					case "bold":
						fWeight = "700";
						break;
					case "black":
						fWeight = "900";
						break;
					case "medium":
						fWeight = "500";
						break;
					case "regular":
					case "normal":
						fWeight = "400";
						break;
					case "light":
					case "thin": fWeight = "200";
				}
			}
			return {
				style: fStyle,
				weight: fontData.fWeight || fWeight
			};
		}
		var FontManager = function() {
			var maxWaitingTime = 5e3;
			var emptyChar = {
				w: 0,
				size: 0,
				shapes: [],
				data: { shapes: [] }
			};
			var combinedCharacters = [];
			combinedCharacters = combinedCharacters.concat([
				2304,
				2305,
				2306,
				2307,
				2362,
				2363,
				2364,
				2364,
				2366,
				2367,
				2368,
				2369,
				2370,
				2371,
				2372,
				2373,
				2374,
				2375,
				2376,
				2377,
				2378,
				2379,
				2380,
				2381,
				2382,
				2383,
				2387,
				2388,
				2389,
				2390,
				2391,
				2402,
				2403
			]);
			var BLACK_FLAG_CODE_POINT = 127988;
			var CANCEL_TAG_CODE_POINT = 917631;
			var A_TAG_CODE_POINT = 917601;
			var Z_TAG_CODE_POINT = 917626;
			var VARIATION_SELECTOR_16_CODE_POINT = 65039;
			var ZERO_WIDTH_JOINER_CODE_POINT = 8205;
			var REGIONAL_CHARACTER_A_CODE_POINT = 127462;
			var REGIONAL_CHARACTER_Z_CODE_POINT = 127487;
			var surrogateModifiers = [
				"d83cdffb",
				"d83cdffc",
				"d83cdffd",
				"d83cdffe",
				"d83cdfff"
			];
			function trimFontOptions(font) {
				var familyArray = font.split(",");
				var i;
				var len = familyArray.length;
				var enabledFamilies = [];
				for (i = 0; i < len; i += 1) if (familyArray[i] !== "sans-serif" && familyArray[i] !== "monospace") enabledFamilies.push(familyArray[i]);
				return enabledFamilies.join(",");
			}
			function setUpNode(font, family) {
				var parentNode = createTag("span");
				parentNode.setAttribute("aria-hidden", true);
				parentNode.style.fontFamily = family;
				var node = createTag("span");
				node.innerText = "giItT1WQy@!-/#";
				parentNode.style.position = "absolute";
				parentNode.style.left = "-10000px";
				parentNode.style.top = "-10000px";
				parentNode.style.fontSize = "300px";
				parentNode.style.fontVariant = "normal";
				parentNode.style.fontStyle = "normal";
				parentNode.style.fontWeight = "normal";
				parentNode.style.letterSpacing = "0";
				parentNode.appendChild(node);
				document.body.appendChild(parentNode);
				var width = node.offsetWidth;
				node.style.fontFamily = trimFontOptions(font) + ", " + family;
				return {
					node,
					w: width,
					parent: parentNode
				};
			}
			function checkLoadedFonts() {
				var i;
				var len = this.fonts.length;
				var node;
				var w;
				var loadedCount = len;
				for (i = 0; i < len; i += 1) if (this.fonts[i].loaded) loadedCount -= 1;
				else if (this.fonts[i].fOrigin === "n" || this.fonts[i].origin === 0) this.fonts[i].loaded = true;
				else {
					node = this.fonts[i].monoCase.node;
					w = this.fonts[i].monoCase.w;
					if (node.offsetWidth !== w) {
						loadedCount -= 1;
						this.fonts[i].loaded = true;
					} else {
						node = this.fonts[i].sansCase.node;
						w = this.fonts[i].sansCase.w;
						if (node.offsetWidth !== w) {
							loadedCount -= 1;
							this.fonts[i].loaded = true;
						}
					}
					if (this.fonts[i].loaded) {
						this.fonts[i].sansCase.parent.parentNode.removeChild(this.fonts[i].sansCase.parent);
						this.fonts[i].monoCase.parent.parentNode.removeChild(this.fonts[i].monoCase.parent);
					}
				}
				if (loadedCount !== 0 && Date.now() - this.initTime < maxWaitingTime) setTimeout(this.checkLoadedFontsBinded, 20);
				else setTimeout(this.setIsLoadedBinded, 10);
			}
			function createHelper(fontData, def) {
				var engine = document.body && def ? "svg" : "canvas";
				var helper;
				var fontProps = getFontProperties(fontData);
				if (engine === "svg") {
					var tHelper = createNS("text");
					tHelper.style.fontSize = "100px";
					tHelper.setAttribute("font-family", fontData.fFamily);
					tHelper.setAttribute("font-style", fontProps.style);
					tHelper.setAttribute("font-weight", fontProps.weight);
					tHelper.textContent = "1";
					if (fontData.fClass) {
						tHelper.style.fontFamily = "inherit";
						tHelper.setAttribute("class", fontData.fClass);
					} else tHelper.style.fontFamily = fontData.fFamily;
					def.appendChild(tHelper);
					helper = tHelper;
				} else {
					var tCanvasHelper = new OffscreenCanvas(500, 500).getContext("2d");
					tCanvasHelper.font = fontProps.style + " " + fontProps.weight + " 100px " + fontData.fFamily;
					helper = tCanvasHelper;
				}
				function measure(text) {
					if (engine === "svg") {
						helper.textContent = text;
						return helper.getComputedTextLength();
					}
					return helper.measureText(text).width;
				}
				return { measureText: measure };
			}
			function addFonts(fontData, defs) {
				if (!fontData) {
					this.isLoaded = true;
					return;
				}
				if (this.chars) {
					this.isLoaded = true;
					this.fonts = fontData.list;
					return;
				}
				if (!document.body) {
					this.isLoaded = true;
					fontData.list.forEach(function(data) {
						data.helper = createHelper(data);
						data.cache = {};
					});
					this.fonts = fontData.list;
					return;
				}
				var fontArr = fontData.list;
				var i;
				var len = fontArr.length;
				var _pendingFonts = len;
				for (i = 0; i < len; i += 1) {
					var shouldLoadFont = true;
					var loadedSelector;
					var j;
					fontArr[i].loaded = false;
					fontArr[i].monoCase = setUpNode(fontArr[i].fFamily, "monospace");
					fontArr[i].sansCase = setUpNode(fontArr[i].fFamily, "sans-serif");
					if (!fontArr[i].fPath) {
						fontArr[i].loaded = true;
						_pendingFonts -= 1;
					} else if (fontArr[i].fOrigin === "p" || fontArr[i].origin === 3) {
						loadedSelector = document.querySelectorAll("style[f-forigin=\"p\"][f-family=\"" + fontArr[i].fFamily + "\"], style[f-origin=\"3\"][f-family=\"" + fontArr[i].fFamily + "\"]");
						if (loadedSelector.length > 0) shouldLoadFont = false;
						if (shouldLoadFont) {
							var s = createTag("style");
							s.setAttribute("f-forigin", fontArr[i].fOrigin);
							s.setAttribute("f-origin", fontArr[i].origin);
							s.setAttribute("f-family", fontArr[i].fFamily);
							s.type = "text/css";
							s.innerText = "@font-face {font-family: " + fontArr[i].fFamily + "; font-style: normal; src: url('" + fontArr[i].fPath + "');}";
							defs.appendChild(s);
						}
					} else if (fontArr[i].fOrigin === "g" || fontArr[i].origin === 1) {
						loadedSelector = document.querySelectorAll("link[f-forigin=\"g\"], link[f-origin=\"1\"]");
						for (j = 0; j < loadedSelector.length; j += 1) if (loadedSelector[j].href.indexOf(fontArr[i].fPath) !== -1) shouldLoadFont = false;
						if (shouldLoadFont) {
							var l = createTag("link");
							l.setAttribute("f-forigin", fontArr[i].fOrigin);
							l.setAttribute("f-origin", fontArr[i].origin);
							l.type = "text/css";
							l.rel = "stylesheet";
							l.href = fontArr[i].fPath;
							document.body.appendChild(l);
						}
					} else if (fontArr[i].fOrigin === "t" || fontArr[i].origin === 2) {
						loadedSelector = document.querySelectorAll("script[f-forigin=\"t\"], script[f-origin=\"2\"]");
						for (j = 0; j < loadedSelector.length; j += 1) if (fontArr[i].fPath === loadedSelector[j].src) shouldLoadFont = false;
						if (shouldLoadFont) {
							var sc = createTag("link");
							sc.setAttribute("f-forigin", fontArr[i].fOrigin);
							sc.setAttribute("f-origin", fontArr[i].origin);
							sc.setAttribute("rel", "stylesheet");
							sc.setAttribute("href", fontArr[i].fPath);
							defs.appendChild(sc);
						}
					}
					fontArr[i].helper = createHelper(fontArr[i], defs);
					fontArr[i].cache = {};
					this.fonts.push(fontArr[i]);
				}
				if (_pendingFonts === 0) this.isLoaded = true;
				else setTimeout(this.checkLoadedFonts.bind(this), 100);
			}
			function addChars(chars) {
				if (!chars) return;
				if (!this.chars) this.chars = [];
				var i;
				var len = chars.length;
				var j;
				var jLen = this.chars.length;
				var found;
				for (i = 0; i < len; i += 1) {
					j = 0;
					found = false;
					while (j < jLen) {
						if (this.chars[j].style === chars[i].style && this.chars[j].fFamily === chars[i].fFamily && this.chars[j].ch === chars[i].ch) found = true;
						j += 1;
					}
					if (!found) {
						this.chars.push(chars[i]);
						jLen += 1;
					}
				}
			}
			function getCharData(_char, style, font) {
				var i = 0;
				var len = this.chars.length;
				while (i < len) {
					if (this.chars[i].ch === _char && this.chars[i].style === style && this.chars[i].fFamily === font) return this.chars[i];
					i += 1;
				}
				if ((typeof _char === "string" && _char.charCodeAt(0) !== 13 || !_char) && console && console.warn && !this._warned) {
					this._warned = true;
					console.warn("Missing character from exported characters list: ", _char, style, font);
				}
				return emptyChar;
			}
			function measureText(_char2, fontName, size) {
				var fontData = this.getFontByName(fontName);
				var index = _char2;
				if (!fontData.cache[index]) {
					var tHelper = fontData.helper;
					if (_char2 === " ") {
						var doubleSize = tHelper.measureText("|" + _char2 + "|");
						var singleSize = tHelper.measureText("||");
						fontData.cache[index] = (doubleSize - singleSize) / 100;
					} else fontData.cache[index] = tHelper.measureText(_char2) / 100;
				}
				return fontData.cache[index] * size;
			}
			function getFontByName(name) {
				var i = 0;
				var len = this.fonts.length;
				while (i < len) {
					if (this.fonts[i].fName === name) return this.fonts[i];
					i += 1;
				}
				return this.fonts[0];
			}
			function getCodePoint(string) {
				var codePoint = 0;
				var first = string.charCodeAt(0);
				if (first >= 55296 && first <= 56319) {
					var second = string.charCodeAt(1);
					if (second >= 56320 && second <= 57343) codePoint = (first - 55296) * 1024 + second - 56320 + 65536;
				}
				return codePoint;
			}
			function isModifier(firstCharCode, secondCharCode) {
				var sum = firstCharCode.toString(16) + secondCharCode.toString(16);
				return surrogateModifiers.indexOf(sum) !== -1;
			}
			function isZeroWidthJoiner(charCode) {
				return charCode === ZERO_WIDTH_JOINER_CODE_POINT;
			}
			function isVariationSelector(charCode) {
				return charCode === VARIATION_SELECTOR_16_CODE_POINT;
			}
			function isRegionalCode(string) {
				var codePoint = getCodePoint(string);
				if (codePoint >= REGIONAL_CHARACTER_A_CODE_POINT && codePoint <= REGIONAL_CHARACTER_Z_CODE_POINT) return true;
				return false;
			}
			function isFlagEmoji(string) {
				return isRegionalCode(string.substr(0, 2)) && isRegionalCode(string.substr(2, 2));
			}
			function isCombinedCharacter(_char3) {
				return combinedCharacters.indexOf(_char3) !== -1;
			}
			function isRegionalFlag(text, index) {
				var codePoint = getCodePoint(text.substr(index, 2));
				if (codePoint !== BLACK_FLAG_CODE_POINT) return false;
				var count = 0;
				index += 2;
				while (count < 5) {
					codePoint = getCodePoint(text.substr(index, 2));
					if (codePoint < A_TAG_CODE_POINT || codePoint > Z_TAG_CODE_POINT) return false;
					count += 1;
					index += 2;
				}
				return getCodePoint(text.substr(index, 2)) === CANCEL_TAG_CODE_POINT;
			}
			function setIsLoaded() {
				this.isLoaded = true;
			}
			var Font = function Font() {
				this.fonts = [];
				this.chars = null;
				this.typekitLoaded = 0;
				this.isLoaded = false;
				this._warned = false;
				this.initTime = Date.now();
				this.setIsLoadedBinded = this.setIsLoaded.bind(this);
				this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this);
			};
			Font.isModifier = isModifier;
			Font.isZeroWidthJoiner = isZeroWidthJoiner;
			Font.isFlagEmoji = isFlagEmoji;
			Font.isRegionalCode = isRegionalCode;
			Font.isCombinedCharacter = isCombinedCharacter;
			Font.isRegionalFlag = isRegionalFlag;
			Font.isVariationSelector = isVariationSelector;
			Font.BLACK_FLAG_CODE_POINT = BLACK_FLAG_CODE_POINT;
			Font.prototype = {
				addChars,
				addFonts,
				getCharData,
				getFontByName,
				measureText,
				checkLoadedFonts,
				setIsLoaded
			};
			return Font;
		}();
		function SlotManager(animationData) {
			this.animationData = animationData;
		}
		SlotManager.prototype.getProp = function(data) {
			if (this.animationData.slots && this.animationData.slots[data.sid]) return Object.assign(data, this.animationData.slots[data.sid].p);
			return data;
		};
		function slotFactory(animationData) {
			return new SlotManager(animationData);
		}
		function RenderableElement() {}
		RenderableElement.prototype = {
			initRenderable: function initRenderable() {
				this.isInRange = false;
				this.hidden = false;
				this.isTransparent = false;
				this.renderableComponents = [];
			},
			addRenderableComponent: function addRenderableComponent(component) {
				if (this.renderableComponents.indexOf(component) === -1) this.renderableComponents.push(component);
			},
			removeRenderableComponent: function removeRenderableComponent(component) {
				if (this.renderableComponents.indexOf(component) !== -1) this.renderableComponents.splice(this.renderableComponents.indexOf(component), 1);
			},
			prepareRenderableFrame: function prepareRenderableFrame(num) {
				this.checkLayerLimits(num);
			},
			checkTransparency: function checkTransparency() {
				if (this.finalTransform.mProp.o.v <= 0) {
					if (!this.isTransparent && this.globalData.renderConfig.hideOnTransparent) {
						this.isTransparent = true;
						this.hide();
					}
				} else if (this.isTransparent) {
					this.isTransparent = false;
					this.show();
				}
			},
			/**
			* @function
			* Initializes frame related properties.
			*
			* @param {number} num
			* current frame number in Layer's time
			*
			*/
			checkLayerLimits: function checkLayerLimits(num) {
				if (this.data.ip - this.data.st <= num && this.data.op - this.data.st > num) {
					if (this.isInRange !== true) {
						this.globalData._mdf = true;
						this._mdf = true;
						this.isInRange = true;
						this.show();
					}
				} else if (this.isInRange !== false) {
					this.globalData._mdf = true;
					this.isInRange = false;
					this.hide();
				}
			},
			renderRenderable: function renderRenderable() {
				var i;
				var len = this.renderableComponents.length;
				for (i = 0; i < len; i += 1) this.renderableComponents[i].renderFrame(this._isFirstFrame);
			},
			sourceRectAtTime: function sourceRectAtTime() {
				return {
					top: 0,
					left: 0,
					width: 100,
					height: 100
				};
			},
			getLayerSize: function getLayerSize() {
				if (this.data.ty === 5) return {
					w: this.data.textData.width,
					h: this.data.textData.height
				};
				return {
					w: this.data.width,
					h: this.data.height
				};
			}
		};
		var getBlendMode = function() {
			var blendModeEnums = {
				0: "source-over",
				1: "multiply",
				2: "screen",
				3: "overlay",
				4: "darken",
				5: "lighten",
				6: "color-dodge",
				7: "color-burn",
				8: "hard-light",
				9: "soft-light",
				10: "difference",
				11: "exclusion",
				12: "hue",
				13: "saturation",
				14: "color",
				15: "luminosity"
			};
			return function(mode) {
				return blendModeEnums[mode] || "";
			};
		}();
		function SliderEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 0, 0, container);
		}
		function AngleEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 0, 0, container);
		}
		function ColorEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 1, 0, container);
		}
		function PointEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 1, 0, container);
		}
		function LayerIndexEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 0, 0, container);
		}
		function MaskIndexEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 0, 0, container);
		}
		function CheckboxEffect(data, elem, container) {
			this.p = PropertyFactory.getProp(elem, data.v, 0, 0, container);
		}
		function NoValueEffect() {
			this.p = {};
		}
		function EffectsManager(data, element) {
			var effects = data.ef || [];
			this.effectElements = [];
			var i;
			var len = effects.length;
			var effectItem;
			for (i = 0; i < len; i += 1) {
				effectItem = new GroupEffect(effects[i], element);
				this.effectElements.push(effectItem);
			}
		}
		function GroupEffect(data, element) {
			this.init(data, element);
		}
		extendPrototype([DynamicPropertyContainer], GroupEffect);
		GroupEffect.prototype.getValue = GroupEffect.prototype.iterateDynamicProperties;
		GroupEffect.prototype.init = function(data, element) {
			this.data = data;
			this.effectElements = [];
			this.initDynamicPropertyContainer(element);
			var i;
			var len = this.data.ef.length;
			var eff;
			var effects = this.data.ef;
			for (i = 0; i < len; i += 1) {
				eff = null;
				switch (effects[i].ty) {
					case 0:
						eff = new SliderEffect(effects[i], element, this);
						break;
					case 1:
						eff = new AngleEffect(effects[i], element, this);
						break;
					case 2:
						eff = new ColorEffect(effects[i], element, this);
						break;
					case 3:
						eff = new PointEffect(effects[i], element, this);
						break;
					case 4:
					case 7:
						eff = new CheckboxEffect(effects[i], element, this);
						break;
					case 10:
						eff = new LayerIndexEffect(effects[i], element, this);
						break;
					case 11:
						eff = new MaskIndexEffect(effects[i], element, this);
						break;
					case 5:
						eff = new EffectsManager(effects[i], element, this);
						break;
					default: eff = new NoValueEffect(effects[i], element, this);
				}
				if (eff) this.effectElements.push(eff);
			}
		};
		function BaseElement() {}
		BaseElement.prototype = {
			checkMasks: function checkMasks() {
				if (!this.data.hasMask) return false;
				var i = 0;
				var len = this.data.masksProperties.length;
				while (i < len) {
					if (this.data.masksProperties[i].mode !== "n" && this.data.masksProperties[i].cl !== false) return true;
					i += 1;
				}
				return false;
			},
			initExpressions: function initExpressions() {
				var expressionsInterfaces = getExpressionInterfaces();
				if (!expressionsInterfaces) return;
				var LayerExpressionInterface = expressionsInterfaces("layer");
				var EffectsExpressionInterface = expressionsInterfaces("effects");
				var ShapeExpressionInterface = expressionsInterfaces("shape");
				var TextExpressionInterface = expressionsInterfaces("text");
				var CompExpressionInterface = expressionsInterfaces("comp");
				this.layerInterface = LayerExpressionInterface(this);
				if (this.data.hasMask && this.maskManager) this.layerInterface.registerMaskInterface(this.maskManager);
				var effectsInterface = EffectsExpressionInterface.createEffectsInterface(this, this.layerInterface);
				this.layerInterface.registerEffectsInterface(effectsInterface);
				if (this.data.ty === 0 || this.data.xt) this.compInterface = CompExpressionInterface(this);
				else if (this.data.ty === 4) {
					this.layerInterface.shapeInterface = ShapeExpressionInterface(this.shapesData, this.itemsData, this.layerInterface);
					this.layerInterface.content = this.layerInterface.shapeInterface;
				} else if (this.data.ty === 5) {
					this.layerInterface.textInterface = TextExpressionInterface(this);
					this.layerInterface.text = this.layerInterface.textInterface;
				}
			},
			setBlendMode: function setBlendMode() {
				var blendModeValue = getBlendMode(this.data.bm);
				var elem = this.baseElement || this.layerElement;
				elem.style["mix-blend-mode"] = blendModeValue;
			},
			initBaseData: function initBaseData(data, globalData, comp) {
				this.globalData = globalData;
				this.comp = comp;
				this.data = data;
				this.layerId = createElementID();
				if (!this.data.sr) this.data.sr = 1;
				this.effectsManager = new EffectsManager(this.data, this, this.dynamicProperties);
			},
			getType: function getType() {
				return this.type;
			},
			sourceRectAtTime: function sourceRectAtTime() {}
		};
		/**
		* @file
		* Handles element's layer frame update.
		* Checks layer in point and out point
		*
		*/
		function FrameElement() {}
		FrameElement.prototype = {
			/**
			* @function
			* Initializes frame related properties.
			*
			*/
			initFrame: function initFrame() {
				this._isFirstFrame = false;
				this.dynamicProperties = [];
				this._mdf = false;
			},
			/**
			* @function
			* Calculates all dynamic values
			*
			* @param {number} num
			* current frame number in Layer's time
			* @param {boolean} isVisible
			* if layers is currently in range
			*
			*/
			prepareProperties: function prepareProperties(num, isVisible) {
				var i;
				var len = this.dynamicProperties.length;
				for (i = 0; i < len; i += 1) if (isVisible || this._isParent && this.dynamicProperties[i].propType === "transform") {
					this.dynamicProperties[i].getValue();
					if (this.dynamicProperties[i]._mdf) {
						this.globalData._mdf = true;
						this._mdf = true;
					}
				}
			},
			addDynamicProperty: function addDynamicProperty(prop) {
				if (this.dynamicProperties.indexOf(prop) === -1) this.dynamicProperties.push(prop);
			}
		};
		function FootageElement(data, globalData, comp) {
			this.initFrame();
			this.initRenderable();
			this.assetData = globalData.getAssetData(data.refId);
			this.footageData = globalData.imageLoader.getAsset(this.assetData);
			this.initBaseData(data, globalData, comp);
		}
		FootageElement.prototype.prepareFrame = function() {};
		extendPrototype([
			RenderableElement,
			BaseElement,
			FrameElement
		], FootageElement);
		FootageElement.prototype.getBaseElement = function() {
			return null;
		};
		FootageElement.prototype.renderFrame = function() {};
		FootageElement.prototype.destroy = function() {};
		FootageElement.prototype.initExpressions = function() {
			var expressionsInterfaces = getExpressionInterfaces();
			if (!expressionsInterfaces) return;
			var FootageInterface = expressionsInterfaces("footage");
			this.layerInterface = FootageInterface(this);
		};
		FootageElement.prototype.getFootageData = function() {
			return this.footageData;
		};
		function AudioElement(data, globalData, comp) {
			this.initFrame();
			this.initRenderable();
			this.assetData = globalData.getAssetData(data.refId);
			this.initBaseData(data, globalData, comp);
			this._isPlaying = false;
			this._canPlay = false;
			var assetPath = this.globalData.getAssetsPath(this.assetData);
			this.audio = this.globalData.audioController.createAudio(assetPath);
			this._currentTime = 0;
			this.globalData.audioController.addAudio(this);
			this._volumeMultiplier = 1;
			this._volume = 1;
			this._previousVolume = null;
			this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, globalData.frameRate, this) : { _placeholder: true };
			this.lv = PropertyFactory.getProp(this, data.au && data.au.lv ? data.au.lv : { k: [100] }, 1, .01, this);
		}
		AudioElement.prototype.prepareFrame = function(num) {
			this.prepareRenderableFrame(num, true);
			this.prepareProperties(num, true);
			if (!this.tm._placeholder) {
				var timeRemapped = this.tm.v;
				this._currentTime = timeRemapped;
			} else this._currentTime = num / this.data.sr;
			this._volume = this.lv.v[0];
			var totalVolume = this._volume * this._volumeMultiplier;
			if (this._previousVolume !== totalVolume) {
				this._previousVolume = totalVolume;
				this.audio.volume(totalVolume);
			}
		};
		extendPrototype([
			RenderableElement,
			BaseElement,
			FrameElement
		], AudioElement);
		AudioElement.prototype.renderFrame = function() {
			if (this.isInRange && this._canPlay) {
				if (!this._isPlaying) {
					this.audio.play();
					this.audio.seek(this._currentTime / this.globalData.frameRate);
					this._isPlaying = true;
				} else if (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > .1) this.audio.seek(this._currentTime / this.globalData.frameRate);
			}
		};
		AudioElement.prototype.show = function() {};
		AudioElement.prototype.hide = function() {
			this.audio.pause();
			this._isPlaying = false;
		};
		AudioElement.prototype.pause = function() {
			this.audio.pause();
			this._isPlaying = false;
			this._canPlay = false;
		};
		AudioElement.prototype.resume = function() {
			this._canPlay = true;
		};
		AudioElement.prototype.setRate = function(rateValue) {
			this.audio.rate(rateValue);
		};
		AudioElement.prototype.volume = function(volumeValue) {
			this._volumeMultiplier = volumeValue;
			this._previousVolume = volumeValue * this._volume;
			this.audio.volume(this._previousVolume);
		};
		AudioElement.prototype.getBaseElement = function() {
			return null;
		};
		AudioElement.prototype.destroy = function() {};
		AudioElement.prototype.sourceRectAtTime = function() {};
		AudioElement.prototype.initExpressions = function() {};
		function BaseRenderer() {}
		BaseRenderer.prototype.checkLayers = function(num) {
			var i;
			var len = this.layers.length;
			var data;
			this.completeLayers = true;
			for (i = len - 1; i >= 0; i -= 1) {
				if (!this.elements[i]) {
					data = this.layers[i];
					if (data.ip - data.st <= num - this.layers[i].st && data.op - data.st > num - this.layers[i].st) this.buildItem(i);
				}
				this.completeLayers = this.elements[i] ? this.completeLayers : false;
			}
			this.checkPendingElements();
		};
		BaseRenderer.prototype.createItem = function(layer) {
			switch (layer.ty) {
				case 2: return this.createImage(layer);
				case 0: return this.createComp(layer);
				case 1: return this.createSolid(layer);
				case 3: return this.createNull(layer);
				case 4: return this.createShape(layer);
				case 5: return this.createText(layer);
				case 6: return this.createAudio(layer);
				case 13: return this.createCamera(layer);
				case 15: return this.createFootage(layer);
				default: return this.createNull(layer);
			}
		};
		BaseRenderer.prototype.createCamera = function() {
			throw new Error("You're using a 3d camera. Try the html renderer.");
		};
		BaseRenderer.prototype.createAudio = function(data) {
			return new AudioElement(data, this.globalData, this);
		};
		BaseRenderer.prototype.createFootage = function(data) {
			return new FootageElement(data, this.globalData, this);
		};
		BaseRenderer.prototype.buildAllItems = function() {
			var i;
			var len = this.layers.length;
			for (i = 0; i < len; i += 1) this.buildItem(i);
			this.checkPendingElements();
		};
		BaseRenderer.prototype.includeLayers = function(newLayers) {
			this.completeLayers = false;
			var i;
			var len = newLayers.length;
			var j;
			var jLen = this.layers.length;
			for (i = 0; i < len; i += 1) {
				j = 0;
				while (j < jLen) {
					if (this.layers[j].id === newLayers[i].id) {
						this.layers[j] = newLayers[i];
						break;
					}
					j += 1;
				}
			}
		};
		BaseRenderer.prototype.setProjectInterface = function(pInterface) {
			this.globalData.projectInterface = pInterface;
		};
		BaseRenderer.prototype.initItems = function() {
			if (!this.globalData.progressiveLoad) this.buildAllItems();
		};
		BaseRenderer.prototype.buildElementParenting = function(element, parentName, hierarchy) {
			var elements = this.elements;
			var layers = this.layers;
			var i = 0;
			var len = layers.length;
			while (i < len) {
				if (layers[i].ind == parentName) {
					if (!elements[i] || elements[i] === true) {
						this.buildItem(i);
						this.addPendingElement(element);
					} else {
						hierarchy.push(elements[i]);
						elements[i].setAsParent();
						if (layers[i].parent !== void 0) this.buildElementParenting(element, layers[i].parent, hierarchy);
						else element.setHierarchy(hierarchy);
					}
				}
				i += 1;
			}
		};
		BaseRenderer.prototype.addPendingElement = function(element) {
			this.pendingElements.push(element);
		};
		BaseRenderer.prototype.searchExtraCompositions = function(assets) {
			var i;
			var len = assets.length;
			for (i = 0; i < len; i += 1) if (assets[i].xt) {
				var comp = this.createComp(assets[i]);
				comp.initExpressions();
				this.globalData.projectInterface.registerComposition(comp);
			}
		};
		BaseRenderer.prototype.getElementById = function(ind) {
			var i;
			var len = this.elements.length;
			for (i = 0; i < len; i += 1) if (this.elements[i].data.ind === ind) return this.elements[i];
			return null;
		};
		BaseRenderer.prototype.getElementByPath = function(path) {
			var pathValue = path.shift();
			var element;
			if (typeof pathValue === "number") element = this.elements[pathValue];
			else {
				var i;
				var len = this.elements.length;
				for (i = 0; i < len; i += 1) if (this.elements[i].data.nm === pathValue) {
					element = this.elements[i];
					break;
				}
			}
			if (path.length === 0) return element;
			return element.getElementByPath(path);
		};
		BaseRenderer.prototype.setupGlobalData = function(animData, fontsContainer) {
			this.globalData.fontManager = new FontManager();
			this.globalData.slotManager = slotFactory(animData);
			this.globalData.fontManager.addChars(animData.chars);
			this.globalData.fontManager.addFonts(animData.fonts, fontsContainer);
			this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem);
			this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem);
			this.globalData.imageLoader = this.animationItem.imagePreloader;
			this.globalData.audioController = this.animationItem.audioController;
			this.globalData.frameId = 0;
			this.globalData.frameRate = animData.fr;
			this.globalData.nm = animData.nm;
			this.globalData.compSize = {
				w: animData.w,
				h: animData.h
			};
		};
		var effectTypes = { TRANSFORM_EFFECT: "transformEFfect" };
		function TransformElement() {}
		TransformElement.prototype = {
			initTransform: function initTransform() {
				var mat = new Matrix();
				this.finalTransform = {
					mProp: this.data.ks ? TransformPropertyFactory.getTransformProperty(this, this.data.ks, this) : { o: 0 },
					_matMdf: false,
					_localMatMdf: false,
					_opMdf: false,
					mat,
					localMat: mat,
					localOpacity: 1
				};
				if (this.data.ao) this.finalTransform.mProp.autoOriented = true;
				if (this.data.ty !== 11) {}
			},
			renderTransform: function renderTransform() {
				this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame;
				this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame;
				if (this.hierarchy) {
					var mat;
					var finalMat = this.finalTransform.mat;
					var i = 0;
					var len = this.hierarchy.length;
					if (!this.finalTransform._matMdf) while (i < len) {
						if (this.hierarchy[i].finalTransform.mProp._mdf) {
							this.finalTransform._matMdf = true;
							break;
						}
						i += 1;
					}
					if (this.finalTransform._matMdf) {
						mat = this.finalTransform.mProp.v.props;
						finalMat.cloneFromProps(mat);
						for (i = 0; i < len; i += 1) finalMat.multiply(this.hierarchy[i].finalTransform.mProp.v);
					}
				}
				if (!this.localTransforms || this.finalTransform._matMdf) this.finalTransform._localMatMdf = this.finalTransform._matMdf;
				if (this.finalTransform._opMdf) this.finalTransform.localOpacity = this.finalTransform.mProp.o.v;
			},
			renderLocalTransform: function renderLocalTransform() {
				if (this.localTransforms) {
					var i = 0;
					var len = this.localTransforms.length;
					this.finalTransform._localMatMdf = this.finalTransform._matMdf;
					if (!this.finalTransform._localMatMdf || !this.finalTransform._opMdf) while (i < len) {
						if (this.localTransforms[i]._mdf) this.finalTransform._localMatMdf = true;
						if (this.localTransforms[i]._opMdf && !this.finalTransform._opMdf) {
							this.finalTransform.localOpacity = this.finalTransform.mProp.o.v;
							this.finalTransform._opMdf = true;
						}
						i += 1;
					}
					if (this.finalTransform._localMatMdf) {
						var localMat = this.finalTransform.localMat;
						this.localTransforms[0].matrix.clone(localMat);
						for (i = 1; i < len; i += 1) {
							var lmat = this.localTransforms[i].matrix;
							localMat.multiply(lmat);
						}
						localMat.multiply(this.finalTransform.mat);
					}
					if (this.finalTransform._opMdf) {
						var localOp = this.finalTransform.localOpacity;
						for (i = 0; i < len; i += 1) localOp *= this.localTransforms[i].opacity * .01;
						this.finalTransform.localOpacity = localOp;
					}
				}
			},
			searchEffectTransforms: function searchEffectTransforms() {
				if (this.renderableEffectsManager) {
					var transformEffects = this.renderableEffectsManager.getEffects(effectTypes.TRANSFORM_EFFECT);
					if (transformEffects.length) {
						this.localTransforms = [];
						this.finalTransform.localMat = new Matrix();
						var i = 0;
						var len = transformEffects.length;
						for (i = 0; i < len; i += 1) this.localTransforms.push(transformEffects[i]);
					}
				}
			},
			globalToLocal: function globalToLocal(pt) {
				var transforms = [];
				transforms.push(this.finalTransform);
				var flag = true;
				var comp = this.comp;
				while (flag) if (comp.finalTransform) {
					if (comp.data.hasMask) transforms.splice(0, 0, comp.finalTransform);
					comp = comp.comp;
				} else flag = false;
				var i;
				var len = transforms.length;
				var ptNew;
				for (i = 0; i < len; i += 1) {
					ptNew = transforms[i].mat.applyToPointArray(0, 0, 0);
					pt = [
						pt[0] - ptNew[0],
						pt[1] - ptNew[1],
						0
					];
				}
				return pt;
			},
			mHelper: new Matrix()
		};
		function MaskElement(data, element, globalData) {
			this.data = data;
			this.element = element;
			this.globalData = globalData;
			this.storedData = [];
			this.masksProperties = this.data.masksProperties || [];
			this.maskElement = null;
			var defs = this.globalData.defs;
			var i;
			var len = this.masksProperties ? this.masksProperties.length : 0;
			this.viewData = createSizedArray(len);
			this.solidPath = "";
			var path;
			var properties = this.masksProperties;
			var count = 0;
			var currentMasks = [];
			var j;
			var jLen;
			var layerId = createElementID();
			var rect;
			var expansor;
			var feMorph;
			var x;
			var maskType = "clipPath";
			var maskRef = "clip-path";
			for (i = 0; i < len; i += 1) {
				if (properties[i].mode !== "a" && properties[i].mode !== "n" || properties[i].inv || properties[i].o.k !== 100 || properties[i].o.x) {
					maskType = "mask";
					maskRef = "mask";
				}
				if ((properties[i].mode === "s" || properties[i].mode === "i") && count === 0) {
					rect = createNS("rect");
					rect.setAttribute("fill", "#ffffff");
					rect.setAttribute("width", this.element.comp.data.w || 0);
					rect.setAttribute("height", this.element.comp.data.h || 0);
					currentMasks.push(rect);
				} else rect = null;
				path = createNS("path");
				if (properties[i].mode === "n") {
					this.viewData[i] = {
						op: PropertyFactory.getProp(this.element, properties[i].o, 0, .01, this.element),
						prop: ShapePropertyFactory.getShapeProp(this.element, properties[i], 3),
						elem: path,
						lastPath: ""
					};
					defs.appendChild(path);
				} else {
					count += 1;
					path.setAttribute("fill", properties[i].mode === "s" ? "#000000" : "#ffffff");
					path.setAttribute("clip-rule", "nonzero");
					var filterID;
					if (properties[i].x.k !== 0) {
						maskType = "mask";
						maskRef = "mask";
						x = PropertyFactory.getProp(this.element, properties[i].x, 0, null, this.element);
						filterID = createElementID();
						expansor = createNS("filter");
						expansor.setAttribute("id", filterID);
						feMorph = createNS("feMorphology");
						feMorph.setAttribute("operator", "erode");
						feMorph.setAttribute("in", "SourceGraphic");
						feMorph.setAttribute("radius", "0");
						expansor.appendChild(feMorph);
						defs.appendChild(expansor);
						path.setAttribute("stroke", properties[i].mode === "s" ? "#000000" : "#ffffff");
					} else {
						feMorph = null;
						x = null;
					}
					this.storedData[i] = {
						elem: path,
						x,
						expan: feMorph,
						lastPath: "",
						lastOperator: "",
						filterId: filterID,
						lastRadius: 0
					};
					if (properties[i].mode === "i") {
						jLen = currentMasks.length;
						var g = createNS("g");
						for (j = 0; j < jLen; j += 1) g.appendChild(currentMasks[j]);
						var mask = createNS("mask");
						mask.setAttribute("mask-type", "alpha");
						mask.setAttribute("id", layerId + "_" + count);
						mask.appendChild(path);
						defs.appendChild(mask);
						g.setAttribute("mask", "url(" + getLocationHref() + "#" + layerId + "_" + count + ")");
						currentMasks.length = 0;
						currentMasks.push(g);
					} else currentMasks.push(path);
					if (properties[i].inv && !this.solidPath) this.solidPath = this.createLayerSolidPath();
					this.viewData[i] = {
						elem: path,
						lastPath: "",
						op: PropertyFactory.getProp(this.element, properties[i].o, 0, .01, this.element),
						prop: ShapePropertyFactory.getShapeProp(this.element, properties[i], 3),
						invRect: rect
					};
					if (!this.viewData[i].prop.k) this.drawPath(properties[i], this.viewData[i].prop.v, this.viewData[i]);
				}
			}
			this.maskElement = createNS(maskType);
			len = currentMasks.length;
			for (i = 0; i < len; i += 1) this.maskElement.appendChild(currentMasks[i]);
			if (count > 0) {
				this.maskElement.setAttribute("id", layerId);
				this.element.maskedElement.setAttribute(maskRef, "url(" + getLocationHref() + "#" + layerId + ")");
				defs.appendChild(this.maskElement);
			}
			if (this.viewData.length) this.element.addRenderableComponent(this);
		}
		MaskElement.prototype.getMaskProperty = function(pos) {
			return this.viewData[pos].prop;
		};
		MaskElement.prototype.renderFrame = function(isFirstFrame) {
			var finalMat = this.element.finalTransform.mat;
			var i;
			var len = this.masksProperties.length;
			for (i = 0; i < len; i += 1) {
				if (this.viewData[i].prop._mdf || isFirstFrame) this.drawPath(this.masksProperties[i], this.viewData[i].prop.v, this.viewData[i]);
				if (this.viewData[i].op._mdf || isFirstFrame) this.viewData[i].elem.setAttribute("fill-opacity", this.viewData[i].op.v);
				if (this.masksProperties[i].mode !== "n") {
					if (this.viewData[i].invRect && (this.element.finalTransform.mProp._mdf || isFirstFrame)) this.viewData[i].invRect.setAttribute("transform", finalMat.getInverseMatrix().to2dCSS());
					if (this.storedData[i].x && (this.storedData[i].x._mdf || isFirstFrame)) {
						var feMorph = this.storedData[i].expan;
						if (this.storedData[i].x.v < 0) {
							if (this.storedData[i].lastOperator !== "erode") {
								this.storedData[i].lastOperator = "erode";
								this.storedData[i].elem.setAttribute("filter", "url(" + getLocationHref() + "#" + this.storedData[i].filterId + ")");
							}
							feMorph.setAttribute("radius", -this.storedData[i].x.v);
						} else {
							if (this.storedData[i].lastOperator !== "dilate") {
								this.storedData[i].lastOperator = "dilate";
								this.storedData[i].elem.setAttribute("filter", null);
							}
							this.storedData[i].elem.setAttribute("stroke-width", this.storedData[i].x.v * 2);
						}
					}
				}
			}
		};
		MaskElement.prototype.getMaskelement = function() {
			return this.maskElement;
		};
		MaskElement.prototype.createLayerSolidPath = function() {
			var path = "M0,0 ";
			path += " h" + this.globalData.compSize.w;
			path += " v" + this.globalData.compSize.h;
			path += " h-" + this.globalData.compSize.w;
			path += " v-" + this.globalData.compSize.h + " ";
			return path;
		};
		MaskElement.prototype.drawPath = function(pathData, pathNodes, viewData) {
			var pathString = " M" + pathNodes.v[0][0] + "," + pathNodes.v[0][1];
			var i;
			var len = pathNodes._length;
			for (i = 1; i < len; i += 1) pathString += " C" + pathNodes.o[i - 1][0] + "," + pathNodes.o[i - 1][1] + " " + pathNodes.i[i][0] + "," + pathNodes.i[i][1] + " " + pathNodes.v[i][0] + "," + pathNodes.v[i][1];
			if (pathNodes.c && len > 1) pathString += " C" + pathNodes.o[i - 1][0] + "," + pathNodes.o[i - 1][1] + " " + pathNodes.i[0][0] + "," + pathNodes.i[0][1] + " " + pathNodes.v[0][0] + "," + pathNodes.v[0][1];
			if (viewData.lastPath !== pathString) {
				var pathShapeValue = "";
				if (viewData.elem) {
					if (pathNodes.c) pathShapeValue = pathData.inv ? this.solidPath + pathString : pathString;
					viewData.elem.setAttribute("d", pathShapeValue);
				}
				viewData.lastPath = pathString;
			}
		};
		MaskElement.prototype.destroy = function() {
			this.element = null;
			this.globalData = null;
			this.maskElement = null;
			this.data = null;
			this.masksProperties = null;
		};
		var filtersFactory = function() {
			var ob = {};
			ob.createFilter = createFilter;
			ob.createAlphaToLuminanceFilter = createAlphaToLuminanceFilter;
			function createFilter(filId, skipCoordinates) {
				var fil = createNS("filter");
				fil.setAttribute("id", filId);
				if (skipCoordinates !== true) {
					fil.setAttribute("filterUnits", "objectBoundingBox");
					fil.setAttribute("x", "0%");
					fil.setAttribute("y", "0%");
					fil.setAttribute("width", "100%");
					fil.setAttribute("height", "100%");
				}
				return fil;
			}
			function createAlphaToLuminanceFilter() {
				var feColorMatrix = createNS("feColorMatrix");
				feColorMatrix.setAttribute("type", "matrix");
				feColorMatrix.setAttribute("color-interpolation-filters", "sRGB");
				feColorMatrix.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1");
				return feColorMatrix;
			}
			return ob;
		}();
		var featureSupport = function() {
			var ob = {
				maskType: true,
				svgLumaHidden: true,
				offscreenCanvas: typeof OffscreenCanvas !== "undefined"
			};
			if (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) ob.maskType = false;
			if (/firefox/i.test(navigator.userAgent)) ob.svgLumaHidden = false;
			return ob;
		}();
		var registeredEffects$1 = {};
		var idPrefix = "filter_result_";
		function SVGEffects(elem) {
			var i;
			var source = "SourceGraphic";
			var len = elem.data.ef ? elem.data.ef.length : 0;
			var filId = createElementID();
			var fil = filtersFactory.createFilter(filId, true);
			var count = 0;
			this.filters = [];
			var filterManager;
			for (i = 0; i < len; i += 1) {
				filterManager = null;
				var type = elem.data.ef[i].ty;
				if (registeredEffects$1[type]) {
					var Effect = registeredEffects$1[type].effect;
					filterManager = new Effect(fil, elem.effectsManager.effectElements[i], elem, idPrefix + count, source);
					source = idPrefix + count;
					if (registeredEffects$1[type].countsAsEffect) count += 1;
				}
				if (filterManager) this.filters.push(filterManager);
			}
			if (count) {
				elem.globalData.defs.appendChild(fil);
				elem.layerElement.setAttribute("filter", "url(" + getLocationHref() + "#" + filId + ")");
			}
			if (this.filters.length) elem.addRenderableComponent(this);
		}
		SVGEffects.prototype.renderFrame = function(_isFirstFrame) {
			var i;
			var len = this.filters.length;
			for (i = 0; i < len; i += 1) this.filters[i].renderFrame(_isFirstFrame);
		};
		SVGEffects.prototype.getEffects = function(type) {
			var i;
			var len = this.filters.length;
			var effects = [];
			for (i = 0; i < len; i += 1) if (this.filters[i].type === type) effects.push(this.filters[i]);
			return effects;
		};
		function SVGBaseElement() {}
		SVGBaseElement.prototype = {
			initRendererElement: function initRendererElement() {
				this.layerElement = createNS("g");
			},
			createContainerElements: function createContainerElements() {
				this.matteElement = createNS("g");
				this.transformedElement = this.layerElement;
				this.maskedElement = this.layerElement;
				this._sizeChanged = false;
				var layerElementParent = null;
				if (this.data.td) {
					this.matteMasks = {};
					var gg = createNS("g");
					gg.setAttribute("id", this.layerId);
					gg.appendChild(this.layerElement);
					layerElementParent = gg;
					this.globalData.defs.appendChild(gg);
				} else if (this.data.tt) {
					this.matteElement.appendChild(this.layerElement);
					layerElementParent = this.matteElement;
					this.baseElement = this.matteElement;
				} else this.baseElement = this.layerElement;
				if (this.data.ln) this.layerElement.setAttribute("id", this.data.ln);
				if (this.data.cl) this.layerElement.setAttribute("class", this.data.cl);
				if (this.data.ty === 0 && !this.data.hd) {
					var cp = createNS("clipPath");
					var pt = createNS("path");
					pt.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
					var clipId = createElementID();
					cp.setAttribute("id", clipId);
					cp.appendChild(pt);
					this.globalData.defs.appendChild(cp);
					if (this.checkMasks()) {
						var cpGroup = createNS("g");
						cpGroup.setAttribute("clip-path", "url(" + getLocationHref() + "#" + clipId + ")");
						cpGroup.appendChild(this.layerElement);
						this.transformedElement = cpGroup;
						if (layerElementParent) layerElementParent.appendChild(this.transformedElement);
						else this.baseElement = this.transformedElement;
					} else this.layerElement.setAttribute("clip-path", "url(" + getLocationHref() + "#" + clipId + ")");
				}
				if (this.data.bm !== 0) this.setBlendMode();
			},
			renderElement: function renderElement() {
				if (this.finalTransform._localMatMdf) this.transformedElement.setAttribute("transform", this.finalTransform.localMat.to2dCSS());
				if (this.finalTransform._opMdf) this.transformedElement.setAttribute("opacity", this.finalTransform.localOpacity);
			},
			destroyBaseElement: function destroyBaseElement() {
				this.layerElement = null;
				this.matteElement = null;
				this.maskManager.destroy();
			},
			getBaseElement: function getBaseElement() {
				if (this.data.hd) return null;
				return this.baseElement;
			},
			createRenderableComponents: function createRenderableComponents() {
				this.maskManager = new MaskElement(this.data, this, this.globalData);
				this.renderableEffectsManager = new SVGEffects(this);
				this.searchEffectTransforms();
			},
			getMatte: function getMatte(matteType) {
				if (!this.matteMasks) this.matteMasks = {};
				if (!this.matteMasks[matteType]) {
					var id = this.layerId + "_" + matteType;
					var filId;
					var fil;
					var useElement;
					var gg;
					if (matteType === 1 || matteType === 3) {
						var masker = createNS("mask");
						masker.setAttribute("id", id);
						masker.setAttribute("mask-type", matteType === 3 ? "luminance" : "alpha");
						useElement = createNS("use");
						useElement.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId);
						masker.appendChild(useElement);
						this.globalData.defs.appendChild(masker);
						if (!featureSupport.maskType && matteType === 1) {
							masker.setAttribute("mask-type", "luminance");
							filId = createElementID();
							fil = filtersFactory.createFilter(filId);
							this.globalData.defs.appendChild(fil);
							fil.appendChild(filtersFactory.createAlphaToLuminanceFilter());
							gg = createNS("g");
							gg.appendChild(useElement);
							masker.appendChild(gg);
							gg.setAttribute("filter", "url(" + getLocationHref() + "#" + filId + ")");
						}
					} else if (matteType === 2) {
						var maskGroup = createNS("mask");
						maskGroup.setAttribute("id", id);
						maskGroup.setAttribute("mask-type", "alpha");
						var maskGrouper = createNS("g");
						maskGroup.appendChild(maskGrouper);
						filId = createElementID();
						fil = filtersFactory.createFilter(filId);
						var feCTr = createNS("feComponentTransfer");
						feCTr.setAttribute("in", "SourceGraphic");
						fil.appendChild(feCTr);
						var feFunc = createNS("feFuncA");
						feFunc.setAttribute("type", "table");
						feFunc.setAttribute("tableValues", "1.0 0.0");
						feCTr.appendChild(feFunc);
						this.globalData.defs.appendChild(fil);
						var alphaRect = createNS("rect");
						alphaRect.setAttribute("width", this.comp.data.w);
						alphaRect.setAttribute("height", this.comp.data.h);
						alphaRect.setAttribute("x", "0");
						alphaRect.setAttribute("y", "0");
						alphaRect.setAttribute("fill", "#ffffff");
						alphaRect.setAttribute("opacity", "0");
						maskGrouper.setAttribute("filter", "url(" + getLocationHref() + "#" + filId + ")");
						maskGrouper.appendChild(alphaRect);
						useElement = createNS("use");
						useElement.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId);
						maskGrouper.appendChild(useElement);
						if (!featureSupport.maskType) {
							maskGroup.setAttribute("mask-type", "luminance");
							fil.appendChild(filtersFactory.createAlphaToLuminanceFilter());
							gg = createNS("g");
							maskGrouper.appendChild(alphaRect);
							gg.appendChild(this.layerElement);
							maskGrouper.appendChild(gg);
						}
						this.globalData.defs.appendChild(maskGroup);
					}
					this.matteMasks[matteType] = id;
				}
				return this.matteMasks[matteType];
			},
			setMatte: function setMatte(id) {
				if (!this.matteElement) return;
				this.matteElement.setAttribute("mask", "url(" + getLocationHref() + "#" + id + ")");
			}
		};
		/**
		* @file
		* Handles AE's layer parenting property.
		*
		*/
		function HierarchyElement() {}
		HierarchyElement.prototype = {
			/**
			* @function
			* Initializes hierarchy properties
			*
			*/
			initHierarchy: function initHierarchy() {
				this.hierarchy = [];
				this._isParent = false;
				this.checkParenting();
			},
			/**
			* @function
			* Sets layer's hierarchy.
			* @param {array} hierarch
			* layer's parent list
			*
			*/
			setHierarchy: function setHierarchy(hierarchy) {
				this.hierarchy = hierarchy;
			},
			/**
			* @function
			* Sets layer as parent.
			*
			*/
			setAsParent: function setAsParent() {
				this._isParent = true;
			},
			/**
			* @function
			* Searches layer's parenting chain
			*
			*/
			checkParenting: function checkParenting() {
				if (this.data.parent !== void 0) this.comp.buildElementParenting(this, this.data.parent, []);
			}
		};
		function RenderableDOMElement() {}
		(function() {
			extendPrototype([RenderableElement, createProxyFunction({
				initElement: function initElement(data, globalData, comp) {
					this.initFrame();
					this.initBaseData(data, globalData, comp);
					this.initTransform(data, globalData, comp);
					this.initHierarchy();
					this.initRenderable();
					this.initRendererElement();
					this.createContainerElements();
					this.createRenderableComponents();
					this.createContent();
					this.hide();
				},
				hide: function hide() {
					if (!this.hidden && (!this.isInRange || this.isTransparent)) {
						var elem = this.baseElement || this.layerElement;
						elem.style.display = "none";
						this.hidden = true;
					}
				},
				show: function show() {
					if (this.isInRange && !this.isTransparent) {
						if (!this.data.hd) {
							var elem = this.baseElement || this.layerElement;
							elem.style.display = "block";
						}
						this.hidden = false;
						this._isFirstFrame = true;
					}
				},
				renderFrame: function renderFrame() {
					if (this.data.hd || this.hidden) return;
					this.renderTransform();
					this.renderRenderable();
					this.renderLocalTransform();
					this.renderElement();
					this.renderInnerContent();
					if (this._isFirstFrame) this._isFirstFrame = false;
				},
				renderInnerContent: function renderInnerContent() {},
				prepareFrame: function prepareFrame(num) {
					this._mdf = false;
					this.prepareRenderableFrame(num);
					this.prepareProperties(num, this.isInRange);
					this.checkTransparency();
				},
				destroy: function destroy() {
					this.innerElem = null;
					this.destroyBaseElement();
				}
			})], RenderableDOMElement);
		})();
		function IImageElement(data, globalData, comp) {
			this.assetData = globalData.getAssetData(data.refId);
			if (this.assetData && this.assetData.sid) this.assetData = globalData.slotManager.getProp(this.assetData);
			this.initElement(data, globalData, comp);
			this.sourceRect = {
				top: 0,
				left: 0,
				width: this.assetData.w,
				height: this.assetData.h
			};
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			SVGBaseElement,
			HierarchyElement,
			FrameElement,
			RenderableDOMElement
		], IImageElement);
		IImageElement.prototype.createContent = function() {
			var assetPath = this.globalData.getAssetsPath(this.assetData);
			this.innerElem = createNS("image");
			this.innerElem.setAttribute("width", this.assetData.w + "px");
			this.innerElem.setAttribute("height", this.assetData.h + "px");
			this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio);
			this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", assetPath);
			this.layerElement.appendChild(this.innerElem);
		};
		IImageElement.prototype.sourceRectAtTime = function() {
			return this.sourceRect;
		};
		function ProcessedElement(element, position) {
			this.elem = element;
			this.pos = position;
		}
		function IShapeElement() {}
		IShapeElement.prototype = {
			addShapeToModifiers: function addShapeToModifiers(data) {
				var i;
				var len = this.shapeModifiers.length;
				for (i = 0; i < len; i += 1) this.shapeModifiers[i].addShape(data);
			},
			isShapeInAnimatedModifiers: function isShapeInAnimatedModifiers(data) {
				var i = 0;
				var len = this.shapeModifiers.length;
				while (i < len) if (this.shapeModifiers[i].isAnimatedWithShape(data)) return true;
				return false;
			},
			renderModifiers: function renderModifiers() {
				if (!this.shapeModifiers.length) return;
				var i;
				var len = this.shapes.length;
				for (i = 0; i < len; i += 1) this.shapes[i].sh.reset();
				len = this.shapeModifiers.length;
				var shouldBreakProcess;
				for (i = len - 1; i >= 0; i -= 1) {
					shouldBreakProcess = this.shapeModifiers[i].processShapes(this._isFirstFrame);
					if (shouldBreakProcess) break;
				}
			},
			searchProcessedElement: function searchProcessedElement(elem) {
				var elements = this.processedElements;
				var i = 0;
				var len = elements.length;
				while (i < len) {
					if (elements[i].elem === elem) return elements[i].pos;
					i += 1;
				}
				return 0;
			},
			addProcessedElement: function addProcessedElement(elem, pos) {
				var elements = this.processedElements;
				var i = elements.length;
				while (i) {
					i -= 1;
					if (elements[i].elem === elem) {
						elements[i].pos = pos;
						return;
					}
				}
				elements.push(new ProcessedElement(elem, pos));
			},
			prepareFrame: function prepareFrame(num) {
				this.prepareRenderableFrame(num);
				this.prepareProperties(num, this.isInRange);
			}
		};
		var lineCapEnum = {
			1: "butt",
			2: "round",
			3: "square"
		};
		var lineJoinEnum = {
			1: "miter",
			2: "round",
			3: "bevel"
		};
		function SVGShapeData(transformers, level, shape) {
			this.caches = [];
			this.styles = [];
			this.transformers = transformers;
			this.lStr = "";
			this.sh = shape;
			this.lvl = level;
			this._isAnimated = !!shape.k;
			var i = 0;
			var len = transformers.length;
			while (i < len) {
				if (transformers[i].mProps.dynamicProperties.length) {
					this._isAnimated = true;
					break;
				}
				i += 1;
			}
		}
		SVGShapeData.prototype.setAsAnimated = function() {
			this._isAnimated = true;
		};
		function SVGStyleData(data, level) {
			this.data = data;
			this.type = data.ty;
			this.d = "";
			this.lvl = level;
			this._mdf = false;
			this.closed = data.hd === true;
			this.pElem = createNS("path");
			this.msElem = null;
		}
		SVGStyleData.prototype.reset = function() {
			this.d = "";
			this._mdf = false;
		};
		function DashProperty(elem, data, renderer, container) {
			this.elem = elem;
			this.frameId = -1;
			this.dataProps = createSizedArray(data.length);
			this.renderer = renderer;
			this.k = false;
			this.dashStr = "";
			this.dashArray = createTypedArray("float32", data.length ? data.length - 1 : 0);
			this.dashoffset = createTypedArray("float32", 1);
			this.initDynamicPropertyContainer(container);
			var i;
			var len = data.length || 0;
			var prop;
			for (i = 0; i < len; i += 1) {
				prop = PropertyFactory.getProp(elem, data[i].v, 0, 0, this);
				this.k = prop.k || this.k;
				this.dataProps[i] = {
					n: data[i].n,
					p: prop
				};
			}
			if (!this.k) this.getValue(true);
			this._isAnimated = this.k;
		}
		DashProperty.prototype.getValue = function(forceRender) {
			if (this.elem.globalData.frameId === this.frameId && !forceRender) return;
			this.frameId = this.elem.globalData.frameId;
			this.iterateDynamicProperties();
			this._mdf = this._mdf || forceRender;
			if (this._mdf) {
				var i = 0;
				var len = this.dataProps.length;
				if (this.renderer === "svg") this.dashStr = "";
				for (i = 0; i < len; i += 1) if (this.dataProps[i].n !== "o") {
					if (this.renderer === "svg") this.dashStr += " " + this.dataProps[i].p.v;
					else this.dashArray[i] = this.dataProps[i].p.v;
				} else this.dashoffset[0] = this.dataProps[i].p.v;
			}
		};
		extendPrototype([DynamicPropertyContainer], DashProperty);
		function SVGStrokeStyleData(elem, data, styleOb) {
			this.initDynamicPropertyContainer(elem);
			this.getValue = this.iterateDynamicProperties;
			this.o = PropertyFactory.getProp(elem, data.o, 0, .01, this);
			this.w = PropertyFactory.getProp(elem, data.w, 0, null, this);
			this.d = new DashProperty(elem, data.d || {}, "svg", this);
			this.c = PropertyFactory.getProp(elem, data.c, 1, 255, this);
			this.style = styleOb;
			this._isAnimated = !!this._isAnimated;
		}
		extendPrototype([DynamicPropertyContainer], SVGStrokeStyleData);
		function SVGFillStyleData(elem, data, styleOb) {
			this.initDynamicPropertyContainer(elem);
			this.getValue = this.iterateDynamicProperties;
			this.o = PropertyFactory.getProp(elem, data.o, 0, .01, this);
			this.c = PropertyFactory.getProp(elem, data.c, 1, 255, this);
			this.style = styleOb;
		}
		extendPrototype([DynamicPropertyContainer], SVGFillStyleData);
		function SVGNoStyleData(elem, data, styleOb) {
			this.initDynamicPropertyContainer(elem);
			this.getValue = this.iterateDynamicProperties;
			this.style = styleOb;
		}
		extendPrototype([DynamicPropertyContainer], SVGNoStyleData);
		function GradientProperty(elem, data, container) {
			this.data = data;
			this.c = createTypedArray("uint8c", data.p * 4);
			var cLength = data.k.k[0].s ? data.k.k[0].s.length - data.p * 4 : data.k.k.length - data.p * 4;
			this.o = createTypedArray("float32", cLength);
			this._cmdf = false;
			this._omdf = false;
			this._collapsable = this.checkCollapsable();
			this._hasOpacity = cLength;
			this.initDynamicPropertyContainer(container);
			this.prop = PropertyFactory.getProp(elem, data.k, 1, null, this);
			this.k = this.prop.k;
			this.getValue(true);
		}
		GradientProperty.prototype.comparePoints = function(values, points) {
			var i = 0;
			var len = this.o.length / 2;
			var diff;
			while (i < len) {
				diff = Math.abs(values[i * 4] - values[points * 4 + i * 2]);
				if (diff > .01) return false;
				i += 1;
			}
			return true;
		};
		GradientProperty.prototype.checkCollapsable = function() {
			if (this.o.length / 2 !== this.c.length / 4) return false;
			if (this.data.k.k[0].s) {
				var i = 0;
				var len = this.data.k.k.length;
				while (i < len) {
					if (!this.comparePoints(this.data.k.k[i].s, this.data.p)) return false;
					i += 1;
				}
			} else if (!this.comparePoints(this.data.k.k, this.data.p)) return false;
			return true;
		};
		GradientProperty.prototype.getValue = function(forceRender) {
			this.prop.getValue();
			this._mdf = false;
			this._cmdf = false;
			this._omdf = false;
			if (this.prop._mdf || forceRender) {
				var i;
				var len = this.data.p * 4;
				var mult;
				var val;
				for (i = 0; i < len; i += 1) {
					mult = i % 4 === 0 ? 100 : 255;
					val = Math.round(this.prop.v[i] * mult);
					if (this.c[i] !== val) {
						this.c[i] = val;
						this._cmdf = !forceRender;
					}
				}
				if (this.o.length) {
					len = this.prop.v.length;
					for (i = this.data.p * 4; i < len; i += 1) {
						mult = i % 2 === 0 ? 100 : 1;
						val = i % 2 === 0 ? Math.round(this.prop.v[i] * 100) : this.prop.v[i];
						if (this.o[i - this.data.p * 4] !== val) {
							this.o[i - this.data.p * 4] = val;
							this._omdf = !forceRender;
						}
					}
				}
				this._mdf = !forceRender;
			}
		};
		extendPrototype([DynamicPropertyContainer], GradientProperty);
		function SVGGradientFillStyleData(elem, data, styleOb) {
			this.initDynamicPropertyContainer(elem);
			this.getValue = this.iterateDynamicProperties;
			this.initGradientData(elem, data, styleOb);
		}
		SVGGradientFillStyleData.prototype.initGradientData = function(elem, data, styleOb) {
			this.o = PropertyFactory.getProp(elem, data.o, 0, .01, this);
			this.s = PropertyFactory.getProp(elem, data.s, 1, null, this);
			this.e = PropertyFactory.getProp(elem, data.e, 1, null, this);
			this.h = PropertyFactory.getProp(elem, data.h || { k: 0 }, 0, .01, this);
			this.a = PropertyFactory.getProp(elem, data.a || { k: 0 }, 0, degToRads, this);
			this.g = new GradientProperty(elem, data.g, this);
			this.style = styleOb;
			this.stops = [];
			this.setGradientData(styleOb.pElem, data);
			this.setGradientOpacity(data, styleOb);
			this._isAnimated = !!this._isAnimated;
		};
		SVGGradientFillStyleData.prototype.setGradientData = function(pathElement, data) {
			var gradientId = createElementID();
			var gfill = createNS(data.t === 1 ? "linearGradient" : "radialGradient");
			gfill.setAttribute("id", gradientId);
			gfill.setAttribute("spreadMethod", "pad");
			gfill.setAttribute("gradientUnits", "userSpaceOnUse");
			var stops = [];
			var stop;
			var j;
			var jLen = data.g.p * 4;
			for (j = 0; j < jLen; j += 4) {
				stop = createNS("stop");
				gfill.appendChild(stop);
				stops.push(stop);
			}
			pathElement.setAttribute(data.ty === "gf" ? "fill" : "stroke", "url(" + getLocationHref() + "#" + gradientId + ")");
			this.gf = gfill;
			this.cst = stops;
		};
		SVGGradientFillStyleData.prototype.setGradientOpacity = function(data, styleOb) {
			if (this.g._hasOpacity && !this.g._collapsable) {
				var stop;
				var j;
				var jLen;
				var mask = createNS("mask");
				var maskElement = createNS("path");
				mask.appendChild(maskElement);
				var opacityId = createElementID();
				var maskId = createElementID();
				mask.setAttribute("id", maskId);
				var opFill = createNS(data.t === 1 ? "linearGradient" : "radialGradient");
				opFill.setAttribute("id", opacityId);
				opFill.setAttribute("spreadMethod", "pad");
				opFill.setAttribute("gradientUnits", "userSpaceOnUse");
				jLen = data.g.k.k[0].s ? data.g.k.k[0].s.length : data.g.k.k.length;
				var stops = this.stops;
				for (j = data.g.p * 4; j < jLen; j += 2) {
					stop = createNS("stop");
					stop.setAttribute("stop-color", "rgb(255,255,255)");
					opFill.appendChild(stop);
					stops.push(stop);
				}
				maskElement.setAttribute(data.ty === "gf" ? "fill" : "stroke", "url(" + getLocationHref() + "#" + opacityId + ")");
				if (data.ty === "gs") {
					maskElement.setAttribute("stroke-linecap", lineCapEnum[data.lc || 2]);
					maskElement.setAttribute("stroke-linejoin", lineJoinEnum[data.lj || 2]);
					if (data.lj === 1) maskElement.setAttribute("stroke-miterlimit", data.ml);
				}
				this.of = opFill;
				this.ms = mask;
				this.ost = stops;
				this.maskId = maskId;
				styleOb.msElem = maskElement;
			}
		};
		extendPrototype([DynamicPropertyContainer], SVGGradientFillStyleData);
		function SVGGradientStrokeStyleData(elem, data, styleOb) {
			this.initDynamicPropertyContainer(elem);
			this.getValue = this.iterateDynamicProperties;
			this.w = PropertyFactory.getProp(elem, data.w, 0, null, this);
			this.d = new DashProperty(elem, data.d || {}, "svg", this);
			this.initGradientData(elem, data, styleOb);
			this._isAnimated = !!this._isAnimated;
		}
		extendPrototype([SVGGradientFillStyleData, DynamicPropertyContainer], SVGGradientStrokeStyleData);
		function ShapeGroupData() {
			this.it = [];
			this.prevViewData = [];
			this.gr = createNS("g");
		}
		function SVGTransformData(mProps, op, container) {
			this.transform = {
				mProps,
				op,
				container
			};
			this.elements = [];
			this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length;
		}
		var buildShapeString = function buildShapeString(pathNodes, length, closed, mat) {
			if (length === 0) return "";
			var _o = pathNodes.o;
			var _i = pathNodes.i;
			var _v = pathNodes.v;
			var i;
			var shapeString = " M" + mat.applyToPointStringified(_v[0][0], _v[0][1]);
			for (i = 1; i < length; i += 1) shapeString += " C" + mat.applyToPointStringified(_o[i - 1][0], _o[i - 1][1]) + " " + mat.applyToPointStringified(_i[i][0], _i[i][1]) + " " + mat.applyToPointStringified(_v[i][0], _v[i][1]);
			if (closed && length) {
				shapeString += " C" + mat.applyToPointStringified(_o[i - 1][0], _o[i - 1][1]) + " " + mat.applyToPointStringified(_i[0][0], _i[0][1]) + " " + mat.applyToPointStringified(_v[0][0], _v[0][1]);
				shapeString += "z";
			}
			return shapeString;
		};
		var SVGElementsRenderer = function() {
			var _identityMatrix = new Matrix();
			var _matrixHelper = new Matrix();
			var ob = { createRenderFunction };
			function createRenderFunction(data) {
				switch (data.ty) {
					case "fl": return renderFill;
					case "gf": return renderGradient;
					case "gs": return renderGradientStroke;
					case "st": return renderStroke;
					case "sh":
					case "el":
					case "rc":
					case "sr": return renderPath;
					case "tr": return renderContentTransform;
					case "no": return renderNoop;
					default: return null;
				}
			}
			function renderContentTransform(styleData, itemData, isFirstFrame) {
				if (isFirstFrame || itemData.transform.op._mdf) itemData.transform.container.setAttribute("opacity", itemData.transform.op.v);
				if (isFirstFrame || itemData.transform.mProps._mdf) itemData.transform.container.setAttribute("transform", itemData.transform.mProps.v.to2dCSS());
			}
			function renderNoop() {}
			function renderPath(styleData, itemData, isFirstFrame) {
				var j;
				var jLen;
				var pathStringTransformed;
				var redraw;
				var pathNodes;
				var l;
				var lLen = itemData.styles.length;
				var lvl = itemData.lvl;
				var paths;
				var mat;
				var iterations;
				var k;
				for (l = 0; l < lLen; l += 1) {
					redraw = itemData.sh._mdf || isFirstFrame;
					if (itemData.styles[l].lvl < lvl) {
						mat = _matrixHelper.reset();
						iterations = lvl - itemData.styles[l].lvl;
						k = itemData.transformers.length - 1;
						while (!redraw && iterations > 0) {
							redraw = itemData.transformers[k].mProps._mdf || redraw;
							iterations -= 1;
							k -= 1;
						}
						if (redraw) {
							iterations = lvl - itemData.styles[l].lvl;
							k = itemData.transformers.length - 1;
							while (iterations > 0) {
								mat.multiply(itemData.transformers[k].mProps.v);
								iterations -= 1;
								k -= 1;
							}
						}
					} else mat = _identityMatrix;
					paths = itemData.sh.paths;
					jLen = paths._length;
					if (redraw) {
						pathStringTransformed = "";
						for (j = 0; j < jLen; j += 1) {
							pathNodes = paths.shapes[j];
							if (pathNodes && pathNodes._length) pathStringTransformed += buildShapeString(pathNodes, pathNodes._length, pathNodes.c, mat);
						}
						itemData.caches[l] = pathStringTransformed;
					} else pathStringTransformed = itemData.caches[l];
					itemData.styles[l].d += styleData.hd === true ? "" : pathStringTransformed;
					itemData.styles[l]._mdf = redraw || itemData.styles[l]._mdf;
				}
			}
			function renderFill(styleData, itemData, isFirstFrame) {
				var styleElem = itemData.style;
				if (itemData.c._mdf || isFirstFrame) styleElem.pElem.setAttribute("fill", "rgb(" + bmFloor(itemData.c.v[0]) + "," + bmFloor(itemData.c.v[1]) + "," + bmFloor(itemData.c.v[2]) + ")");
				if (itemData.o._mdf || isFirstFrame) styleElem.pElem.setAttribute("fill-opacity", itemData.o.v);
			}
			function renderGradientStroke(styleData, itemData, isFirstFrame) {
				renderGradient(styleData, itemData, isFirstFrame);
				renderStroke(styleData, itemData, isFirstFrame);
			}
			function renderGradient(styleData, itemData, isFirstFrame) {
				var gfill = itemData.gf;
				var hasOpacity = itemData.g._hasOpacity;
				var pt1 = itemData.s.v;
				var pt2 = itemData.e.v;
				if (itemData.o._mdf || isFirstFrame) {
					var attr = styleData.ty === "gf" ? "fill-opacity" : "stroke-opacity";
					itemData.style.pElem.setAttribute(attr, itemData.o.v);
				}
				if (itemData.s._mdf || isFirstFrame) {
					var attr1 = styleData.t === 1 ? "x1" : "cx";
					var attr2 = attr1 === "x1" ? "y1" : "cy";
					gfill.setAttribute(attr1, pt1[0]);
					gfill.setAttribute(attr2, pt1[1]);
					if (hasOpacity && !itemData.g._collapsable) {
						itemData.of.setAttribute(attr1, pt1[0]);
						itemData.of.setAttribute(attr2, pt1[1]);
					}
				}
				var stops;
				var i;
				var len;
				var stop;
				if (itemData.g._cmdf || isFirstFrame) {
					stops = itemData.cst;
					var cValues = itemData.g.c;
					len = stops.length;
					for (i = 0; i < len; i += 1) {
						stop = stops[i];
						stop.setAttribute("offset", cValues[i * 4] + "%");
						stop.setAttribute("stop-color", "rgb(" + cValues[i * 4 + 1] + "," + cValues[i * 4 + 2] + "," + cValues[i * 4 + 3] + ")");
					}
				}
				if (hasOpacity && (itemData.g._omdf || isFirstFrame)) {
					var oValues = itemData.g.o;
					if (itemData.g._collapsable) stops = itemData.cst;
					else stops = itemData.ost;
					len = stops.length;
					for (i = 0; i < len; i += 1) {
						stop = stops[i];
						if (!itemData.g._collapsable) stop.setAttribute("offset", oValues[i * 2] + "%");
						stop.setAttribute("stop-opacity", oValues[i * 2 + 1]);
					}
				}
				if (styleData.t === 1) {
					if (itemData.e._mdf || isFirstFrame) {
						gfill.setAttribute("x2", pt2[0]);
						gfill.setAttribute("y2", pt2[1]);
						if (hasOpacity && !itemData.g._collapsable) {
							itemData.of.setAttribute("x2", pt2[0]);
							itemData.of.setAttribute("y2", pt2[1]);
						}
					}
				} else {
					var rad;
					if (itemData.s._mdf || itemData.e._mdf || isFirstFrame) {
						rad = Math.sqrt(Math.pow(pt1[0] - pt2[0], 2) + Math.pow(pt1[1] - pt2[1], 2));
						gfill.setAttribute("r", rad);
						if (hasOpacity && !itemData.g._collapsable) itemData.of.setAttribute("r", rad);
					}
					if (itemData.s._mdf || itemData.e._mdf || itemData.h._mdf || itemData.a._mdf || isFirstFrame) {
						if (!rad) rad = Math.sqrt(Math.pow(pt1[0] - pt2[0], 2) + Math.pow(pt1[1] - pt2[1], 2));
						var ang = Math.atan2(pt2[1] - pt1[1], pt2[0] - pt1[0]);
						var percent = itemData.h.v;
						if (percent >= 1) percent = .99;
						else if (percent <= -1) percent = -.99;
						var dist = rad * percent;
						var x = Math.cos(ang + itemData.a.v) * dist + pt1[0];
						var y = Math.sin(ang + itemData.a.v) * dist + pt1[1];
						gfill.setAttribute("fx", x);
						gfill.setAttribute("fy", y);
						if (hasOpacity && !itemData.g._collapsable) {
							itemData.of.setAttribute("fx", x);
							itemData.of.setAttribute("fy", y);
						}
					}
				}
			}
			function renderStroke(styleData, itemData, isFirstFrame) {
				var styleElem = itemData.style;
				var d = itemData.d;
				if (d && (d._mdf || isFirstFrame) && d.dashStr) {
					styleElem.pElem.setAttribute("stroke-dasharray", d.dashStr);
					styleElem.pElem.setAttribute("stroke-dashoffset", d.dashoffset[0]);
				}
				if (itemData.c && (itemData.c._mdf || isFirstFrame)) styleElem.pElem.setAttribute("stroke", "rgb(" + bmFloor(itemData.c.v[0]) + "," + bmFloor(itemData.c.v[1]) + "," + bmFloor(itemData.c.v[2]) + ")");
				if (itemData.o._mdf || isFirstFrame) styleElem.pElem.setAttribute("stroke-opacity", itemData.o.v);
				if (itemData.w._mdf || isFirstFrame) {
					styleElem.pElem.setAttribute("stroke-width", itemData.w.v);
					if (styleElem.msElem) styleElem.msElem.setAttribute("stroke-width", itemData.w.v);
				}
			}
			return ob;
		}();
		function SVGShapeElement(data, globalData, comp) {
			this.shapes = [];
			this.shapesData = data.shapes;
			this.stylesList = [];
			this.shapeModifiers = [];
			this.itemsData = [];
			this.processedElements = [];
			this.animatedContents = [];
			this.initElement(data, globalData, comp);
			this.prevViewData = [];
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			SVGBaseElement,
			IShapeElement,
			HierarchyElement,
			FrameElement,
			RenderableDOMElement
		], SVGShapeElement);
		SVGShapeElement.prototype.initSecondaryElement = function() {};
		SVGShapeElement.prototype.identityMatrix = new Matrix();
		SVGShapeElement.prototype.buildExpressionInterface = function() {};
		SVGShapeElement.prototype.createContent = function() {
			this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], true);
			this.filterUniqueShapes();
		};
		SVGShapeElement.prototype.filterUniqueShapes = function() {
			var i;
			var len = this.shapes.length;
			var shape;
			var j;
			var jLen = this.stylesList.length;
			var style;
			var tempShapes = [];
			var areAnimated = false;
			for (j = 0; j < jLen; j += 1) {
				style = this.stylesList[j];
				areAnimated = false;
				tempShapes.length = 0;
				for (i = 0; i < len; i += 1) {
					shape = this.shapes[i];
					if (shape.styles.indexOf(style) !== -1) {
						tempShapes.push(shape);
						areAnimated = shape._isAnimated || areAnimated;
					}
				}
				if (tempShapes.length > 1 && areAnimated) this.setShapesAsAnimated(tempShapes);
			}
		};
		SVGShapeElement.prototype.setShapesAsAnimated = function(shapes) {
			var i;
			var len = shapes.length;
			for (i = 0; i < len; i += 1) shapes[i].setAsAnimated();
		};
		SVGShapeElement.prototype.createStyleElement = function(data, level) {
			var elementData;
			var styleOb = new SVGStyleData(data, level);
			var pathElement = styleOb.pElem;
			if (data.ty === "st") elementData = new SVGStrokeStyleData(this, data, styleOb);
			else if (data.ty === "fl") elementData = new SVGFillStyleData(this, data, styleOb);
			else if (data.ty === "gf" || data.ty === "gs") {
				elementData = new (data.ty === "gf" ? SVGGradientFillStyleData : SVGGradientStrokeStyleData)(this, data, styleOb);
				this.globalData.defs.appendChild(elementData.gf);
				if (elementData.maskId) {
					this.globalData.defs.appendChild(elementData.ms);
					this.globalData.defs.appendChild(elementData.of);
					pathElement.setAttribute("mask", "url(" + getLocationHref() + "#" + elementData.maskId + ")");
				}
			} else if (data.ty === "no") elementData = new SVGNoStyleData(this, data, styleOb);
			if (data.ty === "st" || data.ty === "gs") {
				pathElement.setAttribute("stroke-linecap", lineCapEnum[data.lc || 2]);
				pathElement.setAttribute("stroke-linejoin", lineJoinEnum[data.lj || 2]);
				pathElement.setAttribute("fill-opacity", "0");
				if (data.lj === 1) pathElement.setAttribute("stroke-miterlimit", data.ml);
			}
			if (data.r === 2) pathElement.setAttribute("fill-rule", "evenodd");
			if (data.ln) pathElement.setAttribute("id", data.ln);
			if (data.cl) pathElement.setAttribute("class", data.cl);
			if (data.bm) pathElement.style["mix-blend-mode"] = getBlendMode(data.bm);
			this.stylesList.push(styleOb);
			this.addToAnimatedContents(data, elementData);
			return elementData;
		};
		SVGShapeElement.prototype.createGroupElement = function(data) {
			var elementData = new ShapeGroupData();
			if (data.ln) elementData.gr.setAttribute("id", data.ln);
			if (data.cl) elementData.gr.setAttribute("class", data.cl);
			if (data.bm) elementData.gr.style["mix-blend-mode"] = getBlendMode(data.bm);
			return elementData;
		};
		SVGShapeElement.prototype.createTransformElement = function(data, container) {
			var transformProperty = TransformPropertyFactory.getTransformProperty(this, data, this);
			var elementData = new SVGTransformData(transformProperty, transformProperty.o, container);
			this.addToAnimatedContents(data, elementData);
			return elementData;
		};
		SVGShapeElement.prototype.createShapeElement = function(data, ownTransformers, level) {
			var ty = 4;
			if (data.ty === "rc") ty = 5;
			else if (data.ty === "el") ty = 6;
			else if (data.ty === "sr") ty = 7;
			var elementData = new SVGShapeData(ownTransformers, level, ShapePropertyFactory.getShapeProp(this, data, ty, this));
			this.shapes.push(elementData);
			this.addShapeToModifiers(elementData);
			this.addToAnimatedContents(data, elementData);
			return elementData;
		};
		SVGShapeElement.prototype.addToAnimatedContents = function(data, element) {
			var i = 0;
			var len = this.animatedContents.length;
			while (i < len) {
				if (this.animatedContents[i].element === element) return;
				i += 1;
			}
			this.animatedContents.push({
				fn: SVGElementsRenderer.createRenderFunction(data),
				element,
				data
			});
		};
		SVGShapeElement.prototype.setElementStyles = function(elementData) {
			var arr = elementData.styles;
			var j;
			var jLen = this.stylesList.length;
			for (j = 0; j < jLen; j += 1) if (arr.indexOf(this.stylesList[j]) === -1 && !this.stylesList[j].closed) arr.push(this.stylesList[j]);
		};
		SVGShapeElement.prototype.reloadShapes = function() {
			this._isFirstFrame = true;
			var i;
			var len = this.itemsData.length;
			for (i = 0; i < len; i += 1) this.prevViewData[i] = this.itemsData[i];
			this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], true);
			this.filterUniqueShapes();
			len = this.dynamicProperties.length;
			for (i = 0; i < len; i += 1) this.dynamicProperties[i].getValue();
			this.renderModifiers();
		};
		SVGShapeElement.prototype.searchShapes = function(arr, itemsData, prevViewData, container, level, transformers, render) {
			var ownTransformers = [].concat(transformers);
			var i;
			var len = arr.length - 1;
			var j;
			var jLen;
			var ownStyles = [];
			var ownModifiers = [];
			var currentTransform;
			var modifier;
			var processedPos;
			for (i = len; i >= 0; i -= 1) {
				processedPos = this.searchProcessedElement(arr[i]);
				if (!processedPos) arr[i]._render = render;
				else itemsData[i] = prevViewData[processedPos - 1];
				if (arr[i].ty === "fl" || arr[i].ty === "st" || arr[i].ty === "gf" || arr[i].ty === "gs" || arr[i].ty === "no") {
					if (!processedPos) itemsData[i] = this.createStyleElement(arr[i], level);
					else itemsData[i].style.closed = arr[i].hd;
					if (arr[i]._render) {
						if (itemsData[i].style.pElem.parentNode !== container) container.appendChild(itemsData[i].style.pElem);
					}
					ownStyles.push(itemsData[i].style);
				} else if (arr[i].ty === "gr") {
					if (!processedPos) itemsData[i] = this.createGroupElement(arr[i]);
					else {
						jLen = itemsData[i].it.length;
						for (j = 0; j < jLen; j += 1) itemsData[i].prevViewData[j] = itemsData[i].it[j];
					}
					this.searchShapes(arr[i].it, itemsData[i].it, itemsData[i].prevViewData, itemsData[i].gr, level + 1, ownTransformers, render);
					if (arr[i]._render) {
						if (itemsData[i].gr.parentNode !== container) container.appendChild(itemsData[i].gr);
					}
				} else if (arr[i].ty === "tr") {
					if (!processedPos) itemsData[i] = this.createTransformElement(arr[i], container);
					currentTransform = itemsData[i].transform;
					ownTransformers.push(currentTransform);
				} else if (arr[i].ty === "sh" || arr[i].ty === "rc" || arr[i].ty === "el" || arr[i].ty === "sr") {
					if (!processedPos) itemsData[i] = this.createShapeElement(arr[i], ownTransformers, level);
					this.setElementStyles(itemsData[i]);
				} else if (arr[i].ty === "tm" || arr[i].ty === "rd" || arr[i].ty === "ms" || arr[i].ty === "pb" || arr[i].ty === "zz" || arr[i].ty === "op") {
					if (!processedPos) {
						modifier = ShapeModifiers.getModifier(arr[i].ty);
						modifier.init(this, arr[i]);
						itemsData[i] = modifier;
						this.shapeModifiers.push(modifier);
					} else {
						modifier = itemsData[i];
						modifier.closed = false;
					}
					ownModifiers.push(modifier);
				} else if (arr[i].ty === "rp") {
					if (!processedPos) {
						modifier = ShapeModifiers.getModifier(arr[i].ty);
						itemsData[i] = modifier;
						modifier.init(this, arr, i, itemsData);
						this.shapeModifiers.push(modifier);
						render = false;
					} else {
						modifier = itemsData[i];
						modifier.closed = true;
					}
					ownModifiers.push(modifier);
				}
				this.addProcessedElement(arr[i], i + 1);
			}
			len = ownStyles.length;
			for (i = 0; i < len; i += 1) ownStyles[i].closed = true;
			len = ownModifiers.length;
			for (i = 0; i < len; i += 1) ownModifiers[i].closed = true;
		};
		SVGShapeElement.prototype.renderInnerContent = function() {
			this.renderModifiers();
			var i;
			var len = this.stylesList.length;
			for (i = 0; i < len; i += 1) this.stylesList[i].reset();
			this.renderShape();
			for (i = 0; i < len; i += 1) if (this.stylesList[i]._mdf || this._isFirstFrame) {
				if (this.stylesList[i].msElem) {
					this.stylesList[i].msElem.setAttribute("d", this.stylesList[i].d);
					this.stylesList[i].d = "M0 0" + this.stylesList[i].d;
				}
				this.stylesList[i].pElem.setAttribute("d", this.stylesList[i].d || "M0 0");
			}
		};
		SVGShapeElement.prototype.renderShape = function() {
			var i;
			var len = this.animatedContents.length;
			var animatedContent;
			for (i = 0; i < len; i += 1) {
				animatedContent = this.animatedContents[i];
				if ((this._isFirstFrame || animatedContent.element._isAnimated) && animatedContent.data !== true) animatedContent.fn(animatedContent.data, animatedContent.element, this._isFirstFrame);
			}
		};
		SVGShapeElement.prototype.destroy = function() {
			this.destroyBaseElement();
			this.shapesData = null;
			this.itemsData = null;
		};
		function LetterProps(o, sw, sc, fc, m, p) {
			this.o = o;
			this.sw = sw;
			this.sc = sc;
			this.fc = fc;
			this.m = m;
			this.p = p;
			this._mdf = {
				o: true,
				sw: !!sw,
				sc: !!sc,
				fc: !!fc,
				m: true,
				p: true
			};
		}
		LetterProps.prototype.update = function(o, sw, sc, fc, m, p) {
			this._mdf.o = false;
			this._mdf.sw = false;
			this._mdf.sc = false;
			this._mdf.fc = false;
			this._mdf.m = false;
			this._mdf.p = false;
			var updated = false;
			if (this.o !== o) {
				this.o = o;
				this._mdf.o = true;
				updated = true;
			}
			if (this.sw !== sw) {
				this.sw = sw;
				this._mdf.sw = true;
				updated = true;
			}
			if (this.sc !== sc) {
				this.sc = sc;
				this._mdf.sc = true;
				updated = true;
			}
			if (this.fc !== fc) {
				this.fc = fc;
				this._mdf.fc = true;
				updated = true;
			}
			if (this.m !== m) {
				this.m = m;
				this._mdf.m = true;
				updated = true;
			}
			if (p.length && (this.p[0] !== p[0] || this.p[1] !== p[1] || this.p[4] !== p[4] || this.p[5] !== p[5] || this.p[12] !== p[12] || this.p[13] !== p[13])) {
				this.p = p;
				this._mdf.p = true;
				updated = true;
			}
			return updated;
		};
		function TextProperty(elem, data) {
			this._frameId = initialDefaultFrame;
			this.pv = "";
			this.v = "";
			this.kf = false;
			this._isFirstFrame = true;
			this._mdf = false;
			if (data.d && data.d.sid) data.d = elem.globalData.slotManager.getProp(data.d);
			this.data = data;
			this.elem = elem;
			this.comp = this.elem.comp;
			this.keysIndex = 0;
			this.canResize = false;
			this.minimumFontSize = 1;
			this.effectsSequence = [];
			this.currentData = {
				ascent: 0,
				boxWidth: this.defaultBoxWidth,
				f: "",
				fStyle: "",
				fWeight: "",
				fc: "",
				j: "",
				justifyOffset: "",
				l: [],
				lh: 0,
				lineWidths: [],
				ls: "",
				of: "",
				s: "",
				sc: "",
				sw: 0,
				t: 0,
				tr: 0,
				sz: 0,
				ps: null,
				fillColorAnim: false,
				strokeColorAnim: false,
				strokeWidthAnim: false,
				yOffset: 0,
				finalSize: 0,
				finalText: [],
				finalLineHeight: 0,
				__complete: false
			};
			this.copyData(this.currentData, this.data.d.k[0].s);
			if (!this.searchProperty()) this.completeTextData(this.currentData);
		}
		TextProperty.prototype.defaultBoxWidth = [0, 0];
		TextProperty.prototype.copyData = function(obj, data) {
			for (var s in data) if (Object.prototype.hasOwnProperty.call(data, s)) obj[s] = data[s];
			return obj;
		};
		TextProperty.prototype.setCurrentData = function(data) {
			if (!data.__complete) this.completeTextData(data);
			this.currentData = data;
			this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth;
			this._mdf = true;
		};
		TextProperty.prototype.searchProperty = function() {
			return this.searchKeyframes();
		};
		TextProperty.prototype.searchKeyframes = function() {
			this.kf = this.data.d.k.length > 1;
			if (this.kf) this.addEffect(this.getKeyframeValue.bind(this));
			return this.kf;
		};
		TextProperty.prototype.addEffect = function(effectFunction) {
			this.effectsSequence.push(effectFunction);
			this.elem.addDynamicProperty(this);
		};
		TextProperty.prototype.getValue = function(_finalValue) {
			if ((this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length) && !_finalValue) return;
			this.currentData.t = this.data.d.k[this.keysIndex].s.t;
			var currentValue = this.currentData;
			var currentIndex = this.keysIndex;
			if (this.lock) {
				this.setCurrentData(this.currentData);
				return;
			}
			this.lock = true;
			this._mdf = false;
			var i;
			var len = this.effectsSequence.length;
			var finalValue = _finalValue || this.data.d.k[this.keysIndex].s;
			for (i = 0; i < len; i += 1) if (currentIndex !== this.keysIndex) finalValue = this.effectsSequence[i](finalValue, finalValue.t);
			else finalValue = this.effectsSequence[i](this.currentData, finalValue.t);
			if (currentValue !== finalValue) this.setCurrentData(finalValue);
			this.v = this.currentData;
			this.pv = this.v;
			this.lock = false;
			this.frameId = this.elem.globalData.frameId;
		};
		TextProperty.prototype.getKeyframeValue = function() {
			var textKeys = this.data.d.k;
			var frameNum = this.elem.comp.renderedFrame;
			var i = 0;
			var len = textKeys.length;
			while (i <= len - 1) {
				if (i === len - 1 || textKeys[i + 1].t > frameNum) break;
				i += 1;
			}
			if (this.keysIndex !== i) this.keysIndex = i;
			return this.data.d.k[this.keysIndex].s;
		};
		TextProperty.prototype.buildFinalText = function(text) {
			var charactersArray = [];
			var i = 0;
			var len = text.length;
			var charCode;
			var secondCharCode;
			var shouldCombine = false;
			var shouldCombineNext = false;
			var currentChars = "";
			while (i < len) {
				shouldCombine = shouldCombineNext;
				shouldCombineNext = false;
				charCode = text.charCodeAt(i);
				currentChars = text.charAt(i);
				if (FontManager.isCombinedCharacter(charCode)) shouldCombine = true;
				else if (charCode >= 55296 && charCode <= 56319) {
					if (FontManager.isRegionalFlag(text, i)) currentChars = text.substr(i, 14);
					else {
						secondCharCode = text.charCodeAt(i + 1);
						if (secondCharCode >= 56320 && secondCharCode <= 57343) {
							if (FontManager.isModifier(charCode, secondCharCode)) {
								currentChars = text.substr(i, 2);
								shouldCombine = true;
							} else if (FontManager.isFlagEmoji(text.substr(i, 4))) currentChars = text.substr(i, 4);
							else currentChars = text.substr(i, 2);
						}
					}
				} else if (charCode > 56319) {
					secondCharCode = text.charCodeAt(i + 1);
					if (FontManager.isVariationSelector(charCode)) shouldCombine = true;
				} else if (FontManager.isZeroWidthJoiner(charCode)) {
					shouldCombine = true;
					shouldCombineNext = true;
				}
				if (shouldCombine) {
					charactersArray[charactersArray.length - 1] += currentChars;
					shouldCombine = false;
				} else charactersArray.push(currentChars);
				i += currentChars.length;
			}
			return charactersArray;
		};
		TextProperty.prototype.completeTextData = function(documentData) {
			documentData.__complete = true;
			var fontManager = this.elem.globalData.fontManager;
			var data = this.data;
			var letters = [];
			var i;
			var len;
			var newLineFlag;
			var index = 0;
			var val;
			var anchorGrouping = data.m.g;
			var currentSize = 0;
			var currentPos = 0;
			var currentLine = 0;
			var lineWidths = [];
			var lineWidth = 0;
			var maxLineWidth = 0;
			var j;
			var jLen;
			var fontData = fontManager.getFontByName(documentData.f);
			var charData;
			var cLength = 0;
			var fontProps = getFontProperties(fontData);
			documentData.fWeight = fontProps.weight;
			documentData.fStyle = fontProps.style;
			documentData.finalSize = documentData.s;
			documentData.finalText = this.buildFinalText(documentData.t);
			len = documentData.finalText.length;
			documentData.finalLineHeight = documentData.lh;
			var trackingOffset = documentData.tr / 1e3 * documentData.finalSize;
			var charCode;
			if (documentData.sz) {
				var flag = true;
				var boxWidth = documentData.sz[0];
				var boxHeight = documentData.sz[1];
				var currentHeight;
				var finalText;
				while (flag) {
					finalText = this.buildFinalText(documentData.t);
					currentHeight = 0;
					lineWidth = 0;
					len = finalText.length;
					trackingOffset = documentData.tr / 1e3 * documentData.finalSize;
					var lastSpaceIndex = -1;
					for (i = 0; i < len; i += 1) {
						charCode = finalText[i].charCodeAt(0);
						newLineFlag = false;
						if (finalText[i] === " ") lastSpaceIndex = i;
						else if (charCode === 13 || charCode === 3) {
							lineWidth = 0;
							newLineFlag = true;
							currentHeight += documentData.finalLineHeight || documentData.finalSize * 1.2;
						}
						if (fontManager.chars) {
							charData = fontManager.getCharData(finalText[i], fontData.fStyle, fontData.fFamily);
							cLength = newLineFlag ? 0 : charData.w * documentData.finalSize / 100;
						} else cLength = fontManager.measureText(finalText[i], documentData.f, documentData.finalSize);
						if (lineWidth + cLength > boxWidth && finalText[i] !== " ") {
							if (lastSpaceIndex === -1) len += 1;
							else i = lastSpaceIndex;
							currentHeight += documentData.finalLineHeight || documentData.finalSize * 1.2;
							finalText.splice(i, lastSpaceIndex === i ? 1 : 0, "\r");
							lastSpaceIndex = -1;
							lineWidth = 0;
						} else {
							lineWidth += cLength;
							lineWidth += trackingOffset;
						}
					}
					currentHeight += fontData.ascent * documentData.finalSize / 100;
					if (this.canResize && documentData.finalSize > this.minimumFontSize && boxHeight < currentHeight) {
						documentData.finalSize -= 1;
						documentData.finalLineHeight = documentData.finalSize * documentData.lh / documentData.s;
					} else {
						documentData.finalText = finalText;
						len = documentData.finalText.length;
						flag = false;
					}
				}
			}
			lineWidth = -trackingOffset;
			cLength = 0;
			var uncollapsedSpaces = 0;
			var currentChar;
			for (i = 0; i < len; i += 1) {
				newLineFlag = false;
				currentChar = documentData.finalText[i];
				charCode = currentChar.charCodeAt(0);
				if (charCode === 13 || charCode === 3) {
					uncollapsedSpaces = 0;
					lineWidths.push(lineWidth);
					maxLineWidth = lineWidth > maxLineWidth ? lineWidth : maxLineWidth;
					lineWidth = -2 * trackingOffset;
					val = "";
					newLineFlag = true;
					currentLine += 1;
				} else val = currentChar;
				if (fontManager.chars) {
					charData = fontManager.getCharData(currentChar, fontData.fStyle, fontManager.getFontByName(documentData.f).fFamily);
					cLength = newLineFlag ? 0 : charData.w * documentData.finalSize / 100;
				} else cLength = fontManager.measureText(val, documentData.f, documentData.finalSize);
				if (currentChar === " ") uncollapsedSpaces += cLength + trackingOffset;
				else {
					lineWidth += cLength + trackingOffset + uncollapsedSpaces;
					uncollapsedSpaces = 0;
				}
				letters.push({
					l: cLength,
					an: cLength,
					add: currentSize,
					n: newLineFlag,
					anIndexes: [],
					val,
					line: currentLine,
					animatorJustifyOffset: 0
				});
				if (anchorGrouping == 2) {
					currentSize += cLength;
					if (val === "" || val === " " || i === len - 1) {
						if (val === "" || val === " ") currentSize -= cLength;
						while (currentPos <= i) {
							letters[currentPos].an = currentSize;
							letters[currentPos].ind = index;
							letters[currentPos].extra = cLength;
							currentPos += 1;
						}
						index += 1;
						currentSize = 0;
					}
				} else if (anchorGrouping == 3) {
					currentSize += cLength;
					if (val === "" || i === len - 1) {
						if (val === "") currentSize -= cLength;
						while (currentPos <= i) {
							letters[currentPos].an = currentSize;
							letters[currentPos].ind = index;
							letters[currentPos].extra = cLength;
							currentPos += 1;
						}
						currentSize = 0;
						index += 1;
					}
				} else {
					letters[index].ind = index;
					letters[index].extra = 0;
					index += 1;
				}
			}
			documentData.l = letters;
			maxLineWidth = lineWidth > maxLineWidth ? lineWidth : maxLineWidth;
			lineWidths.push(lineWidth);
			if (documentData.sz) {
				documentData.boxWidth = documentData.sz[0];
				documentData.justifyOffset = 0;
			} else {
				documentData.boxWidth = maxLineWidth;
				switch (documentData.j) {
					case 1:
						documentData.justifyOffset = -documentData.boxWidth;
						break;
					case 2:
						documentData.justifyOffset = -documentData.boxWidth / 2;
						break;
					default: documentData.justifyOffset = 0;
				}
			}
			documentData.lineWidths = lineWidths;
			var animators = data.a;
			var animatorData;
			var letterData;
			jLen = animators.length;
			var based;
			var ind;
			var indexes = [];
			for (j = 0; j < jLen; j += 1) {
				animatorData = animators[j];
				if (animatorData.a.sc) documentData.strokeColorAnim = true;
				if (animatorData.a.sw) documentData.strokeWidthAnim = true;
				if (animatorData.a.fc || animatorData.a.fh || animatorData.a.fs || animatorData.a.fb) documentData.fillColorAnim = true;
				ind = 0;
				based = animatorData.s.b;
				for (i = 0; i < len; i += 1) {
					letterData = letters[i];
					letterData.anIndexes[j] = ind;
					if (based == 1 && letterData.val !== "" || based == 2 && letterData.val !== "" && letterData.val !== " " || based == 3 && (letterData.n || letterData.val == " " || i == len - 1) || based == 4 && (letterData.n || i == len - 1)) {
						if (animatorData.s.rn === 1) indexes.push(ind);
						ind += 1;
					}
				}
				data.a[j].s.totalChars = ind;
				var currentInd = -1;
				var newInd;
				if (animatorData.s.rn === 1) for (i = 0; i < len; i += 1) {
					letterData = letters[i];
					if (currentInd != letterData.anIndexes[j]) {
						currentInd = letterData.anIndexes[j];
						newInd = indexes.splice(Math.floor(Math.random() * indexes.length), 1)[0];
					}
					letterData.anIndexes[j] = newInd;
				}
			}
			documentData.yOffset = documentData.finalLineHeight || documentData.finalSize * 1.2;
			documentData.ls = documentData.ls || 0;
			documentData.ascent = fontData.ascent * documentData.finalSize / 100;
		};
		TextProperty.prototype.updateDocumentData = function(newData, index) {
			index = index === void 0 ? this.keysIndex : index;
			var dData = this.copyData({}, this.data.d.k[index].s);
			dData = this.copyData(dData, newData);
			this.data.d.k[index].s = dData;
			this.recalculate(index);
			this.setCurrentData(dData);
			this.elem.addDynamicProperty(this);
		};
		TextProperty.prototype.recalculate = function(index) {
			var dData = this.data.d.k[index].s;
			dData.__complete = false;
			this.keysIndex = 0;
			this._isFirstFrame = true;
			this.getValue(dData);
		};
		TextProperty.prototype.canResizeFont = function(_canResize) {
			this.canResize = _canResize;
			this.recalculate(this.keysIndex);
			this.elem.addDynamicProperty(this);
		};
		TextProperty.prototype.setMinimumFontSize = function(_fontValue) {
			this.minimumFontSize = Math.floor(_fontValue) || 1;
			this.recalculate(this.keysIndex);
			this.elem.addDynamicProperty(this);
		};
		var TextSelectorProp = function() {
			var max = Math.max;
			var min = Math.min;
			var floor = Math.floor;
			function TextSelectorPropFactory(elem, data) {
				this._currentTextLength = -1;
				this.k = false;
				this.data = data;
				this.elem = elem;
				this.comp = elem.comp;
				this.finalS = 0;
				this.finalE = 0;
				this.initDynamicPropertyContainer(elem);
				this.s = PropertyFactory.getProp(elem, data.s || { k: 0 }, 0, 0, this);
				if ("e" in data) this.e = PropertyFactory.getProp(elem, data.e, 0, 0, this);
				else this.e = { v: 100 };
				this.o = PropertyFactory.getProp(elem, data.o || { k: 0 }, 0, 0, this);
				this.xe = PropertyFactory.getProp(elem, data.xe || { k: 0 }, 0, 0, this);
				this.ne = PropertyFactory.getProp(elem, data.ne || { k: 0 }, 0, 0, this);
				this.sm = PropertyFactory.getProp(elem, data.sm || { k: 100 }, 0, 0, this);
				this.a = PropertyFactory.getProp(elem, data.a, 0, .01, this);
				if (!this.dynamicProperties.length) this.getValue();
			}
			TextSelectorPropFactory.prototype = {
				getMult: function getMult(ind) {
					if (this._currentTextLength !== this.elem.textProperty.currentData.l.length) this.getValue();
					var x1 = 0;
					var y1 = 0;
					var x2 = 1;
					var y2 = 1;
					if (this.ne.v > 0) x1 = this.ne.v / 100;
					else y1 = -this.ne.v / 100;
					if (this.xe.v > 0) x2 = 1 - this.xe.v / 100;
					else y2 = 1 + this.xe.v / 100;
					var easer = BezierFactory.getBezierEasing(x1, y1, x2, y2).get;
					var mult = 0;
					var s = this.finalS;
					var e = this.finalE;
					var type = this.data.sh;
					if (type === 2) {
						if (e === s) mult = ind >= e ? 1 : 0;
						else mult = max(0, min(.5 / (e - s) + (ind - s) / (e - s), 1));
						mult = easer(mult);
					} else if (type === 3) {
						if (e === s) mult = ind >= e ? 0 : 1;
						else mult = 1 - max(0, min(.5 / (e - s) + (ind - s) / (e - s), 1));
						mult = easer(mult);
					} else if (type === 4) {
						if (e === s) mult = 0;
						else {
							mult = max(0, min(.5 / (e - s) + (ind - s) / (e - s), 1));
							if (mult < .5) mult *= 2;
							else mult = 1 - 2 * (mult - .5);
						}
						mult = easer(mult);
					} else if (type === 5) {
						if (e === s) mult = 0;
						else {
							var tot = e - s;
							ind = min(max(0, ind + .5 - s), e - s);
							var x = -tot / 2 + ind;
							var a = tot / 2;
							mult = Math.sqrt(1 - x * x / (a * a));
						}
						mult = easer(mult);
					} else if (type === 6) {
						if (e === s) mult = 0;
						else {
							ind = min(max(0, ind + .5 - s), e - s);
							mult = (1 + Math.cos(Math.PI + Math.PI * 2 * ind / (e - s))) / 2;
						}
						mult = easer(mult);
					} else {
						if (ind >= floor(s)) {
							if (ind - s < 0) mult = max(0, min(min(e, 1) - (s - ind), 1));
							else mult = max(0, min(e - ind, 1));
						}
						mult = easer(mult);
					}
					if (this.sm.v !== 100) {
						var smoothness = this.sm.v * .01;
						if (smoothness === 0) smoothness = 1e-8;
						var threshold = .5 - smoothness * .5;
						if (mult < threshold) mult = 0;
						else {
							mult = (mult - threshold) / smoothness;
							if (mult > 1) mult = 1;
						}
					}
					return mult * this.a.v;
				},
				getValue: function getValue(newCharsFlag) {
					this.iterateDynamicProperties();
					this._mdf = newCharsFlag || this._mdf;
					this._currentTextLength = this.elem.textProperty.currentData.l.length || 0;
					if (newCharsFlag && this.data.r === 2) this.e.v = this._currentTextLength;
					var divisor = this.data.r === 2 ? 1 : 100 / this.data.totalChars;
					var o = this.o.v / divisor;
					var s = this.s.v / divisor + o;
					var e = this.e.v / divisor + o;
					if (s > e) {
						var _s = s;
						s = e;
						e = _s;
					}
					this.finalS = s;
					this.finalE = e;
				}
			};
			extendPrototype([DynamicPropertyContainer], TextSelectorPropFactory);
			function getTextSelectorProp(elem, data, arr) {
				return new TextSelectorPropFactory(elem, data, arr);
			}
			return { getTextSelectorProp };
		}();
		function TextAnimatorDataProperty(elem, animatorProps, container) {
			var defaultData = { propType: false };
			var getProp = PropertyFactory.getProp;
			var textAnimatorAnimatables = animatorProps.a;
			this.a = {
				r: textAnimatorAnimatables.r ? getProp(elem, textAnimatorAnimatables.r, 0, degToRads, container) : defaultData,
				rx: textAnimatorAnimatables.rx ? getProp(elem, textAnimatorAnimatables.rx, 0, degToRads, container) : defaultData,
				ry: textAnimatorAnimatables.ry ? getProp(elem, textAnimatorAnimatables.ry, 0, degToRads, container) : defaultData,
				sk: textAnimatorAnimatables.sk ? getProp(elem, textAnimatorAnimatables.sk, 0, degToRads, container) : defaultData,
				sa: textAnimatorAnimatables.sa ? getProp(elem, textAnimatorAnimatables.sa, 0, degToRads, container) : defaultData,
				s: textAnimatorAnimatables.s ? getProp(elem, textAnimatorAnimatables.s, 1, .01, container) : defaultData,
				a: textAnimatorAnimatables.a ? getProp(elem, textAnimatorAnimatables.a, 1, 0, container) : defaultData,
				o: textAnimatorAnimatables.o ? getProp(elem, textAnimatorAnimatables.o, 0, .01, container) : defaultData,
				p: textAnimatorAnimatables.p ? getProp(elem, textAnimatorAnimatables.p, 1, 0, container) : defaultData,
				sw: textAnimatorAnimatables.sw ? getProp(elem, textAnimatorAnimatables.sw, 0, 0, container) : defaultData,
				sc: textAnimatorAnimatables.sc ? getProp(elem, textAnimatorAnimatables.sc, 1, 0, container) : defaultData,
				fc: textAnimatorAnimatables.fc ? getProp(elem, textAnimatorAnimatables.fc, 1, 0, container) : defaultData,
				fh: textAnimatorAnimatables.fh ? getProp(elem, textAnimatorAnimatables.fh, 0, 0, container) : defaultData,
				fs: textAnimatorAnimatables.fs ? getProp(elem, textAnimatorAnimatables.fs, 0, .01, container) : defaultData,
				fb: textAnimatorAnimatables.fb ? getProp(elem, textAnimatorAnimatables.fb, 0, .01, container) : defaultData,
				t: textAnimatorAnimatables.t ? getProp(elem, textAnimatorAnimatables.t, 0, 0, container) : defaultData
			};
			this.s = TextSelectorProp.getTextSelectorProp(elem, animatorProps.s, container);
			this.s.t = animatorProps.s.t;
		}
		function TextAnimatorProperty(textData, renderType, elem) {
			this._isFirstFrame = true;
			this._hasMaskedPath = false;
			this._frameId = -1;
			this._textData = textData;
			this._renderType = renderType;
			this._elem = elem;
			this._animatorsData = createSizedArray(this._textData.a.length);
			this._pathData = {};
			this._moreOptions = { alignment: {} };
			this.renderedLetters = [];
			this.lettersChangedFlag = false;
			this.initDynamicPropertyContainer(elem);
		}
		TextAnimatorProperty.prototype.searchProperties = function() {
			var i;
			var len = this._textData.a.length;
			var animatorProps;
			var getProp = PropertyFactory.getProp;
			for (i = 0; i < len; i += 1) {
				animatorProps = this._textData.a[i];
				this._animatorsData[i] = new TextAnimatorDataProperty(this._elem, animatorProps, this);
			}
			if (this._textData.p && "m" in this._textData.p) {
				this._pathData = {
					a: getProp(this._elem, this._textData.p.a, 0, 0, this),
					f: getProp(this._elem, this._textData.p.f, 0, 0, this),
					l: getProp(this._elem, this._textData.p.l, 0, 0, this),
					r: getProp(this._elem, this._textData.p.r, 0, 0, this),
					p: getProp(this._elem, this._textData.p.p, 0, 0, this),
					m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
				};
				this._hasMaskedPath = true;
			} else this._hasMaskedPath = false;
			this._moreOptions.alignment = getProp(this._elem, this._textData.m.a, 1, 0, this);
		};
		TextAnimatorProperty.prototype.getMeasures = function(documentData, lettersChangedFlag) {
			this.lettersChangedFlag = lettersChangedFlag;
			if (!this._mdf && !this._isFirstFrame && !lettersChangedFlag && (!this._hasMaskedPath || !this._pathData.m._mdf)) return;
			this._isFirstFrame = false;
			var alignment = this._moreOptions.alignment.v;
			var animators = this._animatorsData;
			var textData = this._textData;
			var matrixHelper = this.mHelper;
			var renderType = this._renderType;
			var renderedLettersCount = this.renderedLetters.length;
			var xPos;
			var yPos;
			var i;
			var len;
			var letters = documentData.l;
			var pathInfo;
			var currentLength;
			var currentPoint;
			var segmentLength;
			var flag;
			var pointInd;
			var segmentInd;
			var prevPoint;
			var points;
			var segments;
			var partialLength;
			var totalLength;
			var perc;
			var tanAngle;
			var mask;
			if (this._hasMaskedPath) {
				mask = this._pathData.m;
				if (!this._pathData.n || this._pathData._mdf) {
					var paths = mask.v;
					if (this._pathData.r.v) paths = paths.reverse();
					pathInfo = {
						tLength: 0,
						segments: []
					};
					len = paths._length - 1;
					var bezierData;
					totalLength = 0;
					for (i = 0; i < len; i += 1) {
						bezierData = bez.buildBezierData(paths.v[i], paths.v[i + 1], [paths.o[i][0] - paths.v[i][0], paths.o[i][1] - paths.v[i][1]], [paths.i[i + 1][0] - paths.v[i + 1][0], paths.i[i + 1][1] - paths.v[i + 1][1]]);
						pathInfo.tLength += bezierData.segmentLength;
						pathInfo.segments.push(bezierData);
						totalLength += bezierData.segmentLength;
					}
					i = len;
					if (mask.v.c) {
						bezierData = bez.buildBezierData(paths.v[i], paths.v[0], [paths.o[i][0] - paths.v[i][0], paths.o[i][1] - paths.v[i][1]], [paths.i[0][0] - paths.v[0][0], paths.i[0][1] - paths.v[0][1]]);
						pathInfo.tLength += bezierData.segmentLength;
						pathInfo.segments.push(bezierData);
						totalLength += bezierData.segmentLength;
					}
					this._pathData.pi = pathInfo;
				}
				pathInfo = this._pathData.pi;
				currentLength = this._pathData.f.v;
				segmentInd = 0;
				pointInd = 1;
				segmentLength = 0;
				flag = true;
				segments = pathInfo.segments;
				if (currentLength < 0 && mask.v.c) {
					if (pathInfo.tLength < Math.abs(currentLength)) currentLength = -Math.abs(currentLength) % pathInfo.tLength;
					segmentInd = segments.length - 1;
					points = segments[segmentInd].points;
					pointInd = points.length - 1;
					while (currentLength < 0) {
						currentLength += points[pointInd].partialLength;
						pointInd -= 1;
						if (pointInd < 0) {
							segmentInd -= 1;
							points = segments[segmentInd].points;
							pointInd = points.length - 1;
						}
					}
				}
				points = segments[segmentInd].points;
				prevPoint = points[pointInd - 1];
				currentPoint = points[pointInd];
				partialLength = currentPoint.partialLength;
			}
			len = letters.length;
			xPos = 0;
			yPos = 0;
			var yOff = documentData.finalSize * 1.2 * .714;
			var firstLine = true;
			var animatorProps;
			var animatorSelector;
			var j;
			var jLen;
			var letterValue;
			jLen = animators.length;
			var mult;
			var ind = -1;
			var offf;
			var xPathPos;
			var yPathPos;
			var initPathPos = currentLength;
			var initSegmentInd = segmentInd;
			var initPointInd = pointInd;
			var currentLine = -1;
			var elemOpacity;
			var sc;
			var sw;
			var fc;
			var k;
			var letterSw;
			var letterSc;
			var letterFc;
			var letterM = "";
			var letterP = this.defaultPropsArray;
			var letterO;
			if (documentData.j === 2 || documentData.j === 1) {
				var animatorJustifyOffset = 0;
				var animatorFirstCharOffset = 0;
				var justifyOffsetMult = documentData.j === 2 ? -.5 : -1;
				var lastIndex = 0;
				var isNewLine = true;
				for (i = 0; i < len; i += 1) if (letters[i].n) {
					if (animatorJustifyOffset) animatorJustifyOffset += animatorFirstCharOffset;
					while (lastIndex < i) {
						letters[lastIndex].animatorJustifyOffset = animatorJustifyOffset;
						lastIndex += 1;
					}
					animatorJustifyOffset = 0;
					isNewLine = true;
				} else {
					for (j = 0; j < jLen; j += 1) {
						animatorProps = animators[j].a;
						if (animatorProps.t.propType) {
							if (isNewLine && documentData.j === 2) animatorFirstCharOffset += animatorProps.t.v * justifyOffsetMult;
							animatorSelector = animators[j].s;
							mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
							if (mult.length) animatorJustifyOffset += animatorProps.t.v * mult[0] * justifyOffsetMult;
							else animatorJustifyOffset += animatorProps.t.v * mult * justifyOffsetMult;
						}
					}
					isNewLine = false;
				}
				if (animatorJustifyOffset) animatorJustifyOffset += animatorFirstCharOffset;
				while (lastIndex < i) {
					letters[lastIndex].animatorJustifyOffset = animatorJustifyOffset;
					lastIndex += 1;
				}
			}
			for (i = 0; i < len; i += 1) {
				matrixHelper.reset();
				elemOpacity = 1;
				if (letters[i].n) {
					xPos = 0;
					yPos += documentData.yOffset;
					yPos += firstLine ? 1 : 0;
					currentLength = initPathPos;
					firstLine = false;
					if (this._hasMaskedPath) {
						segmentInd = initSegmentInd;
						pointInd = initPointInd;
						points = segments[segmentInd].points;
						prevPoint = points[pointInd - 1];
						currentPoint = points[pointInd];
						partialLength = currentPoint.partialLength;
						segmentLength = 0;
					}
					letterM = "";
					letterFc = "";
					letterSw = "";
					letterO = "";
					letterP = this.defaultPropsArray;
				} else {
					if (this._hasMaskedPath) {
						if (currentLine !== letters[i].line) {
							switch (documentData.j) {
								case 1:
									currentLength += totalLength - documentData.lineWidths[letters[i].line];
									break;
								case 2: currentLength += (totalLength - documentData.lineWidths[letters[i].line]) / 2;
							}
							currentLine = letters[i].line;
						}
						if (ind !== letters[i].ind) {
							if (letters[ind]) currentLength += letters[ind].extra;
							currentLength += letters[i].an / 2;
							ind = letters[i].ind;
						}
						currentLength += alignment[0] * letters[i].an * .005;
						var animatorOffset = 0;
						for (j = 0; j < jLen; j += 1) {
							animatorProps = animators[j].a;
							if (animatorProps.p.propType) {
								animatorSelector = animators[j].s;
								mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
								if (mult.length) animatorOffset += animatorProps.p.v[0] * mult[0];
								else animatorOffset += animatorProps.p.v[0] * mult;
							}
							if (animatorProps.a.propType) {
								animatorSelector = animators[j].s;
								mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
								if (mult.length) animatorOffset += animatorProps.a.v[0] * mult[0];
								else animatorOffset += animatorProps.a.v[0] * mult;
							}
						}
						flag = true;
						if (this._pathData.a.v) {
							currentLength = letters[0].an * .5 + (totalLength - this._pathData.f.v - letters[0].an * .5 - letters[letters.length - 1].an * .5) * ind / (len - 1);
							currentLength += this._pathData.f.v;
						}
						while (flag) if (segmentLength + partialLength >= currentLength + animatorOffset || !points) {
							perc = (currentLength + animatorOffset - segmentLength) / currentPoint.partialLength;
							xPathPos = prevPoint.point[0] + (currentPoint.point[0] - prevPoint.point[0]) * perc;
							yPathPos = prevPoint.point[1] + (currentPoint.point[1] - prevPoint.point[1]) * perc;
							matrixHelper.translate(-alignment[0] * letters[i].an * .005, -(alignment[1] * yOff) * .01);
							flag = false;
						} else if (points) {
							segmentLength += currentPoint.partialLength;
							pointInd += 1;
							if (pointInd >= points.length) {
								pointInd = 0;
								segmentInd += 1;
								if (!segments[segmentInd]) {
									if (mask.v.c) {
										pointInd = 0;
										segmentInd = 0;
										points = segments[segmentInd].points;
									} else {
										segmentLength -= currentPoint.partialLength;
										points = null;
									}
								} else points = segments[segmentInd].points;
							}
							if (points) {
								prevPoint = currentPoint;
								currentPoint = points[pointInd];
								partialLength = currentPoint.partialLength;
							}
						}
						offf = letters[i].an / 2 - letters[i].add;
						matrixHelper.translate(-offf, 0, 0);
					} else {
						offf = letters[i].an / 2 - letters[i].add;
						matrixHelper.translate(-offf, 0, 0);
						matrixHelper.translate(-alignment[0] * letters[i].an * .005, -alignment[1] * yOff * .01, 0);
					}
					for (j = 0; j < jLen; j += 1) {
						animatorProps = animators[j].a;
						if (animatorProps.t.propType) {
							animatorSelector = animators[j].s;
							mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
							if (xPos !== 0 || documentData.j !== 0) {
								if (this._hasMaskedPath) {
									if (mult.length) currentLength += animatorProps.t.v * mult[0];
									else currentLength += animatorProps.t.v * mult;
								} else if (mult.length) xPos += animatorProps.t.v * mult[0];
								else xPos += animatorProps.t.v * mult;
							}
						}
					}
					if (documentData.strokeWidthAnim) sw = documentData.sw || 0;
					if (documentData.strokeColorAnim) {
						if (documentData.sc) sc = [
							documentData.sc[0],
							documentData.sc[1],
							documentData.sc[2]
						];
						else sc = [
							0,
							0,
							0
						];
					}
					if (documentData.fillColorAnim && documentData.fc) fc = [
						documentData.fc[0],
						documentData.fc[1],
						documentData.fc[2]
					];
					for (j = 0; j < jLen; j += 1) {
						animatorProps = animators[j].a;
						if (animatorProps.a.propType) {
							animatorSelector = animators[j].s;
							mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
							if (mult.length) matrixHelper.translate(-animatorProps.a.v[0] * mult[0], -animatorProps.a.v[1] * mult[1], animatorProps.a.v[2] * mult[2]);
							else matrixHelper.translate(-animatorProps.a.v[0] * mult, -animatorProps.a.v[1] * mult, animatorProps.a.v[2] * mult);
						}
					}
					for (j = 0; j < jLen; j += 1) {
						animatorProps = animators[j].a;
						if (animatorProps.s.propType) {
							animatorSelector = animators[j].s;
							mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
							if (mult.length) matrixHelper.scale(1 + (animatorProps.s.v[0] - 1) * mult[0], 1 + (animatorProps.s.v[1] - 1) * mult[1], 1);
							else matrixHelper.scale(1 + (animatorProps.s.v[0] - 1) * mult, 1 + (animatorProps.s.v[1] - 1) * mult, 1);
						}
					}
					for (j = 0; j < jLen; j += 1) {
						animatorProps = animators[j].a;
						animatorSelector = animators[j].s;
						mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
						if (animatorProps.sk.propType) {
							if (mult.length) matrixHelper.skewFromAxis(-animatorProps.sk.v * mult[0], animatorProps.sa.v * mult[1]);
							else matrixHelper.skewFromAxis(-animatorProps.sk.v * mult, animatorProps.sa.v * mult);
						}
						if (animatorProps.r.propType) {
							if (mult.length) matrixHelper.rotateZ(-animatorProps.r.v * mult[2]);
							else matrixHelper.rotateZ(-animatorProps.r.v * mult);
						}
						if (animatorProps.ry.propType) {
							if (mult.length) matrixHelper.rotateY(animatorProps.ry.v * mult[1]);
							else matrixHelper.rotateY(animatorProps.ry.v * mult);
						}
						if (animatorProps.rx.propType) {
							if (mult.length) matrixHelper.rotateX(animatorProps.rx.v * mult[0]);
							else matrixHelper.rotateX(animatorProps.rx.v * mult);
						}
						if (animatorProps.o.propType) {
							if (mult.length) elemOpacity += (animatorProps.o.v * mult[0] - elemOpacity) * mult[0];
							else elemOpacity += (animatorProps.o.v * mult - elemOpacity) * mult;
						}
						if (documentData.strokeWidthAnim && animatorProps.sw.propType) {
							if (mult.length) sw += animatorProps.sw.v * mult[0];
							else sw += animatorProps.sw.v * mult;
						}
						if (documentData.strokeColorAnim && animatorProps.sc.propType) for (k = 0; k < 3; k += 1) if (mult.length) sc[k] += (animatorProps.sc.v[k] - sc[k]) * mult[0];
						else sc[k] += (animatorProps.sc.v[k] - sc[k]) * mult;
						if (documentData.fillColorAnim && documentData.fc) {
							if (animatorProps.fc.propType) for (k = 0; k < 3; k += 1) if (mult.length) fc[k] += (animatorProps.fc.v[k] - fc[k]) * mult[0];
							else fc[k] += (animatorProps.fc.v[k] - fc[k]) * mult;
							if (animatorProps.fh.propType) {
								if (mult.length) fc = addHueToRGB(fc, animatorProps.fh.v * mult[0]);
								else fc = addHueToRGB(fc, animatorProps.fh.v * mult);
							}
							if (animatorProps.fs.propType) {
								if (mult.length) fc = addSaturationToRGB(fc, animatorProps.fs.v * mult[0]);
								else fc = addSaturationToRGB(fc, animatorProps.fs.v * mult);
							}
							if (animatorProps.fb.propType) {
								if (mult.length) fc = addBrightnessToRGB(fc, animatorProps.fb.v * mult[0]);
								else fc = addBrightnessToRGB(fc, animatorProps.fb.v * mult);
							}
						}
					}
					for (j = 0; j < jLen; j += 1) {
						animatorProps = animators[j].a;
						if (animatorProps.p.propType) {
							animatorSelector = animators[j].s;
							mult = animatorSelector.getMult(letters[i].anIndexes[j], textData.a[j].s.totalChars);
							if (this._hasMaskedPath) {
								if (mult.length) matrixHelper.translate(0, animatorProps.p.v[1] * mult[0], -animatorProps.p.v[2] * mult[1]);
								else matrixHelper.translate(0, animatorProps.p.v[1] * mult, -animatorProps.p.v[2] * mult);
							} else if (mult.length) matrixHelper.translate(animatorProps.p.v[0] * mult[0], animatorProps.p.v[1] * mult[1], -animatorProps.p.v[2] * mult[2]);
							else matrixHelper.translate(animatorProps.p.v[0] * mult, animatorProps.p.v[1] * mult, -animatorProps.p.v[2] * mult);
						}
					}
					if (documentData.strokeWidthAnim) letterSw = sw < 0 ? 0 : sw;
					if (documentData.strokeColorAnim) letterSc = "rgb(" + Math.round(sc[0] * 255) + "," + Math.round(sc[1] * 255) + "," + Math.round(sc[2] * 255) + ")";
					if (documentData.fillColorAnim && documentData.fc) letterFc = "rgb(" + Math.round(fc[0] * 255) + "," + Math.round(fc[1] * 255) + "," + Math.round(fc[2] * 255) + ")";
					if (this._hasMaskedPath) {
						matrixHelper.translate(0, -documentData.ls);
						matrixHelper.translate(0, alignment[1] * yOff * .01 + yPos, 0);
						if (this._pathData.p.v) {
							tanAngle = (currentPoint.point[1] - prevPoint.point[1]) / (currentPoint.point[0] - prevPoint.point[0]);
							var rot = Math.atan(tanAngle) * 180 / Math.PI;
							if (currentPoint.point[0] < prevPoint.point[0]) rot += 180;
							matrixHelper.rotate(-rot * Math.PI / 180);
						}
						matrixHelper.translate(xPathPos, yPathPos, 0);
						currentLength -= alignment[0] * letters[i].an * .005;
						if (letters[i + 1] && ind !== letters[i + 1].ind) {
							currentLength += letters[i].an / 2;
							currentLength += documentData.tr * .001 * documentData.finalSize;
						}
					} else {
						matrixHelper.translate(xPos, yPos, 0);
						if (documentData.ps) matrixHelper.translate(documentData.ps[0], documentData.ps[1] + documentData.ascent, 0);
						switch (documentData.j) {
							case 1:
								matrixHelper.translate(letters[i].animatorJustifyOffset + documentData.justifyOffset + (documentData.boxWidth - documentData.lineWidths[letters[i].line]), 0, 0);
								break;
							case 2: matrixHelper.translate(letters[i].animatorJustifyOffset + documentData.justifyOffset + (documentData.boxWidth - documentData.lineWidths[letters[i].line]) / 2, 0, 0);
						}
						matrixHelper.translate(0, -documentData.ls);
						matrixHelper.translate(offf, 0, 0);
						matrixHelper.translate(alignment[0] * letters[i].an * .005, alignment[1] * yOff * .01, 0);
						xPos += letters[i].l + documentData.tr * .001 * documentData.finalSize;
					}
					if (renderType === "html") letterM = matrixHelper.toCSS();
					else if (renderType === "svg") letterM = matrixHelper.to2dCSS();
					else letterP = [
						matrixHelper.props[0],
						matrixHelper.props[1],
						matrixHelper.props[2],
						matrixHelper.props[3],
						matrixHelper.props[4],
						matrixHelper.props[5],
						matrixHelper.props[6],
						matrixHelper.props[7],
						matrixHelper.props[8],
						matrixHelper.props[9],
						matrixHelper.props[10],
						matrixHelper.props[11],
						matrixHelper.props[12],
						matrixHelper.props[13],
						matrixHelper.props[14],
						matrixHelper.props[15]
					];
					letterO = elemOpacity;
				}
				if (renderedLettersCount <= i) {
					letterValue = new LetterProps(letterO, letterSw, letterSc, letterFc, letterM, letterP);
					this.renderedLetters.push(letterValue);
					renderedLettersCount += 1;
					this.lettersChangedFlag = true;
				} else {
					letterValue = this.renderedLetters[i];
					this.lettersChangedFlag = letterValue.update(letterO, letterSw, letterSc, letterFc, letterM, letterP) || this.lettersChangedFlag;
				}
			}
		};
		TextAnimatorProperty.prototype.getValue = function() {
			if (this._elem.globalData.frameId === this._frameId) return;
			this._frameId = this._elem.globalData.frameId;
			this.iterateDynamicProperties();
		};
		TextAnimatorProperty.prototype.mHelper = new Matrix();
		TextAnimatorProperty.prototype.defaultPropsArray = [];
		extendPrototype([DynamicPropertyContainer], TextAnimatorProperty);
		function ITextElement() {}
		ITextElement.prototype.initElement = function(data, globalData, comp) {
			this.lettersChangedFlag = true;
			this.initFrame();
			this.initBaseData(data, globalData, comp);
			this.textProperty = new TextProperty(this, data.t, this.dynamicProperties);
			this.textAnimator = new TextAnimatorProperty(data.t, this.renderType, this);
			this.initTransform(data, globalData, comp);
			this.initHierarchy();
			this.initRenderable();
			this.initRendererElement();
			this.createContainerElements();
			this.createRenderableComponents();
			this.createContent();
			this.hide();
			this.textAnimator.searchProperties(this.dynamicProperties);
		};
		ITextElement.prototype.prepareFrame = function(num) {
			this._mdf = false;
			this.prepareRenderableFrame(num);
			this.prepareProperties(num, this.isInRange);
		};
		ITextElement.prototype.createPathShape = function(matrixHelper, shapes) {
			var j;
			var jLen = shapes.length;
			var pathNodes;
			var shapeStr = "";
			for (j = 0; j < jLen; j += 1) if (shapes[j].ty === "sh") {
				pathNodes = shapes[j].ks.k;
				shapeStr += buildShapeString(pathNodes, pathNodes.i.length, true, matrixHelper);
			}
			return shapeStr;
		};
		ITextElement.prototype.updateDocumentData = function(newData, index) {
			this.textProperty.updateDocumentData(newData, index);
		};
		ITextElement.prototype.canResizeFont = function(_canResize) {
			this.textProperty.canResizeFont(_canResize);
		};
		ITextElement.prototype.setMinimumFontSize = function(_fontSize) {
			this.textProperty.setMinimumFontSize(_fontSize);
		};
		ITextElement.prototype.applyTextPropertiesToMatrix = function(documentData, matrixHelper, lineNumber, xPos, yPos) {
			if (documentData.ps) matrixHelper.translate(documentData.ps[0], documentData.ps[1] + documentData.ascent, 0);
			matrixHelper.translate(0, -documentData.ls, 0);
			switch (documentData.j) {
				case 1:
					matrixHelper.translate(documentData.justifyOffset + (documentData.boxWidth - documentData.lineWidths[lineNumber]), 0, 0);
					break;
				case 2: matrixHelper.translate(documentData.justifyOffset + (documentData.boxWidth - documentData.lineWidths[lineNumber]) / 2, 0, 0);
			}
			matrixHelper.translate(xPos, yPos, 0);
		};
		ITextElement.prototype.buildColor = function(colorData) {
			return "rgb(" + Math.round(colorData[0] * 255) + "," + Math.round(colorData[1] * 255) + "," + Math.round(colorData[2] * 255) + ")";
		};
		ITextElement.prototype.emptyProp = new LetterProps();
		ITextElement.prototype.destroy = function() {};
		ITextElement.prototype.validateText = function() {
			if (this.textProperty._mdf || this.textProperty._isFirstFrame) {
				this.buildNewText();
				this.textProperty._isFirstFrame = false;
				this.textProperty._mdf = false;
			}
		};
		var emptyShapeData = { shapes: [] };
		function SVGTextLottieElement(data, globalData, comp) {
			this.textSpans = [];
			this.renderType = "svg";
			this.initElement(data, globalData, comp);
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			SVGBaseElement,
			HierarchyElement,
			FrameElement,
			RenderableDOMElement,
			ITextElement
		], SVGTextLottieElement);
		SVGTextLottieElement.prototype.createContent = function() {
			if (this.data.singleShape && !this.globalData.fontManager.chars) this.textContainer = createNS("text");
		};
		SVGTextLottieElement.prototype.buildTextContents = function(textArray) {
			var i = 0;
			var len = textArray.length;
			var textContents = [];
			var currentTextContent = "";
			while (i < len) {
				if (textArray[i] === String.fromCharCode(13) || textArray[i] === String.fromCharCode(3)) {
					textContents.push(currentTextContent);
					currentTextContent = "";
				} else currentTextContent += textArray[i];
				i += 1;
			}
			textContents.push(currentTextContent);
			return textContents;
		};
		SVGTextLottieElement.prototype.buildShapeData = function(data, scale) {
			if (data.shapes && data.shapes.length) {
				var shape = data.shapes[0];
				if (shape.it) {
					var shapeItem = shape.it[shape.it.length - 1];
					if (shapeItem.s) {
						shapeItem.s.k[0] = scale;
						shapeItem.s.k[1] = scale;
					}
				}
			}
			return data;
		};
		SVGTextLottieElement.prototype.buildNewText = function() {
			this.addDynamicProperty(this);
			var i;
			var len;
			var documentData = this.textProperty.currentData;
			this.renderedLetters = createSizedArray(documentData ? documentData.l.length : 0);
			if (documentData.fc) this.layerElement.setAttribute("fill", this.buildColor(documentData.fc));
			else this.layerElement.setAttribute("fill", "rgba(0,0,0,0)");
			if (documentData.sc) {
				this.layerElement.setAttribute("stroke", this.buildColor(documentData.sc));
				this.layerElement.setAttribute("stroke-width", documentData.sw);
			}
			this.layerElement.setAttribute("font-size", documentData.finalSize);
			var fontData = this.globalData.fontManager.getFontByName(documentData.f);
			if (fontData.fClass) this.layerElement.setAttribute("class", fontData.fClass);
			else {
				this.layerElement.setAttribute("font-family", fontData.fFamily);
				var fWeight = documentData.fWeight;
				var fStyle = documentData.fStyle;
				this.layerElement.setAttribute("font-style", fStyle);
				this.layerElement.setAttribute("font-weight", fWeight);
			}
			this.layerElement.setAttribute("aria-label", documentData.t);
			var letters = documentData.l || [];
			var usesGlyphs = !!this.globalData.fontManager.chars;
			len = letters.length;
			var tSpan;
			var matrixHelper = this.mHelper;
			var shapeStr = "";
			var singleShape = this.data.singleShape;
			var xPos = 0;
			var yPos = 0;
			var firstLine = true;
			var trackingOffset = documentData.tr * .001 * documentData.finalSize;
			if (singleShape && !usesGlyphs && !documentData.sz) {
				var tElement = this.textContainer;
				var justify = "start";
				switch (documentData.j) {
					case 1:
						justify = "end";
						break;
					case 2:
						justify = "middle";
						break;
					default: justify = "start";
				}
				tElement.setAttribute("text-anchor", justify);
				tElement.setAttribute("letter-spacing", trackingOffset);
				var textContent = this.buildTextContents(documentData.finalText);
				len = textContent.length;
				yPos = documentData.ps ? documentData.ps[1] + documentData.ascent : 0;
				for (i = 0; i < len; i += 1) {
					tSpan = this.textSpans[i].span || createNS("tspan");
					tSpan.textContent = textContent[i];
					tSpan.setAttribute("x", 0);
					tSpan.setAttribute("y", yPos);
					tSpan.style.display = "inherit";
					tElement.appendChild(tSpan);
					if (!this.textSpans[i]) this.textSpans[i] = {
						span: null,
						glyph: null
					};
					this.textSpans[i].span = tSpan;
					yPos += documentData.finalLineHeight;
				}
				this.layerElement.appendChild(tElement);
			} else {
				var cachedSpansLength = this.textSpans.length;
				var charData;
				for (i = 0; i < len; i += 1) {
					if (!this.textSpans[i]) this.textSpans[i] = {
						span: null,
						childSpan: null,
						glyph: null
					};
					if (!usesGlyphs || !singleShape || i === 0) {
						tSpan = cachedSpansLength > i ? this.textSpans[i].span : createNS(usesGlyphs ? "g" : "text");
						if (cachedSpansLength <= i) {
							tSpan.setAttribute("stroke-linecap", "butt");
							tSpan.setAttribute("stroke-linejoin", "round");
							tSpan.setAttribute("stroke-miterlimit", "4");
							this.textSpans[i].span = tSpan;
							if (usesGlyphs) {
								var childSpan = createNS("g");
								tSpan.appendChild(childSpan);
								this.textSpans[i].childSpan = childSpan;
							}
							this.textSpans[i].span = tSpan;
							this.layerElement.appendChild(tSpan);
						}
						tSpan.style.display = "inherit";
					}
					matrixHelper.reset();
					if (singleShape) {
						if (letters[i].n) {
							xPos = -trackingOffset;
							yPos += documentData.yOffset;
							yPos += firstLine ? 1 : 0;
							firstLine = false;
						}
						this.applyTextPropertiesToMatrix(documentData, matrixHelper, letters[i].line, xPos, yPos);
						xPos += letters[i].l || 0;
						xPos += trackingOffset;
					}
					if (usesGlyphs) {
						charData = this.globalData.fontManager.getCharData(documentData.finalText[i], fontData.fStyle, this.globalData.fontManager.getFontByName(documentData.f).fFamily);
						var glyphElement;
						if (charData.t === 1) glyphElement = new SVGCompElement(charData.data, this.globalData, this);
						else {
							var data = emptyShapeData;
							if (charData.data && charData.data.shapes) data = this.buildShapeData(charData.data, documentData.finalSize);
							glyphElement = new SVGShapeElement(data, this.globalData, this);
						}
						if (this.textSpans[i].glyph) {
							var glyph = this.textSpans[i].glyph;
							this.textSpans[i].childSpan.removeChild(glyph.layerElement);
							glyph.destroy();
						}
						this.textSpans[i].glyph = glyphElement;
						glyphElement._debug = true;
						glyphElement.prepareFrame(0);
						glyphElement.renderFrame();
						this.textSpans[i].childSpan.appendChild(glyphElement.layerElement);
						if (charData.t === 1) this.textSpans[i].childSpan.setAttribute("transform", "scale(" + documentData.finalSize / 100 + "," + documentData.finalSize / 100 + ")");
					} else {
						if (singleShape) tSpan.setAttribute("transform", "translate(" + matrixHelper.props[12] + "," + matrixHelper.props[13] + ")");
						tSpan.textContent = letters[i].val;
						tSpan.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
					}
				}
				if (singleShape && tSpan) tSpan.setAttribute("d", shapeStr);
			}
			while (i < this.textSpans.length) {
				this.textSpans[i].span.style.display = "none";
				i += 1;
			}
			this._sizeChanged = true;
		};
		SVGTextLottieElement.prototype.sourceRectAtTime = function() {
			this.prepareFrame(this.comp.renderedFrame - this.data.st);
			this.renderInnerContent();
			if (this._sizeChanged) {
				this._sizeChanged = false;
				var textBox = this.layerElement.getBBox();
				this.bbox = {
					top: textBox.y,
					left: textBox.x,
					width: textBox.width,
					height: textBox.height
				};
			}
			return this.bbox;
		};
		SVGTextLottieElement.prototype.getValue = function() {
			var i;
			var len = this.textSpans.length;
			var glyphElement;
			this.renderedFrame = this.comp.renderedFrame;
			for (i = 0; i < len; i += 1) {
				glyphElement = this.textSpans[i].glyph;
				if (glyphElement) {
					glyphElement.prepareFrame(this.comp.renderedFrame - this.data.st);
					if (glyphElement._mdf) this._mdf = true;
				}
			}
		};
		SVGTextLottieElement.prototype.renderInnerContent = function() {
			this.validateText();
			if (!this.data.singleShape || this._mdf) {
				this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag);
				if (this.lettersChangedFlag || this.textAnimator.lettersChangedFlag) {
					this._sizeChanged = true;
					var i;
					var len;
					var renderedLetters = this.textAnimator.renderedLetters;
					var letters = this.textProperty.currentData.l;
					len = letters.length;
					var renderedLetter;
					var textSpan;
					var glyphElement;
					for (i = 0; i < len; i += 1) if (!letters[i].n) {
						renderedLetter = renderedLetters[i];
						textSpan = this.textSpans[i].span;
						glyphElement = this.textSpans[i].glyph;
						if (glyphElement) glyphElement.renderFrame();
						if (renderedLetter._mdf.m) textSpan.setAttribute("transform", renderedLetter.m);
						if (renderedLetter._mdf.o) textSpan.setAttribute("opacity", renderedLetter.o);
						if (renderedLetter._mdf.sw) textSpan.setAttribute("stroke-width", renderedLetter.sw);
						if (renderedLetter._mdf.sc) textSpan.setAttribute("stroke", renderedLetter.sc);
						if (renderedLetter._mdf.fc) textSpan.setAttribute("fill", renderedLetter.fc);
					}
				}
			}
		};
		function ISolidElement(data, globalData, comp) {
			this.initElement(data, globalData, comp);
		}
		extendPrototype([IImageElement], ISolidElement);
		ISolidElement.prototype.createContent = function() {
			var rect = createNS("rect");
			rect.setAttribute("width", this.data.sw);
			rect.setAttribute("height", this.data.sh);
			rect.setAttribute("fill", this.data.sc);
			this.layerElement.appendChild(rect);
		};
		function NullElement(data, globalData, comp) {
			this.initFrame();
			this.initBaseData(data, globalData, comp);
			this.initFrame();
			this.initTransform(data, globalData, comp);
			this.initHierarchy();
		}
		NullElement.prototype.prepareFrame = function(num) {
			this.prepareProperties(num, true);
		};
		NullElement.prototype.renderFrame = function() {};
		NullElement.prototype.getBaseElement = function() {
			return null;
		};
		NullElement.prototype.destroy = function() {};
		NullElement.prototype.sourceRectAtTime = function() {};
		NullElement.prototype.hide = function() {};
		extendPrototype([
			BaseElement,
			TransformElement,
			HierarchyElement,
			FrameElement
		], NullElement);
		function SVGRendererBase() {}
		extendPrototype([BaseRenderer], SVGRendererBase);
		SVGRendererBase.prototype.createNull = function(data) {
			return new NullElement(data, this.globalData, this);
		};
		SVGRendererBase.prototype.createShape = function(data) {
			return new SVGShapeElement(data, this.globalData, this);
		};
		SVGRendererBase.prototype.createText = function(data) {
			return new SVGTextLottieElement(data, this.globalData, this);
		};
		SVGRendererBase.prototype.createImage = function(data) {
			return new IImageElement(data, this.globalData, this);
		};
		SVGRendererBase.prototype.createSolid = function(data) {
			return new ISolidElement(data, this.globalData, this);
		};
		SVGRendererBase.prototype.configAnimation = function(animData) {
			this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg");
			this.svgElement.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
			if (this.renderConfig.viewBoxSize) this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize);
			else this.svgElement.setAttribute("viewBox", "0 0 " + animData.w + " " + animData.h);
			if (!this.renderConfig.viewBoxOnly) {
				this.svgElement.setAttribute("width", animData.w);
				this.svgElement.setAttribute("height", animData.h);
				this.svgElement.style.width = "100%";
				this.svgElement.style.height = "100%";
				this.svgElement.style.transform = "translate3d(0,0,0)";
				this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility;
			}
			if (this.renderConfig.width) this.svgElement.setAttribute("width", this.renderConfig.width);
			if (this.renderConfig.height) this.svgElement.setAttribute("height", this.renderConfig.height);
			if (this.renderConfig.className) this.svgElement.setAttribute("class", this.renderConfig.className);
			if (this.renderConfig.id) this.svgElement.setAttribute("id", this.renderConfig.id);
			if (this.renderConfig.focusable !== void 0) this.svgElement.setAttribute("focusable", this.renderConfig.focusable);
			this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio);
			this.animationItem.wrapper.appendChild(this.svgElement);
			var defs = this.globalData.defs;
			this.setupGlobalData(animData, defs);
			this.globalData.progressiveLoad = this.renderConfig.progressiveLoad;
			this.data = animData;
			var maskElement = createNS("clipPath");
			var rect = createNS("rect");
			rect.setAttribute("width", animData.w);
			rect.setAttribute("height", animData.h);
			rect.setAttribute("x", 0);
			rect.setAttribute("y", 0);
			var maskId = createElementID();
			maskElement.setAttribute("id", maskId);
			maskElement.appendChild(rect);
			this.layerElement.setAttribute("clip-path", "url(" + getLocationHref() + "#" + maskId + ")");
			defs.appendChild(maskElement);
			this.layers = animData.layers;
			this.elements = createSizedArray(animData.layers.length);
		};
		SVGRendererBase.prototype.destroy = function() {
			if (this.animationItem.wrapper) this.animationItem.wrapper.innerText = "";
			this.layerElement = null;
			this.globalData.defs = null;
			var i;
			var len = this.layers ? this.layers.length : 0;
			for (i = 0; i < len; i += 1) if (this.elements[i] && this.elements[i].destroy) this.elements[i].destroy();
			this.elements.length = 0;
			this.destroyed = true;
			this.animationItem = null;
		};
		SVGRendererBase.prototype.updateContainerSize = function() {};
		SVGRendererBase.prototype.findIndexByInd = function(ind) {
			var i = 0;
			var len = this.layers.length;
			for (i = 0; i < len; i += 1) if (this.layers[i].ind === ind) return i;
			return -1;
		};
		SVGRendererBase.prototype.buildItem = function(pos) {
			var elements = this.elements;
			if (elements[pos] || this.layers[pos].ty === 99) return;
			elements[pos] = true;
			var element = this.createItem(this.layers[pos]);
			elements[pos] = element;
			if (getExpressionsPlugin()) {
				if (this.layers[pos].ty === 0) this.globalData.projectInterface.registerComposition(element);
				element.initExpressions();
			}
			this.appendElementInPos(element, pos);
			if (this.layers[pos].tt) {
				var elementIndex = "tp" in this.layers[pos] ? this.findIndexByInd(this.layers[pos].tp) : pos - 1;
				if (elementIndex === -1) return;
				if (!this.elements[elementIndex] || this.elements[elementIndex] === true) {
					this.buildItem(elementIndex);
					this.addPendingElement(element);
				} else {
					var matteMask = elements[elementIndex].getMatte(this.layers[pos].tt);
					element.setMatte(matteMask);
				}
			}
		};
		SVGRendererBase.prototype.checkPendingElements = function() {
			while (this.pendingElements.length) {
				var element = this.pendingElements.pop();
				element.checkParenting();
				if (element.data.tt) {
					var i = 0;
					var len = this.elements.length;
					while (i < len) {
						if (this.elements[i] === element) {
							var elementIndex = "tp" in element.data ? this.findIndexByInd(element.data.tp) : i - 1;
							var matteMask = this.elements[elementIndex].getMatte(this.layers[i].tt);
							element.setMatte(matteMask);
							break;
						}
						i += 1;
					}
				}
			}
		};
		SVGRendererBase.prototype.renderFrame = function(num) {
			if (this.renderedFrame === num || this.destroyed) return;
			if (num === null) num = this.renderedFrame;
			else this.renderedFrame = num;
			this.globalData.frameNum = num;
			this.globalData.frameId += 1;
			this.globalData.projectInterface.currentFrame = num;
			this.globalData._mdf = false;
			var i;
			var len = this.layers.length;
			if (!this.completeLayers) this.checkLayers(num);
			for (i = len - 1; i >= 0; i -= 1) if (this.completeLayers || this.elements[i]) this.elements[i].prepareFrame(num - this.layers[i].st);
			if (this.globalData._mdf) {
				for (i = 0; i < len; i += 1) if (this.completeLayers || this.elements[i]) this.elements[i].renderFrame();
			}
		};
		SVGRendererBase.prototype.appendElementInPos = function(element, pos) {
			var newElement = element.getBaseElement();
			if (!newElement) return;
			var i = 0;
			var nextElement;
			while (i < pos) {
				if (this.elements[i] && this.elements[i] !== true && this.elements[i].getBaseElement()) nextElement = this.elements[i].getBaseElement();
				i += 1;
			}
			if (nextElement) this.layerElement.insertBefore(newElement, nextElement);
			else this.layerElement.appendChild(newElement);
		};
		SVGRendererBase.prototype.hide = function() {
			this.layerElement.style.display = "none";
		};
		SVGRendererBase.prototype.show = function() {
			this.layerElement.style.display = "block";
		};
		function ICompElement() {}
		extendPrototype([
			BaseElement,
			TransformElement,
			HierarchyElement,
			FrameElement,
			RenderableDOMElement
		], ICompElement);
		ICompElement.prototype.initElement = function(data, globalData, comp) {
			this.initFrame();
			this.initBaseData(data, globalData, comp);
			this.initTransform(data, globalData, comp);
			this.initRenderable();
			this.initHierarchy();
			this.initRendererElement();
			this.createContainerElements();
			this.createRenderableComponents();
			if (this.data.xt || !globalData.progressiveLoad) this.buildAllItems();
			this.hide();
		};
		ICompElement.prototype.prepareFrame = function(num) {
			this._mdf = false;
			this.prepareRenderableFrame(num);
			this.prepareProperties(num, this.isInRange);
			if (!this.isInRange && !this.data.xt) return;
			if (!this.tm._placeholder) {
				var timeRemapped = this.tm.v;
				if (timeRemapped === this.data.op) timeRemapped = this.data.op - 1;
				this.renderedFrame = timeRemapped;
			} else this.renderedFrame = num / this.data.sr;
			var i;
			var len = this.elements.length;
			if (!this.completeLayers) this.checkLayers(this.renderedFrame);
			for (i = len - 1; i >= 0; i -= 1) if (this.completeLayers || this.elements[i]) {
				this.elements[i].prepareFrame(this.renderedFrame - this.layers[i].st);
				if (this.elements[i]._mdf) this._mdf = true;
			}
		};
		ICompElement.prototype.renderInnerContent = function() {
			var i;
			var len = this.layers.length;
			for (i = 0; i < len; i += 1) if (this.completeLayers || this.elements[i]) this.elements[i].renderFrame();
		};
		ICompElement.prototype.setElements = function(elems) {
			this.elements = elems;
		};
		ICompElement.prototype.getElements = function() {
			return this.elements;
		};
		ICompElement.prototype.destroyElements = function() {
			var i;
			var len = this.layers.length;
			for (i = 0; i < len; i += 1) if (this.elements[i]) this.elements[i].destroy();
		};
		ICompElement.prototype.destroy = function() {
			this.destroyElements();
			this.destroyBaseElement();
		};
		function SVGCompElement(data, globalData, comp) {
			this.layers = data.layers;
			this.supports3d = true;
			this.completeLayers = false;
			this.pendingElements = [];
			this.elements = this.layers ? createSizedArray(this.layers.length) : [];
			this.initElement(data, globalData, comp);
			this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, globalData.frameRate, this) : { _placeholder: true };
		}
		extendPrototype([
			SVGRendererBase,
			ICompElement,
			SVGBaseElement
		], SVGCompElement);
		SVGCompElement.prototype.createComp = function(data) {
			return new SVGCompElement(data, this.globalData, this);
		};
		function SVGRenderer(animationItem, config) {
			this.animationItem = animationItem;
			this.layers = null;
			this.renderedFrame = -1;
			this.svgElement = createNS("svg");
			var ariaLabel = "";
			if (config && config.title) {
				var titleElement = createNS("title");
				var titleId = createElementID();
				titleElement.setAttribute("id", titleId);
				titleElement.textContent = config.title;
				this.svgElement.appendChild(titleElement);
				ariaLabel += titleId;
			}
			if (config && config.description) {
				var descElement = createNS("desc");
				var descId = createElementID();
				descElement.setAttribute("id", descId);
				descElement.textContent = config.description;
				this.svgElement.appendChild(descElement);
				ariaLabel += " " + descId;
			}
			if (ariaLabel) this.svgElement.setAttribute("aria-labelledby", ariaLabel);
			var defs = createNS("defs");
			this.svgElement.appendChild(defs);
			var maskElement = createNS("g");
			this.svgElement.appendChild(maskElement);
			this.layerElement = maskElement;
			this.renderConfig = {
				preserveAspectRatio: config && config.preserveAspectRatio || "xMidYMid meet",
				imagePreserveAspectRatio: config && config.imagePreserveAspectRatio || "xMidYMid slice",
				contentVisibility: config && config.contentVisibility || "visible",
				progressiveLoad: config && config.progressiveLoad || false,
				hideOnTransparent: !(config && config.hideOnTransparent === false),
				viewBoxOnly: config && config.viewBoxOnly || false,
				viewBoxSize: config && config.viewBoxSize || false,
				className: config && config.className || "",
				id: config && config.id || "",
				focusable: config && config.focusable,
				filterSize: {
					width: config && config.filterSize && config.filterSize.width || "100%",
					height: config && config.filterSize && config.filterSize.height || "100%",
					x: config && config.filterSize && config.filterSize.x || "0%",
					y: config && config.filterSize && config.filterSize.y || "0%"
				},
				width: config && config.width,
				height: config && config.height,
				runExpressions: !config || config.runExpressions === void 0 || config.runExpressions
			};
			this.globalData = {
				_mdf: false,
				frameNum: -1,
				defs,
				renderConfig: this.renderConfig
			};
			this.elements = [];
			this.pendingElements = [];
			this.destroyed = false;
			this.rendererType = "svg";
		}
		extendPrototype([SVGRendererBase], SVGRenderer);
		SVGRenderer.prototype.createComp = function(data) {
			return new SVGCompElement(data, this.globalData, this);
		};
		function ShapeTransformManager() {
			this.sequences = {};
			this.sequenceList = [];
			this.transform_key_count = 0;
		}
		ShapeTransformManager.prototype = {
			addTransformSequence: function addTransformSequence(transforms) {
				var i;
				var len = transforms.length;
				var key = "_";
				for (i = 0; i < len; i += 1) key += transforms[i].transform.key + "_";
				var sequence = this.sequences[key];
				if (!sequence) {
					sequence = {
						transforms: [].concat(transforms),
						finalTransform: new Matrix(),
						_mdf: false
					};
					this.sequences[key] = sequence;
					this.sequenceList.push(sequence);
				}
				return sequence;
			},
			processSequence: function processSequence(sequence, isFirstFrame) {
				var i = 0;
				var len = sequence.transforms.length;
				var _mdf = isFirstFrame;
				while (i < len && !isFirstFrame) {
					if (sequence.transforms[i].transform.mProps._mdf) {
						_mdf = true;
						break;
					}
					i += 1;
				}
				if (_mdf) {
					sequence.finalTransform.reset();
					for (i = len - 1; i >= 0; i -= 1) sequence.finalTransform.multiply(sequence.transforms[i].transform.mProps.v);
				}
				sequence._mdf = _mdf;
			},
			processSequences: function processSequences(isFirstFrame) {
				var i;
				var len = this.sequenceList.length;
				for (i = 0; i < len; i += 1) this.processSequence(this.sequenceList[i], isFirstFrame);
			},
			getNewKey: function getNewKey() {
				this.transform_key_count += 1;
				return "_" + this.transform_key_count;
			}
		};
		var lumaLoader = function lumaLoader() {
			var id = "__lottie_element_luma_buffer";
			var lumaBuffer = null;
			var lumaBufferCtx = null;
			var svg = null;
			function createLumaSvgFilter() {
				var _svg = createNS("svg");
				var fil = createNS("filter");
				var matrix = createNS("feColorMatrix");
				fil.setAttribute("id", id);
				matrix.setAttribute("type", "matrix");
				matrix.setAttribute("color-interpolation-filters", "sRGB");
				matrix.setAttribute("values", "0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0");
				fil.appendChild(matrix);
				_svg.appendChild(fil);
				_svg.setAttribute("id", "__lottie_element_luma_buffer_svg");
				if (featureSupport.svgLumaHidden) _svg.style.display = "none";
				return _svg;
			}
			function loadLuma() {
				if (!lumaBuffer) {
					svg = createLumaSvgFilter();
					document.body.appendChild(svg);
					lumaBuffer = createTag("canvas");
					lumaBufferCtx = lumaBuffer.getContext("2d");
					lumaBufferCtx.filter = "url(#__lottie_element_luma_buffer)";
					lumaBufferCtx.fillStyle = "rgba(0,0,0,0)";
					lumaBufferCtx.fillRect(0, 0, 1, 1);
				}
			}
			function getLuma(canvas) {
				if (!lumaBuffer) loadLuma();
				lumaBuffer.width = canvas.width;
				lumaBuffer.height = canvas.height;
				lumaBufferCtx.filter = "url(#__lottie_element_luma_buffer)";
				return lumaBuffer;
			}
			return {
				load: loadLuma,
				get: getLuma
			};
		};
		function createCanvas(width, height) {
			if (featureSupport.offscreenCanvas) return new OffscreenCanvas(width, height);
			var canvas = createTag("canvas");
			canvas.width = width;
			canvas.height = height;
			return canvas;
		}
		var assetLoader = function() {
			return {
				loadLumaCanvas: lumaLoader.load,
				getLumaCanvas: lumaLoader.get,
				createCanvas
			};
		}();
		var registeredEffects = {};
		function CVEffects(elem) {
			var i;
			var len = elem.data.ef ? elem.data.ef.length : 0;
			this.filters = [];
			var filterManager;
			for (i = 0; i < len; i += 1) {
				filterManager = null;
				var type = elem.data.ef[i].ty;
				if (registeredEffects[type]) {
					var Effect = registeredEffects[type].effect;
					filterManager = new Effect(elem.effectsManager.effectElements[i], elem);
				}
				if (filterManager) this.filters.push(filterManager);
			}
			if (this.filters.length) elem.addRenderableComponent(this);
		}
		CVEffects.prototype.renderFrame = function(_isFirstFrame) {
			var i;
			var len = this.filters.length;
			for (i = 0; i < len; i += 1) this.filters[i].renderFrame(_isFirstFrame);
		};
		CVEffects.prototype.getEffects = function(type) {
			var i;
			var len = this.filters.length;
			var effects = [];
			for (i = 0; i < len; i += 1) if (this.filters[i].type === type) effects.push(this.filters[i]);
			return effects;
		};
		function CVMaskElement(data, element) {
			this.data = data;
			this.element = element;
			this.masksProperties = this.data.masksProperties || [];
			this.viewData = createSizedArray(this.masksProperties.length);
			var i;
			var len = this.masksProperties.length;
			var hasMasks = false;
			for (i = 0; i < len; i += 1) {
				if (this.masksProperties[i].mode !== "n") hasMasks = true;
				this.viewData[i] = ShapePropertyFactory.getShapeProp(this.element, this.masksProperties[i], 3);
			}
			this.hasMasks = hasMasks;
			if (hasMasks) this.element.addRenderableComponent(this);
		}
		CVMaskElement.prototype.renderFrame = function() {
			if (!this.hasMasks) return;
			var transform = this.element.finalTransform.mat;
			var ctx = this.element.canvasContext;
			var i;
			var len = this.masksProperties.length;
			var pt;
			var pts;
			var data;
			ctx.beginPath();
			for (i = 0; i < len; i += 1) if (this.masksProperties[i].mode !== "n") {
				if (this.masksProperties[i].inv) {
					ctx.moveTo(0, 0);
					ctx.lineTo(this.element.globalData.compSize.w, 0);
					ctx.lineTo(this.element.globalData.compSize.w, this.element.globalData.compSize.h);
					ctx.lineTo(0, this.element.globalData.compSize.h);
					ctx.lineTo(0, 0);
				}
				data = this.viewData[i].v;
				pt = transform.applyToPointArray(data.v[0][0], data.v[0][1], 0);
				ctx.moveTo(pt[0], pt[1]);
				var j;
				var jLen = data._length;
				for (j = 1; j < jLen; j += 1) {
					pts = transform.applyToTriplePoints(data.o[j - 1], data.i[j], data.v[j]);
					ctx.bezierCurveTo(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]);
				}
				pts = transform.applyToTriplePoints(data.o[j - 1], data.i[0], data.v[0]);
				ctx.bezierCurveTo(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]);
			}
			this.element.globalData.renderer.save(true);
			ctx.clip();
		};
		CVMaskElement.prototype.getMaskProperty = MaskElement.prototype.getMaskProperty;
		CVMaskElement.prototype.destroy = function() {
			this.element = null;
		};
		function CVBaseElement() {}
		var operationsMap = {
			1: "source-in",
			2: "source-out",
			3: "source-in",
			4: "source-out"
		};
		CVBaseElement.prototype = {
			createElements: function createElements() {},
			initRendererElement: function initRendererElement() {},
			createContainerElements: function createContainerElements() {
				if (this.data.tt >= 1) {
					this.buffers = [];
					var canvasContext = this.globalData.canvasContext;
					var bufferCanvas = assetLoader.createCanvas(canvasContext.canvas.width, canvasContext.canvas.height);
					this.buffers.push(bufferCanvas);
					var bufferCanvas2 = assetLoader.createCanvas(canvasContext.canvas.width, canvasContext.canvas.height);
					this.buffers.push(bufferCanvas2);
					if (this.data.tt >= 3 && !document._isProxy) assetLoader.loadLumaCanvas();
				}
				this.canvasContext = this.globalData.canvasContext;
				this.transformCanvas = this.globalData.transformCanvas;
				this.renderableEffectsManager = new CVEffects(this);
				this.searchEffectTransforms();
			},
			createContent: function createContent() {},
			setBlendMode: function setBlendMode() {
				var globalData = this.globalData;
				if (globalData.blendMode !== this.data.bm) {
					globalData.blendMode = this.data.bm;
					var blendModeValue = getBlendMode(this.data.bm);
					globalData.canvasContext.globalCompositeOperation = blendModeValue;
				}
			},
			createRenderableComponents: function createRenderableComponents() {
				this.maskManager = new CVMaskElement(this.data, this);
				this.transformEffects = this.renderableEffectsManager.getEffects(effectTypes.TRANSFORM_EFFECT);
			},
			hideElement: function hideElement() {
				if (!this.hidden && (!this.isInRange || this.isTransparent)) this.hidden = true;
			},
			showElement: function showElement() {
				if (this.isInRange && !this.isTransparent) {
					this.hidden = false;
					this._isFirstFrame = true;
					this.maskManager._isFirstFrame = true;
				}
			},
			clearCanvas: function clearCanvas(canvasContext) {
				canvasContext.clearRect(this.transformCanvas.tx, this.transformCanvas.ty, this.transformCanvas.w * this.transformCanvas.sx, this.transformCanvas.h * this.transformCanvas.sy);
			},
			prepareLayer: function prepareLayer() {
				if (this.data.tt >= 1) {
					var bufferCtx = this.buffers[0].getContext("2d");
					this.clearCanvas(bufferCtx);
					bufferCtx.drawImage(this.canvasContext.canvas, 0, 0);
					this.currentTransform = this.canvasContext.getTransform();
					this.canvasContext.setTransform(1, 0, 0, 1, 0, 0);
					this.clearCanvas(this.canvasContext);
					this.canvasContext.setTransform(this.currentTransform);
				}
			},
			exitLayer: function exitLayer() {
				if (this.data.tt >= 1) {
					var buffer = this.buffers[1];
					var bufferCtx = buffer.getContext("2d");
					this.clearCanvas(bufferCtx);
					bufferCtx.drawImage(this.canvasContext.canvas, 0, 0);
					this.canvasContext.setTransform(1, 0, 0, 1, 0, 0);
					this.clearCanvas(this.canvasContext);
					this.canvasContext.setTransform(this.currentTransform);
					this.comp.getElementById("tp" in this.data ? this.data.tp : this.data.ind - 1).renderFrame(true);
					this.canvasContext.setTransform(1, 0, 0, 1, 0, 0);
					if (this.data.tt >= 3 && !document._isProxy) {
						var lumaBuffer = assetLoader.getLumaCanvas(this.canvasContext.canvas);
						lumaBuffer.getContext("2d").drawImage(this.canvasContext.canvas, 0, 0);
						this.clearCanvas(this.canvasContext);
						this.canvasContext.drawImage(lumaBuffer, 0, 0);
					}
					this.canvasContext.globalCompositeOperation = operationsMap[this.data.tt];
					this.canvasContext.drawImage(buffer, 0, 0);
					this.canvasContext.globalCompositeOperation = "destination-over";
					this.canvasContext.drawImage(this.buffers[0], 0, 0);
					this.canvasContext.setTransform(this.currentTransform);
					this.canvasContext.globalCompositeOperation = "source-over";
				}
			},
			renderFrame: function renderFrame(forceRender) {
				if (this.hidden || this.data.hd) return;
				if (this.data.td === 1 && !forceRender) return;
				this.renderTransform();
				this.renderRenderable();
				this.renderLocalTransform();
				this.setBlendMode();
				var forceRealStack = this.data.ty === 0;
				this.prepareLayer();
				this.globalData.renderer.save(forceRealStack);
				this.globalData.renderer.ctxTransform(this.finalTransform.localMat.props);
				this.globalData.renderer.ctxOpacity(this.finalTransform.localOpacity);
				this.renderInnerContent();
				this.globalData.renderer.restore(forceRealStack);
				this.exitLayer();
				if (this.maskManager.hasMasks) this.globalData.renderer.restore(true);
				if (this._isFirstFrame) this._isFirstFrame = false;
			},
			destroy: function destroy() {
				this.canvasContext = null;
				this.data = null;
				this.globalData = null;
				this.maskManager.destroy();
			},
			mHelper: new Matrix()
		};
		CVBaseElement.prototype.hide = CVBaseElement.prototype.hideElement;
		CVBaseElement.prototype.show = CVBaseElement.prototype.showElement;
		function CVShapeData(element, data, styles, transformsManager) {
			this.styledShapes = [];
			this.tr = [
				0,
				0,
				0,
				0,
				0,
				0
			];
			var ty = 4;
			if (data.ty === "rc") ty = 5;
			else if (data.ty === "el") ty = 6;
			else if (data.ty === "sr") ty = 7;
			this.sh = ShapePropertyFactory.getShapeProp(element, data, ty, element);
			var i;
			var len = styles.length;
			var styledShape;
			for (i = 0; i < len; i += 1) if (!styles[i].closed) {
				styledShape = {
					transforms: transformsManager.addTransformSequence(styles[i].transforms),
					trNodes: []
				};
				this.styledShapes.push(styledShape);
				styles[i].elements.push(styledShape);
			}
		}
		CVShapeData.prototype.setAsAnimated = SVGShapeData.prototype.setAsAnimated;
		function CVShapeElement(data, globalData, comp) {
			this.shapes = [];
			this.shapesData = data.shapes;
			this.stylesList = [];
			this.itemsData = [];
			this.prevViewData = [];
			this.shapeModifiers = [];
			this.processedElements = [];
			this.transformsManager = new ShapeTransformManager();
			this.initElement(data, globalData, comp);
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			CVBaseElement,
			IShapeElement,
			HierarchyElement,
			FrameElement,
			RenderableElement
		], CVShapeElement);
		CVShapeElement.prototype.initElement = RenderableDOMElement.prototype.initElement;
		CVShapeElement.prototype.transformHelper = {
			opacity: 1,
			_opMdf: false
		};
		CVShapeElement.prototype.dashResetter = [];
		CVShapeElement.prototype.createContent = function() {
			this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, true, []);
		};
		CVShapeElement.prototype.createStyleElement = function(data, transforms) {
			var styleElem = {
				data,
				type: data.ty,
				preTransforms: this.transformsManager.addTransformSequence(transforms),
				transforms: [],
				elements: [],
				closed: data.hd === true
			};
			var elementData = {};
			if (data.ty === "fl" || data.ty === "st") {
				elementData.c = PropertyFactory.getProp(this, data.c, 1, 255, this);
				if (!elementData.c.k) styleElem.co = "rgb(" + bmFloor(elementData.c.v[0]) + "," + bmFloor(elementData.c.v[1]) + "," + bmFloor(elementData.c.v[2]) + ")";
			} else if (data.ty === "gf" || data.ty === "gs") {
				elementData.s = PropertyFactory.getProp(this, data.s, 1, null, this);
				elementData.e = PropertyFactory.getProp(this, data.e, 1, null, this);
				elementData.h = PropertyFactory.getProp(this, data.h || { k: 0 }, 0, .01, this);
				elementData.a = PropertyFactory.getProp(this, data.a || { k: 0 }, 0, degToRads, this);
				elementData.g = new GradientProperty(this, data.g, this);
			}
			elementData.o = PropertyFactory.getProp(this, data.o, 0, .01, this);
			if (data.ty === "st" || data.ty === "gs") {
				styleElem.lc = lineCapEnum[data.lc || 2];
				styleElem.lj = lineJoinEnum[data.lj || 2];
				if (data.lj == 1) styleElem.ml = data.ml;
				elementData.w = PropertyFactory.getProp(this, data.w, 0, null, this);
				if (!elementData.w.k) styleElem.wi = elementData.w.v;
				if (data.d) {
					elementData.d = new DashProperty(this, data.d, "canvas", this);
					if (!elementData.d.k) {
						styleElem.da = elementData.d.dashArray;
						styleElem["do"] = elementData.d.dashoffset[0];
					}
				}
			} else styleElem.r = data.r === 2 ? "evenodd" : "nonzero";
			this.stylesList.push(styleElem);
			elementData.style = styleElem;
			return elementData;
		};
		CVShapeElement.prototype.createGroupElement = function() {
			return {
				it: [],
				prevViewData: []
			};
		};
		CVShapeElement.prototype.createTransformElement = function(data) {
			return { transform: {
				opacity: 1,
				_opMdf: false,
				key: this.transformsManager.getNewKey(),
				op: PropertyFactory.getProp(this, data.o, 0, .01, this),
				mProps: TransformPropertyFactory.getTransformProperty(this, data, this)
			} };
		};
		CVShapeElement.prototype.createShapeElement = function(data) {
			var elementData = new CVShapeData(this, data, this.stylesList, this.transformsManager);
			this.shapes.push(elementData);
			this.addShapeToModifiers(elementData);
			return elementData;
		};
		CVShapeElement.prototype.reloadShapes = function() {
			this._isFirstFrame = true;
			var i;
			var len = this.itemsData.length;
			for (i = 0; i < len; i += 1) this.prevViewData[i] = this.itemsData[i];
			this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, true, []);
			len = this.dynamicProperties.length;
			for (i = 0; i < len; i += 1) this.dynamicProperties[i].getValue();
			this.renderModifiers();
			this.transformsManager.processSequences(this._isFirstFrame);
		};
		CVShapeElement.prototype.addTransformToStyleList = function(transform) {
			var i;
			var len = this.stylesList.length;
			for (i = 0; i < len; i += 1) if (!this.stylesList[i].closed) this.stylesList[i].transforms.push(transform);
		};
		CVShapeElement.prototype.removeTransformFromStyleList = function() {
			var i;
			var len = this.stylesList.length;
			for (i = 0; i < len; i += 1) if (!this.stylesList[i].closed) this.stylesList[i].transforms.pop();
		};
		CVShapeElement.prototype.closeStyles = function(styles) {
			var i;
			var len = styles.length;
			for (i = 0; i < len; i += 1) styles[i].closed = true;
		};
		CVShapeElement.prototype.searchShapes = function(arr, itemsData, prevViewData, shouldRender, transforms) {
			var i;
			var len = arr.length - 1;
			var j;
			var jLen;
			var ownStyles = [];
			var ownModifiers = [];
			var processedPos;
			var modifier;
			var currentTransform;
			var ownTransforms = [].concat(transforms);
			for (i = len; i >= 0; i -= 1) {
				processedPos = this.searchProcessedElement(arr[i]);
				if (!processedPos) arr[i]._shouldRender = shouldRender;
				else itemsData[i] = prevViewData[processedPos - 1];
				if (arr[i].ty === "fl" || arr[i].ty === "st" || arr[i].ty === "gf" || arr[i].ty === "gs") {
					if (!processedPos) itemsData[i] = this.createStyleElement(arr[i], ownTransforms);
					else itemsData[i].style.closed = false;
					ownStyles.push(itemsData[i].style);
				} else if (arr[i].ty === "gr") {
					if (!processedPos) itemsData[i] = this.createGroupElement(arr[i]);
					else {
						jLen = itemsData[i].it.length;
						for (j = 0; j < jLen; j += 1) itemsData[i].prevViewData[j] = itemsData[i].it[j];
					}
					this.searchShapes(arr[i].it, itemsData[i].it, itemsData[i].prevViewData, shouldRender, ownTransforms);
				} else if (arr[i].ty === "tr") {
					if (!processedPos) {
						currentTransform = this.createTransformElement(arr[i]);
						itemsData[i] = currentTransform;
					}
					ownTransforms.push(itemsData[i]);
					this.addTransformToStyleList(itemsData[i]);
				} else if (arr[i].ty === "sh" || arr[i].ty === "rc" || arr[i].ty === "el" || arr[i].ty === "sr") {
					if (!processedPos) itemsData[i] = this.createShapeElement(arr[i]);
				} else if (arr[i].ty === "tm" || arr[i].ty === "rd" || arr[i].ty === "pb" || arr[i].ty === "zz" || arr[i].ty === "op") {
					if (!processedPos) {
						modifier = ShapeModifiers.getModifier(arr[i].ty);
						modifier.init(this, arr[i]);
						itemsData[i] = modifier;
						this.shapeModifiers.push(modifier);
					} else {
						modifier = itemsData[i];
						modifier.closed = false;
					}
					ownModifiers.push(modifier);
				} else if (arr[i].ty === "rp") {
					if (!processedPos) {
						modifier = ShapeModifiers.getModifier(arr[i].ty);
						itemsData[i] = modifier;
						modifier.init(this, arr, i, itemsData);
						this.shapeModifiers.push(modifier);
						shouldRender = false;
					} else {
						modifier = itemsData[i];
						modifier.closed = true;
					}
					ownModifiers.push(modifier);
				}
				this.addProcessedElement(arr[i], i + 1);
			}
			this.removeTransformFromStyleList();
			this.closeStyles(ownStyles);
			len = ownModifiers.length;
			for (i = 0; i < len; i += 1) ownModifiers[i].closed = true;
		};
		CVShapeElement.prototype.renderInnerContent = function() {
			this.transformHelper.opacity = 1;
			this.transformHelper._opMdf = false;
			this.renderModifiers();
			this.transformsManager.processSequences(this._isFirstFrame);
			this.renderShape(this.transformHelper, this.shapesData, this.itemsData, true);
		};
		CVShapeElement.prototype.renderShapeTransform = function(parentTransform, groupTransform) {
			if (parentTransform._opMdf || groupTransform.op._mdf || this._isFirstFrame) {
				groupTransform.opacity = parentTransform.opacity;
				groupTransform.opacity *= groupTransform.op.v;
				groupTransform._opMdf = true;
			}
		};
		CVShapeElement.prototype.drawLayer = function() {
			var i;
			var len = this.stylesList.length;
			var j;
			var jLen;
			var k;
			var kLen;
			var elems;
			var nodes;
			var renderer = this.globalData.renderer;
			var ctx = this.globalData.canvasContext;
			var type;
			var currentStyle;
			for (i = 0; i < len; i += 1) {
				currentStyle = this.stylesList[i];
				type = currentStyle.type;
				if (!((type === "st" || type === "gs") && currentStyle.wi === 0 || !currentStyle.data._shouldRender || currentStyle.coOp === 0 || this.globalData.currentGlobalAlpha === 0)) {
					renderer.save();
					elems = currentStyle.elements;
					if (type === "st" || type === "gs") {
						renderer.ctxStrokeStyle(type === "st" ? currentStyle.co : currentStyle.grd);
						renderer.ctxLineWidth(currentStyle.wi);
						renderer.ctxLineCap(currentStyle.lc);
						renderer.ctxLineJoin(currentStyle.lj);
						renderer.ctxMiterLimit(currentStyle.ml || 0);
					} else renderer.ctxFillStyle(type === "fl" ? currentStyle.co : currentStyle.grd);
					renderer.ctxOpacity(currentStyle.coOp);
					if (type !== "st" && type !== "gs") ctx.beginPath();
					renderer.ctxTransform(currentStyle.preTransforms.finalTransform.props);
					jLen = elems.length;
					for (j = 0; j < jLen; j += 1) {
						if (type === "st" || type === "gs") {
							ctx.beginPath();
							if (currentStyle.da) {
								ctx.setLineDash(currentStyle.da);
								ctx.lineDashOffset = currentStyle["do"];
							}
						}
						nodes = elems[j].trNodes;
						kLen = nodes.length;
						for (k = 0; k < kLen; k += 1) if (nodes[k].t === "m") ctx.moveTo(nodes[k].p[0], nodes[k].p[1]);
						else if (nodes[k].t === "c") ctx.bezierCurveTo(nodes[k].pts[0], nodes[k].pts[1], nodes[k].pts[2], nodes[k].pts[3], nodes[k].pts[4], nodes[k].pts[5]);
						else ctx.closePath();
						if (type === "st" || type === "gs") {
							renderer.ctxStroke();
							if (currentStyle.da) ctx.setLineDash(this.dashResetter);
						}
					}
					if (type !== "st" && type !== "gs") this.globalData.renderer.ctxFill(currentStyle.r);
					renderer.restore();
				}
			}
		};
		CVShapeElement.prototype.renderShape = function(parentTransform, items, data, isMain) {
			var i;
			var len = items.length - 1;
			var groupTransform = parentTransform;
			for (i = len; i >= 0; i -= 1) if (items[i].ty === "tr") {
				groupTransform = data[i].transform;
				this.renderShapeTransform(parentTransform, groupTransform);
			} else if (items[i].ty === "sh" || items[i].ty === "el" || items[i].ty === "rc" || items[i].ty === "sr") this.renderPath(items[i], data[i]);
			else if (items[i].ty === "fl") this.renderFill(items[i], data[i], groupTransform);
			else if (items[i].ty === "st") this.renderStroke(items[i], data[i], groupTransform);
			else if (items[i].ty === "gf" || items[i].ty === "gs") this.renderGradientFill(items[i], data[i], groupTransform);
			else if (items[i].ty === "gr") this.renderShape(groupTransform, items[i].it, data[i].it);
			else if (items[i].ty === "tm") {}
			if (isMain) this.drawLayer();
		};
		CVShapeElement.prototype.renderStyledShape = function(styledShape, shape) {
			if (this._isFirstFrame || shape._mdf || styledShape.transforms._mdf) {
				var shapeNodes = styledShape.trNodes;
				var paths = shape.paths;
				var i;
				var len;
				var j;
				var jLen = paths._length;
				shapeNodes.length = 0;
				var groupTransformMat = styledShape.transforms.finalTransform;
				for (j = 0; j < jLen; j += 1) {
					var pathNodes = paths.shapes[j];
					if (pathNodes && pathNodes.v) {
						len = pathNodes._length;
						for (i = 1; i < len; i += 1) {
							if (i === 1) shapeNodes.push({
								t: "m",
								p: groupTransformMat.applyToPointArray(pathNodes.v[0][0], pathNodes.v[0][1], 0)
							});
							shapeNodes.push({
								t: "c",
								pts: groupTransformMat.applyToTriplePoints(pathNodes.o[i - 1], pathNodes.i[i], pathNodes.v[i])
							});
						}
						if (len === 1) shapeNodes.push({
							t: "m",
							p: groupTransformMat.applyToPointArray(pathNodes.v[0][0], pathNodes.v[0][1], 0)
						});
						if (pathNodes.c && len) {
							shapeNodes.push({
								t: "c",
								pts: groupTransformMat.applyToTriplePoints(pathNodes.o[i - 1], pathNodes.i[0], pathNodes.v[0])
							});
							shapeNodes.push({ t: "z" });
						}
					}
				}
				styledShape.trNodes = shapeNodes;
			}
		};
		CVShapeElement.prototype.renderPath = function(pathData, itemData) {
			if (pathData.hd !== true && pathData._shouldRender) {
				var i;
				var len = itemData.styledShapes.length;
				for (i = 0; i < len; i += 1) this.renderStyledShape(itemData.styledShapes[i], itemData.sh);
			}
		};
		CVShapeElement.prototype.renderFill = function(styleData, itemData, groupTransform) {
			var styleElem = itemData.style;
			if (itemData.c._mdf || this._isFirstFrame) styleElem.co = "rgb(" + bmFloor(itemData.c.v[0]) + "," + bmFloor(itemData.c.v[1]) + "," + bmFloor(itemData.c.v[2]) + ")";
			if (itemData.o._mdf || groupTransform._opMdf || this._isFirstFrame) styleElem.coOp = itemData.o.v * groupTransform.opacity;
		};
		CVShapeElement.prototype.renderGradientFill = function(styleData, itemData, groupTransform) {
			var styleElem = itemData.style;
			var grd;
			if (!styleElem.grd || itemData.g._mdf || itemData.s._mdf || itemData.e._mdf || styleData.t !== 1 && (itemData.h._mdf || itemData.a._mdf)) {
				var ctx = this.globalData.canvasContext;
				var pt1 = itemData.s.v;
				var pt2 = itemData.e.v;
				if (styleData.t === 1) grd = ctx.createLinearGradient(pt1[0], pt1[1], pt2[0], pt2[1]);
				else {
					var rad = Math.sqrt(Math.pow(pt1[0] - pt2[0], 2) + Math.pow(pt1[1] - pt2[1], 2));
					var ang = Math.atan2(pt2[1] - pt1[1], pt2[0] - pt1[0]);
					var percent = itemData.h.v;
					if (percent >= 1) percent = .99;
					else if (percent <= -1) percent = -.99;
					var dist = rad * percent;
					var x = Math.cos(ang + itemData.a.v) * dist + pt1[0];
					var y = Math.sin(ang + itemData.a.v) * dist + pt1[1];
					grd = ctx.createRadialGradient(x, y, 0, pt1[0], pt1[1], rad);
				}
				var i;
				var len = styleData.g.p;
				var cValues = itemData.g.c;
				var opacity = 1;
				for (i = 0; i < len; i += 1) {
					if (itemData.g._hasOpacity && itemData.g._collapsable) opacity = itemData.g.o[i * 2 + 1];
					grd.addColorStop(cValues[i * 4] / 100, "rgba(" + cValues[i * 4 + 1] + "," + cValues[i * 4 + 2] + "," + cValues[i * 4 + 3] + "," + opacity + ")");
				}
				styleElem.grd = grd;
			}
			styleElem.coOp = itemData.o.v * groupTransform.opacity;
		};
		CVShapeElement.prototype.renderStroke = function(styleData, itemData, groupTransform) {
			var styleElem = itemData.style;
			var d = itemData.d;
			if (d && (d._mdf || this._isFirstFrame)) {
				styleElem.da = d.dashArray;
				styleElem["do"] = d.dashoffset[0];
			}
			if (itemData.c._mdf || this._isFirstFrame) styleElem.co = "rgb(" + bmFloor(itemData.c.v[0]) + "," + bmFloor(itemData.c.v[1]) + "," + bmFloor(itemData.c.v[2]) + ")";
			if (itemData.o._mdf || groupTransform._opMdf || this._isFirstFrame) styleElem.coOp = itemData.o.v * groupTransform.opacity;
			if (itemData.w._mdf || this._isFirstFrame) styleElem.wi = itemData.w.v;
		};
		CVShapeElement.prototype.destroy = function() {
			this.shapesData = null;
			this.globalData = null;
			this.canvasContext = null;
			this.stylesList.length = 0;
			this.itemsData.length = 0;
		};
		function CVTextElement(data, globalData, comp) {
			this.textSpans = [];
			this.yOffset = 0;
			this.fillColorAnim = false;
			this.strokeColorAnim = false;
			this.strokeWidthAnim = false;
			this.stroke = false;
			this.fill = false;
			this.justifyOffset = 0;
			this.currentRender = null;
			this.renderType = "canvas";
			this.values = {
				fill: "rgba(0,0,0,0)",
				stroke: "rgba(0,0,0,0)",
				sWidth: 0,
				fValue: ""
			};
			this.initElement(data, globalData, comp);
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			CVBaseElement,
			HierarchyElement,
			FrameElement,
			RenderableElement,
			ITextElement
		], CVTextElement);
		CVTextElement.prototype.tHelper = createTag("canvas").getContext("2d");
		CVTextElement.prototype.buildNewText = function() {
			var documentData = this.textProperty.currentData;
			this.renderedLetters = createSizedArray(documentData.l ? documentData.l.length : 0);
			var hasFill = false;
			if (documentData.fc) {
				hasFill = true;
				this.values.fill = this.buildColor(documentData.fc);
			} else this.values.fill = "rgba(0,0,0,0)";
			this.fill = hasFill;
			var hasStroke = false;
			if (documentData.sc) {
				hasStroke = true;
				this.values.stroke = this.buildColor(documentData.sc);
				this.values.sWidth = documentData.sw;
			}
			var fontData = this.globalData.fontManager.getFontByName(documentData.f);
			var i;
			var len;
			var letters = documentData.l;
			var matrixHelper = this.mHelper;
			this.stroke = hasStroke;
			this.values.fValue = documentData.finalSize + "px " + this.globalData.fontManager.getFontByName(documentData.f).fFamily;
			len = documentData.finalText.length;
			var charData;
			var shapeData;
			var k;
			var kLen;
			var shapes;
			var j;
			var jLen;
			var pathNodes;
			var commands;
			var pathArr;
			var singleShape = this.data.singleShape;
			var trackingOffset = documentData.tr * .001 * documentData.finalSize;
			var xPos = 0;
			var yPos = 0;
			var firstLine = true;
			var cnt = 0;
			for (i = 0; i < len; i += 1) {
				charData = this.globalData.fontManager.getCharData(documentData.finalText[i], fontData.fStyle, this.globalData.fontManager.getFontByName(documentData.f).fFamily);
				shapeData = charData && charData.data || {};
				matrixHelper.reset();
				if (singleShape && letters[i].n) {
					xPos = -trackingOffset;
					yPos += documentData.yOffset;
					yPos += firstLine ? 1 : 0;
					firstLine = false;
				}
				shapes = shapeData.shapes ? shapeData.shapes[0].it : [];
				jLen = shapes.length;
				matrixHelper.scale(documentData.finalSize / 100, documentData.finalSize / 100);
				if (singleShape) this.applyTextPropertiesToMatrix(documentData, matrixHelper, letters[i].line, xPos, yPos);
				commands = createSizedArray(jLen - 1);
				var commandsCounter = 0;
				for (j = 0; j < jLen; j += 1) if (shapes[j].ty === "sh") {
					kLen = shapes[j].ks.k.i.length;
					pathNodes = shapes[j].ks.k;
					pathArr = [];
					for (k = 1; k < kLen; k += 1) {
						if (k === 1) pathArr.push(matrixHelper.applyToX(pathNodes.v[0][0], pathNodes.v[0][1], 0), matrixHelper.applyToY(pathNodes.v[0][0], pathNodes.v[0][1], 0));
						pathArr.push(matrixHelper.applyToX(pathNodes.o[k - 1][0], pathNodes.o[k - 1][1], 0), matrixHelper.applyToY(pathNodes.o[k - 1][0], pathNodes.o[k - 1][1], 0), matrixHelper.applyToX(pathNodes.i[k][0], pathNodes.i[k][1], 0), matrixHelper.applyToY(pathNodes.i[k][0], pathNodes.i[k][1], 0), matrixHelper.applyToX(pathNodes.v[k][0], pathNodes.v[k][1], 0), matrixHelper.applyToY(pathNodes.v[k][0], pathNodes.v[k][1], 0));
					}
					pathArr.push(matrixHelper.applyToX(pathNodes.o[k - 1][0], pathNodes.o[k - 1][1], 0), matrixHelper.applyToY(pathNodes.o[k - 1][0], pathNodes.o[k - 1][1], 0), matrixHelper.applyToX(pathNodes.i[0][0], pathNodes.i[0][1], 0), matrixHelper.applyToY(pathNodes.i[0][0], pathNodes.i[0][1], 0), matrixHelper.applyToX(pathNodes.v[0][0], pathNodes.v[0][1], 0), matrixHelper.applyToY(pathNodes.v[0][0], pathNodes.v[0][1], 0));
					commands[commandsCounter] = pathArr;
					commandsCounter += 1;
				}
				if (singleShape) {
					xPos += letters[i].l;
					xPos += trackingOffset;
				}
				if (this.textSpans[cnt]) this.textSpans[cnt].elem = commands;
				else this.textSpans[cnt] = { elem: commands };
				cnt += 1;
			}
		};
		CVTextElement.prototype.renderInnerContent = function() {
			this.validateText();
			var ctx = this.canvasContext;
			ctx.font = this.values.fValue;
			this.globalData.renderer.ctxLineCap("butt");
			this.globalData.renderer.ctxLineJoin("miter");
			this.globalData.renderer.ctxMiterLimit(4);
			if (!this.data.singleShape) this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag);
			var i;
			var len;
			var j;
			var jLen;
			var k;
			var kLen;
			var renderedLetters = this.textAnimator.renderedLetters;
			var letters = this.textProperty.currentData.l;
			len = letters.length;
			var renderedLetter;
			var lastFill = null;
			var lastStroke = null;
			var lastStrokeW = null;
			var commands;
			var pathArr;
			var renderer = this.globalData.renderer;
			for (i = 0; i < len; i += 1) if (!letters[i].n) {
				renderedLetter = renderedLetters[i];
				if (renderedLetter) {
					renderer.save();
					renderer.ctxTransform(renderedLetter.p);
					renderer.ctxOpacity(renderedLetter.o);
				}
				if (this.fill) {
					if (renderedLetter && renderedLetter.fc) {
						if (lastFill !== renderedLetter.fc) {
							renderer.ctxFillStyle(renderedLetter.fc);
							lastFill = renderedLetter.fc;
						}
					} else if (lastFill !== this.values.fill) {
						lastFill = this.values.fill;
						renderer.ctxFillStyle(this.values.fill);
					}
					commands = this.textSpans[i].elem;
					jLen = commands.length;
					this.globalData.canvasContext.beginPath();
					for (j = 0; j < jLen; j += 1) {
						pathArr = commands[j];
						kLen = pathArr.length;
						this.globalData.canvasContext.moveTo(pathArr[0], pathArr[1]);
						for (k = 2; k < kLen; k += 6) this.globalData.canvasContext.bezierCurveTo(pathArr[k], pathArr[k + 1], pathArr[k + 2], pathArr[k + 3], pathArr[k + 4], pathArr[k + 5]);
					}
					this.globalData.canvasContext.closePath();
					renderer.ctxFill();
				}
				if (this.stroke) {
					if (renderedLetter && renderedLetter.sw) {
						if (lastStrokeW !== renderedLetter.sw) {
							lastStrokeW = renderedLetter.sw;
							renderer.ctxLineWidth(renderedLetter.sw);
						}
					} else if (lastStrokeW !== this.values.sWidth) {
						lastStrokeW = this.values.sWidth;
						renderer.ctxLineWidth(this.values.sWidth);
					}
					if (renderedLetter && renderedLetter.sc) {
						if (lastStroke !== renderedLetter.sc) {
							lastStroke = renderedLetter.sc;
							renderer.ctxStrokeStyle(renderedLetter.sc);
						}
					} else if (lastStroke !== this.values.stroke) {
						lastStroke = this.values.stroke;
						renderer.ctxStrokeStyle(this.values.stroke);
					}
					commands = this.textSpans[i].elem;
					jLen = commands.length;
					this.globalData.canvasContext.beginPath();
					for (j = 0; j < jLen; j += 1) {
						pathArr = commands[j];
						kLen = pathArr.length;
						this.globalData.canvasContext.moveTo(pathArr[0], pathArr[1]);
						for (k = 2; k < kLen; k += 6) this.globalData.canvasContext.bezierCurveTo(pathArr[k], pathArr[k + 1], pathArr[k + 2], pathArr[k + 3], pathArr[k + 4], pathArr[k + 5]);
					}
					this.globalData.canvasContext.closePath();
					renderer.ctxStroke();
				}
				if (renderedLetter) this.globalData.renderer.restore();
			}
		};
		function CVImageElement(data, globalData, comp) {
			this.assetData = globalData.getAssetData(data.refId);
			this.img = globalData.imageLoader.getAsset(this.assetData);
			this.initElement(data, globalData, comp);
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			CVBaseElement,
			HierarchyElement,
			FrameElement,
			RenderableElement
		], CVImageElement);
		CVImageElement.prototype.initElement = SVGShapeElement.prototype.initElement;
		CVImageElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame;
		CVImageElement.prototype.createContent = function() {
			if (this.img.width && (this.assetData.w !== this.img.width || this.assetData.h !== this.img.height)) {
				var canvas = createTag("canvas");
				canvas.width = this.assetData.w;
				canvas.height = this.assetData.h;
				var ctx = canvas.getContext("2d");
				var imgW = this.img.width;
				var imgH = this.img.height;
				var imgRel = imgW / imgH;
				var canvasRel = this.assetData.w / this.assetData.h;
				var widthCrop;
				var heightCrop;
				var par = this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio;
				if (imgRel > canvasRel && par === "xMidYMid slice" || imgRel < canvasRel && par !== "xMidYMid slice") {
					heightCrop = imgH;
					widthCrop = heightCrop * canvasRel;
				} else {
					widthCrop = imgW;
					heightCrop = widthCrop / canvasRel;
				}
				ctx.drawImage(this.img, (imgW - widthCrop) / 2, (imgH - heightCrop) / 2, widthCrop, heightCrop, 0, 0, this.assetData.w, this.assetData.h);
				this.img = canvas;
			}
		};
		CVImageElement.prototype.renderInnerContent = function() {
			this.canvasContext.drawImage(this.img, 0, 0);
		};
		CVImageElement.prototype.destroy = function() {
			this.img = null;
		};
		function CVSolidElement(data, globalData, comp) {
			this.initElement(data, globalData, comp);
		}
		extendPrototype([
			BaseElement,
			TransformElement,
			CVBaseElement,
			HierarchyElement,
			FrameElement,
			RenderableElement
		], CVSolidElement);
		CVSolidElement.prototype.initElement = SVGShapeElement.prototype.initElement;
		CVSolidElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame;
		CVSolidElement.prototype.renderInnerContent = function() {
			this.globalData.renderer.ctxFillStyle(this.data.sc);
			this.globalData.renderer.ctxFillRect(0, 0, this.data.sw, this.data.sh);
		};
		function CanvasRendererBase() {}
		extendPrototype([BaseRenderer], CanvasRendererBase);
		CanvasRendererBase.prototype.createShape = function(data) {
			return new CVShapeElement(data, this.globalData, this);
		};
		CanvasRendererBase.prototype.createText = function(data) {
			return new CVTextElement(data, this.globalData, this);
		};
		CanvasRendererBase.prototype.createImage = function(data) {
			return new CVImageElement(data, this.globalData, this);
		};
		CanvasRendererBase.prototype.createSolid = function(data) {
			return new CVSolidElement(data, this.globalData, this);
		};
		CanvasRendererBase.prototype.createNull = SVGRenderer.prototype.createNull;
		CanvasRendererBase.prototype.ctxTransform = function(props) {
			if (props[0] === 1 && props[1] === 0 && props[4] === 0 && props[5] === 1 && props[12] === 0 && props[13] === 0) return;
			this.canvasContext.transform(props[0], props[1], props[4], props[5], props[12], props[13]);
		};
		CanvasRendererBase.prototype.ctxOpacity = function(op) {
			this.canvasContext.globalAlpha *= op < 0 ? 0 : op;
		};
		CanvasRendererBase.prototype.ctxFillStyle = function(value) {
			this.canvasContext.fillStyle = value;
		};
		CanvasRendererBase.prototype.ctxStrokeStyle = function(value) {
			this.canvasContext.strokeStyle = value;
		};
		CanvasRendererBase.prototype.ctxLineWidth = function(value) {
			this.canvasContext.lineWidth = value;
		};
		CanvasRendererBase.prototype.ctxLineCap = function(value) {
			this.canvasContext.lineCap = value;
		};
		CanvasRendererBase.prototype.ctxLineJoin = function(value) {
			this.canvasContext.lineJoin = value;
		};
		CanvasRendererBase.prototype.ctxMiterLimit = function(value) {
			this.canvasContext.miterLimit = value;
		};
		CanvasRendererBase.prototype.ctxFill = function(rule) {
			this.canvasContext.fill(rule);
		};
		CanvasRendererBase.prototype.ctxFillRect = function(x, y, w, h) {
			this.canvasContext.fillRect(x, y, w, h);
		};
		CanvasRendererBase.prototype.ctxStroke = function() {
			this.canvasContext.stroke();
		};
		CanvasRendererBase.prototype.reset = function() {
			if (!this.renderConfig.clearCanvas) {
				this.canvasContext.restore();
				return;
			}
			this.contextData.reset();
		};
		CanvasRendererBase.prototype.save = function() {
			this.canvasContext.save();
		};
		CanvasRendererBase.prototype.restore = function(actionFlag) {
			if (!this.renderConfig.clearCanvas) {
				this.canvasContext.restore();
				return;
			}
			if (actionFlag) this.globalData.blendMode = "source-over";
			this.contextData.restore(actionFlag);
		};
		CanvasRendererBase.prototype.configAnimation = function(animData) {
			if (this.animationItem.wrapper) {
				this.animationItem.container = createTag("canvas");
				var containerStyle = this.animationItem.container.style;
				containerStyle.width = "100%";
				containerStyle.height = "100%";
				var origin = "0px 0px 0px";
				containerStyle.transformOrigin = origin;
				containerStyle.mozTransformOrigin = origin;
				containerStyle.webkitTransformOrigin = origin;
				containerStyle["-webkit-transform"] = origin;
				containerStyle.contentVisibility = this.renderConfig.contentVisibility;
				this.animationItem.wrapper.appendChild(this.animationItem.container);
				this.canvasContext = this.animationItem.container.getContext("2d");
				if (this.renderConfig.className) this.animationItem.container.setAttribute("class", this.renderConfig.className);
				if (this.renderConfig.id) this.animationItem.container.setAttribute("id", this.renderConfig.id);
			} else this.canvasContext = this.renderConfig.context;
			this.contextData.setContext(this.canvasContext);
			this.data = animData;
			this.layers = animData.layers;
			this.transformCanvas = {
				w: animData.w,
				h: animData.h,
				sx: 0,
				sy: 0,
				tx: 0,
				ty: 0
			};
			this.setupGlobalData(animData, document.body);
			this.globalData.canvasContext = this.canvasContext;
			this.globalData.renderer = this;
			this.globalData.isDashed = false;
			this.globalData.progressiveLoad = this.renderConfig.progressiveLoad;
			this.globalData.transformCanvas = this.transformCanvas;
			this.elements = createSizedArray(animData.layers.length);
			this.updateContainerSize();
		};
		CanvasRendererBase.prototype.updateContainerSize = function(width, height) {
			this.reset();
			var elementWidth;
			var elementHeight;
			if (width) {
				elementWidth = width;
				elementHeight = height;
				this.canvasContext.canvas.width = elementWidth;
				this.canvasContext.canvas.height = elementHeight;
			} else {
				if (this.animationItem.wrapper && this.animationItem.container) {
					elementWidth = this.animationItem.wrapper.offsetWidth;
					elementHeight = this.animationItem.wrapper.offsetHeight;
				} else {
					elementWidth = this.canvasContext.canvas.width;
					elementHeight = this.canvasContext.canvas.height;
				}
				this.canvasContext.canvas.width = elementWidth * this.renderConfig.dpr;
				this.canvasContext.canvas.height = elementHeight * this.renderConfig.dpr;
			}
			var elementRel;
			var animationRel;
			if (this.renderConfig.preserveAspectRatio.indexOf("meet") !== -1 || this.renderConfig.preserveAspectRatio.indexOf("slice") !== -1) {
				var par = this.renderConfig.preserveAspectRatio.split(" ");
				var fillType = par[1] || "meet";
				var pos = par[0] || "xMidYMid";
				var xPos = pos.substr(0, 4);
				var yPos = pos.substr(4);
				elementRel = elementWidth / elementHeight;
				animationRel = this.transformCanvas.w / this.transformCanvas.h;
				if (animationRel > elementRel && fillType === "meet" || animationRel < elementRel && fillType === "slice") {
					this.transformCanvas.sx = elementWidth / (this.transformCanvas.w / this.renderConfig.dpr);
					this.transformCanvas.sy = elementWidth / (this.transformCanvas.w / this.renderConfig.dpr);
				} else {
					this.transformCanvas.sx = elementHeight / (this.transformCanvas.h / this.renderConfig.dpr);
					this.transformCanvas.sy = elementHeight / (this.transformCanvas.h / this.renderConfig.dpr);
				}
				if (xPos === "xMid" && (animationRel < elementRel && fillType === "meet" || animationRel > elementRel && fillType === "slice")) this.transformCanvas.tx = (elementWidth - this.transformCanvas.w * (elementHeight / this.transformCanvas.h)) / 2 * this.renderConfig.dpr;
				else if (xPos === "xMax" && (animationRel < elementRel && fillType === "meet" || animationRel > elementRel && fillType === "slice")) this.transformCanvas.tx = (elementWidth - this.transformCanvas.w * (elementHeight / this.transformCanvas.h)) * this.renderConfig.dpr;
				else this.transformCanvas.tx = 0;
				if (yPos === "YMid" && (animationRel > elementRel && fillType === "meet" || animationRel < elementRel && fillType === "slice")) this.transformCanvas.ty = (elementHeight - this.transformCanvas.h * (elementWidth / this.transformCanvas.w)) / 2 * this.renderConfig.dpr;
				else if (yPos === "YMax" && (animationRel > elementRel && fillType === "meet" || animationRel < elementRel && fillType === "slice")) this.transformCanvas.ty = (elementHeight - this.transformCanvas.h * (elementWidth / this.transformCanvas.w)) * this.renderConfig.dpr;
				else this.transformCanvas.ty = 0;
			} else if (this.renderConfig.preserveAspectRatio === "none") {
				this.transformCanvas.sx = elementWidth / (this.transformCanvas.w / this.renderConfig.dpr);
				this.transformCanvas.sy = elementHeight / (this.transformCanvas.h / this.renderConfig.dpr);
				this.transformCanvas.tx = 0;
				this.transformCanvas.ty = 0;
			} else {
				this.transformCanvas.sx = this.renderConfig.dpr;
				this.transformCanvas.sy = this.renderConfig.dpr;
				this.transformCanvas.tx = 0;
				this.transformCanvas.ty = 0;
			}
			this.transformCanvas.props = [
				this.transformCanvas.sx,
				0,
				0,
				0,
				0,
				this.transformCanvas.sy,
				0,
				0,
				0,
				0,
				1,
				0,
				this.transformCanvas.tx,
				this.transformCanvas.ty,
				0,
				1
			];
			this.ctxTransform(this.transformCanvas.props);
			this.canvasContext.beginPath();
			this.canvasContext.rect(0, 0, this.transformCanvas.w, this.transformCanvas.h);
			this.canvasContext.closePath();
			this.canvasContext.clip();
			this.renderFrame(this.renderedFrame, true);
		};
		CanvasRendererBase.prototype.destroy = function() {
			if (this.renderConfig.clearCanvas && this.animationItem.wrapper) this.animationItem.wrapper.innerText = "";
			var i;
			for (i = (this.layers ? this.layers.length : 0) - 1; i >= 0; i -= 1) if (this.elements[i] && this.elements[i].destroy) this.elements[i].destroy();
			this.elements.length = 0;
			this.globalData.canvasContext = null;
			this.animationItem.container = null;
			this.destroyed = true;
		};
		CanvasRendererBase.prototype.renderFrame = function(num, forceRender) {
			if (this.renderedFrame === num && this.renderConfig.clearCanvas === true && !forceRender || this.destroyed || num === -1) return;
			this.renderedFrame = num;
			this.globalData.frameNum = num - this.animationItem._isFirstFrame;
			this.globalData.frameId += 1;
			this.globalData._mdf = !this.renderConfig.clearCanvas || forceRender;
			this.globalData.projectInterface.currentFrame = num;
			var i;
			var len = this.layers.length;
			if (!this.completeLayers) this.checkLayers(num);
			for (i = len - 1; i >= 0; i -= 1) if (this.completeLayers || this.elements[i]) this.elements[i].prepareFrame(num - this.layers[i].st);
			if (this.globalData._mdf) {
				if (this.renderConfig.clearCanvas === true) this.canvasContext.clearRect(0, 0, this.transformCanvas.w, this.transformCanvas.h);
				else this.save();
				for (i = len - 1; i >= 0; i -= 1) if (this.completeLayers || this.elements[i]) this.elements[i].renderFrame();
				if (this.renderConfig.clearCanvas !== true) this.restore();
			}
		};
		CanvasRendererBase.prototype.buildItem = function(pos) {
			var elements = this.elements;
			if (elements[pos] || this.layers[pos].ty === 99) return;
			var element = this.createItem(this.layers[pos], this, this.globalData);
			elements[pos] = element;
			element.initExpressions();
		};
		CanvasRendererBase.prototype.checkPendingElements = function() {
			while (this.pendingElements.length) this.pendingElements.pop().checkParenting();
		};
		CanvasRendererBase.prototype.hide = function() {
			this.animationItem.container.style.display = "none";
		};
		CanvasRendererBase.prototype.show = function() {
			this.animationItem.container.style.display = "block";
		};
		function CanvasContext() {
			this.opacity = -1;
			this.transform = createTypedArray("float32", 16);
			this.fillStyle = "";
			this.strokeStyle = "";
			this.lineWidth = "";
			this.lineCap = "";
			this.lineJoin = "";
			this.miterLimit = "";
			this.id = Math.random();
		}
		function CVContextData() {
			this.stack = [];
			this.cArrPos = 0;
			this.cTr = new Matrix();
			var i;
			var len = 15;
			for (i = 0; i < len; i += 1) {
				var canvasContext = new CanvasContext();
				this.stack[i] = canvasContext;
			}
			this._length = len;
			this.nativeContext = null;
			this.transformMat = new Matrix();
			this.currentOpacity = 1;
			this.currentFillStyle = "";
			this.appliedFillStyle = "";
			this.currentStrokeStyle = "";
			this.appliedStrokeStyle = "";
			this.currentLineWidth = "";
			this.appliedLineWidth = "";
			this.currentLineCap = "";
			this.appliedLineCap = "";
			this.currentLineJoin = "";
			this.appliedLineJoin = "";
			this.appliedMiterLimit = "";
			this.currentMiterLimit = "";
		}
		CVContextData.prototype.duplicate = function() {
			var newLength = this._length * 2;
			var i = 0;
			for (i = this._length; i < newLength; i += 1) this.stack[i] = new CanvasContext();
			this._length = newLength;
		};
		CVContextData.prototype.reset = function() {
			this.cArrPos = 0;
			this.cTr.reset();
			this.stack[this.cArrPos].opacity = 1;
		};
		CVContextData.prototype.restore = function(forceRestore) {
			this.cArrPos -= 1;
			var currentContext = this.stack[this.cArrPos];
			var transform = currentContext.transform;
			var i;
			var arr = this.cTr.props;
			for (i = 0; i < 16; i += 1) arr[i] = transform[i];
			if (forceRestore) {
				this.nativeContext.restore();
				var prevStack = this.stack[this.cArrPos + 1];
				this.appliedFillStyle = prevStack.fillStyle;
				this.appliedStrokeStyle = prevStack.strokeStyle;
				this.appliedLineWidth = prevStack.lineWidth;
				this.appliedLineCap = prevStack.lineCap;
				this.appliedLineJoin = prevStack.lineJoin;
				this.appliedMiterLimit = prevStack.miterLimit;
			}
			this.nativeContext.setTransform(transform[0], transform[1], transform[4], transform[5], transform[12], transform[13]);
			if (forceRestore || currentContext.opacity !== -1 && this.currentOpacity !== currentContext.opacity) {
				this.nativeContext.globalAlpha = currentContext.opacity;
				this.currentOpacity = currentContext.opacity;
			}
			this.currentFillStyle = currentContext.fillStyle;
			this.currentStrokeStyle = currentContext.strokeStyle;
			this.currentLineWidth = currentContext.lineWidth;
			this.currentLineCap = currentContext.lineCap;
			this.currentLineJoin = currentContext.lineJoin;
			this.currentMiterLimit = currentContext.miterLimit;
		};
		CVContextData.prototype.save = function(saveOnNativeFlag) {
			if (saveOnNativeFlag) this.nativeContext.save();
			var props = this.cTr.props;
			if (this._length <= this.cArrPos) this.duplicate();
			var currentStack = this.stack[this.cArrPos];
			var i;
			for (i = 0; i < 16; i += 1) currentStack.transform[i] = props[i];
			this.cArrPos += 1;
			var newStack = this.stack[this.cArrPos];
			newStack.opacity = currentStack.opacity;
			newStack.fillStyle = currentStack.fillStyle;
			newStack.strokeStyle = currentStack.strokeStyle;
			newStack.lineWidth = currentStack.lineWidth;
			newStack.lineCap = currentStack.lineCap;
			newStack.lineJoin = currentStack.lineJoin;
			newStack.miterLimit = currentStack.miterLimit;
		};
		CVContextData.prototype.setOpacity = function(value) {
			this.stack[this.cArrPos].opacity = value;
		};
		CVContextData.prototype.setContext = function(value) {
			this.nativeContext = value;
		};
		CVContextData.prototype.fillStyle = function(value) {
			if (this.stack[this.cArrPos].fillStyle !== value) {
				this.currentFillStyle = value;
				this.stack[this.cArrPos].fillStyle = value;
			}
		};
		CVContextData.prototype.strokeStyle = function(value) {
			if (this.stack[this.cArrPos].strokeStyle !== value) {
				this.currentStrokeStyle = value;
				this.stack[this.cArrPos].strokeStyle = value;
			}
		};
		CVContextData.prototype.lineWidth = function(value) {
			if (this.stack[this.cArrPos].lineWidth !== value) {
				this.currentLineWidth = value;
				this.stack[this.cArrPos].lineWidth = value;
			}
		};
		CVContextData.prototype.lineCap = function(value) {
			if (this.stack[this.cArrPos].lineCap !== value) {
				this.currentLineCap = value;
				this.stack[this.cArrPos].lineCap = value;
			}
		};
		CVContextData.prototype.lineJoin = function(value) {
			if (this.stack[this.cArrPos].lineJoin !== value) {
				this.currentLineJoin = value;
				this.stack[this.cArrPos].lineJoin = value;
			}
		};
		CVContextData.prototype.miterLimit = function(value) {
			if (this.stack[this.cArrPos].miterLimit !== value) {
				this.currentMiterLimit = value;
				this.stack[this.cArrPos].miterLimit = value;
			}
		};
		CVContextData.prototype.transform = function(props) {
			this.transformMat.cloneFromProps(props);
			var currentTransform = this.cTr;
			this.transformMat.multiply(currentTransform);
			currentTransform.cloneFromProps(this.transformMat.props);
			var trProps = currentTransform.props;
			this.nativeContext.setTransform(trProps[0], trProps[1], trProps[4], trProps[5], trProps[12], trProps[13]);
		};
		CVContextData.prototype.opacity = function(op) {
			var currentOpacity = this.stack[this.cArrPos].opacity;
			currentOpacity *= op < 0 ? 0 : op;
			if (this.stack[this.cArrPos].opacity !== currentOpacity) {
				if (this.currentOpacity !== op) {
					this.nativeContext.globalAlpha = op;
					this.currentOpacity = op;
				}
				this.stack[this.cArrPos].opacity = currentOpacity;
			}
		};
		CVContextData.prototype.fill = function(rule) {
			if (this.appliedFillStyle !== this.currentFillStyle) {
				this.appliedFillStyle = this.currentFillStyle;
				this.nativeContext.fillStyle = this.appliedFillStyle;
			}
			this.nativeContext.fill(rule);
		};
		CVContextData.prototype.fillRect = function(x, y, w, h) {
			if (this.appliedFillStyle !== this.currentFillStyle) {
				this.appliedFillStyle = this.currentFillStyle;
				this.nativeContext.fillStyle = this.appliedFillStyle;
			}
			this.nativeContext.fillRect(x, y, w, h);
		};
		CVContextData.prototype.stroke = function() {
			if (this.appliedStrokeStyle !== this.currentStrokeStyle) {
				this.appliedStrokeStyle = this.currentStrokeStyle;
				this.nativeContext.strokeStyle = this.appliedStrokeStyle;
			}
			if (this.appliedLineWidth !== this.currentLineWidth) {
				this.appliedLineWidth = this.currentLineWidth;
				this.nativeContext.lineWidth = this.appliedLineWidth;
			}
			if (this.appliedLineCap !== this.currentLineCap) {
				this.appliedLineCap = this.currentLineCap;
				this.nativeContext.lineCap = this.appliedLineCap;
			}
			if (this.appliedLineJoin !== this.currentLineJoin) {
				this.appliedLineJoin = this.currentLineJoin;
				this.nativeContext.lineJoin = this.appliedLineJoin;
			}
			if (this.appliedMiterLimit !== this.currentMiterLimit) {
				this.appliedMiterLimit = this.currentMiterLimit;
				this.nativeContext.miterLimit = this.appliedMiterLimit;
			}
			this.nativeContext.stroke();
		};
		function CVCompElement(data, globalData, comp) {
			this.completeLayers = false;
			this.layers = data.layers;
			this.pendingElements = [];
			this.elements = createSizedArray(this.layers.length);
			this.initElement(data, globalData, comp);
			this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, globalData.frameRate, this) : { _placeholder: true };
		}
		extendPrototype([
			CanvasRendererBase,
			ICompElement,
			CVBaseElement
		], CVCompElement);
		CVCompElement.prototype.renderInnerContent = function() {
			var ctx = this.canvasContext;
			ctx.beginPath();
			ctx.moveTo(0, 0);
			ctx.lineTo(this.data.w, 0);
			ctx.lineTo(this.data.w, this.data.h);
			ctx.lineTo(0, this.data.h);
			ctx.lineTo(0, 0);
			ctx.clip();
			var i;
			for (i = this.layers.length - 1; i >= 0; i -= 1) if (this.completeLayers || this.elements[i]) this.elements[i].renderFrame();
		};
		CVCompElement.prototype.destroy = function() {
			var i;
			for (i = this.layers.length - 1; i >= 0; i -= 1) if (this.elements[i]) this.elements[i].destroy();
			this.layers = null;
			this.elements = null;
		};
		CVCompElement.prototype.createComp = function(data) {
			return new CVCompElement(data, this.globalData, this);
		};
		function CanvasRenderer(animationItem, config) {
			this.animationItem = animationItem;
			this.renderConfig = {
				clearCanvas: config && config.clearCanvas !== void 0 ? config.clearCanvas : true,
				context: config && config.context || null,
				progressiveLoad: config && config.progressiveLoad || false,
				preserveAspectRatio: config && config.preserveAspectRatio || "xMidYMid meet",
				imagePreserveAspectRatio: config && config.imagePreserveAspectRatio || "xMidYMid slice",
				contentVisibility: config && config.contentVisibility || "visible",
				className: config && config.className || "",
				id: config && config.id || "",
				runExpressions: !config || config.runExpressions === void 0 || config.runExpressions
			};
			this.renderConfig.dpr = config && config.dpr || 1;
			if (this.animationItem.wrapper) this.renderConfig.dpr = config && config.dpr || window.devicePixelRatio || 1;
			this.renderedFrame = -1;
			this.globalData = {
				frameNum: -1,
				_mdf: false,
				renderConfig: this.renderConfig,
				currentGlobalAlpha: -1
			};
			this.contextData = new CVContextData();
			this.elements = [];
			this.pendingElements = [];
			this.transformMat = new Matrix();
			this.completeLayers = false;
			this.rendererType = "canvas";
			if (this.renderConfig.clearCanvas) {
				this.ctxTransform = this.contextData.transform.bind(this.contextData);
				this.ctxOpacity = this.contextData.opacity.bind(this.contextData);
				this.ctxFillStyle = this.contextData.fillStyle.bind(this.contextData);
				this.ctxStrokeStyle = this.contextData.strokeStyle.bind(this.contextData);
				this.ctxLineWidth = this.contextData.lineWidth.bind(this.contextData);
				this.ctxLineCap = this.contextData.lineCap.bind(this.contextData);
				this.ctxLineJoin = this.contextData.lineJoin.bind(this.contextData);
				this.ctxMiterLimit = this.contextData.miterLimit.bind(this.contextData);
				this.ctxFill = this.contextData.fill.bind(this.contextData);
				this.ctxFillRect = this.contextData.fillRect.bind(this.contextData);
				this.ctxStroke = this.contextData.stroke.bind(this.contextData);
				this.save = this.contextData.save.bind(this.contextData);
			}
		}
		extendPrototype([CanvasRendererBase], CanvasRenderer);
		CanvasRenderer.prototype.createComp = function(data) {
			return new CVCompElement(data, this.globalData, this);
		};
		registerRenderer("canvas", CanvasRenderer);
		ShapeModifiers.registerModifier("tm", TrimModifier);
		ShapeModifiers.registerModifier("pb", PuckerAndBloatModifier);
		ShapeModifiers.registerModifier("rp", RepeaterModifier);
		ShapeModifiers.registerModifier("rd", RoundCornersModifier);
		ShapeModifiers.registerModifier("zz", ZigZagModifier);
		ShapeModifiers.registerModifier("op", OffsetPathModifier);
		return lottie;
	}));
})))(), 1);
var textFits = /* @__PURE__ */ new WeakMap();
var textFitCallbacks = /* @__PURE__ */ new WeakMap();
var lottieAnimations = /* @__PURE__ */ new WeakMap();
function findFittedFontSize(options) {
	const authored = Math.max(.1, options.authoredFontSize);
	const floor = options.mode === "shrink-to-fit" ? Math.min(authored, Math.max(1, options.minFontSize)) : .1;
	const rounded = (value) => Math.max(.1, Math.floor(value * 10) / 10);
	if (!options.fits(floor)) {
		const fontSize = rounded(floor);
		return {
			fontSize,
			ratio: fontSize / authored,
			degenerate: true
		};
	}
	let lower = floor;
	let upper = Math.max(floor, authored);
	if (options.mode === "fit-to-width" && options.fits(upper)) {
		lower = upper;
		while (upper < 16384) {
			const candidate = Math.min(16384, upper * 2);
			if (options.fits(candidate)) {
				lower = candidate;
				upper = candidate;
				if (candidate === 16384) break;
			} else {
				upper = candidate;
				break;
			}
		}
	}
	if (lower !== upper) for (let iteration = 0; iteration < 16; iteration++) {
		const candidate = (lower + upper) / 2;
		if (options.fits(candidate)) lower = candidate;
		else upper = candidate;
	}
	const fontSize = rounded(lower);
	return {
		fontSize,
		ratio: fontSize / authored,
		degenerate: false
	};
}
/** Disconnects text-fitting observation before a renderer discards a content host. */
function disposeElementContent(container) {
	lottieAnimations.get(container)?.animation.destroy();
	lottieAnimations.delete(container);
	const mountedFit = textFits.get(container);
	mountedFit?.observer?.disconnect();
	if (mountedFit?.fontSet && mountedFit.onFontsLoaded) mountedFit.fontSet.removeEventListener("loadingdone", mountedFit.onFontsLoaded);
	mountedFit?.probe?.remove();
	textFits.delete(container);
	textFitCallbacks.delete(container);
	container.replaceChildren();
	delete container.dataset.ografBasePaint;
}
function rememberPaint(container, paint) {
	container.dataset.ografBasePaint = JSON.stringify(paint);
}
/** Re-evaluates gradient-stop tracks against the currently rendered authored/data-bound paint. */
function applyAnimatedPaint(container, tracks, frame) {
	const directChild = container.firstElementChild;
	const renderHost = directChild?.classList?.contains("layer-content-host") ? directChild : container;
	const serialized = renderHost.dataset?.ografBasePaint;
	const content = renderHost.firstElementChild;
	if (!content) return;
	if (serialized) {
		const paint = JSON.parse(serialized);
		content.style.background = paintToCss(getPaintAtFrame(paint, tracks, frame));
	}
	const strokeTrack = tracks.strokeWidth ?? [];
	if (strokeTrack.length > 0) {
		const fallback = strokeTrack[0]?.value ?? 0;
		content.style.webkitTextStrokeWidth = `${Math.max(0, getTrackValueAtFrame(strokeTrack, frame, fallback))}px`;
		content.style.paintOrder = "stroke fill";
		textFitCallbacks.get(renderHost)?.();
	}
}
function applyTextStrokeStyle(style, strokeColor, strokeWidth) {
	style.webkitTextStrokeColor = strokeColor;
	style.webkitTextStrokeWidth = `${Math.max(0, strokeWidth)}px`;
	style.paintOrder = "stroke fill";
}
function applyContentBaseStyle(el) {
	el.style.width = "100%";
	el.style.height = "100%";
	el.style.boxSizing = "border-box";
	el.style.pointerEvents = "none";
	el.style.userSelect = "none";
}
/**
* Vanilla-DOM equivalent of the editor's LayerNode content rendering — no framework at runtime.
* `frameIndex` only matters for `image-sequence` (which frame of the flipbook to show). Lottie is
* mounted paused at its in-point and is subsequently driven by `renderAnimatedElementAtTime`.
*/
function renderElementContent(container, element, frameIndex = 0) {
	disposeElementContent(container);
	switch (element.type) {
		case "rectangle": {
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.background = paintToCss(element.fill);
			rememberPaint(container, element.fill);
			content.style.borderRadius = `${element.borderRadius}px`;
			if (element.strokeWidth > 0) content.style.border = `${element.strokeWidth}px solid ${element.strokeColor}`;
			container.appendChild(content);
			break;
		}
		case "ellipse": {
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.background = paintToCss(element.fill);
			rememberPaint(container, element.fill);
			content.style.borderRadius = "50%";
			if (element.strokeWidth > 0) content.style.border = `${element.strokeWidth}px solid ${element.strokeColor}`;
			container.appendChild(content);
			break;
		}
		case "text": {
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.color = element.color;
			applyTextStrokeStyle(content.style, element.strokeColor, element.strokeWidth);
			content.style.fontFamily = element.fontFamily;
			content.style.fontSize = `${element.fontSize}px`;
			content.style.fontWeight = String(element.fontWeight);
			content.style.textAlign = element.textAlign;
			content.style.letterSpacing = `${element.letterSpacing}px`;
			content.style.textTransform = element.textTransform;
			content.style.display = "flex";
			content.style.flexDirection = "column";
			content.style.justifyContent = element.verticalAlign === "middle" ? "center" : element.verticalAlign === "bottom" ? "flex-end" : "flex-start";
			content.style.transform = `translateY(${element.baselineShift}px)`;
			content.style.whiteSpace = element.autoFit === "auto-size" || element.autoFit === "fit-to-width" ? "pre" : element.overflowPolicy === "ellipsis" ? "nowrap" : "pre-wrap";
			content.style.lineHeight = element.autoFit === "shrink-to-fit" ? `${element.fontSize * element.lineHeight}px` : String(element.lineHeight);
			content.style.overflow = element.autoFit === "shrink-to-fit" || element.autoFit === "fit-to-width" || element.overflowPolicy !== "visible" ? "hidden" : "visible";
			content.style.textOverflow = element.overflowPolicy === "ellipsis" ? "ellipsis" : "clip";
			content.textContent = element.content;
			container.appendChild(content);
			if (element.autoFit === "shrink-to-fit" || element.autoFit === "fit-to-width") {
				const fitMode = element.autoFit;
				const mounted = {};
				if (fitMode === "fit-to-width") {
					const probe = content.cloneNode(true);
					Object.assign(probe.style, {
						position: "fixed",
						left: "-100000px",
						top: "0",
						visibility: "hidden",
						pointerEvents: "none",
						transform: "none",
						zIndex: "-1"
					});
					(document.body ?? document.documentElement).appendChild(probe);
					mounted.probe = probe;
				}
				const fit = () => {
					if (textFitCallbacks.get(container) !== fit) return;
					if (container.clientWidth <= 0 || container.clientHeight <= 0) return;
					if (element.content.length === 0) {
						content.style.fontSize = `${element.fontSize}px`;
						content.dataset.ografAppliedFontSize = String(element.fontSize);
						content.dataset.ografFitRatio = "1";
						content.dataset.ografFitDegenerate = "false";
						return;
					}
					const strokeExpansion = Math.max(0, Number.parseFloat(content.style.webkitTextStrokeWidth) || element.strokeWidth);
					const fits = (fontSize) => {
						if (fitMode === "shrink-to-fit") {
							content.style.fontSize = `${fontSize}px`;
							return content.scrollWidth + strokeExpansion <= container.clientWidth + .5 && content.scrollHeight + strokeExpansion <= container.clientHeight + .5;
						}
						const probe = mounted.probe;
						if (!probe) return false;
						probe.style.width = `${container.clientWidth}px`;
						probe.style.height = `${container.clientHeight}px`;
						probe.style.fontSize = `${fontSize}px`;
						probe.style.webkitTextStrokeWidth = content.style.webkitTextStrokeWidth;
						const range = document.createRange();
						range.selectNodeContents(probe);
						const bounds = range.getBoundingClientRect();
						range.detach();
						const availableHeight = Math.max(0, container.clientHeight - Math.abs(element.baselineShift));
						return bounds.width + strokeExpansion <= container.clientWidth + .5 && bounds.height + strokeExpansion <= availableHeight + .5;
					};
					const result = findFittedFontSize({
						mode: fitMode,
						authoredFontSize: element.fontSize,
						minFontSize: element.minFontSize,
						fits
					});
					content.style.fontSize = `${result.fontSize}px`;
					content.dataset.ografAppliedFontSize = String(result.fontSize);
					content.dataset.ografFitRatio = String(result.ratio);
					content.dataset.ografFitDegenerate = String(result.degenerate);
					if (fitMode === "shrink-to-fit") {
						content.dataset.ografShrinkRatio = String(result.ratio);
						content.dataset.ografShrinkDegenerate = String(result.degenerate);
					}
				};
				textFitCallbacks.set(container, fit);
				textFits.set(container, mounted);
				fit();
				if (typeof ResizeObserver !== "undefined") {
					const observer = new ResizeObserver(fit);
					observer.observe(container);
					mounted.observer = observer;
				}
				if (typeof document !== "undefined" && document.fonts) {
					const onFontsLoaded = () => fit();
					document.fonts.addEventListener("loadingdone", onFontsLoaded);
					document.fonts.ready.then(fit);
					mounted.fontSet = document.fonts;
					mounted.onFontsLoaded = onFontsLoaded;
				}
			}
			break;
		}
		case "image":
			if (element.src) {
				const img = document.createElement("img");
				applyContentBaseStyle(img);
				img.style.objectFit = "contain";
				img.src = element.src;
				img.alt = "";
				img.draggable = false;
				container.appendChild(img);
			}
			break;
		case "path": {
			const SVG_NS = "http://www.w3.org/2000/svg";
			const svg = document.createElementNS(SVG_NS, "svg");
			applyContentBaseStyle(svg);
			svg.setAttribute("viewBox", `0 0 ${element.viewBoxWidth} ${element.viewBoxHeight}`);
			svg.setAttribute("preserveAspectRatio", "none");
			const path = document.createElementNS(SVG_NS, "path");
			path.setAttribute("d", element.d);
			path.setAttribute("fill", element.fill);
			path.setAttribute("stroke", element.strokeWidth > 0 ? element.strokeColor : "none");
			path.setAttribute("stroke-width", String(element.strokeWidth));
			svg.appendChild(path);
			container.appendChild(svg);
			break;
		}
		case "image-sequence": {
			const src = element.frames.length > 0 ? element.frames[frameIndex % element.frames.length] : void 0;
			if (src) {
				const img = document.createElement("img");
				applyContentBaseStyle(img);
				img.style.objectFit = "contain";
				img.src = src;
				img.alt = "";
				img.draggable = false;
				container.appendChild(img);
			}
			break;
		}
		case "lottie": {
			if (!element.animationData) break;
			const content = document.createElement("div");
			applyContentBaseStyle(content);
			content.style.overflow = "hidden";
			container.appendChild(content);
			const animation = import_lottie_light_canvas.default.loadAnimation({
				container: content,
				renderer: "canvas",
				loop: false,
				autoplay: false,
				animationData: JSON.parse(JSON.stringify(element.animationData)),
				rendererSettings: {
					clearCanvas: true,
					preserveAspectRatio: "xMidYMid meet"
				}
			});
			animation.setSubframe(true);
			const mounted = {
				animation,
				width: -1,
				height: -1,
				desiredFrame: element.animationData.ip
			};
			animation.addEventListener("DOMLoaded", () => {
				animation.resize(container.clientWidth, container.clientHeight);
				animation.goToAndStop(mounted.desiredFrame, true);
			});
			animation.goToAndStop(mounted.desiredFrame, true);
			lottieAnimations.set(container, mounted);
			break;
		}
	}
}
/** Updates self-animated content from an absolute clock without remounting its DOM/player. */
function renderAnimatedElementAtTime(container, element, elapsedMs) {
	if (element.type === "image-sequence") {
		if (element.frames.length === 0) return;
		const rawFrame = Math.max(0, Math.floor(elapsedMs / 1e3 * Math.max(1, element.fps)));
		const frameIndex = element.loop ? rawFrame % element.frames.length : Math.min(rawFrame, element.frames.length - 1);
		const image = container.firstElementChild;
		const src = element.frames[frameIndex];
		if (image?.tagName === "IMG" && src) image.src = src;
		else renderElementContent(container, element, frameIndex);
		return;
	}
	if (element.type === "lottie" && element.animationData) {
		const mounted = lottieAnimations.get(container);
		if (!mounted) return;
		mounted.desiredFrame = lottieFrameAtTime(element, elapsedMs);
		const width = container.clientWidth;
		const height = container.clientHeight;
		if (width !== mounted.width || height !== mounted.height) {
			mounted.width = width;
			mounted.height = height;
			if (width > 0 && height > 0) mounted.animation.resize(width, height);
		}
		mounted.animation.goToAndStop(mounted.desiredFrame, true);
	}
}
/**
* The element a compiled layer should render with, given runtime data — mirrors the editor's
* design-time `resolveEffectiveElement` (apps/editor/src/state/dataBinding.ts), adapted to the
* compiled descriptor's shape (data keyed by field `key`, not `fieldId`). All current bindable
* properties are string-typed, so the override always stringifies.
*/
function resolveBoundElement(layer, data) {
	return (layer.bindings ?? (layer.binding ? [layer.binding] : [])).reduce((element, binding) => {
		const root = data[binding.dataKey];
		const value = valueAtSourcePath(binding.itemIndex === void 0 ? root : Array.isArray(root) ? root[binding.itemIndex] : void 0, binding.sourcePath);
		if (value === void 0) return element;
		const mappedValue = binding.valueMap?.[String(value)] ?? value;
		const resolvedValue = binding.targetProperty === "fill" && mappedValue && typeof mappedValue === "object" ? mappedValue : String(mappedValue);
		return {
			...element,
			[binding.targetProperty]: resolvedValue
		};
	}, layer.element);
}
//#endregion
//#region src/buildRuntimeTimeline.ts
var DIRECT_GSAP_PROPERTIES = {
	x: "x",
	y: "y",
	width: "width",
	height: "height",
	rotation: "rotation",
	opacity: "opacity"
};
function compiledPoseAtFrame(layer, frame) {
	const first = [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform;
	if (!first) throw new Error(`Compiled layer "${layer.id}" has no transform key.`);
	return Object.fromEntries(TRANSFORM_ANIMATION_PROPERTIES.map((property) => [property, getTrackValueAtFrame(layer.animationTracks[property] ?? [], frame, first[property])]));
}
/**
* Builds one paused GSAP timeline spanning every keyframe in sequence, from an already-compiled
* descriptor (frame positions precomputed — this never re-derives them, unlike the editor's own
* apps/editor/src/canvas/masterTimeline.ts, which builds the analogous authoring-time timeline
* directly from Composition data). Layers are first snapped to Keyframe 0's pose via `gsap.set`
* so the first tween in the chain has a correct "from" value.
*/
function buildRuntimeTimeline(descriptor, layerEls) {
	const tl = gsapWithCSS.timeline({ paused: true });
	const frameRate = descriptor.frameRate;
	const applyInitialStates = [];
	for (const keyframe of descriptor.keyframes) tl.addLabel(keyframe.id, keyframe.frame / frameRate);
	for (const layer of descriptor.layers) {
		const el = layerEls.get(layer.id);
		if (!el) continue;
		const tracks = layer.animationTracks;
		const firstTransform = Object.fromEntries(TRANSFORM_ANIMATION_PROPERTIES.map((property) => [property, [...tracks[property] ?? []].sort((a, b) => a.frame - b.frame)[0]?.value ?? [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform[property] ?? 0]));
		const originState = {
			transformOriginX: firstTransform.transformOriginX,
			transformOriginY: firstTransform.transformOriginY
		};
		const effectState = { ...layer.effects };
		for (const property of EFFECT_ANIMATION_PROPERTIES) {
			const first = [...tracks[property] ?? []].sort((a, b) => a.frame - b.frame)[0];
			if (first) effectState[property] = first.value;
		}
		const firstEffects = { ...effectState };
		const updateOrigin = () => {
			el.style.transformOrigin = `${originState.transformOriginX * 100}% ${originState.transformOriginY * 100}%`;
		};
		const updateEffects = () => {
			el.style.filter = layerEffectsToCssFilter(effectState);
		};
		const applyInitialState = () => {
			originState.transformOriginX = firstTransform.transformOriginX;
			originState.transformOriginY = firstTransform.transformOriginY;
			Object.assign(effectState, firstEffects);
			gsapWithCSS.set(el, {
				x: firstTransform.x,
				y: firstTransform.y,
				width: firstTransform.width,
				height: firstTransform.height,
				rotation: firstTransform.rotation,
				opacity: firstTransform.opacity,
				transformOrigin: `${firstTransform.transformOriginX * 100}% ${firstTransform.transformOriginY * 100}%`
			});
			updateEffects();
		};
		applyInitialStates.push(applyInitialState);
		applyInitialState();
		for (const property of Object.keys(tracks)) {
			if (isGradientStopOffsetProperty(property) || property === "strokeWidth") continue;
			const keyframes = [...tracks[property] ?? []].sort((a, b) => a.frame - b.frame);
			for (let index = 1; index < keyframes.length; index++) {
				const from = keyframes[index - 1];
				const to = keyframes[index];
				const common = {
					duration: (to.frame - from.frame) / frameRate,
					ease: easingForGsap(to.easing, to.curve)
				};
				const directProperty = DIRECT_GSAP_PROPERTIES[property];
				if (directProperty) tl.to(el, {
					[directProperty]: to.value,
					...common
				}, from.frame / frameRate);
				else if (property === "transformOriginX" || property === "transformOriginY") tl.to(originState, {
					[property]: to.value,
					...common,
					onUpdate: updateOrigin
				}, from.frame / frameRate);
				else tl.to(effectState, {
					[property]: to.value,
					...common,
					onUpdate: updateEffects
				}, from.frame / frameRate);
			}
		}
	}
	const endFrame = descriptor.keyframes.at(-1)?.frame ?? 0;
	const updateDynamicRendering = () => {
		const frame = tl.time() * frameRate;
		for (const layer of descriptor.layers) {
			const child = layerEls.get(layer.id);
			if (child) applyAnimatedPaint(child, layer.animationTracks, frame);
			if (!layer.clipParentId) continue;
			const parent = layerEls.get(layer.clipParentId);
			if (!child || !parent) {
				if (child) child.style.clipPath = "inset(50%)";
				continue;
			}
			const parentLayer = descriptor.layers.find((candidate) => candidate.id === layer.clipParentId);
			const radius = parentLayer?.element.type === "rectangle" ? parentLayer.element.borderRadius : 0;
			if (parentLayer) child.style.clipPath = clipPathForParentBounds(compiledPoseAtFrame(layer, frame), compiledPoseAtFrame(parentLayer, frame), radius);
		}
	};
	if (descriptor.layers.some((layer) => layer.clipParentId || Object.keys(layer.animationTracks).some((property) => isGradientStopOffsetProperty(property) || property === "strokeWidth"))) {
		tl.to({ progress: 0 }, {
			progress: 1,
			duration: endFrame / frameRate,
			ease: "none",
			onUpdate: updateDynamicRendering
		}, 0);
		updateDynamicRendering();
	}
	tl.to({}, { duration: 0 }, endFrame / frameRate);
	const nativeSeek = tl.seek.bind(tl);
	tl.seek = ((position, suppressEvents) => {
		const result = nativeSeek(position, suppressEvents);
		if (tl.time() === 0) for (const applyInitialState of applyInitialStates) applyInitialState();
		updateDynamicRendering();
		return result;
	});
	return tl;
}
//#endregion
//#region src/lifecycle.ts
/** Pure OGraf step resolution shared by realtime actions and non-realtime schedule replay. */
function resolvePlayTarget(stepKeyframeIds, startKeyframeId, endKeyframeId, currentStep, params) {
	const targetStep = params.goto ?? (currentStep ?? -1) + (params.delta ?? 1);
	if (targetStep < 0) return {
		keyframeId: startKeyframeId,
		currentStep: void 0
	};
	if (targetStep >= stepKeyframeIds.length) return {
		keyframeId: endKeyframeId,
		currentStep: void 0
	};
	return {
		keyframeId: stepKeyframeIds[targetStep],
		currentStep: targetStep
	};
}
//#endregion
//#region src/loopRendering.ts
function incomingProgress(layer, property, targetFrame, progress) {
	const targetKey = [...layer.animationTracks[property] ?? []].sort((left, right) => left.frame - right.frame).reverse().find((key) => key.frame <= targetFrame);
	if (!targetKey) return progress;
	return targetKey.curve ? cubicBezierProgress(progress, targetKey.curve) : easedProgress(progress, targetKey.easing);
}
function interpolate(from, to, progress) {
	return from + (to - from) * progress;
}
/**
* Interpolates directly between two already-resolved visual states. This is intentionally not a
* composition-frame sample: an OGraf stop from Step 1 to End must not expose Step 2 or Step 3 merely
* because those states sit between the source and End on the authoring ruler.
*/
function interpolateCompiledLayerVisualState(layer, source, target, progress, targetFrame) {
	const clampedProgress = Math.min(1, Math.max(0, progress));
	const transform = { ...source.transform };
	for (const property of TRANSFORM_ANIMATION_PROPERTIES) {
		const eased = incomingProgress(layer, property, targetFrame, clampedProgress);
		transform[property] = interpolate(source.transform[property], target.transform[property], eased);
	}
	const effects = { ...source.effects };
	for (const property of EFFECT_ANIMATION_PROPERTIES) {
		const eased = incomingProgress(layer, property, targetFrame, clampedProgress);
		effects[property] = interpolate(source.effects[property], target.effects[property], eased);
	}
	const paintTracks = {};
	const paintProperties = /* @__PURE__ */ new Set([...Object.keys(source.paintTracks), ...Object.keys(target.paintTracks)]);
	for (const property of paintProperties) {
		if (!isGradientStopOffsetProperty(property) && property !== "strokeWidth") continue;
		const from = source.paintTracks[property]?.[0]?.value ?? 0;
		const to = target.paintTracks[property]?.[0]?.value ?? from;
		const eased = incomingProgress(layer, property, targetFrame, clampedProgress);
		paintTracks[property] = [{
			id: `${layer.id}:${property}:transition`,
			frame: 0,
			value: interpolate(from, to, eased),
			easing: "linear"
		}];
	}
	return {
		transform,
		effects,
		paintTracks,
		paintFrame: 0
	};
}
function firstTransform(layer) {
	const first = [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform;
	if (!first) throw new Error(`Compiled layer "${layer.id}" has no transform key.`);
	return first;
}
/** Pure property sampling shared by realtime loops, non-realtime seeking, and editor preview. */
function sampleCompiledLayerVisualState(layer, baseFrame, loopElapsedFrames) {
	const initial = firstTransform(layer);
	const transform = Object.fromEntries(TRANSFORM_ANIMATION_PROPERTIES.map((property) => [property, getTrackValueAtFrame(layer.animationTracks[property] ?? [], baseFrame, initial[property])]));
	const effects = { ...layer.effects };
	for (const property of EFFECT_ANIMATION_PROPERTIES) effects[property] = getTrackValueAtFrame(layer.animationTracks[property] ?? [], baseFrame, effects[property]);
	const loop = layer.loop;
	const localFrame = loop && loopElapsedFrames !== void 0 ? getLoopFrameAtElapsed(loop, loopElapsedFrames) : void 0;
	if (loop && localFrame !== void 0) for (const property of Object.keys(loop.tracks)) {
		const keys = loop.tracks[property] ?? [];
		if (keys.length === 0 || isGradientStopOffsetProperty(property) || property === "strokeWidth") continue;
		if (TRANSFORM_ANIMATION_PROPERTIES.includes(property)) {
			const transformProperty = property;
			transform[transformProperty] = getTrackValueAtFrame(keys, localFrame, transform[transformProperty]);
		} else if (EFFECT_ANIMATION_PROPERTIES.some((candidate) => candidate === property)) {
			const effectProperty = property;
			effects[effectProperty] = getTrackValueAtFrame(keys, localFrame, effects[effectProperty]);
		}
	}
	const paintTracks = {};
	const paintProperties = /* @__PURE__ */ new Set([...Object.keys(layer.animationTracks), ...Object.keys(loop?.tracks ?? {})]);
	for (const property of paintProperties) {
		if (!isGradientStopOffsetProperty(property) && property !== "strokeWidth") continue;
		const fallback = property === "strokeWidth" && layer.element.type === "text" ? layer.element.strokeWidth : 0;
		const baseValue = getTrackValueAtFrame(layer.animationTracks[property] ?? [], baseFrame, fallback);
		const loopKeys = loop?.tracks[property] ?? [];
		const value = localFrame !== void 0 && loopKeys.length > 0 ? getTrackValueAtFrame(loopKeys, localFrame, baseValue) : baseValue;
		paintTracks[property] = [{
			id: `${layer.id}:${property}:sample`,
			frame: 0,
			value,
			easing: "linear"
		}];
	}
	return {
		transform,
		effects,
		paintTracks,
		paintFrame: 0
	};
}
function applyCompiledLayerVisualState(element, state) {
	const { transform } = state;
	gsapWithCSS.set(element, {
		x: transform.x,
		y: transform.y,
		width: transform.width,
		height: transform.height,
		rotation: transform.rotation,
		opacity: transform.opacity,
		transformOrigin: `${transform.transformOriginX * 100}% ${transform.transformOriginY * 100}%`
	});
	element.style.filter = layerEffectsToCssFilter(state.effects);
	applyAnimatedPaint(element, state.paintTracks, state.paintFrame);
}
/** Applies clipping after every participating layer pose has been resolved. */
function applyCompiledClipPaths(descriptor, elements, states) {
	for (const layer of descriptor.layers) {
		if (!layer.clipParentId) continue;
		const child = elements.get(layer.id);
		const childState = states.get(layer.id);
		const parentState = states.get(layer.clipParentId);
		const parentLayer = descriptor.layers.find((candidate) => candidate.id === layer.clipParentId);
		if (!child || !childState || !parentState || !parentLayer) {
			if (child) child.style.clipPath = "inset(50%)";
			continue;
		}
		const radius = parentLayer.element.type === "rectangle" ? parentLayer.element.borderRadius : 0;
		child.style.clipPath = clipPathForParentBounds(childState.transform, parentState.transform, radius);
	}
}
//#endregion
//#region src/runtimeCollections.ts
function instanceId(collectionId, index, prototypeLayerId) {
	return `${collectionId}::${index}::${prototypeLayerId}`;
}
function offsetLayer(collection, prototype, index, idByPrototypeId) {
	const offsetX = collection.offsetPerItem.x * index;
	const offsetY = collection.offsetPerItem.y * index;
	const layer = structuredClone(prototype);
	layer.id = idByPrototypeId.get(prototype.id);
	layer.keyframes = layer.keyframes.map((keyframe) => ({
		...keyframe,
		transform: {
			...keyframe.transform,
			x: keyframe.transform.x + offsetX,
			y: keyframe.transform.y + offsetY
		}
	}));
	for (const [property, offset] of [["x", offsetX], ["y", offsetY]]) {
		const keys = layer.animationTracks[property];
		if (keys) layer.animationTracks[property] = keys.map((key) => ({
			...key,
			value: key.value + offset
		}));
		const loopKeys = layer.loop?.tracks[property];
		if (loopKeys && layer.loop) layer.loop.tracks[property] = loopKeys.map((key) => ({
			...key,
			value: key.value + offset
		}));
	}
	layer.clipParentId = prototype.clipParentId ? idByPrototypeId.get(prototype.clipParentId) ?? null : null;
	layer.bindings = layer.bindings.map((binding) => ({
		...binding,
		itemIndex: index
	}));
	layer.collectionItem = {
		collectionId: collection.id,
		dataKey: collection.dataKey,
		index
	};
	return layer;
}
function expandCollection(collection) {
	const result = [];
	for (let index = 0; index < collection.capacity; index++) {
		const idByPrototypeId = new Map(collection.prototypeLayers.map((layer) => [layer.id, instanceId(collection.id, index, layer.id)]));
		for (const prototype of collection.prototypeLayers) result.push(offsetLayer(collection, prototype, index, idByPrototypeId));
	}
	return result;
}
/** Pure bounded expansion shared by the packaged runtime and browser-authoritative capture. */
function expandRuntimeCollections(descriptor) {
	const collections = descriptor.collections ?? [];
	if (collections.length === 0) return descriptor;
	const layerById = new Map(descriptor.layers.map((layer) => [layer.id, layer]));
	const collectionById = new Map(collections.map((collection) => [collection.id, collection]));
	const layers = [];
	const paintOrder = descriptor.paintOrder ?? [...descriptor.layers.map((layer) => ({
		type: "layer",
		id: layer.id
	})), ...collections.map((collection) => ({
		type: "collection",
		id: collection.id
	}))];
	for (const entry of paintOrder) if (entry.type === "layer") {
		const layer = layerById.get(entry.id);
		if (layer) layers.push(layer);
	} else {
		const collection = collectionById.get(entry.id);
		if (collection) layers.push(...expandCollection(collection));
	}
	return {
		...descriptor,
		layers
	};
}
function isRuntimeCollectionLayerActive(layer, data) {
	const item = layer.collectionItem;
	if (!item) return true;
	const value = data[item.dataKey];
	return Array.isArray(value) && item.index < value.length;
}
//#endregion
//#region src/GraphicElement.ts
function errorPayload(err) {
	return {
		statusCode: 550,
		statusMessage: err instanceof Error ? err.message : String(err)
	};
}
/**
* The generic, descriptor-driven `Graphic` implementation — interprets a CompiledGraphicDescriptor
* rather than being generated per-project. The SAME class (via this same npm-published/bundled
* source) drives both the editor's in-app preview harness and every exported package's `main.js`,
* which is what guarantees the two can never diverge (see docs/PLAN.md, "Runtime is interpreted,
* not templated per-project").
*
* Custom Elements can't take constructor arguments (the browser calls `new SubClass()` with no
* args when upgrading/creating one), so the descriptor is read via a `static descriptor` on the
* concrete subclass instead: `class Foo extends GraphicElement { static descriptor = {...} }`.
* The in-app preview harness dynamically declares one such subclass per compile and registers it
* under a fresh tag name; an exported package's main.js does the same thing once, statically.
*/
var GraphicElement = class extends HTMLElement {
	static descriptor;
	#layerEls = /* @__PURE__ */ new Map();
	#renderDescriptor = null;
	#timeline = null;
	#activeTween = null;
	/** Index into `descriptor.stepKeyframeIds` — the OGraf "current step", not a keyframe index. */
	#currentStep;
	#lastData = {};
	#schedule = [];
	/** Snapshot of `#lastData` taken when `setActionsSchedule` is called — the baseline `goToTime`
	* replays scheduled `updateAction` entries on top of, so scrubbing backward past a scheduled
	* update correctly reverts keys that update doesn't touch, instead of leaving them stuck. */
	#scheduleBaseData = {};
	/** Realtime self-animated-content redraw requests. Phase is derived from absolute elapsed time. */
	#contentAnimationFrames = /* @__PURE__ */ new Map();
	#renderType = "realtime";
	/** Absolute clock epochs for active layer-local loops. Values use performance.now() in realtime
	* and the scheduled OGraf timestamp in non-realtime; sampling always derives phase absolutely. */
	#activeLoopEpochs = /* @__PURE__ */ new Map();
	#loopAnimationFrame = null;
	#loopExitCorrection = null;
	#directLifecycleTransition = null;
	#updateAnimations = [];
	get descriptor() {
		return this.constructor.descriptor;
	}
	get activeDescriptor() {
		return this.#renderDescriptor ?? this.descriptor;
	}
	connectedCallback() {
		if (!this.shadowRoot) this.attachShadow({ mode: "open" });
		this.#buildDom();
	}
	disconnectedCallback() {
		this.#activeTween?.kill();
		this.#timeline?.kill();
		this.#clearContentAnimationFrames();
		this.#stopLoopRendering();
		this.#cancelUpdateAnimations();
		for (const element of this.#layerEls.values()) disposeElementContent(element);
		this.#layerEls.clear();
		this.#renderDescriptor = null;
	}
	#clearContentAnimationFrames() {
		if (typeof cancelAnimationFrame !== "undefined") for (const id of this.#contentAnimationFrames.values()) cancelAnimationFrame(id);
		this.#contentAnimationFrames.clear();
	}
	#cancelUpdateAnimations() {
		for (const animation of this.#updateAnimations) animation.cancel();
		this.#updateAnimations = [];
		for (const layer of this.activeDescriptor.layers) {
			const content = this.#layerEls.get(layer.id)?.firstElementChild;
			if (content) content.style.opacity = "";
		}
	}
	#changedBindingKeys(data) {
		if (!data || typeof data !== "object") return /* @__PURE__ */ new Set();
		const patch = data;
		return new Set(this.activeDescriptor.layers.flatMap((layer) => [...(layer.bindings ?? (layer.binding ? [layer.binding] : [])).map((binding) => binding.dataKey), ...layer.collectionItem ? [layer.collectionItem.dataKey] : []]).filter((key) => key !== void 0 && Object.hasOwn(patch, key)));
	}
	#setBoundContentOpacity(dataKeys, opacity) {
		for (const layer of this.activeDescriptor.layers) {
			if (!(layer.bindings ?? (layer.binding ? [layer.binding] : [])).some((binding) => dataKeys.has(binding.dataKey)) && !dataKeys.has(layer.collectionItem?.dataKey ?? "")) continue;
			const content = this.#layerEls.get(layer.id)?.firstElementChild;
			if (content) content.style.opacity = String(opacity);
		}
	}
	async #animateBoundContent(dataKeys, from, to, durationMs) {
		if (durationMs <= 0 || dataKeys.size === 0) return;
		const animations = [];
		for (const layer of this.activeDescriptor.layers) {
			if (!(layer.bindings ?? (layer.binding ? [layer.binding] : [])).some((binding) => dataKeys.has(binding.dataKey)) && !dataKeys.has(layer.collectionItem?.dataKey ?? "")) continue;
			const content = this.#layerEls.get(layer.id)?.firstElementChild;
			if (!content) continue;
			const animation = content.animate([{ opacity: from }, { opacity: to }], {
				duration: durationMs,
				easing: "ease-in-out",
				fill: "forwards"
			});
			animations.push(animation);
		}
		this.#updateAnimations = animations;
		await Promise.all(animations.map((animation) => animation.finished.catch(() => void 0)));
		if (this.#updateAnimations === animations) this.#updateAnimations = [];
	}
	#stopLoopRendering() {
		if (this.#loopAnimationFrame !== null && typeof cancelAnimationFrame !== "undefined") cancelAnimationFrame(this.#loopAnimationFrame);
		this.#loopAnimationFrame = null;
		this.#activeLoopEpochs.clear();
	}
	#renderLoopSnapshot(clockMs, epochs = this.#activeLoopEpochs) {
		const baseFrame = (this.#timeline?.time() ?? 0) * this.descriptor.frameRate;
		const states = /* @__PURE__ */ new Map();
		for (const layer of this.activeDescriptor.layers) {
			const direct = this.#directLifecycleTransition;
			const directLayer = direct?.layers.get(layer.id);
			const directDistance = direct ? Math.abs(direct.targetFrame - direct.startFrame) : 0;
			const directProgress = !direct || directDistance === 0 ? 1 : Math.min(1, Math.abs(baseFrame - direct.startFrame) / directDistance);
			const epoch = epochs.get(layer.id);
			const elapsedFrames = epoch === void 0 ? void 0 : Math.max(0, (clockMs - epoch) / 1e3 * this.descriptor.frameRate);
			const state = direct && directLayer ? interpolateCompiledLayerVisualState(layer, directLayer.source, directLayer.target, directProgress, direct.targetFrame) : sampleCompiledLayerVisualState(layer, baseFrame, elapsedFrames);
			const correction = this.#loopExitCorrection?.layers.get(layer.id);
			if (!direct && correction && this.#loopExitCorrection) {
				const distance = Math.abs(this.#loopExitCorrection.targetFrame - this.#loopExitCorrection.startFrame);
				const remaining = 1 - (distance === 0 ? 1 : Math.min(1, Math.abs(baseFrame - this.#loopExitCorrection.startFrame) / distance));
				for (const [property, delta] of Object.entries(correction.transform)) state.transform[property] += delta * remaining;
				for (const [property, delta] of Object.entries(correction.effects)) state.effects[property] += delta * remaining;
				for (const [property, delta] of Object.entries(correction.paint)) {
					const sampled = state.paintTracks[property]?.[0];
					if (sampled) sampled.value += delta * remaining;
				}
			}
			states.set(layer.id, state);
			const element = this.#layerEls.get(layer.id);
			if (element) applyCompiledLayerVisualState(element, state);
		}
		applyCompiledClipPaths(this.activeDescriptor, this.#layerEls, states);
	}
	#createDirectLifecycleTransition(startFrame, targetFrame, clockMs, epochs = this.#activeLoopEpochs) {
		const layers = /* @__PURE__ */ new Map();
		for (const layer of this.activeDescriptor.layers) {
			const epoch = epochs.get(layer.id);
			const elapsedFrames = epoch === void 0 ? void 0 : Math.max(0, (clockMs - epoch) / 1e3 * this.descriptor.frameRate);
			layers.set(layer.id, {
				source: sampleCompiledLayerVisualState(layer, startFrame, elapsedFrames),
				target: sampleCompiledLayerVisualState(layer, targetFrame)
			});
		}
		return {
			startFrame,
			targetFrame,
			layers
		};
	}
	#renderDirectLifecycleTransition(transition, progress) {
		const states = /* @__PURE__ */ new Map();
		for (const layer of this.activeDescriptor.layers) {
			const resolved = transition.layers.get(layer.id);
			if (!resolved) continue;
			const state = interpolateCompiledLayerVisualState(layer, resolved.source, resolved.target, progress, transition.targetFrame);
			states.set(layer.id, state);
			const element = this.#layerEls.get(layer.id);
			if (element) applyCompiledLayerVisualState(element, state);
		}
		applyCompiledClipPaths(this.activeDescriptor, this.#layerEls, states);
	}
	#beginDirectLifecycleTransition(targetFrame, clockMs) {
		const startFrame = (this.#timeline?.time() ?? 0) * this.descriptor.frameRate;
		this.#loopExitCorrection = null;
		this.#directLifecycleTransition = this.#createDirectLifecycleTransition(startFrame, targetFrame, clockMs);
	}
	#beginLoopExit(targetFrame, clockMs, shouldExit) {
		this.#directLifecycleTransition = null;
		const baseFrame = (this.#timeline?.time() ?? 0) * this.descriptor.frameRate;
		const layers = /* @__PURE__ */ new Map();
		for (const layer of this.activeDescriptor.layers) {
			const epoch = this.#activeLoopEpochs.get(layer.id);
			if (epoch === void 0 || !layer.loop || !shouldExit(layer)) continue;
			const looped = sampleCompiledLayerVisualState(layer, baseFrame, Math.max(0, (clockMs - epoch) / 1e3 * this.descriptor.frameRate));
			const base = sampleCompiledLayerVisualState(layer, baseFrame);
			const transform = {};
			const effects = {};
			const paint = {};
			for (const property of Object.keys(layer.loop.tracks)) if (TRANSFORM_ANIMATION_PROPERTIES.includes(property)) {
				const key = property;
				transform[key] = looped.transform[key] - base.transform[key];
			} else if (EFFECT_ANIMATION_PROPERTIES.some((candidate) => candidate === property)) {
				const key = property;
				effects[key] = looped.effects[key] - base.effects[key];
			} else if (isGradientStopOffsetProperty(property) || property === "strokeWidth") paint[property] = (looped.paintTracks[property]?.[0]?.value ?? 0) - (base.paintTracks[property]?.[0]?.value ?? 0);
			layers.set(layer.id, {
				transform,
				effects,
				paint
			});
		}
		this.#loopExitCorrection = layers.size > 0 ? {
			startFrame: baseFrame,
			targetFrame,
			layers
		} : null;
	}
	#ensureLoopRendering() {
		if (this.#renderType !== "realtime" || this.#activeLoopEpochs.size === 0 || this.#loopAnimationFrame !== null || typeof requestAnimationFrame === "undefined") return;
		const render = (now) => {
			this.#loopAnimationFrame = null;
			if (this.#activeLoopEpochs.size === 0 || this.#renderType !== "realtime") return;
			this.#renderLoopSnapshot(now);
			this.#loopAnimationFrame = requestAnimationFrame(render);
		};
		this.#loopAnimationFrame = requestAnimationFrame(render);
	}
	#activateLoopsAtStep(step, epochMs, firstStep) {
		const stepKeyframeId = step === void 0 ? void 0 : this.descriptor.stepKeyframeIds[step];
		for (const layer of this.activeDescriptor.layers) {
			const activation = layer.loop?.activation;
			if (!activation) continue;
			if (activation.type === "lifecycle") {
				if (firstStep || !this.#activeLoopEpochs.has(layer.id)) this.#activeLoopEpochs.set(layer.id, epochMs);
			} else if (activation.stepKeyframeId === stepKeyframeId) this.#activeLoopEpochs.set(layer.id, epochMs);
		}
		this.#ensureLoopRendering();
	}
	#deactivateStepLoops() {
		for (const layer of this.activeDescriptor.layers) if (layer.loop?.activation.type === "step") this.#activeLoopEpochs.delete(layer.id);
	}
	#deactivateAllLoops() {
		this.#stopLoopRendering();
	}
	#buildDom() {
		const shadow = this.shadowRoot;
		if (!shadow) return;
		const descriptor = this.descriptor;
		this.#renderDescriptor = expandRuntimeCollections(descriptor);
		const renderDescriptor = this.activeDescriptor;
		for (const element of this.#layerEls.values()) disposeElementContent(element);
		shadow.replaceChildren();
		this.#clearContentAnimationFrames();
		const style = document.createElement("style");
		style.textContent = `${(descriptor.fonts ?? []).map((font) => {
			return `@font-face { font-family: "${font.family.replaceAll("\\", "\\\\").replaceAll("\"", "\\\"")}"; src: url("${font.source.replaceAll("\\", "\\\\").replaceAll("\"", "\\\"")}") format("${font.mimeType === "font/woff2" ? "woff2" : font.mimeType === "font/woff" ? "woff" : font.mimeType === "font/otf" ? "opentype" : "truetype"}"); font-style: ${font.style || "normal"}; font-weight: ${font.weight || "100 900"}; font-display: block; }`;
		}).join("\n")}\n:host { display: block; position: relative; overflow: hidden; isolation: isolate; }`;
		shadow.appendChild(style);
		this.style.width = `${descriptor.width}px`;
		this.style.height = `${descriptor.height}px`;
		this.style.backgroundColor = descriptor.backgroundColor;
		this.#layerEls.clear();
		for (const layer of renderDescriptor.layers) {
			const el = document.createElement("div");
			el.style.position = "absolute";
			el.style.left = "0";
			el.style.top = "0";
			el.style.boxSizing = "border-box";
			el.style.display = layer.isVisible ? "" : "none";
			if (layer.collectionItem) {
				el.dataset.ografCollectionId = layer.collectionItem.collectionId;
				el.dataset.ografCollectionIndex = String(layer.collectionItem.index);
				el.dataset.ografCollectionDataKey = layer.collectionItem.dataKey;
			}
			el.style.mixBlendMode = !layer.blendMode || layer.blendMode === "normal" ? "" : layer.blendMode;
			el.style.filter = layerEffectsToCssFilter(layer.effects);
			const firstTransform = [...layer.keyframes].sort((a, b) => a.frame - b.frame)[0]?.transform;
			if (firstTransform) {
				el.style.width = `${firstTransform.width}px`;
				el.style.height = `${firstTransform.height}px`;
			}
			renderElementContent(el, resolveBoundElement(layer, this.#lastData));
			shadow.appendChild(el);
			this.#layerEls.set(layer.id, el);
			this.#startContentPlayback(layer, el);
		}
		this.#syncCollectionVisibility();
		this.#timeline?.kill();
		this.#timeline = buildRuntimeTimeline(renderDescriptor, this.#layerEls);
	}
	#startContentPlayback(layer, el) {
		const element = layer.element;
		if (element.type !== "image-sequence" && element.type !== "lottie" || element.type === "image-sequence" && element.frames.length === 0 || element.type === "lottie" && !element.animationData) return;
		if (typeof requestAnimationFrame === "undefined") return;
		const epoch = performance.now();
		const render = (now) => {
			const elapsedMs = Math.max(0, now - epoch);
			renderAnimatedElementAtTime(el, element, elapsedMs);
			if (element.type === "image-sequence" && !element.loop && elapsedMs / 1e3 >= element.frames.length / Math.max(1, element.fps)) {
				this.#contentAnimationFrames.delete(layer.id);
				return;
			}
			const request = requestAnimationFrame(render);
			this.#contentAnimationFrames.set(layer.id, request);
		};
		this.#contentAnimationFrames.set(layer.id, requestAnimationFrame(render));
	}
	#startRealtimeContentAnimations() {
		this.#clearContentAnimationFrames();
		for (const layer of this.activeDescriptor.layers) {
			const el = this.#layerEls.get(layer.id);
			if (el) this.#startContentPlayback(layer, el);
		}
	}
	#renderAnimatedContentAt(timestampMs) {
		for (const layer of this.activeDescriptor.layers) {
			if (layer.element.type !== "image-sequence" && layer.element.type !== "lottie") continue;
			const el = this.#layerEls.get(layer.id);
			if (!el) continue;
			renderAnimatedElementAtTime(el, layer.element, timestampMs);
		}
	}
	#refreshBoundLayers() {
		for (const layer of this.activeDescriptor.layers) {
			if ((layer.bindings ?? (layer.binding ? [layer.binding] : [])).length === 0 && !layer.collectionItem) continue;
			const el = this.#layerEls.get(layer.id);
			if (el) {
				renderElementContent(el, resolveBoundElement(layer, this.#lastData));
				applyAnimatedPaint(el, layer.animationTracks, (this.#timeline?.time() ?? 0) * this.descriptor.frameRate);
			}
		}
		this.#syncCollectionVisibility();
	}
	#syncCollectionVisibility() {
		for (const layer of this.activeDescriptor.layers) {
			const el = this.#layerEls.get(layer.id);
			if (!el) continue;
			const active = isRuntimeCollectionLayerActive(layer, this.#lastData);
			el.style.display = layer.isVisible && active ? "" : "none";
		}
	}
	#applyData(data) {
		if (!data || typeof data !== "object") return;
		this.#lastData = {
			...this.#lastData,
			...data
		};
		this.#refreshBoundLayers();
	}
	#replaceData(data) {
		this.#lastData = data && typeof data === "object" ? { ...data } : {};
		this.#refreshBoundLayers();
	}
	async #seekToKeyframeId(keyframeId, skipAnimation, durationSeconds) {
		const keyframe = this.descriptor.keyframes.find((k) => k.id === keyframeId);
		const tl = this.#timeline;
		if (!keyframe || !tl) return;
		const targetSeconds = keyframe.frame / this.descriptor.frameRate;
		this.#activeTween?.kill();
		this.#activeTween = null;
		if (skipAnimation) {
			this.#loopExitCorrection = null;
			this.#directLifecycleTransition = null;
			tl.seek(targetSeconds, true);
		} else await new Promise((resolve) => {
			const finish = () => {
				this.#activeTween = null;
				this.#loopExitCorrection = null;
				this.#directLifecycleTransition = null;
				this.#renderLoopSnapshot(typeof performance !== "undefined" ? performance.now() : Date.now());
				resolve();
			};
			this.#activeTween = tl.tweenTo(targetSeconds, {
				...durationSeconds !== void 0 ? {
					duration: durationSeconds,
					ease: "none"
				} : {},
				onUpdate: () => this.#renderLoopSnapshot(typeof performance !== "undefined" ? performance.now() : Date.now()),
				onComplete: finish,
				onInterrupt: finish
			});
		});
	}
	async load(params) {
		try {
			this.#cancelUpdateAnimations();
			this.#replaceData(params.data);
			this.#stopLoopRendering();
			this.#renderType = params.renderType;
			if (this.#renderType === "realtime") this.#startRealtimeContentAnimations();
			else {
				this.#clearContentAnimationFrames();
				this.#renderAnimatedContentAt(0);
			}
			this.#schedule = [];
			this.#scheduleBaseData = { ...this.#lastData };
			this.#currentStep = void 0;
			this.#directLifecycleTransition = null;
			await this.#seekToKeyframeId(this.descriptor.startKeyframeId, true);
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async dispose() {
		try {
			this.#timeline?.kill();
			this.#timeline = null;
			this.#activeTween?.kill();
			this.#activeTween = null;
			this.#clearContentAnimationFrames();
			this.#stopLoopRendering();
			this.#cancelUpdateAnimations();
			this.#schedule = [];
			this.#directLifecycleTransition = null;
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async updateAction(params) {
		try {
			this.#cancelUpdateAnimations();
			const keys = this.#changedBindingKeys(params.data);
			const durationMs = params.skipAnimation || (this.descriptor.updateTransitionFrames ?? 0) <= 0 ? 0 : (this.descriptor.updateTransitionFrames ?? 0) / this.descriptor.frameRate * 1e3;
			if (durationMs <= 0 || keys.size === 0) {
				this.#applyData(params.data);
				return { statusCode: 200 };
			}
			await this.#animateBoundContent(keys, 1, 0, durationMs / 2);
			this.#applyData(params.data);
			this.#setBoundContentOpacity(keys, 0);
			await this.#animateBoundContent(keys, 0, 1, durationMs / 2);
			this.#setBoundContentOpacity(keys, 1);
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	#resolvePlayTarget(currentStep, params) {
		return resolvePlayTarget(this.descriptor.stepKeyframeIds, this.descriptor.startKeyframeId, this.descriptor.endKeyframeId, currentStep, params);
	}
	async playAction(params) {
		try {
			const previousStep = this.#currentStep;
			const target = this.#resolvePlayTarget(this.#currentStep, params);
			const targetFrame = this.descriptor.keyframes.find((keyframe) => keyframe.id === target.keyframeId)?.frame ?? 0;
			const now = typeof performance !== "undefined" ? performance.now() : Date.now();
			const exitsToEnd = previousStep !== void 0 && target.keyframeId === this.descriptor.endKeyframeId;
			if (exitsToEnd) this.#beginDirectLifecycleTransition(targetFrame, now);
			else this.#beginLoopExit(targetFrame, now, (layer) => target.currentStep === void 0 || layer.loop?.activation.type === "step");
			this.#deactivateStepLoops();
			if (target.currentStep === void 0) this.#deactivateAllLoops();
			const exitDurationSeconds = exitsToEnd ? (this.descriptor.transitions.find((transition) => transition.toKeyframeId === this.descriptor.endKeyframeId)?.durationFrames ?? 0) / this.descriptor.frameRate : void 0;
			await this.#seekToKeyframeId(target.keyframeId, params.skipAnimation, exitDurationSeconds);
			this.#currentStep = target.currentStep;
			if (this.#currentStep !== void 0) this.#activateLoopsAtStep(this.#currentStep, typeof performance !== "undefined" ? performance.now() : Date.now(), previousStep === void 0);
			return {
				statusCode: 200,
				...this.#currentStep !== void 0 ? { currentStep: this.#currentStep } : {}
			};
		} catch (err) {
			return {
				...errorPayload(err),
				...this.#currentStep !== void 0 ? { currentStep: this.#currentStep } : {}
			};
		}
	}
	async stopAction(params) {
		try {
			const targetFrame = this.descriptor.keyframes.find((keyframe) => keyframe.id === this.descriptor.endKeyframeId)?.frame ?? 0;
			this.#beginDirectLifecycleTransition(targetFrame, typeof performance !== "undefined" ? performance.now() : Date.now());
			this.#deactivateAllLoops();
			const durationSeconds = (this.descriptor.transitions.find((transition) => transition.toKeyframeId === this.descriptor.endKeyframeId)?.durationFrames ?? 0) / this.descriptor.frameRate;
			await this.#seekToKeyframeId(this.descriptor.endKeyframeId, params.skipAnimation, durationSeconds);
			this.#currentStep = void 0;
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async customAction(params) {
		try {
			if (!this.descriptor.customActions.some((a) => a.id === params.id)) return {
				statusCode: 404,
				statusMessage: `Unknown customAction id: "${params.id}"`
			};
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	/**
	* Re-derives the full logical state (keyframe position + bound data) implied by every scheduled
	* action at or before `timestamp`, from the `#scheduleBaseData`/keyframe-0 baseline forward —
	* NOT an incremental cursor. Replaying the full prefix every call (rather than only newly-passed
	* entries) is what makes scrubbing backward correct: a key set by an action that's since fallen
	* out of the qualifying prefix reverts to the baseline instead of staying stuck at its old value.
	*/
	#applySchedule(timestamp) {
		const due = this.#schedule.filter((a) => a.timestamp <= timestamp);
		let step;
		let targetKeyframeId = this.descriptor.startKeyframeId;
		let data = { ...this.#scheduleBaseData };
		let displayData = { ...data };
		let updateOpacity = 1;
		let updateKeys = /* @__PURE__ */ new Set();
		let dataAnimation;
		const keyframeSeconds = (keyframeId) => (this.descriptor.keyframes.find((keyframe) => keyframe.id === keyframeId)?.frame ?? 0) / this.descriptor.frameRate;
		let positionSeconds = keyframeSeconds(this.descriptor.startKeyframeId);
		let animation;
		let directSample;
		let stepArrivalTimestamp;
		let lifecycleEpoch;
		const advanceTo = (atTimestamp) => {
			if (!animation) return positionSeconds;
			const progress = Math.min(1, Math.max(0, (atTimestamp - animation.startTimestamp) / animation.durationMs));
			directSample = animation.directTransition ? {
				transition: animation.directTransition,
				progress
			} : void 0;
			positionSeconds = animation.startSeconds + (animation.targetSeconds - animation.startSeconds) * progress;
			if (progress >= 1) {
				animation = void 0;
				directSample = void 0;
			}
			return positionSeconds;
		};
		const advanceDataTo = (atTimestamp) => {
			if (!dataAnimation) {
				updateOpacity = 1;
				updateKeys = /* @__PURE__ */ new Set();
				return;
			}
			const progress = Math.min(1, Math.max(0, (atTimestamp - dataAnimation.startTimestamp) / dataAnimation.durationMs));
			displayData = progress < .5 ? dataAnimation.oldData : dataAnimation.newData;
			updateOpacity = progress < .5 ? 1 - progress * 2 : (progress - .5) * 2;
			updateKeys = dataAnimation.keys;
			if (progress >= 1) {
				displayData = dataAnimation.newData;
				updateOpacity = 1;
				updateKeys = /* @__PURE__ */ new Set();
				dataAnimation = void 0;
			}
		};
		for (const scheduled of due) {
			advanceTo(scheduled.timestamp);
			advanceDataTo(scheduled.timestamp);
			const { type, params } = scheduled.action;
			if (type === "updateAction") {
				const updateParams = params;
				if (updateParams.data && typeof updateParams.data === "object") {
					if (dataAnimation) {
						displayData = { ...data };
						updateOpacity = 1;
						updateKeys = /* @__PURE__ */ new Set();
						dataAnimation = void 0;
					}
					data = {
						...data,
						...updateParams.data
					};
					const durationMs = (this.descriptor.updateTransitionFrames ?? 0) / this.descriptor.frameRate * 1e3;
					const keys = this.#changedBindingKeys(updateParams.data);
					if (updateParams.skipAnimation || durationMs <= 0 || keys.size === 0) displayData = { ...data };
					else dataAnimation = {
						startTimestamp: scheduled.timestamp,
						durationMs,
						oldData: { ...displayData },
						newData: { ...data },
						keys
					};
				}
			} else if (type === "playAction") {
				const playParams = params;
				const previousStep = step;
				const target = this.#resolvePlayTarget(step, playParams);
				step = target.currentStep;
				targetKeyframeId = target.keyframeId;
				const targetSeconds = keyframeSeconds(targetKeyframeId);
				const exitsToEnd = previousStep !== void 0 && targetKeyframeId === this.descriptor.endKeyframeId;
				const durationMs = exitsToEnd ? (this.descriptor.transitions.find((transition) => transition.toKeyframeId === this.descriptor.endKeyframeId)?.durationFrames ?? 0) / this.descriptor.frameRate * 1e3 : Math.abs(targetSeconds - positionSeconds) * 1e3;
				animation = playParams.skipAnimation || durationMs === 0 ? void 0 : {
					startTimestamp: scheduled.timestamp,
					startSeconds: positionSeconds,
					targetSeconds,
					durationMs,
					...exitsToEnd ? { directTransition: this.#createDirectLifecycleTransition(positionSeconds * this.descriptor.frameRate, targetSeconds * this.descriptor.frameRate, scheduled.timestamp, /* @__PURE__ */ new Map()) } : {}
				};
				directSample = void 0;
				if (!animation) positionSeconds = targetSeconds;
				if (target.currentStep === void 0) {
					lifecycleEpoch = void 0;
					stepArrivalTimestamp = void 0;
				} else {
					const arrival = scheduled.timestamp + (animation?.durationMs ?? 0);
					stepArrivalTimestamp = arrival;
					lifecycleEpoch ??= arrival;
				}
			} else if (type === "stopAction") {
				const stopParams = params;
				step = void 0;
				targetKeyframeId = this.descriptor.endKeyframeId;
				const targetSeconds = keyframeSeconds(targetKeyframeId);
				const durationMs = (this.descriptor.transitions.find((transition) => transition.toKeyframeId === this.descriptor.endKeyframeId)?.durationFrames ?? 0) / this.descriptor.frameRate * 1e3;
				animation = stopParams.skipAnimation || durationMs === 0 ? void 0 : {
					startTimestamp: scheduled.timestamp,
					startSeconds: positionSeconds,
					targetSeconds,
					durationMs,
					directTransition: this.#createDirectLifecycleTransition(positionSeconds * this.descriptor.frameRate, targetSeconds * this.descriptor.frameRate, scheduled.timestamp, /* @__PURE__ */ new Map())
				};
				directSample = void 0;
				if (!animation) positionSeconds = targetSeconds;
				lifecycleEpoch = void 0;
				stepArrivalTimestamp = void 0;
			}
		}
		advanceDataTo(timestamp);
		this.#lastData = displayData;
		this.#refreshBoundLayers();
		this.#setBoundContentOpacity(updateKeys, updateOpacity);
		this.#currentStep = step;
		advanceTo(timestamp);
		this.#timeline?.seek(positionSeconds, true);
		const epochs = /* @__PURE__ */ new Map();
		const settled = animation === void 0;
		const stepKeyframeId = step === void 0 ? void 0 : this.descriptor.stepKeyframeIds[step];
		for (const layer of this.activeDescriptor.layers) {
			const activation = layer.loop?.activation;
			if (!activation) continue;
			if (activation.type === "lifecycle" && lifecycleEpoch !== void 0 && timestamp >= lifecycleEpoch) epochs.set(layer.id, lifecycleEpoch);
			else if (activation.type === "step" && settled && stepArrivalTimestamp !== void 0 && activation.stepKeyframeId === stepKeyframeId) epochs.set(layer.id, stepArrivalTimestamp);
		}
		if (directSample) this.#renderDirectLifecycleTransition(directSample.transition, directSample.progress);
		else this.#renderLoopSnapshot(timestamp, epochs);
	}
	async goToTime(params) {
		try {
			this.#timeline?.pause();
			this.#activeTween?.kill();
			this.#activeTween = null;
			this.#timeline?.seek(params.timestamp / 1e3, true);
			if (this.#schedule.length > 0) this.#applySchedule(params.timestamp);
			else this.#renderLoopSnapshot(params.timestamp, /* @__PURE__ */ new Map());
			this.#renderAnimatedContentAt(params.timestamp);
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
	async setActionsSchedule(params) {
		try {
			this.#schedule = [...params.schedule].sort((a, b) => a.timestamp - b.timestamp);
			this.#scheduleBaseData = { ...this.#lastData };
			return { statusCode: 200 };
		} catch (err) {
			return errorPayload(err);
		}
	}
};
//#endregion
//#region src/index.ts
/** A concrete, instantiable GraphicElement bound to one descriptor — see GraphicElement's own doc comment. */
function createGraphicClass(descriptor) {
	return class extends GraphicElement {
		static descriptor = descriptor;
	};
}
var registrationCounter = 0;
/**
* Registers a fresh Custom Element tag for this descriptor and returns the tag name — used by the
* live preview harness, which needs a new tag every recompile (`customElements.define` can't be
* called twice for the same name, and there's no way to update an already-defined element's class).
*/
function registerGraphicElement(descriptor) {
	const tagName = `ograf-preview-graphic-${registrationCounter++}`;
	customElements.define(tagName, createGraphicClass(descriptor));
	return tagName;
}
//#endregion
export { GraphicElement, applyAnimatedPaint, applyCompiledClipPaths, applyCompiledLayerVisualState, buildRuntimeTimeline, createGraphicClass, disposeElementContent, easingForGsap, expandRuntimeCollections, isRuntimeCollectionLayerActive, registerGraphicElement, renderAnimatedElementAtTime, renderElementContent, resolveBoundElement, resolvePlayTarget, sampleCompiledLayerVisualState };

const exportedDescriptor = {"width":1920,"height":1080,"backgroundColor":"transparent","frameRate":50,"updateTransitionFrames":0,"fonts":[],"layers":[{"id":"layer-81a41863-66dc-4a65-b464-9340838f60c6","isVisible":true,"blendMode":"normal","element":{"type":"image","src":"assets/asset-6d810572-e78e-4c9f-ac49-f657d62b0bad.png"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d","frame":0,"transform":{"x":-1126,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e","frame":25,"transform":{"x":138,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f","frame":35,"transform":{"x":138,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890","frame":45,"transform":{"x":138,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527","frame":65,"transform":{"x":138,"y":1104,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-bc453d67-5206-400a-93b9-1fe754cd297e","frame":0,"value":-1126,"easing":"linear"},{"id":"property-keyframe-fbcde5e0-4811-46b5-8257-05e5c17fb8be","frame":25,"value":138,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-7933cdae-ec34-482b-b8e6-810a88777cd5","frame":0,"value":824,"easing":"linear"},{"id":"property-keyframe-192e4c49-bda1-4e73-8b32-e4d190cb762d","frame":45,"value":824,"easing":"linear"},{"id":"property-keyframe-050dac94-92f2-4ee9-94dc-d00acf1f728b","frame":65,"value":1104,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d:width","frame":0,"value":1066,"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e:width","frame":25,"value":1066,"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f:width","frame":35,"value":1066,"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890:width","frame":45,"value":1066,"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527:width","frame":65,"value":1066,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d:height","frame":0,"value":130,"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e:height","frame":25,"value":130,"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f:height","frame":35,"value":130,"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890:height","frame":45,"value":130,"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527:height","frame":65,"value":130,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-8fe2d36e-a966-42a9-b49c-338bfbdf523d:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-4cafee59-b14c-40e9-9cc6-6b18ffd0462e:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-d6376f01-e13c-412f-bf57-53ee9c0d600f:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-89054656-edd0-47b4-8a8e-39a70893a890:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-d8853c84-2513-4d77-8e96-70f47cb0f527:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"blur":[{"id":"layer-81a41863-66dc-4a65-b464-9340838f60c6:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-81a41863-66dc-4a65-b464-9340838f60c6:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-81a41863-66dc-4a65-b464-9340838f60c6:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-81a41863-66dc-4a65-b464-9340838f60c6:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-81a41863-66dc-4a65-b464-9340838f60c6:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[],"clipParentId":null},{"id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c","isVisible":true,"blendMode":"normal","element":{"type":"image","src":"assets/asset-4b171995-ee1f-41ff-917c-61b883886982.png"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0","frame":0,"transform":{"x":-1021,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931","frame":25,"transform":{"x":-1021,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec","frame":35,"transform":{"x":284,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13","frame":45,"transform":{"x":284,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890","frame":65,"transform":{"x":284,"y":1126,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-fe8f7d66-0353-40e6-b177-b39050beae09","frame":0,"value":-1021,"easing":"linear"},{"id":"property-keyframe-b853a42c-5da3-48b9-95f8-9eb37e292158","frame":25,"value":-1021,"easing":"linear"},{"id":"property-keyframe-bcb569f9-9d6d-4aaf-98ab-f11b6e40f02b","frame":35,"value":284,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-5adae1dd-3c73-4ef5-ad2a-fb4e4674c372","frame":0,"value":846,"easing":"linear"},{"id":"property-keyframe-8b7e2039-a89d-423e-883f-0fd757444eb4","frame":45,"value":846,"easing":"linear"},{"id":"property-keyframe-8439911a-d892-43bb-ab85-71c0798018f1","frame":65,"value":1126,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0:width","frame":0,"value":961,"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931:width","frame":25,"value":961,"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec:width","frame":35,"value":961,"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13:width","frame":45,"value":961,"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890:width","frame":65,"value":961,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0:height","frame":0,"value":135,"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931:height","frame":25,"value":135,"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec:height","frame":35,"value":135,"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13:height","frame":45,"value":135,"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890:height","frame":65,"value":135,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-e1c5d29a-1b76-4ae6-8bba-2e81c49c5ca0:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-ef0ef7cd-a1db-4bb0-b2d2-a3903a9fe931:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-307d1498-27ca-45b2-a89c-8c44944735ec:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-b8f378ec-5160-4ea8-b8db-24cffa1c5e13:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-7f50e3c7-0911-4a03-bead-7baa1fa29890:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"blur":[{"id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[],"clipParentId":null},{"id":"layer-c330787c-1504-4ef1-972b-723398b39044","isVisible":true,"blendMode":"normal","element":{"type":"image","src":"assets/asset-5849787c-ac59-4384-9364-177930db751e.png"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f","frame":0,"transform":{"x":-531,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f","frame":25,"transform":{"x":-531,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8","frame":35,"transform":{"x":-531,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894","frame":45,"transform":{"x":668,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed","frame":65,"transform":{"x":668,"y":1240,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-4f4e535c-062e-4d5c-b6a1-69c698c47e21","frame":0,"value":-531,"easing":"linear"},{"id":"property-keyframe-e72f2b39-781c-4935-b6d4-b67f30687378","frame":35,"value":-531,"easing":"linear"},{"id":"property-keyframe-e810d22b-c716-4409-9143-1ee4ee33a270","frame":45,"value":668,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-9c9d8224-a39f-4ef4-a390-17fa785103e2","frame":0,"value":960,"easing":"linear"},{"id":"property-keyframe-200fa037-aff7-4a7e-b619-5a9ed9e2184e","frame":45,"value":960,"easing":"linear"},{"id":"property-keyframe-4f3668cf-e06b-4811-8cf5-aa337610f006","frame":65,"value":1240,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f:width","frame":0,"value":471,"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f:width","frame":25,"value":471,"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8:width","frame":35,"value":471,"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894:width","frame":45,"value":471,"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed:width","frame":65,"value":471,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f:height","frame":0,"value":58,"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f:height","frame":25,"value":58,"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8:height","frame":35,"value":58,"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894:height","frame":45,"value":58,"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed:height","frame":65,"value":58,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-fc5d21b9-b252-4963-a593-550d15ac960f:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-81a6c73e-571b-4b8d-b386-a00103c7ab4f:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-351305a0-1d29-403c-95dd-59476ba5a4d8:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-43a907ca-0367-499d-aa7c-2cd9c8dc3894:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-6ec63896-943d-4fa9-921c-9eef246ec6ed:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"blur":[{"id":"layer-c330787c-1504-4ef1-972b-723398b39044:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-c330787c-1504-4ef1-972b-723398b39044:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-c330787c-1504-4ef1-972b-723398b39044:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-c330787c-1504-4ef1-972b-723398b39044:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-c330787c-1504-4ef1-972b-723398b39044:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[],"clipParentId":null},{"id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3","isVisible":true,"blendMode":"normal","element":{"type":"image","src":"assets/embedded-0.png"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773","frame":0,"transform":{"x":-1126,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7","frame":25,"transform":{"x":138,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f","frame":35,"transform":{"x":138,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f","frame":45,"transform":{"x":138,"y":824,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59","frame":65,"transform":{"x":138,"y":1104,"width":1066,"height":130,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-4d733d32-752a-4a5f-aa87-b277be61884a","frame":0,"value":-1126,"easing":"linear"},{"id":"property-keyframe-b53ec27e-f599-418b-b267-a941ba5342d9","frame":25,"value":138,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-16bb0a43-5502-4dd7-a58d-592b59cb5428","frame":0,"value":824,"easing":"linear"},{"id":"property-keyframe-b7589ed1-d2bf-4abd-ba9c-5bd187fbf249","frame":45,"value":824,"easing":"linear"},{"id":"property-keyframe-643b5bac-7163-41d9-a9e0-5c7a6311412a","frame":65,"value":1104,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773:width","frame":0,"value":1066,"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7:width","frame":25,"value":1066,"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f:width","frame":35,"value":1066,"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f:width","frame":45,"value":1066,"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59:width","frame":65,"value":1066,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773:height","frame":0,"value":130,"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7:height","frame":25,"value":130,"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f:height","frame":35,"value":130,"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f:height","frame":45,"value":130,"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59:height","frame":65,"value":130,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-70f7d764-5a37-42f3-9018-0779b10a4773:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-1db1736c-d7c0-47e8-80cd-3ab7405a35d7:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-ff997e2a-f1eb-422a-95f7-0f007d29b10f:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-c6816b2c-a769-4c02-b219-b565d44e417f:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-912662a7-1fed-4f6a-b39b-d80d848b2a59:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"blur":[{"id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[{"dataKey":"breakingNews","targetProperty":"src","valueMap":{"false":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAALSURBVBhXY2AAAgAABQABqtXIUQAAAABJRU5ErkJggg==","true":"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDY2IiBoZWlnaHQ9IjEzMCIgdmlld0JveD0iMCAwIDEwNjYgMTMwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwIiB5MT0iMCIgeDI9IjAiIHkyPSIxIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNDODEwMkUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiM0QTA1MTIiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cG9seWdvbiBwb2ludHM9IjY5LjU1LDAgMTA2NiwwIDk5Ni40NSwxMzAgMCwxMzAiIGZpbGw9InVybCgjZykiLz48L3N2Zz4="}}],"clipParentId":null},{"id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8","isVisible":true,"blendMode":"normal","element":{"type":"image","src":"assets/embedded-0.png"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae","frame":0,"transform":{"x":-1021,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427","frame":25,"transform":{"x":-1021,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b","frame":35,"transform":{"x":284,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0","frame":45,"transform":{"x":284,"y":846,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f","frame":65,"transform":{"x":284,"y":1126,"width":961,"height":135,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-f358a409-42ff-4a94-a77d-46fcf3764f17","frame":0,"value":-1021,"easing":"linear"},{"id":"property-keyframe-5bbc6c40-ba31-47c6-95ff-0fe134a8cea0","frame":25,"value":-1021,"easing":"linear"},{"id":"property-keyframe-5054d734-71fa-4699-b850-f96530e1c365","frame":35,"value":284,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-19c8b916-12db-44f2-856f-b55e6ef95798","frame":0,"value":846,"easing":"linear"},{"id":"property-keyframe-f2d7083e-29b7-4aec-9dd6-ba6b03d14218","frame":45,"value":846,"easing":"linear"},{"id":"property-keyframe-5453cfb2-c4e0-4730-a381-ca7753ab64bd","frame":65,"value":1126,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae:width","frame":0,"value":961,"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427:width","frame":25,"value":961,"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b:width","frame":35,"value":961,"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0:width","frame":45,"value":961,"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f:width","frame":65,"value":961,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae:height","frame":0,"value":135,"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427:height","frame":25,"value":135,"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b:height","frame":35,"value":135,"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0:height","frame":45,"value":135,"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f:height","frame":65,"value":135,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-38836de0-52c6-4bbf-86eb-138d803855ae:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-e5a0651a-0926-46bc-b4b6-d85153064427:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-e90c726b-23d7-4d2d-95e5-e7548fd4d64b:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-e9109622-5d0f-4408-830e-a4bc910d1ed0:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-30031d31-a0ad-42ed-8318-c398bd3d1d2f:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"blur":[{"id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[{"dataKey":"breakingNews","targetProperty":"src","valueMap":{"false":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAALSURBVBhXY2AAAgAABQABqtXIUQAAAABJRU5ErkJggg==","true":"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5NjEiIGhlaWdodD0iMTM1IiB2aWV3Qm94PSIwIDAgOTYxIDEzNSI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJnIiB4MT0iMCIgeTE9IjAiIHgyPSIwIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjQTgwRDI2Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjM0QwNDBGIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHBvbHlnb24gcG9pbnRzPSI3Mi4yMywwIDk2MSwwIDg4OC43NywxMzUgMCwxMzUiIGZpbGw9InVybCgjZykiLz48L3N2Zz4="}}],"clipParentId":null},{"id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96","isVisible":true,"blendMode":"normal","element":{"type":"image","src":"assets/embedded-0.png"},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079","frame":0,"transform":{"x":-531,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6","frame":25,"transform":{"x":-531,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87","frame":35,"transform":{"x":-531,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a","frame":45,"transform":{"x":668,"y":960,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d","frame":65,"transform":{"x":668,"y":1240,"width":471,"height":58,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-7e343dcc-33b5-4129-b78a-0b76cf6c08e4","frame":0,"value":-531,"easing":"linear"},{"id":"property-keyframe-91407a18-d7f6-4e2c-931a-f93567a33a2d","frame":35,"value":-531,"easing":"linear"},{"id":"property-keyframe-9c5f137d-0381-4fda-a895-ccab7bd5d727","frame":45,"value":668,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-fa7f987c-7ae5-451f-bfd0-bea205e03e42","frame":0,"value":960,"easing":"linear"},{"id":"property-keyframe-1280ce0c-2556-4ac6-8e1a-fb5884439a4a","frame":45,"value":960,"easing":"linear"},{"id":"property-keyframe-2ef1ca8d-415a-4d7e-99af-ab13a1d4bb9c","frame":65,"value":1240,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079:width","frame":0,"value":471,"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6:width","frame":25,"value":471,"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87:width","frame":35,"value":471,"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a:width","frame":45,"value":471,"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d:width","frame":65,"value":471,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079:height","frame":0,"value":58,"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6:height","frame":25,"value":58,"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87:height","frame":35,"value":58,"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a:height","frame":45,"value":58,"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d:height","frame":65,"value":58,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-0b83a463-a875-488f-b250-eb30d6162079:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-d166a6bc-2dd7-49cc-b2c0-264d9b8b79c6:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-ea7b0d83-ef64-4964-b023-85387db57c87:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-f9b4dc61-90aa-45cd-b1f5-419f84b1396a:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-dc39c489-cbc7-4913-bd4a-93a68526d05d:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"blur":[{"id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[{"dataKey":"breakingNews","targetProperty":"src","valueMap":{"false":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAALSURBVBhXY2AAAgAABQABqtXIUQAAAABJRU5ErkJggg==","true":"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0NzEiIGhlaWdodD0iNTgiIHZpZXdCb3g9IjAgMCA0NzEgNTgiPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0iZyIgeDE9IjAiIHkxPSIwIiB4Mj0iMCIgeTI9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI0M4MTAyRSIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzNEMDQxMCIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxwb2x5Z29uIHBvaW50cz0iMzEuMDMsMCA0NzEsMCA0MzkuOTcsNTggMCw1OCIgZmlsbD0idXJsKCNnKSIvPjwvc3ZnPg=="}}],"clipParentId":null},{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4","isVisible":true,"blendMode":"normal","element":{"type":"text","content":"LIVE","color":"#FFFFFF","strokeColor":"transparent","strokeWidth":0,"fontFamily":"Rubik, Arial, Helvetica, sans-serif","fontWeight":700,"textAlign":"left","lineHeight":1.2,"letterSpacing":0,"textTransform":"none","verticalAlign":"top","baselineShift":0,"minFontSize":26,"overflowPolicy":"clip","autoFit":"shrink-to-fit","fontSize":44},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a","frame":0,"transform":{"x":-1052,"y":884,"width":240,"height":60,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692","frame":25,"transform":{"x":212,"y":884,"width":240,"height":60,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8","frame":35,"transform":{"x":212,"y":884,"width":240,"height":60,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765","frame":45,"transform":{"x":212,"y":884,"width":240,"height":60,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33","frame":65,"transform":{"x":212,"y":1164,"width":240,"height":60,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-ee043fbb-2212-4f67-b164-4a2b92e51de6","frame":0,"value":-1052,"easing":"linear"},{"id":"property-keyframe-d9fa0e0a-9ec0-4e43-be4e-51cf8ea86b98","frame":25,"value":212,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-e9946db6-a664-4477-bfe1-822f8e408698","frame":0,"value":884,"easing":"linear"},{"id":"property-keyframe-eca28ebb-84ad-4a4a-bba3-33adda539e21","frame":45,"value":884,"easing":"linear"},{"id":"property-keyframe-48dfed6d-348a-4f07-a4b6-42e91ad799ff","frame":65,"value":1164,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a:width","frame":0,"value":240,"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692:width","frame":25,"value":240,"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8:width","frame":35,"value":240,"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765:width","frame":45,"value":240,"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33:width","frame":65,"value":240,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a:height","frame":0,"value":60,"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692:height","frame":25,"value":60,"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8:height","frame":35,"value":60,"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765:height","frame":45,"value":60,"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33:height","frame":65,"value":60,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-a988f751-beee-41f8-8c40-be86f3b7652a:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-10be95d7-1d24-4686-a3dd-034ab215e692:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-86092340-a70b-4932-b998-ded601c3efa8:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-b7f18276-9e19-4331-a6c2-9e0c8883a765:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-5fb81e4c-ffea-4db6-a8b5-11507e35ab33:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"strokeWidth":[{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4:strokeWidth:0","frame":0,"value":0,"easing":"linear"}],"blur":[{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[{"dataKey":"liveTag","targetProperty":"content"}],"clipParentId":null},{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d","isVisible":true,"blendMode":"normal","element":{"type":"text","content":"HEADLINES","color":"#001E4F","strokeColor":"transparent","strokeWidth":0,"fontFamily":"Rubik, Arial, Helvetica, sans-serif","fontWeight":700,"textAlign":"left","lineHeight":1.2,"letterSpacing":0,"textTransform":"none","verticalAlign":"top","baselineShift":0,"minFontSize":38,"overflowPolicy":"clip","autoFit":"shrink-to-fit","fontSize":66},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b","frame":0,"transform":{"x":-821,"y":887,"width":700,"height":90,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151","frame":25,"transform":{"x":-821,"y":887,"width":700,"height":90,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e","frame":35,"transform":{"x":484,"y":887,"width":700,"height":90,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b","frame":45,"transform":{"x":484,"y":887,"width":700,"height":90,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6","frame":65,"transform":{"x":484,"y":1167,"width":700,"height":90,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-7dd3bf14-1ea2-4cc6-85ca-f792d52dfd4c","frame":0,"value":-821,"easing":"linear"},{"id":"property-keyframe-0ecccca8-fc56-473f-8049-0c1e90c66c1f","frame":25,"value":-821,"easing":"linear"},{"id":"property-keyframe-229da1c0-a86a-4677-a85a-35dba8dcbe3e","frame":35,"value":484,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-b16715dd-4084-4ff3-b712-6c82ed149296","frame":0,"value":887,"easing":"linear"},{"id":"property-keyframe-4e39020f-9979-469d-8d77-cbbee9f75285","frame":45,"value":887,"easing":"linear"},{"id":"property-keyframe-3ba8b3e1-aa9c-49e0-9fc9-4023ce194fc3","frame":65,"value":1167,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b:width","frame":0,"value":700,"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151:width","frame":25,"value":700,"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e:width","frame":35,"value":700,"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b:width","frame":45,"value":700,"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6:width","frame":65,"value":700,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b:height","frame":0,"value":90,"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151:height","frame":25,"value":90,"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e:height","frame":35,"value":90,"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b:height","frame":45,"value":90,"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6:height","frame":65,"value":90,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-17eec31e-2ffe-4bdb-8f84-b4e000f0036b:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-847b27cd-b665-4c6a-8927-b7f11cb26151:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-4b1a41ee-8f18-4b19-bb61-0e580875a14e:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-d1a0b794-2b41-4304-bea8-e6b6fe3ea54b:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-86fd8e40-fdde-4703-be62-2107a675c6d6:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"strokeWidth":[{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d:strokeWidth:0","frame":0,"value":0,"easing":"linear"}],"blur":[{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[{"dataKey":"headline","targetProperty":"content"},{"dataKey":"breakingNews","targetProperty":"color","valueMap":{"false":"#001E4F","true":"#FFFFFF"}}],"clipParentId":null},{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea","isVisible":true,"blendMode":"normal","element":{"type":"text","content":"NETHERLANDS","color":"#ECECEC","strokeColor":"transparent","strokeWidth":0,"fontFamily":"Rubik, Arial, Helvetica, sans-serif","fontWeight":700,"textAlign":"left","lineHeight":1.2,"letterSpacing":0,"textTransform":"none","verticalAlign":"top","baselineShift":0,"minFontSize":24,"overflowPolicy":"clip","autoFit":"shrink-to-fit","fontSize":41},"effects":{"blur":0,"dropShadowEnabled":false,"dropShadowColor":"#000000","dropShadowOpacity":0.65,"dropShadowOffsetX":8,"dropShadowOffsetY":8,"dropShadowBlur":12},"keyframes":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2","frame":0,"transform":{"x":-458,"y":970,"width":380,"height":56,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45","frame":25,"transform":{"x":-458,"y":970,"width":380,"height":56,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b","frame":35,"transform":{"x":-458,"y":970,"width":380,"height":56,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376","frame":45,"transform":{"x":741,"y":970,"width":380,"height":56,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00","frame":65,"transform":{"x":741,"y":1250,"width":380,"height":56,"rotation":0,"opacity":1,"transformOriginX":0.5,"transformOriginY":0.5},"easing":"cubic-in"}],"animationTracks":{"x":[{"id":"property-keyframe-55426c57-e47a-4724-bc7e-586bfedf9b3a","frame":0,"value":-458,"easing":"linear"},{"id":"property-keyframe-54b83fd3-3619-47d0-8cb5-0257c16e4d18","frame":35,"value":-458,"easing":"linear"},{"id":"property-keyframe-3249ab5f-8fbd-4feb-9b2e-23074c16356b","frame":45,"value":741,"easing":"cubic-out"}],"y":[{"id":"property-keyframe-883146f0-4217-4cd7-b03e-2aa72095db43","frame":0,"value":970,"easing":"linear"},{"id":"property-keyframe-19b4f580-3cb2-446e-b6bf-ae85dc1f77b9","frame":45,"value":970,"easing":"linear"},{"id":"property-keyframe-1aeb4e58-e1b2-43fb-93ca-6e353bc3f091","frame":65,"value":1250,"easing":"cubic-in"}],"width":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2:width","frame":0,"value":380,"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45:width","frame":25,"value":380,"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b:width","frame":35,"value":380,"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376:width","frame":45,"value":380,"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00:width","frame":65,"value":380,"easing":"cubic-in"}],"height":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2:height","frame":0,"value":56,"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45:height","frame":25,"value":56,"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b:height","frame":35,"value":56,"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376:height","frame":45,"value":56,"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00:height","frame":65,"value":56,"easing":"cubic-in"}],"rotation":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2:rotation","frame":0,"value":0,"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45:rotation","frame":25,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b:rotation","frame":35,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376:rotation","frame":45,"value":0,"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00:rotation","frame":65,"value":0,"easing":"cubic-in"}],"opacity":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2:opacity","frame":0,"value":1,"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45:opacity","frame":25,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b:opacity","frame":35,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376:opacity","frame":45,"value":1,"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00:opacity","frame":65,"value":1,"easing":"cubic-in"}],"transformOriginX":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2:transformOriginX","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45:transformOriginX","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b:transformOriginX","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376:transformOriginX","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00:transformOriginX","frame":65,"value":0.5,"easing":"cubic-in"}],"transformOriginY":[{"id":"layer-keyframe-8705e4f7-765d-4b1d-bfcc-24a064222db2:transformOriginY","frame":0,"value":0.5,"easing":"ease-in-out"},{"id":"layer-keyframe-39377cbe-66cc-4764-952b-a0d06a7e1f45:transformOriginY","frame":25,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-e3963085-8fff-43d3-9835-5bb0ff7e323b:transformOriginY","frame":35,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-af0ea7e1-28d1-4b91-9483-74706d7b4376:transformOriginY","frame":45,"value":0.5,"easing":"cubic-out"},{"id":"layer-keyframe-43cef77e-cf4f-4a52-ac6d-0160124e0c00:transformOriginY","frame":65,"value":0.5,"easing":"cubic-in"}],"strokeWidth":[{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea:strokeWidth:0","frame":0,"value":0,"easing":"linear"}],"blur":[{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea:blur:0","frame":0,"value":0,"easing":"linear"}],"dropShadowOpacity":[{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea:dropShadowOpacity:0","frame":0,"value":0.65,"easing":"linear"}],"dropShadowOffsetX":[{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea:dropShadowOffsetX:0","frame":0,"value":8,"easing":"linear"}],"dropShadowOffsetY":[{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea:dropShadowOffsetY:0","frame":0,"value":8,"easing":"linear"}],"dropShadowBlur":[{"id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea:dropShadowBlur:0","frame":0,"value":12,"easing":"linear"}]},"loop":null,"bindings":[{"dataKey":"location","targetProperty":"content"},{"dataKey":"breakingNews","targetProperty":"color","valueMap":{"false":"#ECECEC","true":"#FFECEE"}}],"clipParentId":null}],"collections":[],"paintOrder":[{"type":"layer","id":"layer-81a41863-66dc-4a65-b464-9340838f60c6"},{"type":"layer","id":"layer-aabff7fd-c65e-4e27-9754-bba404c7871c"},{"type":"layer","id":"layer-c330787c-1504-4ef1-972b-723398b39044"},{"type":"layer","id":"layer-5dfd083b-6693-493b-b6b0-358e82e537d3"},{"type":"layer","id":"layer-268a518c-2ddb-492a-8d54-0355cb78f4d8"},{"type":"layer","id":"layer-f9ed4ef3-2fe6-4a7a-aefa-b130b4080c96"},{"type":"layer","id":"layer-9db21b40-d7fe-472c-8783-bf70b02982b4"},{"type":"layer","id":"layer-74a7f0c1-b3b9-422a-9e8b-20c939c09b4d"},{"type":"layer","id":"layer-40e06746-4629-46e2-b582-e1a7acf3e7ea"}],"keyframes":[{"id":"keyframe-7cfb174d-c23a-42d3-b7d8-3585e8c1f050","frame":0,"role":"start"},{"id":"keyframe-eded5a8b-b7ff-4342-89b7-ec72974479fc","frame":25,"role":"step"},{"id":"keyframe-de031bd7-84ee-434f-aa5f-f77b29f0aac6","frame":35,"role":"step"},{"id":"keyframe-9e0b48fd-16dd-4675-b2be-a51b03f720e7","frame":45,"role":"step"},{"id":"keyframe-ab215c53-c648-4241-96f7-16f90e4b7317","frame":65,"role":"end"}],"transitions":[{"fromKeyframeId":"keyframe-7cfb174d-c23a-42d3-b7d8-3585e8c1f050","toKeyframeId":"keyframe-eded5a8b-b7ff-4342-89b7-ec72974479fc","durationFrames":25,"easing":"cubic-out"},{"fromKeyframeId":"keyframe-eded5a8b-b7ff-4342-89b7-ec72974479fc","toKeyframeId":"keyframe-de031bd7-84ee-434f-aa5f-f77b29f0aac6","durationFrames":10,"easing":"cubic-out"},{"fromKeyframeId":"keyframe-de031bd7-84ee-434f-aa5f-f77b29f0aac6","toKeyframeId":"keyframe-9e0b48fd-16dd-4675-b2be-a51b03f720e7","durationFrames":10,"easing":"cubic-out"},{"fromKeyframeId":"keyframe-9e0b48fd-16dd-4675-b2be-a51b03f720e7","toKeyframeId":"keyframe-ab215c53-c648-4241-96f7-16f90e4b7317","durationFrames":20,"easing":"cubic-in"}],"stepKeyframeIds":["keyframe-eded5a8b-b7ff-4342-89b7-ec72974479fc","keyframe-de031bd7-84ee-434f-aa5f-f77b29f0aac6","keyframe-9e0b48fd-16dd-4675-b2be-a51b03f720e7"],"stepCount":3,"startKeyframeId":"keyframe-7cfb174d-c23a-42d3-b7d8-3585e8c1f050","endKeyframeId":"keyframe-ab215c53-c648-4241-96f7-16f90e4b7317","customActions":[]};
const exportedModuleBaseUrl = import.meta.url.startsWith('blob:') ? document.baseURI : import.meta.url;
for (const layer of exportedDescriptor.layers) {
  if (layer.element.type === 'image' && layer.element.src?.startsWith('assets/')) {
    layer.element.src = new URL(layer.element.src, exportedModuleBaseUrl).href;
  } else if (layer.element.type === 'image-sequence') {
    layer.element.frames = layer.element.frames.map((frame) =>
      frame.startsWith('assets/') ? new URL(frame, exportedModuleBaseUrl).href : frame
    );
  }
}
for (const font of exportedDescriptor.fonts ?? []) {
  if (font.source?.startsWith('assets/')) {
    font.source = new URL(font.source, exportedModuleBaseUrl).href;
  }
}
class ExportedGraphic extends GraphicElement {
  static descriptor = exportedDescriptor;
}
export default ExportedGraphic;
