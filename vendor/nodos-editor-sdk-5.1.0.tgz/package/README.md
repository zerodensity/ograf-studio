# Nodos Editor SDK for TypeScript

The Nodos Editor API for programs that work with a running Nodos engine as an editor, such as a graphics editor that
keeps templates set as node presets.

- `EditorConnection` connects to an engine (`localhost:50052` by default for Nodos), sends requests and matches each
  answer to its request, and passes on every message the engine sends.
- `TypeSchema` holds the engine's types, from the type schema it sends editors, and reads and writes pin values of any
  of them: structs and tables as objects, enum values by name, arrays as arrays, and a `nos.Dict` as an object of its
  entries. Without a schema it handles scalars, strings, `nos.Dict` and arrays of them.
- `nos` is the Editor API itself, generated from the engine's schemas. Each table has an object class, ending in `T`,
  that packs into a message.

```ts
import { EditorConnection, nos } from '@nodos/editor-sdk';

const nodos = new EditorConnection('localhost:50052', 'My Editor');
await nodos.connected;
const pin = new nos.fb.PinT();
pin.name = 'Tint';
pin.typeName = 'nos.fb.vec4';
pin.data = [...nodos.types.write('nos.fb.vec4', { x: 1, y: 0.5, z: 0, w: 1 })];
```

Its version is the Editor API's. Its source ships in a Nodos engine's `SDK/Editor/TypeScript` folder; there,
`npm install` and then `npm pack` build the package, as JavaScript with type declarations, into a `.tgz` that a project
installs with `npm install <path to the .tgz>`.
